#!/usr/bin/python3
"""Ümraniye Merkez Anadolu Lisesi 2.4.0 — offline board. GPL-3.0-or-later."""
import sys, os, json, math, copy, tempfile, uuid, shutil, time
import fitz
from PyQt5.QtCore import QProcess, Qt, QPoint, QPointF, QRect, QRectF, QSize, QTimer, QEvent, QStandardPaths, QLockFile, QVariantAnimation, QEasingCurve
from PyQt5.QtGui import QColor, QImage, QPainter, QPen, QKeySequence, QPolygonF, QPixmap, QIcon, QRegion
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QPushButton, QLabel, QScrollArea, QFileDialog, QMessageBox,
    QSpinBox, QSlider, QShortcut, QInputDialog, QComboBox, QGridLayout, QSizePolicy, QDialog, QCheckBox)

TAG = 'TahtaKalem/1'
TAG_FX = 'TahtaKalem/1-fx'   # extra look-only annotations (neon glow); rebuilt on every save
APP_NAME = 'Ümraniye Merkez Anadolu Lisesi'
BACKGROUNDS = [('Beyaz','white'),('Kareli','grid'),('Noktalı','dots'),('Koyu','dark'),('Yeşil tahta','green'),('Kara tahta','black')]
# Dark boards start with white ink.
DARK_BACKGROUNDS = ('dark','green','black')
LOGO = os.path.join(os.path.dirname(__file__),'okul-logo.jpeg')

def svg_path(d):
    """Tiny SVG path reader (M/m, c, l, z) for the drawn icons."""
    import re
    from PyQt5.QtGui import QPainterPath
    path = QPainterPath(); x = y = 0.0; cmd = None
    toks = re.findall(r'[MmCcLlZz]|-?\d*\.?\d+', d); i = 0
    while i < len(toks):
        t = toks[i]
        if t in 'MmCcLlZz': cmd = t; i += 1
        if cmd in 'Zz': path.closeSubpath(); continue
        n = [float(v) for v in toks[i:i+(6 if cmd in 'Cc' else 2)]]; i += len(n)
        if cmd == 'M': x, y = n; path.moveTo(x, y); cmd = 'L'
        elif cmd == 'm': x, y = x+n[0], y+n[1]; path.moveTo(x, y); cmd = 'l'
        elif cmd == 'l': x, y = x+n[0], y+n[1]; path.lineTo(x, y)
        elif cmd == 'L': x, y = n; path.lineTo(x, y)
        elif cmd == 'c': path.cubicTo(x+n[0], y+n[1], x+n[2], y+n[3], x+n[4], y+n[5]); x, y = x+n[4], y+n[5]
        elif cmd == 'C': path.cubicTo(*n); x, y = n[4], n[5]
    return path

def havuz_icon(height=24):
    """PDF Havuzu: a flying pigeon carrying a PDF letter in its beak."""
    from PyQt5.QtGui import QFont
    k = 4; w, h = 120, 96
    pix = QPixmap(w*k, h*k); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing); p.scale(k, k); p.setPen(Qt.NoPen)
    p.setBrush(QColor('#edf4ff')); p.drawPath(svg_path('M14 54c10-2 20 0 28 6 6-14 18-22 32-22-6 6-10 12-12 20 10-2 18 0 24 6-14 4-30 6-44 4-10 6-22 6-28-2 0 0-4-8 0-12z'))
    p.setBrush(QColor('#b9d4f3')); p.drawPath(svg_path('M44 58c-8-14-6-28 4-40 6 12 8 26 4 38z'))
    p.setBrush(QColor('#dbe8f8')); p.drawPath(svg_path('M58 42c4-14 14-24 28-28-2 14-10 26-24 32z'))
    p.setBrush(QColor('#122034')); p.drawEllipse(QPointF(82, 58), 2.4, 2.4)
    p.setBrush(QColor('#ffb02e')); p.drawPolygon(QPolygonF([QPointF(88, 60), QPointF(95, 62), QPointF(88, 65)]))
    p.save(); p.translate(104, 70); p.rotate(10); p.translate(-104, -70)
    p.setBrush(QColor('#fff8e6')); p.setPen(QPen(QColor('#c9a96b'), 1.4)); p.drawRoundedRect(QRectF(92, 60, 24, 17), 2, 2)
    p.drawPolyline(QPolygonF([QPointF(92, 60), QPointF(104, 69), QPointF(116, 60)]))
    p.setPen(Qt.NoPen); p.setBrush(QColor('#e23b4d')); p.drawRoundedRect(QRectF(96, 70, 16, 6), 1, 1)
    f = QFont('DejaVu Sans'); f.setPixelSize(5); f.setBold(True); p.setFont(f); p.setPen(QColor('white'))
    p.drawText(QRectF(96, 70, 16, 6), Qt.AlignCenter, 'PDF'); p.restore(); p.end()
    pix = pix.copy(QRect(8*k, 12*k, 112*k, 72*k))   # trim empty margins so the bird fills the button
    return QIcon(pix.scaledToHeight(height*2, Qt.SmoothTransformation))

UI_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts')
_FONTS = {}
def ui_fonts():
    """Pakette gelen yazı tipleri (bir kez yüklenir): Poppins arayüz yazısı, Phosphor ikonları."""
    if not _FONTS and QApplication.instance() is not None:
        from PyQt5.QtGui import QFontDatabase
        for name in ('Poppins-Regular', 'Poppins-Medium', 'Poppins-Bold', 'Phosphor-Fill'):
            path = os.path.join(UI_FONT_DIR, name + '.ttf'); fam = None
            if os.path.isfile(path):
                i = QFontDatabase.addApplicationFont(path)
                fams = QFontDatabase.applicationFontFamilies(i) if i >= 0 else []
                fam = fams[0] if fams else None
            _FONTS[name] = fam
    return _FONTS

# Premium ikonlar (C: cam efektli renkli daire, beyaz dolu Phosphor ikonu). Phosphor: MIT lisansı.
# Renk araç türünü söyler: yazı mavi, silme pembe, düzen mor, sunum turuncu, kayıt kırmızı.
PREMIUM_ICONS = {
    'Kalem': (0xe3b4, '#2f7cf6'), 'Taşı': (0xe298, '#64748b'), 'Çözüm alanı': (0xe296, '#0ea5a4'), 'Alan seç': (0xe69a, '#0ea5a4'),
    'Fosforlu': (0xe632, '#eab308'), 'Silgi': (0xe21e, '#ec4899'), 'Alan silgisi': (0xe69e, '#db2777'), 'Tümünü sil': (0xe4a6, '#ef4444'),
    'Seçimi kaldır': (0xe69e, '#94a3b8'), 'Akıllı seçim': (0xe69c, '#6366f1'), 'Şekiller': (0xec5e, '#8b5cf6'),
    'Çizgi': (0xe6d2, '#8b5cf6'), 'Ok': (0xe092, '#8b5cf6'), 'Dikdörtgen': (0xe3f0, '#8b5cf6'), 'Elips': (0xe18a, '#8b5cf6'), 'Kesikli çizgi': (0xe6d4, '#8b5cf6'),
    'Post-it': (0xe348, '#f59e0b'), 'Perde': (0xeb16, '#f97316'), 'Spot ışığı': (0xe246, '#fb923c'), 'Alkış': (0xe81a, '#d946ef'),
    'Geri al': (0xe038, '#64748b'), 'İleri al': (0xe036, '#64748b'), 'Ekrana yaz': (0xe654, '#06b6d4'), 'PDF kaydet': (0xe248, '#ef4444'),
    'Günün soruları': (0xe2f6, '#22c55e'), 'Araçlar': (0xe464, '#6366f1'), 'Ayarlar': (0xe272, '#94a3b8'), 'Tam ekran': (0xe0a2, '#64748b'),
    'Sayaç': (0xe492, '#f97316'), 'Hesap makinesi': (0xe538, '#0ea5e9'), 'PDF aç': (0xe702, '#ef4444'), 'Yeni tahta': (0xe236, '#2f7cf6'),
    'Tema': (0xe6c8, '#d946ef'), 'Gizle': (0xe224, '#64748b'), 'Tahtaya dön': (0xe08a, '#2f7cf6'), "PDF'ye yaz": (0xe34c, '#2f7cf6'),
    'Akıcı': (0xe3ac, '#2f7cf6'), 'Neon': (0xe6a2, '#d946ef'),
    'Grafik çizici': (0xe154, '#2f7cf6'), 'Şablonlar': (0xec8c, '#0ea5a4'), 'Cetvel': (0xe6b8, '#eab308'), 'Pergel': (0xea0e, '#8b5cf6'),
    'Üçgen': (0xe4b0, '#8b5cf6'), 'Ölçülü üçgen': (0xe4b0, '#7c3aed'),
    'Notları PDF kaydet': (0xe248, '#ef4444'), 'Masaüstünü kullan': (0xe560, '#06b6d4'),
    'Sayfaya git': (0xe2a2, '#64748b'), 'Sığdır': (0xe626, '#64748b'), 'Önceki': (0xe138, '#64748b'), 'Sonraki': (0xe13a, '#64748b'),
}
_ICONS = {}
def _drop_icons():   # ikon önbelleği Qt kapanmadan boşaltılır (kapanışta çökmesin)
    _ICONS.clear()
import atexit; atexit.register(_drop_icons)
def premium_icon(label, size=64):
    app = QApplication.instance()
    if app is not None and not getattr(app, '_umal_icons_hook', False):
        app.aboutToQuit.connect(_drop_icons); app._umal_icons_hook = True
    g = PREMIUM_ICONS.get(label)
    fam = ui_fonts().get('Phosphor-Fill') if g else None
    if not g or not fam: return None
    if label in _ICONS: return _ICONS[label]
    from PyQt5.QtGui import QFont, QLinearGradient, QRadialGradient
    code, color = g; pix = QPixmap(size, size); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
    r = QRectF(2, 2, size-4, size-4); base = QColor(color)
    grad = QLinearGradient(r.topLeft(), r.bottomLeft()); grad.setColorAt(0, base.lighter(128)); grad.setColorAt(1, base.darker(118))
    p.setPen(QPen(QColor(255, 255, 255, 95), size*.035)); p.setBrush(grad); p.drawEllipse(r)
    gloss = QRadialGradient(QPointF(size*.34, size*.24), size*.5); gloss.setColorAt(0, QColor(255, 255, 255, 150)); gloss.setColorAt(.55, QColor(255, 255, 255, 25)); gloss.setColorAt(1, QColor(255, 255, 255, 0))
    p.setPen(Qt.NoPen); p.setBrush(gloss); p.drawEllipse(r)
    f = QFont(fam); f.setPixelSize(int(size*.5)); p.setFont(f); p.setPen(QColor(0, 0, 0, 55)); p.drawText(r.translated(0, size*.025), Qt.AlignCenter, chr(code))
    p.setPen(QColor('#ffffff')); p.drawText(r, Qt.AlignCenter, chr(code)); p.end()
    _ICONS[label] = QIcon(pix); return _ICONS[label]

def glyph_style(code, px, extra=''):
    """Düğmede ikon fontundan tek işaret (ok, artı, eksi): yeni ikonlarla aynı aileden."""
    fam = ui_fonts().get('Phosphor-Fill')
    return (chr(code), ('font-family:"%s";font-size:%dpx;font-weight:normal;' % (fam, px) if fam else 'font-size:%dpx;' % px) + extra)

def tool_icon(label, ink='#edf4ff'):
    """Small high-contrast vector-style UI glyphs; no external icon dependency."""
    ic = premium_icon(label)
    if ic is not None: return ic
    pix=QPixmap(32,32);pix.fill(Qt.transparent)
    p=QPainter(pix);p.setRenderHint(QPainter.Antialiasing)
    p.setPen(QPen(QColor(ink),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
    def line(a,b):p.drawLine(QPointF(*a),QPointF(*b))
    def poly(pts):p.drawPolyline(QPolygonF([QPointF(*pt) for pt in pts]))
    if label=='Kalem':
        poly([(5,26),(8,17),(23,3),(29,9),(14,24),(5,26)])
        line((8,17),(14,24));line((21,6),(26,11))
    elif label=='Fosforlu':
        p.setPen(QPen(QColor('#ffdf56'),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        poly([(9,19),(20,5),(28,12),(17,25),(9,19)])
        p.setBrush(QColor('#ffdf56'));p.drawPolygon(QPolygonF([QPointF(9,19),QPointF(17,25),QPointF(11,28),QPointF(5,24)]))
        line((3,30),(27,30))
    elif label=='Silgi':
        poly([(4,20),(17,5),(29,16),(17,28),(12,28),(4,20)])
        line((10,13),(23,23));line((17,28),(29,28))
    elif label=='Post-it':
        p.setBrush(QColor('#ffe27a'));p.setPen(QPen(QColor('#ffe27a'),1.5));p.drawPolygon(QPolygonF([QPointF(5,6),QPointF(27,6),QPointF(27,20),QPointF(20,27),QPointF(5,27)]))
        p.setPen(QPen(QColor('#122034'),1.6));line((9,12),(23,12));line((9,17),(20,17));p.setBrush(QColor('#d9a400'));p.drawPolygon(QPolygonF([QPointF(20,27),QPointF(20,20),QPointF(27,20)]))
    elif label in ('Neon kalem','Neon'):
        glow=QColor(ink);glow.setAlpha(90);p.setPen(QPen(glow,6,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        pts=[(4,22),(10,10),(16,22),(22,10),(28,22)];poly(pts)
        p.setPen(QPen(QColor(ink),2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));poly(pts)
    elif label=='Alan silgisi':
        p.setPen(QPen(QColor(ink),1.8,Qt.DashLine));p.drawEllipse(QRectF(2,2,28,28))
        p.setPen(QPen(QColor(ink),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        poly([(8,19),(17,9),(25,17),(17,25),(13,25),(8,19)]);line((12,14),(20,22))
    elif label in ('Alan seç','Akıllı seçim','Çözüm alanı','Seçimi kaldır'):
        p.setPen(QPen(QColor('#edf4ff'),2,Qt.DashLine));p.drawRect(QRectF(5,5,22,22))
        if label=='Seçimi kaldır':line((10,10),(22,22));line((22,10),(10,22))
    elif label=='Taşı':   # open hand ✋
        from PyQt5.QtGui import QPainterPath, QTransform
        hand=QPainterPath();hand.setFillRule(Qt.WindingFill)
        for x,top in ((9,6),(13.5,3),(18,4),(22.5,7.5)):hand.addRoundedRect(QRectF(x-2,top,4,16),2,2)
        hand.addRoundedRect(QRectF(7,14,17.5,15),5,5)
        t=QPainterPath();t.addRoundedRect(QRectF(-2,-10,4,12),2,2);hand.addPath(QTransform().translate(8,21).rotate(-50).map(t))
        p.setBrush(QColor(ink));p.setPen(Qt.NoPen);p.drawPath(hand.simplified())
    elif label=='Dikdörtgen':p.drawRect(QRectF(4,7,24,18))
    elif label=='Elips':p.drawEllipse(QRectF(4,7,24,18))
    elif label=='Çizgi':line((5,27),(27,5))
    elif label=='Ok':line((5,27),(27,5));poly([(15,5),(27,5),(27,17)])
    elif label=='Şekiller':
        p.drawRect(QRectF(4,4,12,10));p.drawEllipse(QRectF(16,15,13,13));line((4,28),(14,18))
    elif label=='Kesikli çizgi':
        for a in range(4):line((3+a*7.5,27-a*7.5),(7.5+a*7.5,22.5-a*7.5))
    elif label in ('Geri al','Yinele','İleri al'):
        if label!='Geri al':p.translate(32,0);p.scale(-1,1)
        poly([(11,6),(4,13),(11,20)]);poly([(4,13),(20,13),(26,18),(26,24)])
    elif label in ('PDF kaydet','Notları PDF kaydet'):
        poly([(5,4),(23,4),(28,9),(28,28),(5,28),(5,4)])
        p.drawRect(QRectF(10,4,11,9));p.drawRect(QRectF(10,20,13,8))
    elif label in ('Ekrana yaz','Masaüstünü kullan','Yazmaya dön'):
        p.drawRoundedRect(QRectF(3,4,26,19),2,2);line((16,23),(16,28));line((10,28),(22,28))
        line((10,18),(23,8))
    elif label in ('Yeni tahta','PDF aç','Tahtaya dön',"PDF'ye yaz"):
        p.drawRoundedRect(QRectF(5,3,22,26),2,2)
        if label=='Yeni tahta':line((16,10),(16,23));line((10,16),(22,16))
        elif label=='PDF aç':line((10,11),(22,11));line((10,17),(22,17));line((10,23),(18,23))
        elif label=="PDF'ye yaz":line((10,11),(19,11));line((10,16),(16,16));poly([(13,25),(14,21),(24,11),(27,14),(17,24),(13,25)])
        else:poly([(15,10),(9,16),(15,22)]);line((9,16),(23,16))
    elif label in ('Temizle','Notları temizle','Tümünü sil'):
        poly([(8,10),(10,28),(23,28),(25,10)]);line((5,7),(28,7));line((12,3),(21,3))
    elif label=='Tema':
        p.drawEllipse(QRectF(4,4,24,24));p.setBrush(QColor('#edf4ff'))
        for x,y in ((11,11),(20,10),(23,18)):p.drawEllipse(QPointF(x,y),2.2,2.2)
        p.setBrush(Qt.NoBrush)
    elif label=='Hesap makinesi':
        p.drawRoundedRect(QRectF(6,3,20,26),3,3);p.drawRect(QRectF(10,7,12,5))
        for x in (11,16,21):
            for y in (17,23):p.drawPoint(QPointF(x,y))
    elif label=='Sayaç':
        p.drawEllipse(QRectF(5,7,22,22));line((16,18),(16,12));line((16,18),(20,21));line((13,3),(19,3));line((16,3),(16,7))
    elif label=='Gizle':   # eye, struck through
        path=QPolygonF([QPointF(3+i*1.0,16-9*math.sin(math.pi*i/26)) for i in range(27)]+[QPointF(29-i*1.0,16+9*math.sin(math.pi*i/26)) for i in range(27)])
        p.drawPolygon(path);p.drawEllipse(QPointF(16,16),4,4);line((6,27),(26,5))
    elif label=='Perde':   # curtain pulled half way, with its handle
        p.setBrush(QColor(ink));p.setPen(Qt.NoPen);p.drawRoundedRect(QRectF(4,15,24,13),2,2)
        p.setBrush(Qt.NoBrush);p.setPen(QPen(QColor(ink),2));p.drawRoundedRect(QRectF(4,4,24,24),3,3);line((12,12),(20,12))
    elif label=='Spot ışığı':   # dark field, one bright circle
        p.setBrush(QColor(ink));p.setPen(Qt.NoPen);p.drawRoundedRect(QRectF(3,3,26,26),4,4)
        p.setBrush(QColor('#ffe14d'));p.drawEllipse(QPointF(18,14),7,7)
    elif label=='Araçlar':   # 2×2 tiles
        for x,y in ((5,5),(18,5),(5,18),(18,18)):p.drawRoundedRect(QRectF(x,y,9,9),2,2)
    elif label=='PDF Havuzu':   # two stacked pages and a down arrow
        p.drawRoundedRect(QRectF(9,3,17,21),2,2);p.setBrush(QColor('#16253a'));p.drawRoundedRect(QRectF(5,8,17,21),2,2);p.setBrush(Qt.NoBrush)
        line((13.5,13),(13.5,24));poly([(9.5,20),(13.5,24),(17.5,20)])
    elif label=='Ayarlar':   # gear
        p.setBrush(Qt.NoBrush)
        for k in range(8):
            a=math.radians(k*45);line((16+9*math.cos(a),16+9*math.sin(a)),(16+13*math.cos(a),16+13*math.sin(a)))
        p.setPen(QPen(QColor(ink),2.6));p.drawEllipse(QPointF(16,16),9,9);p.setPen(QPen(QColor(ink),2.2));p.drawEllipse(QPointF(16,16),3.5,3.5)
    elif label=='Günün soruları':   # page with a numbered list
        p.drawRoundedRect(QRectF(6,3,20,26),3,3)
        for k,y in enumerate((10,16,22)):
            p.drawPoint(QPointF(11,y));line((15,y),(22 if k!=1 else 20,y))
    elif label=='Alkış':   # party popper: cone and bursts
        poly([(5,28),(11,12),(21,22),(5,28)])
        for a,b_ in (((15,9),(17,4)),((20,13),(26,9)),((23,18),(28,19))):line(a,b_)
        p.drawPoint(QPointF(24,5));p.drawPoint(QPointF(28,13));p.drawPoint(QPointF(19,4))
    elif label=='Tam ekran':
        for pts in [[(4,12),(4,4),(12,4)],[(20,4),(28,4),(28,12)],[(4,20),(4,28),(12,28)],[(20,28),(28,28),(28,20)]]:poly(pts)
    else:
        p.end();return QIcon()
    p.end();return QIcon(pix)

COLOR_TOOLS = ('pen','highlight','line','arrow','rect','circle','dash','laser')
SHAPE_TOOLS = ('line','arrow','rect','circle','triangle','dash')   # grouped under the Şekiller button
DASH_PATTERN = (2, 3)   # in pen widths; with round caps: dash 3w, gap 2w

def stroke_pen(s, offset=0):
    pen = QPen(QColor(s['color']), s['width'], Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    if s.get('dash'):
        pen.setDashPattern(list(DASH_PATTERN)); pen.setDashOffset(offset / max(s['width'], .1))
    return pen

PEN_STYLES = (('fluid','Akıcı'),('laser','Neon (söner)'))
# Only these two tips are offered; writing made earlier with Normal, Tebeşir,
# Keçeli, Kurşun kalem or Neon still draws exactly as before.
# 'laser' in the tips row is the Neon kalem tool (glows, then fades; not saved).
# Tebeşir was removed from the row; old chalk writing still draws as before.
STYLE_SPAN = {'fluid':1, 'felt':1.7, 'chalk':1.6, 'pencil':1, 'neon':5.5, 'laser':8}   # drawn width ÷ pen width
STYLED_TOOLS = ('pen','line','rect','circle','laser')   # snapped shapes keep the style

def fluid_outline(s):
    """Akıcı kalem: outline of a stroke whose width follows the stored
    per-point factors (speed + tapered ends), as one polygon."""
    pts, ws, half = s['points'], s['w'], s['width']/2
    if len(pts) < 2: return None
    left, right = [], []
    for i, (x, y) in enumerate(pts):
        a, b = pts[max(0, i-1)], pts[min(len(pts)-1, i+1)]
        dx, dy = b[0]-a[0], b[1]-a[1]; d = math.hypot(dx, dy)
        nx, ny = (-dy/d, dx/d) if d > 1e-6 else (0, 1)
        r = max(.25, half*ws[i]); left.append([x+nx*r, y+ny*r]); right.append([x-nx*r, y-ny*r])
    return left+right[::-1]

def mix_color(c, other, t):
    c, o = QColor(c), QColor(other)
    return QColor.fromRgbF(c.redF()+(o.redF()-c.redF())*t, c.greenF()+(o.greenF()-c.greenF())*t, c.blueF()+(o.blueF()-c.blueF())*t)

_masks = {}
def style_mask(kind):
    """Soft grain (alpha only) laid over a whole chalk / pencil stroke at once.
    Coarse blotches + fine speckle, so it reads as chalk dust or graphite
    on the board instead of hard pixel noise."""
    if kind not in _masks:
        import random
        rng = random.Random(7 if kind == 'chalk' else 23); N = 128
        def noise(n):
            img = QImage(n, n, QImage.Format_Grayscale8)
            for y in range(n):
                for x in range(n): img.setPixel(x, y, QColor.fromHsv(0, 0, rng.randrange(256)).rgb())
            return img
        def tile(img):   # 3×3 tiling before smoothing keeps the edges seamless
            big = QImage(img.width()*3, img.height()*3, QImage.Format_Grayscale8); p = QPainter(big)
            for i in range(3):
                for j in range(3): p.drawImage(i*img.width(), j*img.height(), img)
            p.end(); s = big.scaled(N*3, N*3, Qt.IgnoreAspectRatio, Qt.SmoothTransformation); return s.copy(N, N, N, N)
        coarse = tile(noise(N//8)); mid = tile(noise(N//3)); fine = noise(N)
        out = QImage(N, N, QImage.Format_ARGB32_Premultiplied)
        for y in range(N):
            for x in range(N):
                c, m, f = QColor(coarse.pixel(x, y)).red()/255, QColor(mid.pixel(x, y)).red()/255, QColor(fine.pixel(x, y)).red()/255
                if kind == 'chalk': a = .9*c + .6*m + .55*f - .28
                else: a = .62 + .18*m + .28*f
                a = max(0., min(1., a)); out.setPixel(x, y, QColor(255, 255, 255, int(a*255)).rgba())
        _masks[kind] = QPixmap.fromImage(out)
    return _masks[kind]

def style_passes(s):
    """How a styled stroke is painted: a list of (pen, opacity, mask) passes.
    Each pass is drawn solid on its own layer and only then made see-through
    or grainy, so overlapping pieces never darken or speckle."""
    st = s.get('style'); w = s['width']; c = QColor(s['color'])
    if s['tool'] not in STYLED_TOOLS or st not in STYLE_SPAN or st == 'fluid': return None
    pen = lambda col, k: QPen(QColor(col), max(.6, w*k), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    if st == 'felt': return [(pen(c, 1.7), 1, None)]
    if st == 'chalk': return [(pen(mix_color(c, '#ffffff', .12), 1.6), .95, 'chalk')]
    if st == 'pencil': return [(pen(mix_color(c, '#4a4f57', .35), .85), 1, 'pencil')]
    if st == 'laser':   # Neon kalem: geniş ışıma + beyaz-sıcak çekirdek
        return [(pen(c, 8), .07, None), (pen(c, 5.5), .12, None), (pen(c, 3.4), .28, None), (pen(c, 1.8), .9, None),
                (pen(mix_color(c, '#ffffff', .8), .65), 1, None)]
    return [(pen(c, 5.5), .16, None), (pen(c, 3), .42, None), (pen('#ffffff', .7), 1, None), (pen(c, .35), .95, None)]

def arrow_points(a, b, width):
    """Ok: the shaft and both head strokes as one polyline (a plain 'line'
    stroke, so drawing, erasing, saving and the PDF work unchanged)."""
    d = math.hypot(b[0]-a[0], b[1]-a[1])
    if d < 3: return [a, b]
    ux, uy = (b[0]-a[0])/d, (b[1]-a[1])/d; L = min(d*.45, max(12, width*4.5)); s, c = math.sin(math.radians(28)), math.cos(math.radians(28))
    h1 = [b[0]-L*(ux*c-uy*s), b[1]-L*(uy*c+ux*s)]; h2 = [b[0]-L*(ux*c+uy*s), b[1]-L*(uy*c-ux*s)]
    return [a, b, h1, b, h2]

def stroke_path(pts):
    from PyQt5.QtGui import QPainterPath
    path = QPainterPath(QPointF(*pts[0]))
    for pt in pts[1:]: path.lineTo(QPointF(*pt))
    if len(pts) == 1: path.lineTo(QPointF(pts[0][0]+.01, pts[0][1]))
    return path

def apply_mask(q, kind, r):
    """Cut the grain into a layer; q is set up in widget pixels (r = area)."""
    from PyQt5.QtGui import QBrush
    q.save(); q.resetTransform(); q.translate(-r.x(), -r.y())
    q.setCompositionMode(QPainter.CompositionMode_DestinationIn); q.fillRect(QRectF(r), QBrush(style_mask(kind))); q.restore()

def paint_passes(p, path, passes, clip, dpr=1):
    """Finished styled stroke: every pass on a small clear layer, then laid
    over the page — the same result as while it was being written."""
    t = p.transform()
    for pen, opacity, mask in passes:
        if opacity >= 1 and not mask:   # plain opaque pass: straight onto the page
            p.setPen(pen); p.drawPath(path); continue
        pad = pen.widthF()/2 + 2
        r = (t.mapRect(path.boundingRect().adjusted(-pad, -pad, pad, pad)) & clip).toAlignedRect()
        if r.isEmpty(): continue
        img = QImage(max(1, int(r.width()*dpr)), max(1, int(r.height()*dpr)), QImage.Format_ARGB32_Premultiplied)
        img.setDevicePixelRatio(dpr); img.fill(Qt.transparent)
        q = QPainter(img); q.setRenderHint(QPainter.Antialiasing)
        q.translate(-r.x(), -r.y()); q.setTransform(t, True); q.setPen(pen); q.drawPath(path)
        if mask: apply_mask(q, mask, r)
        q.end()
        p.save(); p.resetTransform(); p.setOpacity(p.opacity()*opacity); p.drawImage(QRectF(r), img); p.restore()

def style_icon(key, size=26, ink='#ffffff'):
    pix = QPixmap(size*2, size*2); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing); p.scale(2, 2)
    s = dict(tool='pen', color=ink, width=size/10 if key != 'neon' else size/14,
             points=[[size*.16+i*size*.68/20, size*.5+math.sin(i/20*2*math.pi)*size*.2] for i in range(21)])
    if key != 'normal': s['style'] = key
    if key == 'fluid': s['width'] = size/8
    passes = style_passes(s); path = stroke_path(s['points'])
    if passes: paint_passes(p, path, passes, QRectF(0, 0, size*2, size*2))
    elif s.get('w'):
        p.setPen(Qt.NoPen); p.setBrush(QColor(ink)); p.drawPolygon(QPolygonF([QPointF(*q) for q in fluid_outline(s)]), Qt.WindingFill)
    else: p.setPen(stroke_pen(s)); p.drawPath(path)
    p.end(); return QIcon(pix)

def paint_tool_buttons(buttons, labels, tool, color):
    """The selected drawing tool's button takes the current ink colour, so
    the chosen colour is always visible on the tool itself."""
    q = QColor(color); light = .299*q.redF()+.587*q.greenF()+.114*q.blueF() > .6
    ink = '#122034' if light else '#ffffff'
    for key, b in buttons.items():
        if key == tool and key in COLOR_TOOLS:
            b.setStyleSheet('QPushButton:checked{background:%s;color:%s;border:3px solid #ffffff;}' % (color, ink))
            b.setIcon(tool_icon(labels[key], ink))
        else:
            b.setStyleSheet(''); b.setIcon(tool_icon(labels[key]))

BOARD_FILLS = {'dark': (.025,.065,.13), 'green': (.13,.30,.22), 'black': (.07,.07,.08)}
def make_board(background='white', width=960, height=540):
    doc = fitz.open(); page = doc.new_page(width=width,height=height)
    if background in BOARD_FILLS:
        page.draw_rect(page.rect,color=None,fill=BOARD_FILLS[background])
    elif background == 'grid':
        shape = page.new_shape()
        for x in range(0,int(width)+1,24): shape.draw_line((x,0),(x,height))
        for y in range(0,int(height)+1,24): shape.draw_line((0,y),(width,y))
        shape.finish(color=(.55,.64,.76),width=.9); shape.commit()
    elif background == 'dots':
        shape = page.new_shape()
        for x in range(24,int(width),24):
            for y in range(24,int(height),24): shape.draw_circle((x,y),1.6)
        shape.finish(color=None,fill=(.40,.50,.64)); shape.commit()
    doc.set_metadata({'title':APP_NAME,'keywords':'UMAL-board:'+background})
    return doc

def nib_outline(stroke):
    """Same directional nib geometry for the screen and vector PDF export."""
    if stroke.get('w') and len(stroke['w']) == len(stroke['points']): return fluid_outline(stroke)
    if stroke['tool'] != 'pen' or stroke.get('nib') not in ('fountain','marker'): return None
    pts = stroke['points']; width = stroke['width']; nib = stroke['nib']
    if len(pts) == 1 or all(math.dist(pts[0],p)<.01 for p in pts):
        x,y = pts[0]; radius = width*(1 if nib=='marker' else .55)
        return [[x+radius*math.cos(i*math.pi/12),y+radius*math.sin(i*math.pi/12)] for i in range(24)]
    left,right = [],[]
    distances = [0.0]
    for a,b in zip(pts,pts[1:]): distances.append(distances[-1]+math.dist(a,b))
    for i,(x,y) in enumerate(pts):
        a,b = pts[max(0,i-2)],pts[min(len(pts)-1,i+2)]
        dx,dy = b[0]-a[0],b[1]-a[1]; length = math.hypot(dx,dy)
        nx,ny = (-dy/length,dx/length) if length>.0001 else (0,1)
        angle = abs((nx+ny)*.70710678)
        if nib == 'fountain':
            taper = .35+.65*min(1,distances[i]/max(width*2,1),(distances[-1]-distances[i])/max(width*2,1))
            half = width*(.22+.65*angle)*taper
        else: half = width*(.65+.55*angle)
        left.append([x+nx*half,y+ny*half]); right.append([x-nx*half,y-ny*half])
    return left+right[::-1]

def catmull_rom(p0, p1, p2, p3, steps):
    """Centripetal Catmull–Rom from p1 to p2 (p1 excluded, p2 included).
    It passes through the pen samples themselves, so small loops and letter
    joins keep their size, and the centripetal form makes no cusps or loops
    at sharp turns."""
    def knot(t, a, b):
        return t + max(1e-6, math.hypot(b[0]-a[0], b[1]-a[1])) ** .5
    t0 = 0.0; t1 = knot(t0, p0, p1); t2 = knot(t1, p1, p2); t3 = knot(t2, p2, p3)
    out = []
    for k in range(1, steps+1):
        t = t1 + (t2-t1)*k/steps
        def lerp(a, b, ta, tb): u = (t-ta)/(tb-ta); return (a[0]+(b[0]-a[0])*u, a[1]+(b[1]-a[1])*u)
        a1 = lerp(p0, p1, t0, t1); a2 = lerp(p1, p2, t1, t2); a3 = lerp(p2, p3, t2, t3)
        b1 = lerp(a1, a2, t0, t2); b2 = lerp(a2, a3, t1, t3)
        c = lerp(b1, b2, t1, t2); out.append([c[0], c[1]])
    out[-1] = list(p2)
    return out

def cr_steps(a, b, scale):
    return max(2, min(24, int(math.hypot(b[0]-a[0], b[1]-a[1])*scale/1.5)+1))

def cr_points(raw, scale):
    """Whole-stroke reference of Board.smooth_append() for Akıcı (tests)."""
    if len(raw) < 3: return [list(p) for p in raw]
    pts = [list(raw[0])]
    for n in range(3, len(raw)+1):
        p0 = raw[n-4] if n >= 4 else raw[n-3]
        pts.extend(catmull_rom(p0, raw[n-3], raw[n-2], raw[n-1], cr_steps(raw[n-3], raw[n-2], scale)))
    pts.append(list(raw[-1])); return pts

def smooth_points(raw):
    """Quadratic midpoint interpolation suppresses jitter without sharp corners."""
    if len(raw) < 3: return list(raw)
    result = [raw[0]]
    start = raw[0]
    for i in range(1,len(raw)-1):
        control = raw[i]
        end = [(raw[i][j]+raw[i+1][j])/2 for j in (0,1)]
        steps = max(2,min(16,int(math.hypot(end[0]-start[0],end[1]-start[1])/1.2)+1))
        for k in range(1,steps+1):
            t = k/steps
            result.append([(1-t)**2*start[j]+2*(1-t)*t*control[j]+t*t*end[j] for j in (0,1)])
        start = end
    result.append(raw[-1])
    return result

def export_document(doc, marks, target, solutions=None):
    """Write atomically; keep original PDF and its existing annotations intact."""
    out = fitz.open(stream=doc.tobytes(), filetype='pdf')
    try:
        if solutions is not None:
            if SOLUTIONS_FILE in out.embfile_names(): out.embfile_del(SOLUTIONS_FILE)
            if solutions:
                data = {k: dict(v, marks={str(p): m for p, m in v['marks'].items()}) for k, v in solutions.items()}
                out.embfile_add(SOLUTIONS_FILE, json.dumps(data, ensure_ascii=False).encode('utf-8'),
                                desc='Ümraniye Merkez Anadolu Lisesi soru çözümleri')
        for n, strokes in marks.items():
            page = out[n]
            for s in strokes:
                if s['tool'] == 'geo':   # koordinat düzlemi: görünmez taşıyıcı + çizimin kendisi
                    a = page.add_ink_annot([[(1, 1), (1.01, 1.01)]]); a.set_opacity(0); a.set_info(title=TAG, content=json.dumps(s)); a.update()
                    try:
                        for sub_ in geo_strokes(s, page.rect.width, page.rect.height):
                            g = page.add_ink_annot([[tuple(q) for q in sub_['points']]]); c_ = QColor(sub_['color'])
                            g.set_colors(stroke=(c_.redF(), c_.greenF(), c_.blueF())); g.set_border(width=sub_['width']); g.set_info(title=TAG_FX); g.update()
                    except Exception: pass
                    continue
                outline = nib_outline(s)
                if outline:
                    points = [fitz.Point(*pt)*page.derotation_matrix for pt in outline]
                    a = page.add_polygon_annot([(pt.x,pt.y) for pt in points])
                    c = QColor(s['color']); rgb = (c.redF(),c.greenF(),c.blueF())
                    a.set_colors(stroke=rgb,fill=rgb); a.set_border(width=0)
                    a.set_info(title=TAG,content=json.dumps(s)); a.update()
                    continue
                if s['tool'] == 'whiteout':
                    rect = fitz.Rect(*s['points'][0], *s['points'][1]) * page.derotation_matrix
                    a = page.add_rect_annot(rect)
                    a.set_colors(stroke=(1,1,1), fill=(1,1,1))
                    a.set_border(width=0)
                    a.set_info(title=TAG, content=json.dumps(s))
                    a.update()
                    continue
                pts = [fitz.Point(*p) * page.derotation_matrix for p in s['points']]
                if len(pts) == 1:
                    pts.append(pts[0] + fitz.Point(.01, .01))
                ink = [[(p.x,p.y) for p in pts]]
                c = QColor(s['color']); width = s['width']; opacity = .3 if s['tool'] == 'highlight' else 1
                style = s.get('style') if s['tool'] in STYLED_TOOLS else None
                # Pen styles outside the app: plain ink that looks close to them.
                if style == 'felt': width *= 1.7
                elif style == 'chalk': width *= 1.6; c = mix_color(c, '#ffffff', .12); opacity = .85
                elif style == 'pencil': width = max(.6, width*.85); c = mix_color(c, '#4a4f57', .35); opacity = .85
                elif style == 'neon':
                    for k, alpha, col in ((5.5, .16, c), (3, .42, c), (.7, 1, QColor('#ffffff'))):
                        g = page.add_ink_annot(ink); g.set_colors(stroke=(col.redF(), col.greenF(), col.blueF()))
                        g.set_border(width=max(.6, width*k)); g.set_opacity(alpha); g.set_info(title=TAG_FX); g.update()
                    width = max(.6, width*.35)
                a = page.add_ink_annot(ink)
                a.set_colors(stroke=(c.redF(), c.greenF(), c.blueF()))
                if s.get('dash'): a.set_border(width=s['width'], dashes=[DASH_PATTERN[0]*s['width']+s['width'], DASH_PATTERN[1]*s['width']-s['width']])
                else: a.set_border(width=width)
                a.set_opacity(opacity)
                a.set_info(title=TAG, content=json.dumps(s))
                a.update()
        fd, tmp = tempfile.mkstemp(suffix='.pdf', dir=os.path.dirname(os.path.abspath(target)))
        os.close(fd)
        try:
            # garbage=3/deflate re-compress every image of large textbooks
            # (10+ s, UI freeze); garbage=1 keeps output valid and fast.
            out.save(tmp, garbage=1)
            os.replace(tmp, target)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
    finally:
        out.close()

SOLUTIONS_FILE = 'umal-cozumler.json'

def read_solutions(doc):
    """Saved question solutions travel inside the PDF as an embedded file."""
    try:
        if SOLUTIONS_FILE in doc.embfile_names():
            data = json.loads(doc.embfile_get(SOLUTIONS_FILE).decode('utf-8'))
            return {k: dict(v, marks=load_marks(v.get('marks'))) for k, v in data.items()
                    if len(v.get('rect', [])) == 4}
    except Exception: pass
    return {}

def solution_overlap(a, b):
    ra, rb = fitz.Rect(a), fitz.Rect(b); inter = ra & rb
    if inter.is_empty: return 0
    area = lambda r: max(0, r.width) * max(0, r.height)
    union = area(ra) + area(rb) - area(inter)
    return area(inter) / union if union else 0

def recover_marks(doc):
    marks = {}
    for page in doc:
        marks[page.number] = []
        for a in list(page.annots() or []):
            if a.info.get('title') == TAG_FX: page.delete_annot(a); continue
            if a.info.get('title') != TAG: continue
            try:
                s = json.loads(a.info['content'])
                assert s['tool'] in ('pen', 'highlight', 'line', 'rect', 'circle', 'whiteout', 'geo')
                assert 0 < float(s['width']) <= 100
                assert s['points'] and all(len(p) == 2 and all(math.isfinite(float(v)) for v in p) for p in s['points'])
                assert QColor(s['color']).isValid()
                if s['tool'] == 'whiteout':
                    assert len(s['points']) == 2
                    assert s['points'][1][0] > s['points'][0][0] and s['points'][1][1] > s['points'][0][1]
                marks[page.number].append(s)
                page.delete_annot(a)
            except (ValueError, KeyError, TypeError, AssertionError):
                pass
    return marks

def load_marks(data):
    """Validated marks from autosave JSON (same rules as recover_marks)."""
    marks = {}
    for key, strokes in (data or {}).items():
        page = int(key); marks[page] = []
        for s in strokes:
            try:
                assert s['tool'] in ('pen', 'highlight', 'line', 'rect', 'circle', 'whiteout', 'geo')
                assert 0 < float(s['width']) <= 100
                assert s['points'] and all(len(p) == 2 and all(math.isfinite(float(v)) for v in p) for p in s['points'])
                assert QColor(s['color']).isValid()
                marks[page].append(s)
            except (ValueError, KeyError, TypeError, AssertionError):
                pass
    return marks

def segment_distance(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    d = dx*dx+dy*dy
    t = max(0, min(1, ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/d)) if d else 0
    return math.hypot(p[0]-a[0]-t*dx, p[1]-a[1]-t*dy)

def stroke_bounds(stroke):
    pts=stroke['points']; pad=stroke['width']/2
    x0=min(p[0] for p in pts)-pad;y0=min(p[1] for p in pts)-pad
    return QRectF(x0,y0,max(p[0] for p in pts)+pad-x0,max(p[1] for p in pts)+pad-y0)

def is_scribble(points, scale=1):
    """Back-and-forth scratching (≥5 reversals, very long for its size)."""
    if len(points) < 10: return False
    xs = [p[0] for p in points]; ys = [p[1] for p in points]
    w, h = max(xs)-min(xs), max(ys)-min(ys)
    if max(w, h)*scale < 24: return False
    length = sum(math.dist(a, b) for a, b in zip(points, points[1:]))
    if length < 3*(w+h): return False
    def reversals(vals, extent):
        hyst = max(4/scale, .18*extent); count = 0; direction = 0; anchor = vals[0]
        for v in vals[1:]:
            if direction >= 0 and v < anchor-hyst:
                count += direction > 0; direction = -1; anchor = v
            elif direction <= 0 and v > anchor+hyst:
                count += direction < 0; direction = 1; anchor = v
            elif (direction > 0 and v > anchor) or (direction < 0 and v < anchor): anchor = v
        return count
    return max(reversals(xs, w), reversals(ys, h)) >= 5

def scribble_hits(strokes, scribble, scale=1):
    """Strokes lying mostly under the scribble."""
    xs = [p[0] for p in scribble['points']]; ys = [p[1] for p in scribble['points']]
    pad = max(4/scale, scribble.get('width', 3))
    x0, x1, y0, y1 = min(xs)-pad, max(xs)+pad, min(ys)-pad, max(ys)+pad
    hits = []
    for s in strokes:
        if s is scribble or s['tool'] == 'whiteout' or not s['points']: continue
        inside = sum(1 for q in s['points'] if x0 <= q[0] <= x1 and y0 <= q[1] <= y1)
        if inside >= .5*len(s['points']): hits.append(s)
    return hits

def recognize_triangle(points, diag, length):
    """Kapalı ve üç köşeli el çizimi → düzgün üçgen (köşeler el çiziminden)."""
    def far(pts, a, b):
        return max(range(len(pts)), key=lambda k: segment_distance(pts[k], a, b) if a != b else math.dist(pts[k], a))
    p0 = points[0]; i1 = max(range(len(points)), key=lambda k: math.dist(points[k], p0)); A = points[i1]
    i2 = max(range(len(points)), key=lambda k: math.dist(points[k], A)); B = points[i2]
    i3 = far(points, A, B); C = points[i3]
    corners = [A, B, C]
    sides = [math.dist(A, B), math.dist(B, C), math.dist(C, A)]
    if min(sides) < diag*.25: return None
    per = sum(sides)
    if not (.85*per < length < 1.18*per): return None
    edges = [(A, B), (B, C), (C, A)]
    err = [min(segment_distance(p, a, b) for a, b in edges) for p in points]
    if sum(e < diag*.06 for e in err)/len(err) < .9: return None
    # her köşenin yakınından geçilmiş olmalı (dörtgen/daire elensin)
    def ang(p, q, r):
        v1 = (q[0]-p[0], q[1]-p[1]); v2 = (r[0]-p[0], r[1]-p[1])
        c = (v1[0]*v2[0] + v1[1]*v2[1])/max(1e-9, math.hypot(*v1)*math.hypot(*v2)); return math.degrees(math.acos(max(-1, min(1, c))))
    if min(ang(A, B, C), ang(B, C, A), ang(C, A, B)) < 12: return None
    return [list(A), list(B), list(C), list(A)]

def recognize_shape(points):
    """Conservative axis-aligned shapes; called only after an intentional hold."""
    if len(points)<3:return None
    xs=[p[0] for p in points];ys=[p[1] for p in points]
    x0,x1=min(xs),max(xs);y0,y1=min(ys),max(ys)
    w,h=x1-x0,y1-y0;diag=math.hypot(w,h)
    if diag<20:return None
    # Remove sampling jitter and resample uniformly. Touch screens often send
    # many points while stationary and only a few during a fast straight stroke.
    def simplify(pts):
        keep={0,len(pts)-1};stack=[(0,len(pts)-1)]
        while stack:
            a,b=stack.pop()
            if b-a<2:continue
            i=max(range(a+1,b),key=lambda k:segment_distance(pts[k],pts[a],pts[b]))
            if segment_distance(pts[i],pts[a],pts[b])>max(1.5,diag*.012):
                keep.add(i);stack.extend([(a,i),(i,b)])
        return [pts[i] for i in sorted(keep)]
    filtered=simplify(points)
    samples=[]
    for a,b in zip(filtered,filtered[1:]):
        steps=max(1,min(200,int(math.dist(a,b)/max(1,diag/80))))
        samples.extend([[a[0]+(b[0]-a[0])*i/steps,a[1]+(b[1]-a[1])*i/steps] for i in range(steps)])
    points=samples+[filtered[-1]]
    length=sum(math.dist(a,b) for a,b in zip(points,points[1:]))
    chord=math.dist(points[0],points[-1])
    if chord>.8*diag and length<chord*1.2 and max(segment_distance(p,points[0],points[-1]) for p in points)<max(2.5,diag*.04):
        return 'line',[points[0],points[-1]]
    if min(w,h)<12 or chord>diag*.2:return None
    tri=recognize_triangle(points,diag,length)
    if tri:return 'triangle',tri
    perimeter=2*(w+h)
    if .8*perimeter<length<1.2*perimeter:
        errors=[min(abs(x-x0),abs(x-x1),abs(y-y0),abs(y-y1)) for x,y in points]
        corners=[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]
        if sum(e<min(w,h)*.07 for e in errors)/len(errors)>.9 and all(min(math.dist(c,p) for p in points)<diag*.09 for c in corners):
            return 'rect',corners+[corners[0]]
    cx,cy=(x0+x1)/2,(y0+y1)/2;rx,ry=w/2,h/2
    error=sum(abs(math.hypot((x-cx)/rx,(y-cy)/ry)-1) for x,y in points)/len(points)
    angles=[math.atan2((y-cy)/ry,(x-cx)/rx) for x,y in points]
    sweep=sum((b-a+math.pi)%(2*math.pi)-math.pi for a,b in zip(angles,angles[1:]))
    if error<.09 and 5.4<abs(sweep)<7.1:
        return 'circle',[[cx+rx*math.cos(t*math.pi/32),cy+ry*math.sin(t*math.pi/32)] for t in range(65)]
    return None

# Çizgi yazısı: etiketler (A, B, C, 6, 60°) normal kalem çizgisi olarak yazılır;
# silinir, taşınır, PDF'e aynen geçer. Hershey Roman Simplex (kamu malı).
HERSHEY = {"!":[14,[[[5,-12],[5,2]],[[5,7],[4,8],[5,9],[6,8],[5,7]]]],"\"":[20,[[[4,-12],[4,-5]],[[12,-12],[12,-5]]]],"#":[25,[[[11,-16],[4,16]],[[17,-16],[10,16]],[[4,-3],[18,-3]],[[3,3],[17,3]]]],"$":[24,[[[8,-16],[8,13]],[[12,-16],[12,13]],[[17,-9],[15,-11],[12,-12],[8,-12],[5,-11],[3,-9],[3,-7],[4,-5],[5,-4],[7,-3],[13,-1],[15,0],[16,1],[17,3],[17,6],[15,8],[12,9],[8,9],[5,8],[3,6]]]],"%":[28,[[[21,-12],[3,9]],[[8,-12],[10,-10],[10,-8],[9,-6],[7,-5],[5,-5],[3,-7],[3,-9],[4,-11],[6,-12],[8,-12],[10,-11],[13,-10],[16,-10],[19,-11],[21,-12]],[[17,2],[15,3],[14,5],[14,7],[16,9],[18,9],[20,8],[21,6],[21,4],[19,2],[17,2]]]],"&":[30,[[[23,-3],[23,-4],[22,-5],[21,-5],[20,-4],[19,-2],[17,3],[15,6],[13,8],[11,9],[7,9],[5,8],[4,7],[3,5],[3,3],[4,1],[5,0],[12,-4],[13,-5],[14,-7],[14,-9],[13,-11],[11,-12],[9,-11],[8,-9],[8,-7],[9,-4],[11,-1],[16,6],[18,8],[20,9],[22,9],[23,8],[23,7]]]],"'":[14,[[[5,-10],[4,-11],[5,-12],[6,-11],[6,-9],[5,-7],[4,-6]]]],"(":[18,[[[11,-16],[9,-14],[7,-11],[5,-7],[4,-2],[4,2],[5,7],[7,11],[9,14],[11,16]]]],")":[18,[[[3,-16],[5,-14],[7,-11],[9,-7],[10,-2],[10,2],[9,7],[7,11],[5,14],[3,16]]]],"*":[20,[[[8,-6],[8,6]],[[3,-3],[13,3]],[[13,-3],[3,3]]]],"+":[30,[[[13,-9],[13,9]],[[4,0],[22,0]]]],",":[12,[[[5,5],[4,6],[3,5],[4,4],[5,5],[5,7],[3,9]]]],"-":[30,[[[4,0],[22,0]]]],".":[12,[[[4,4],[3,5],[4,6],[5,5],[4,4]]]],"/":[26,[[[20,-16],[2,16]]]],"0":[24,[[[9,-12],[6,-11],[4,-8],[3,-3],[3,0],[4,5],[6,8],[9,9],[11,9],[14,8],[16,5],[17,0],[17,-3],[16,-8],[14,-11],[11,-12],[9,-12]]]],"1":[24,[[[6,-8],[8,-9],[11,-12],[11,9]]]],"2":[24,[[[4,-7],[4,-8],[5,-10],[6,-11],[8,-12],[12,-12],[14,-11],[15,-10],[16,-8],[16,-6],[15,-4],[13,-1],[3,9],[17,9]]]],"3":[24,[[[5,-12],[16,-12],[10,-4],[13,-4],[15,-3],[16,-2],[17,1],[17,3],[16,6],[14,8],[11,9],[8,9],[5,8],[4,7],[3,5]]]],"4":[24,[[[13,-12],[3,2],[18,2]],[[13,-12],[13,9]]]],"5":[24,[[[15,-12],[5,-12],[4,-3],[5,-4],[8,-5],[11,-5],[14,-4],[16,-2],[17,1],[17,3],[16,6],[14,8],[11,9],[8,9],[5,8],[4,7],[3,5]]]],"6":[24,[[[16,-9],[15,-11],[12,-12],[10,-12],[7,-11],[5,-8],[4,-3],[4,2],[5,6],[7,8],[10,9],[11,9],[14,8],[16,6],[17,3],[17,2],[16,-1],[14,-3],[11,-4],[10,-4],[7,-3],[5,-1],[4,2]]]],"7":[24,[[[17,-12],[7,9]],[[3,-12],[17,-12]]]],"8":[24,[[[8,-12],[5,-11],[4,-9],[4,-7],[5,-5],[7,-4],[11,-3],[14,-2],[16,0],[17,2],[17,5],[16,7],[15,8],[12,9],[8,9],[5,8],[4,7],[3,5],[3,2],[4,0],[6,-2],[9,-3],[13,-4],[15,-5],[16,-7],[16,-9],[15,-11],[12,-12],[8,-12]]]],"9":[24,[[[16,-5],[15,-2],[13,0],[10,1],[9,1],[6,0],[4,-2],[3,-5],[3,-6],[4,-9],[6,-11],[9,-12],[10,-12],[13,-11],[15,-9],[16,-5],[16,0],[15,5],[13,8],[10,9],[8,9],[5,8],[4,6]]]],":":[12,[[[4,-3],[3,-2],[4,-1],[5,-2],[4,-3]],[[4,4],[3,5],[4,6],[5,5],[4,4]]]],";":[12,[[[4,-3],[3,-2],[4,-1],[5,-2],[4,-3]],[[5,5],[4,6],[3,5],[4,4],[5,5],[5,7],[3,9]]]],"<":[28,[[[20,-9],[4,0],[20,9]]]],"=":[30,[[[4,-3],[22,-3]],[[4,3],[22,3]]]],">":[28,[[[4,-9],[20,0],[4,9]]]],"?":[22,[[[3,-7],[3,-8],[4,-10],[5,-11],[7,-12],[11,-12],[13,-11],[14,-10],[15,-8],[15,-6],[14,-4],[13,-3],[9,-1],[9,2]],[[9,7],[8,8],[9,9],[10,8],[9,7]]]],"@":[31,[[[18,-4],[17,-6],[15,-7],[12,-7],[10,-6],[9,-5],[8,-2],[8,1],[9,3],[11,4],[14,4],[16,3],[17,1]],[[12,-7],[10,-5],[9,-2],[9,1],[10,3],[11,4]],[[18,-7],[17,1],[17,3],[19,4],[21,4],[23,2],[24,-1],[24,-3],[23,-6],[22,-8],[20,-10],[18,-11],[15,-12],[12,-12],[9,-11],[7,-10],[5,-8],[4,-6],[3,-3],[3,0],[4,3],[5,5],[7,7],[9,8],[12,9],[15,9],[18,8],[20,7],[21,6]],[[19,-7],[18,1],[18,3],[19,4]]]],"A":[22,[[[9,-12],[1,9]],[[9,-12],[17,9]],[[4,2],[14,2]]]],"B":[25,[[[4,-12],[4,9]],[[4,-12],[13,-12],[16,-11],[17,-10],[18,-8],[18,-6],[17,-4],[16,-3],[13,-2]],[[4,-2],[13,-2],[16,-1],[17,0],[18,2],[18,5],[17,7],[16,8],[13,9],[4,9]]]],"C":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4]]]],"D":[25,[[[4,-12],[4,9]],[[4,-12],[11,-12],[14,-11],[16,-9],[17,-7],[18,-4],[18,1],[17,4],[16,6],[14,8],[11,9],[4,9]]]],"E":[23,[[[4,-12],[4,9]],[[4,-12],[17,-12]],[[4,-2],[12,-2]],[[4,9],[17,9]]]],"F":[22,[[[4,-12],[4,9]],[[4,-12],[17,-12]],[[4,-2],[12,-2]]]],"G":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[18,1]],[[13,1],[18,1]]]],"H":[26,[[[4,-12],[4,9]],[[18,-12],[18,9]],[[4,-2],[18,-2]]]],"I":[12,[[[4,-12],[4,9]]]],"J":[20,[[[12,-12],[12,4],[11,7],[10,8],[8,9],[6,9],[4,8],[3,7],[2,4],[2,2]]]],"K":[25,[[[4,-12],[4,9]],[[18,-12],[4,2]],[[9,-3],[18,9]]]],"L":[21,[[[4,-12],[4,9]],[[4,9],[16,9]]]],"M":[28,[[[4,-12],[4,9]],[[4,-12],[12,9]],[[20,-12],[12,9]],[[20,-12],[20,9]]]],"N":[26,[[[4,-12],[4,9]],[[4,-12],[18,9]],[[18,-12],[18,9]]]],"O":[26,[[[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[19,1],[19,-4],[18,-7],[17,-9],[15,-11],[13,-12],[9,-12]]]],"P":[25,[[[4,-12],[4,9]],[[4,-12],[13,-12],[16,-11],[17,-10],[18,-8],[18,-5],[17,-3],[16,-2],[13,-1],[4,-1]]]],"Q":[26,[[[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[19,1],[19,-4],[18,-7],[17,-9],[15,-11],[13,-12],[9,-12]],[[12,5],[18,11]]]],"R":[25,[[[4,-12],[4,9]],[[4,-12],[13,-12],[16,-11],[17,-10],[18,-8],[18,-6],[17,-4],[16,-3],[13,-2],[4,-2]],[[11,-2],[18,9]]]],"S":[24,[[[17,-9],[15,-11],[12,-12],[8,-12],[5,-11],[3,-9],[3,-7],[4,-5],[5,-4],[7,-3],[13,-1],[15,0],[16,1],[17,3],[17,6],[15,8],[12,9],[8,9],[5,8],[3,6]]]],"T":[20,[[[8,-12],[8,9]],[[1,-12],[15,-12]]]],"U":[26,[[[4,-12],[4,3],[5,6],[7,8],[10,9],[12,9],[15,8],[17,6],[18,3],[18,-12]]]],"V":[22,[[[1,-12],[9,9]],[[17,-12],[9,9]]]],"W":[28,[[[2,-12],[7,9]],[[12,-12],[7,9]],[[12,-12],[17,9]],[[22,-12],[17,9]]]],"X":[24,[[[3,-12],[17,9]],[[17,-12],[3,9]]]],"Y":[22,[[[1,-12],[9,-2],[9,9]],[[17,-12],[9,-2]]]],"Z":[24,[[[17,-12],[3,9]],[[3,-12],[17,-12]],[[3,9],[17,9]]]],"[":[18,[[[4,-16],[4,16]],[[5,-16],[5,16]],[[4,-16],[11,-16]],[[4,16],[11,16]]]],"\\":[18,[[[0,-12],[14,12]]]],"]":[18,[[[9,-16],[9,16]],[[10,-16],[10,16]],[[3,-16],[10,-16]],[[3,16],[10,16]]]],"^":[20,[[[8,-14],[0,0]],[[8,-14],[16,0]]]],"_":[22,[[[0,16],[18,16]]]],"`":[12,[[[5,-7],[3,-5],[3,-3],[4,-2],[5,-3],[4,-4],[3,-3]]]],"a":[23,[[[15,-5],[15,9]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"b":[23,[[[4,-12],[4,9]],[[4,-2],[6,-4],[8,-5],[11,-5],[13,-4],[15,-2],[16,1],[16,3],[15,6],[13,8],[11,9],[8,9],[6,8],[4,6]]]],"c":[22,[[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"d":[23,[[[15,-12],[15,9]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"e":[22,[[[3,1],[15,1],[15,-1],[14,-3],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"f":[16,[[[10,-12],[8,-12],[6,-11],[5,-8],[5,9]],[[2,-5],[9,-5]]]],"g":[23,[[[15,-5],[15,11],[14,14],[13,15],[11,16],[8,16],[6,15]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"h":[23,[[[4,-12],[4,9]],[[4,-1],[7,-4],[9,-5],[12,-5],[14,-4],[15,-1],[15,9]]]],"i":[12,[[[3,-12],[4,-11],[5,-12],[4,-13],[3,-12]],[[4,-5],[4,9]]]],"j":[14,[[[5,-12],[6,-11],[7,-12],[6,-13],[5,-12]],[[6,-5],[6,12],[5,15],[3,16],[1,16]]]],"k":[21,[[[4,-12],[4,9]],[[14,-5],[4,5]],[[8,1],[15,9]]]],"l":[12,[[[4,-12],[4,9]]]],"m":[34,[[[4,-5],[4,9]],[[4,-1],[7,-4],[9,-5],[12,-5],[14,-4],[15,-1],[15,9]],[[15,-1],[18,-4],[20,-5],[23,-5],[25,-4],[26,-1],[26,9]]]],"n":[23,[[[4,-5],[4,9]],[[4,-1],[7,-4],[9,-5],[12,-5],[14,-4],[15,-1],[15,9]]]],"o":[23,[[[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6],[16,3],[16,1],[15,-2],[13,-4],[11,-5],[8,-5]]]],"p":[23,[[[4,-5],[4,16]],[[4,-2],[6,-4],[8,-5],[11,-5],[13,-4],[15,-2],[16,1],[16,3],[15,6],[13,8],[11,9],[8,9],[6,8],[4,6]]]],"q":[23,[[[15,-5],[15,16]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"r":[17,[[[4,-5],[4,9]],[[4,1],[5,-2],[7,-4],[9,-5],[12,-5]]]],"s":[21,[[[14,-2],[13,-4],[10,-5],[7,-5],[4,-4],[3,-2],[4,0],[6,1],[11,2],[13,3],[14,5],[14,6],[13,8],[10,9],[7,9],[4,8],[3,6]]]],"t":[16,[[[5,-12],[5,5],[6,8],[8,9],[10,9]],[[2,-5],[9,-5]]]],"u":[23,[[[4,-5],[4,5],[5,8],[7,9],[10,9],[12,8],[15,5]],[[15,-5],[15,9]]]],"v":[20,[[[2,-5],[8,9]],[[14,-5],[8,9]]]],"w":[26,[[[3,-5],[7,9]],[[11,-5],[7,9]],[[11,-5],[15,9]],[[19,-5],[15,9]]]],"x":[21,[[[3,-5],[14,9]],[[14,-5],[3,9]]]],"y":[20,[[[2,-5],[8,9]],[[14,-5],[8,9],[6,13],[4,15],[2,16],[1,16]]]],"z":[21,[[[14,-5],[3,9]],[[3,-5],[14,-5]],[[3,9],[14,9]]]],"{":[18,[[[9,-16],[7,-15],[6,-14],[5,-12],[5,-10],[6,-8],[7,-7],[8,-5],[8,-3],[6,-1]],[[7,-15],[6,-13],[6,-11],[7,-9],[8,-8],[9,-6],[9,-4],[8,-2],[4,0],[8,2],[9,4],[9,6],[8,8],[7,9],[6,11],[6,13],[7,15]],[[6,1],[8,3],[8,5],[7,7],[6,8],[5,10],[5,12],[6,14],[7,15],[9,16]]]],"|":[12,[[[4,-16],[4,16]]]],"}":[18,[[[5,-16],[7,-15],[8,-14],[9,-12],[9,-10],[8,-8],[7,-7],[6,-5],[6,-3],[8,-1]],[[7,-15],[8,-13],[8,-11],[7,-9],[6,-8],[5,-6],[5,-4],[6,-2],[10,0],[6,2],[5,4],[5,6],[6,8],[7,9],[8,11],[8,13],[7,15]],[[8,1],[6,3],[6,5],[7,7],[8,8],[9,10],[9,12],[8,14],[7,15],[5,16]]]],"~":[28,[[[3,3],[3,1],[4,-2],[6,-3],[8,-3],[10,-2],[14,1],[16,2],[18,2],[20,1],[21,-1]],[[3,1],[4,-1],[6,-2],[8,-2],[10,-1],[14,2],[16,3],[18,3],[20,2],[21,-1],[21,-3]]]]," ":[16,[]],"\u0131":[12,[[[4,-5],[4,9]]]],"\u0130":[12,[[[4,-12],[4,9]],[[4.0,-16],[4.0,-15]]]],"\u015f":[21,[[[14,-2],[13,-4],[10,-5],[7,-5],[4,-4],[3,-2],[4,0],[6,1],[11,2],[13,3],[14,5],[14,6],[13,8],[10,9],[7,9],[4,8],[3,6]],[[8.5,9],[10.5,11],[8.5,13],[6.5,13]]]],"\u015e":[24,[[[17,-9],[15,-11],[12,-12],[8,-12],[5,-11],[3,-9],[3,-7],[4,-5],[5,-4],[7,-3],[13,-1],[15,0],[16,1],[17,3],[17,6],[15,8],[12,9],[8,9],[5,8],[3,6]],[[10.0,9],[12.0,11],[10.0,13],[8.0,13]]]],"\u00e7":[22,[[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]],[[9.0,9],[11.0,11],[9.0,13],[7.0,13]]]],"\u00c7":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4]],[[10.5,9],[12.5,11],[10.5,13],[8.5,13]]]],"\u011f":[23,[[[15,-5],[15,11],[14,14],[13,15],[11,16],[8,16],[6,15]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]],[[5.0,-12],[6.0,-10],[9.0,-9],[12.0,-10],[13.0,-12]]]],"\u011e":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[18,1]],[[13,1],[18,1]],[[6.5,-17],[7.5,-15],[10.5,-14],[13.5,-15],[14.5,-17]]]],"\u00f6":[23,[[[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6],[16,3],[16,1],[15,-2],[13,-4],[11,-5],[8,-5]],[[6.5,-10],[6.5,-9]],[[12.5,-10],[12.5,-9]]]],"\u00fc":[23,[[[4,-5],[4,5],[5,8],[7,9],[10,9],[12,8],[15,5]],[[15,-5],[15,9]],[[6.5,-10],[6.5,-9]],[[12.5,-10],[12.5,-9]]]],"\u00d6":[26,[[[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[19,1],[19,-4],[18,-7],[17,-9],[15,-11],[13,-12],[9,-12]],[[8.0,-16],[8.0,-15]],[[14.0,-16],[14.0,-15]]]],"\u00dc":[26,[[[4,-12],[4,3],[5,6],[7,8],[10,9],[12,9],[15,8],[17,6],[18,3],[18,-12]],[[8.0,-16],[8.0,-15]],[[14.0,-16],[14.0,-15]]]],"\u2212":[22,[[[4,0],[18,0]]]],"\u2019":[14,[[[5,-10],[4,-11],[5,-12],[6,-11],[6,-9],[5,-7],[4,-6]]]],"\u00b7":[10,[[[5,-1],[5,0]]]],"\u221a":[22,[[[2,1],[5,0],[9,9],[15,-14],[22,-14]]]],"\u0394":[20,[[[3,9],[10,-12],[17,9],[3,9]]]],"\u2225":[14,[[[5,-12],[5,9]],[[10,-12],[10,9]]]],"\u22a5":[20,[[[10,-12],[10,9]],[[3,9],[17,9]]]],"\u2229":[20,[[[4,9],[4,-2],[6,-6],[10,-8],[14,-6],[16,-2],[16,9]]]],"\u2248":[22,[[[3,-2.0],[4,-2.8419035512031976],[5,-3.5556349186104046],[6,-4.03253497152483],[7,-4.2],[8,-4.03253497152483],[9,-3.555634918610405],[10,-2.841903551203198],[11,-2.0000000000000004],[12,-1.1580964487968026],[13,-0.4443650813895954],[14,0.032534971524830425],[15,0.20000000000000018],[16,0.03253497152483087],[17,-0.44436508138959496],[18,-1.158096448796801],[19,-1.9999999999999996]],[[3,4.0],[4,3.1580964487968024],[5,2.4443650813895954],[6,1.9674650284751691],[7,1.7999999999999998],[8,1.9674650284751691],[9,2.444365081389595],[10,3.158096448796802],[11,3.9999999999999996],[12,4.841903551203197],[13,5.555634918610405],[14,6.03253497152483],[15,6.2],[16,6.03253497152483],[17,5.555634918610405],[18,4.841903551203199],[19,4.000000000000001]]]],"\u2080":[14.879999999999999,[[[5.58,-0.4399999999999995],[3.7199999999999998,0.17999999999999972],[2.48,2.04],[1.8599999999999999,5.140000000000001],[1.8599999999999999,7.0],[2.48,10.1],[3.7199999999999998,11.96],[5.58,12.58],[6.82,12.58],[8.68,11.96],[9.92,10.1],[10.54,7.0],[10.54,5.140000000000001],[9.92,2.04],[8.68,0.17999999999999972],[6.82,-0.4399999999999995],[5.58,-0.4399999999999995]]]],"\u2081":[14.879999999999999,[[[3.7199999999999998,2.04],[4.96,1.42],[6.82,-0.4399999999999995],[6.82,12.58]]]],"\u2082":[14.879999999999999,[[[2.48,2.66],[2.48,2.04],[3.1,0.7999999999999998],[3.7199999999999998,0.17999999999999972],[4.96,-0.4399999999999995],[7.4399999999999995,-0.4399999999999995],[8.68,0.17999999999999972],[9.3,0.7999999999999998],[9.92,2.04],[9.92,3.2800000000000002],[9.3,4.52],[8.06,6.38],[1.8599999999999999,12.58],[10.54,12.58]]]],"\u2083":[14.879999999999999,[[[3.1,-0.4399999999999995],[9.92,-0.4399999999999995],[6.2,4.52],[8.06,4.52],[9.3,5.140000000000001],[9.92,5.76],[10.54,7.62],[10.54,8.86],[9.92,10.719999999999999],[8.68,11.96],[6.82,12.58],[4.96,12.58],[3.1,11.96],[2.48,11.34],[1.8599999999999999,10.1]]]],"\u2084":[14.879999999999999,[[[8.06,-0.4399999999999995],[1.8599999999999999,8.24],[11.16,8.24]],[[8.06,-0.4399999999999995],[8.06,12.58]]]],"\u2085":[14.879999999999999,[[[9.3,-0.4399999999999995],[3.1,-0.4399999999999995],[2.48,5.140000000000001],[3.1,4.52],[4.96,3.9],[6.82,3.9],[8.68,4.52],[9.92,5.76],[10.54,7.62],[10.54,8.86],[9.92,10.719999999999999],[8.68,11.96],[6.82,12.58],[4.96,12.58],[3.1,11.96],[2.48,11.34],[1.8599999999999999,10.1]]]],"\u2086":[14.879999999999999,[[[9.92,1.42],[9.3,0.17999999999999972],[7.4399999999999995,-0.4399999999999995],[6.2,-0.4399999999999995],[4.34,0.17999999999999972],[3.1,2.04],[2.48,5.140000000000001],[2.48,8.24],[3.1,10.719999999999999],[4.34,11.96],[6.2,12.58],[6.82,12.58],[8.68,11.96],[9.92,10.719999999999999],[10.54,8.86],[10.54,8.24],[9.92,6.38],[8.68,5.140000000000001],[6.82,4.52],[6.2,4.52],[4.34,5.140000000000001],[3.1,6.38],[2.48,8.24]]]],"\u2087":[14.879999999999999,[[[10.54,-0.4399999999999995],[4.34,12.58]],[[1.8599999999999999,-0.4399999999999995],[10.54,-0.4399999999999995]]]],"\u2088":[14.879999999999999,[[[4.96,-0.4399999999999995],[3.1,0.17999999999999972],[2.48,1.42],[2.48,2.66],[3.1,3.9],[4.34,4.52],[6.82,5.140000000000001],[8.68,5.76],[9.92,7.0],[10.54,8.24],[10.54,10.1],[9.92,11.34],[9.3,11.96],[7.4399999999999995,12.58],[4.96,12.58],[3.1,11.96],[2.48,11.34],[1.8599999999999999,10.1],[1.8599999999999999,8.24],[2.48,7.0],[3.7199999999999998,5.76],[5.58,5.140000000000001],[8.06,4.52],[9.3,3.9],[9.92,2.66],[9.92,1.42],[9.3,0.17999999999999972],[7.4399999999999995,-0.4399999999999995],[4.96,-0.4399999999999995]]]],"\u2089":[14.879999999999999,[[[9.92,3.9],[9.3,5.76],[8.06,7.0],[6.2,7.62],[5.58,7.62],[3.7199999999999998,7.0],[2.48,5.76],[1.8599999999999999,3.9],[1.8599999999999999,3.2800000000000002],[2.48,1.42],[3.7199999999999998,0.17999999999999972],[5.58,-0.4399999999999995],[6.2,-0.4399999999999995],[8.06,0.17999999999999972],[9.3,1.42],[9.92,3.9],[9.92,7.0],[9.3,10.1],[8.06,11.96],[6.2,12.58],[4.96,12.58],[3.1,11.96],[2.48,10.719999999999999]]]]}
HERSHEY['°'] = [12, [[[6 + 3*math.cos(t*math.pi/8), -9 + 3*math.sin(t*math.pi/8)] for t in range(17)]]]
def text_strokes(text, x, y, h, color, width, anchor='c'):
    """Yazıyı kalem çizgilerine çevirir (h: büyük harf yüksekliği, sayfa birimi).
    anchor: 'c' ortası (x, y), 'l' sol-orta, 'r' sağ-orta."""
    k = h/21.0; glyphs = [HERSHEY.get(ch, HERSHEY.get(ch.upper(), [12, []])) for ch in text]
    total = sum(g[0] for g in glyphs)*k
    cx = x - total/2 if anchor == 'c' else x - total if anchor == 'r' else x
    out = []
    for adv, polys in glyphs:
        for poly in polys:
            out.append(dict(tool='pen', color=color, width=width, points=[[cx + gx*k, y + (gy + 1.5)*k] for gx, gy in poly]))
        cx += adv*k
    return out

def fmt_num(v, nd=2):
    """Türkçe ondalık: 5,29 · tam sayıysa 6."""
    if abs(v - round(v)) < 1e-9: return str(int(round(v)))
    return ('{:.%df}' % nd).format(v).rstrip('0').rstrip('.').replace('.', ',')

def tri_points(a, b):
    """Sürükleyerek çizilen sıradan üçgen: tabanı alt kenar, tepesi biraz solda."""
    x0, x1 = min(a[0], b[0]), max(a[0], b[0]); y0, y1 = min(a[1], b[1]), max(a[1], b[1])
    apex = [x0 + .38*(x1 - x0), y0]
    return [[x0, y1], [x1, y1], apex, [x0, y1]]

PEN_DEFAULT = '#111111'   # canlı palet: siyah, kırmızı, mavi, yeşil, mor, pembe, sarı, beyaz
SIDE_ARROW_W, SIDE_ARROW_H = 56, 116
HAVUZ_DIR = os.path.join(os.path.expanduser('~'), 'PDF Havuzu')
HAVUZ_TOOL = '/usr/lib/umal-tahta/umal-havuz'
HAVUZ_RCLONE = '/usr/lib/umal-tahta/rclone'
HAVUZ_PYTHON = None
if sys.platform == 'win32':   # taşınabilir Windows paketi: app/umal-havuz.py + runtime/
    _app = os.path.dirname(os.path.abspath(__file__))
    HAVUZ_TOOL = os.path.join(_app, 'umal-havuz.py')
    HAVUZ_RCLONE = os.path.join(os.path.dirname(_app), 'runtime', 'rclone.exe')
    HAVUZ_PYTHON = os.path.join(os.path.dirname(_app), 'runtime', 'pythonw.exe')

def havuz_ready():
    if HAVUZ_PYTHON: return os.path.isfile(HAVUZ_TOOL) and os.path.isfile(HAVUZ_PYTHON)
    return os.access(HAVUZ_TOOL, os.X_OK)

def token_from_authorize(out):
    """The token rclone authorize prints between its paste markers."""
    if '--->' not in out or '<---End paste' not in out: return None
    blob = out.split('--->', 1)[1].split('<---End paste', 1)[0].strip()
    if not blob.startswith('{'):
        try:
            import base64; blob = base64.b64decode(blob + '=' * (-len(blob) % 4)).decode('utf-8')
        except Exception: return None
    try: data = json.loads(blob)
    except ValueError: return None
    if isinstance(data, dict) and 'token' in data and isinstance(data['token'], (str, dict)):
        data = data['token'] if isinstance(data['token'], dict) else json.loads(data['token'])
    return json.dumps(data, separators=(',', ':')) if isinstance(data, dict) and data.get('refresh_token') else None

def havuz_data():
    return os.path.join(QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation), 'umal-tahta', 'havuz')

# ---------------------------------------------------------------------------
# Günün soruları: derste çözülen sorular, tarih / konu / öğretmen adıyla iki
# sütunlu A4 sayfaya dizilir; PDF "Günün Soruları" klasörüne (Drive) gider.
GUNUN_DIR = os.environ.get('UMAL_GUNUN_KLASOR') or os.path.join(os.path.expanduser('~'), 'Günün Soruları')
GUNUN_CARD = 864   # soru kartı genişliği (çözüm alanıyla aynı)

FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts')

def pdf_fonts():
    """Mizanpaj yazı tipleri: pakette gelen Poppins; yoksa sistemdeki Türkçe karakterli yazı tipi.
    Döner: {'r': normal, 'm': orta, 'b': kalın} dosya yolları (None: PDF'in yerleşik yazısı)."""
    pop = {k: os.path.join(FONT_DIR, 'Poppins-%s.ttf' % n) for k, n in (('r', 'Regular'), ('m', 'Medium'), ('b', 'Bold'))}
    if all(os.path.isfile(v) for v in pop.values()): return pop
    pairs = [('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
             ('/usr/share/fonts/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf')]
    win = os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts')
    pairs += [(os.path.join(win, 'segoeui.ttf'), os.path.join(win, 'segoeuib.ttf')), (os.path.join(win, 'arial.ttf'), os.path.join(win, 'arialbd.ttf'))]
    for a, b in pairs:
        if os.path.isfile(a): b = b if os.path.isfile(b) else a; return {'r': a, 'm': b, 'b': b}
    return {'r': None, 'm': None, 'b': None}

def bake(doc):
    """Kalem izleri PDF'te not (annotation) olarak durur; başka sayfaya gömülürken
    görünmeleri için sayfa içeriğine işlenir."""
    if hasattr(doc, 'bake'): doc.bake(annots=True, widgets=False)
    else:   # eski PyMuPDF: sayfayı resim olarak yeniden çiz
        for i in range(len(doc)):
            pg = doc[i]; pix = pg.get_pixmap(matrix=fitz.Matrix(3, 3), alpha=False); r = pg.rect
            for a in list(pg.annots() or []): pg.delete_annot(a)
            pg.clean_contents(); pg.insert_image(r, pixmap=pix, overlay=True)

def content_box(page, clip, marks):
    """Çerçevenin içinde gözle görülen kısım: alan resim gibi çizilir ve beyaz olmayan
    noktaların kutusu alınır. (PDF'teki görünmez yazı katmanı, beyaz kutu, kırpma
    alanı gibi nesneler hesaba katılmaz; kenar boşlukları kesilir, soru büyük çıkar.)"""
    clip = fitz.Rect(clip)
    if clip.is_empty: return clip
    try:
        z = min(4.0, 1400/max(clip.width, clip.height))
        pix = page.get_pixmap(matrix=fitz.Matrix(z, z), clip=clip, colorspace=fitz.csGRAY, alpha=False)
        w, h, st, data = pix.width, pix.height, pix.stride, pix.samples
        ink = bytes(1 if v < 225 else 0 for v in range(256))   # açık gri kâğıt dokusu sayılmaz
        x0, x1, y0, y1 = w, -1, None, None
        for y in range(h):
            row = data[y*st:y*st+w].translate(ink)
            a = row.find(1)
            if a < 0: continue
            if y0 is None: y0 = y
            y1 = y; x0 = min(x0, a); x1 = max(x1, row.rfind(1))
        r = fitz.Rect() if y0 is None else fitz.Rect(clip.x0 + x0/z, clip.y0 + y0/z, clip.x0 + (x1+1)/z, clip.y0 + (y1+1)/z)
    except Exception: return clip
    for st_ in marks or []:
        if st_.get('tool') == 'whiteout' or not st_.get('points'): continue
        xs = [q[0] for q in st_['points']]; ys = [q[1] for q in st_['points']]; lw = st_.get('width', 3)
        b = fitz.Rect(min(xs)-lw, min(ys)-lw, max(xs)+lw, max(ys)+lw) & clip
        if not b.is_empty: r |= b
    return clip if r.is_empty or r.width < 8 or r.height < 8 else r

def question_card(src, page_no, page_marks, clip, ink=None):
    """Soru (+ çözüm mürekkebi) tek sayfalık PDF, çözüm alanıyla aynı yerleşimde
    (soru 864 birim genişlikte; mürekkep koordinatları birebir tutar).
    Döner: (pdf baytları, tüm kırpma, yalnız soru kırpması)."""
    clip = fitz.Rect(clip)
    box = content_box(src[page_no], clip, page_marks)
    with tempfile.TemporaryDirectory() as folder:
        single = fitz.open(); single.insert_pdf(src, from_page=page_no, to_page=page_no)
        path = os.path.join(folder, 'soru.pdf'); export_document(single, {0: page_marks or []}, path); single.close()
        qdoc = fitz.open(path); bake(qdoc)   # notlar sayfaya işlenir (gömülünce kaybolmasın)
        card_h = min(300, GUNUN_CARD*clip.height/max(clip.width, 1))
        s = min(GUNUN_CARD/max(clip.width, 1), card_h/max(clip.height, 1)); x0 = 48 + (GUNUN_CARD - clip.width*s)/2
        q = fitz.Rect(x0 + (box.x0-clip.x0)*s, 36 + (box.y0-clip.y0)*s, x0 + (box.x1-clip.x0)*s, 36 + (box.y1-clip.y0)*s)
        full = fitz.Rect(q)
        for st in ink or []:
            if not st.get('points'): continue
            w = st.get('width', 3); xs = [p_[0] for p_ in st['points']]; ys = [p_[1] for p_ in st['points']]
            full |= fitz.Rect(min(xs)-w, min(ys)-w, max(xs)+w, max(ys)+w)
        height = max(800, full.y1 + 40)
        doc = fitz.open(); page = doc.new_page(width=960, height=height)
        page.show_pdf_page(fitz.Rect(48, 36, 912, 36 + card_h), qdoc, 0, clip=clip)
        qdoc.close()
        out = os.path.join(folder, 'kart.pdf'); export_document(doc, {0: ink or []}, out); doc.close()
        kd = fitz.open(out); bake(kd); data = kd.tobytes(garbage=3, deflate=True); kd.close()
    pad = lambda r, k: [max(0, r.x0-k), max(0, r.y0-k), min(960, r.x1+k), min(height, r.y1+k)]
    return data, pad(full, 10), pad(q, 6)

def daily_grid(n, W, H, aspects, gap):
    """1 ya da 2 sütun: soruların en büyük çıktığı düzen (aspects: yükseklik/genişlik)."""
    best = None
    for cols in (1, 2):
        if cols > n: break
        rows = math.ceil(n/cols); cw = (W - gap*(cols-1))/cols; ch = (H - gap*(rows-1))/rows
        sc = min(min(cw, ch/a) for a in aspects)
        if best is None or sc > best[0] + .01: best = (sc, cols, rows, cw, ch)
    return best[1:]

def build_daily_pdf(items, folder, date_text, topic, teacher, target):
    """Kareli defter mizanpajı (A4). Önce soruların boş hâli (altı kareli çözüm alanı),
    sonra yeni sayfadan çözümler, aynı numaralarla. Sayfada en çok 4 soru; sorular
    sayfaya yayılır, kenar boşlukları kesilip olabildiğince büyük konur."""
    W, H, M = 595, 842, 30
    TEAL = (.04, .43, .4); LIGHT = (.9, .96, .95); DARK = (.1, .12, .15); GRID = (.8, .9, .89)
    fonts = pdf_fonts(); out = fitz.open()
    def width_of(t, size, f):
        return fitz.Font(fontfile=fonts[f]).text_length(t, fontsize=size) if fonts[f] else fitz.get_text_length(t, fontsize=size)
    def text(pg, x, y, t, size, f='r', color=DARK, right=False, center=False):
        if right: x -= width_of(t, size, f)
        if center: x -= width_of(t, size, f)/2
        if fonts[f]: pg.insert_text((x, y), t, fontsize=size, fontname='umal' + f, fontfile=fonts[f], color=color)
        else: pg.insert_text((x, y), t, fontsize=size, color=color)
    srcs = {}
    def src(name):
        if name not in srcs: srcs[name] = fitz.open(os.path.join(folder, name))
        return srcs[name]
    def place(pg, rect, name, clip):
        clip = fitz.Rect(clip); s = min(rect.width/clip.width, rect.height/clip.height)
        r = fitz.Rect(rect.x0, rect.y0, rect.x0 + clip.width*s, rect.y0 + clip.height*s)
        pg.show_pdf_page(r, src(name), 0, clip=clip); return r.height
    pages = []   # (bölüm başlığı, ilk sayfa mı, [(no, dosya, kırpma)], boş mu)
    blank = [(n+1, it.get('qsnap') or it['snap'], it.get('qcrop') or it['crop']) for n, it in enumerate(items)]
    solved = [(n+1, it['snap'], it['crop']) for n, it in enumerate(items) if it['done']]
    for title, cards, is_blank in (('Günün soruları', blank, True), ('Çözümler', solved, False)):
        for k in range(0, len(cards), 4): pages.append((title, k == 0, cards[k:k+4], is_blank))
    for pi, (title, first, cards, is_blank) in enumerate(pages):
        pg = out.new_page(width=W, height=H)
        if pi == 0:
            pg.draw_rect(fitz.Rect(M, 28, M+6, 80), color=None, fill=TEAL)
            text(pg, M+16, 52 if topic else 60, title, 22, 'b')
            if topic: text(pg, M+16, 72, topic, 11, 'm', TEAL)
            r = fitz.Rect(W-M-140, 34, W-M, 74); pg.draw_rect(r, color=None, fill=LIGHT, radius=.25)
            text(pg, r.x0+70, 50, 'TARİH', 7.5, 'm', TEAL, center=True); text(pg, r.x0+70, 66, date_text, 9.5, 'm', center=True)
            top = 100
        else:
            pg.draw_rect(fitz.Rect(M, 28, M+6, 56), color=None, fill=TEAL)
            text(pg, M+16, 48, title if first or title == 'Çözümler' else title, 16, 'b'); text(pg, W-M, 48, date_text, 9.5, 'r', (.4, .45, .45), right=True)
            top = 74
        area = fitz.Rect(M, top, W-M, H-50); gap = 14
        aspects = [(2.2 if is_blank else 1.0)*fitz.Rect(c).height/fitz.Rect(c).width + 44/max(fitz.Rect(c).width, 1) for _, _, c in cards]
        cols, rows, cw, ch = daily_grid(len(cards), area.width - 44*0, area.height, aspects, gap)
        for k, (no, name, clip) in enumerate(cards):
            row, col = divmod(k, cols)
            if cols == 2 and len(cards) % 2 and k == len(cards)-1: x = area.x0 + (area.width-cw)/2   # tek kalan: ortada
            else: x = area.x0 + col*(cw+gap)
            cell = fitz.Rect(x, area.y0 + row*(ch+gap), x+cw, area.y0 + row*(ch+gap) + ch)
            pg.draw_rect(cell, color=(.78, .86, .85), fill=(1, 1, 1), width=.7, radius=min(.03, 8/max(cell.height, 1)))
            tab = fitz.Rect(cell.x0-1, cell.y0+12, cell.x0+28, cell.y0+38); pg.draw_rect(tab, color=None, fill=TEAL)
            text(pg, tab.x0+14.5, tab.y0+18, str(no), 12, 'b', (1, 1, 1), center=True)
            inner = fitz.Rect(cell.x0+34, cell.y0+10, cell.x1-10, cell.y1-10)
            if is_blank:
                h = place(pg, fitz.Rect(inner.x0, inner.y0, inner.x1, inner.y0 + inner.height*.5), name, clip)
                a = fitz.Rect(cell.x0+10, inner.y0+h+10, cell.x1-10, cell.y1-10); step = 12
                if a.height > step:
                    x_ = a.x0
                    while x_ <= a.x1 + .1: pg.draw_line((x_, a.y0), (x_, a.y1), color=GRID, width=.4); x_ += step
                    y_ = a.y0
                    while y_ <= a.y1 + .1: pg.draw_line((a.x0, y_), (a.x1, y_), color=GRID, width=.4); y_ += step
            else: place(pg, inner, name, clip)
        text(pg, W/2, H-26, '%d / %d' % (pi+1, len(pages)), 8.5, 'r', (.45, .5, .5), center=True)
        if teacher and pi == len(pages)-1: text(pg, W-M, H-26, 'Öğretmen: ' + teacher, 9, 'm', TEAL, right=True)
    for d in srcs.values(): d.close()
    try: out.subset_fonts()
    except Exception: pass
    out.save(target, garbage=3, deflate=True); out.close()

class DailyStrip(QWidget):
    """Günün soruları listesi: yazı alanının sağ üstünde 1, 2, 3… ve +."""
    S, GAP = 46, 10
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.setCursor(Qt.PointingHandCursor); self.hide()
    def sync(self):
        n = len(self.main.daily['items'])
        self.setFixedSize(self.S + 12, (n + 1)*(self.S + self.GAP) + 4)
        self.setVisible(n > 0 or self.main.tool == 'pick'); self.update()
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); f = p.font(); f.setPixelSize(18); f.setBold(True); p.setFont(f)
        cur = self.main.daily_current()
        for i, it in enumerate(self.main.daily['items'] + [None]):
            r = QRectF(5, 5 + i*(self.S + self.GAP), self.S, self.S)
            if it is None:
                p.setPen(QPen(QColor('#8fa3bd'), 1.5, Qt.DashLine)); p.setBrush(QColor(11, 31, 58, 215)); p.drawRoundedRect(r, 10, 10)
                p.setPen(QPen(QColor('#dbe6f5'), 2.4)); c = r.center()
                p.drawLine(QPointF(c.x()-8, c.y()), QPointF(c.x()+8, c.y())); p.drawLine(QPointF(c.x(), c.y()-8), QPointF(c.x(), c.y()+8)); continue
            now = i == cur
            p.setPen(QPen(QColor('#ffe14d' if now else '#6fa8ff' if it['done'] else '#3a5577'), 2))
            p.setBrush(QColor('#1d4f8f') if it['done'] else QColor(11, 31, 58, 225)); p.drawRoundedRect(r, 10, 10)
            p.setPen(QColor('#ffe14d' if now else '#ffffff')); p.drawText(r, Qt.AlignCenter, str(i+1))
            if it['done']:
                b = QRectF(r.right()-12, r.top()-4, 16, 16); p.setPen(Qt.NoPen); p.setBrush(QColor('#00a24a')); p.drawEllipse(b)
                p.setPen(QPen(QColor('white'), 2)); p.drawPolyline(QPolygonF([QPointF(b.x()+4, b.y()+8.5), QPointF(b.x()+7, b.y()+11.5), QPointF(b.x()+12.5, b.y()+5)]))
    def mousePressEvent(self, e):
        i = int((e.pos().y() - 5)//(self.S + self.GAP)); n = len(self.main.daily['items'])
        if 0 <= i < n: self.main.daily_open(i)
        elif i == n: self.main.set_tool('pick')

class DailyDialog(QDialog):
    """Günün soruları: tarih, isteğe bağlı konu ve öğretmen adı; soruları seç, önizle, gönder."""
    def __init__(self, main):
        super().__init__(main); self.main = main
        from PyQt5.QtWidgets import QCheckBox, QLineEdit, QGridLayout
        self.setWindowTitle('Günün soruları'); self.setModal(True)
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(820, scr.width()-80), min(640, scr.height()-80))
        box = QVBoxLayout(self); box.setContentsMargins(20, 18, 20, 18); box.setSpacing(12)
        self.title = QLabel(); self.title.setStyleSheet('font-size:20px;font-weight:bold;'); box.addWidget(self.title)
        cfg = main.daily_cfg(); grid = QGridLayout(); grid.setHorizontalSpacing(14); grid.setVerticalSpacing(12); box.addLayout(grid)
        grid.addWidget(QLabel('Tarih'), 0, 0); grid.addWidget(QLabel(daily_date_text()), 0, 1)
        self.topic_on = QCheckBox('Konu'); self.topic_on.setChecked(cfg.get('konu_on', True)); grid.addWidget(self.topic_on, 1, 0)
        self.topic = QLineEdit(cfg.get('konu', '') if cfg.get('konu_gun') == daily_today() else ''); grid.addWidget(self.topic, 1, 1)
        self.teacher_on = QCheckBox('Öğretmen'); self.teacher_on.setChecked(cfg.get('ogretmen_on', False)); grid.addWidget(self.teacher_on, 2, 0)
        self.teacher = QLineEdit(cfg.get('ogretmen', '')); self.teacher.setPlaceholderText('Ad Soyad'); grid.addWidget(self.teacher, 2, 1)
        for c in (self.topic, self.teacher): c.setMinimumHeight(48); c.installEventFilter(self)
        self.keyboard = TouchKeyboard(self); self.keyboard.hide()
        self.note = QLabel(); self.note.setWordWrap(True); self.note.setStyleSheet('color:#a9b9cf;'); box.addWidget(self.note)
        self.chips = QWidget(); self.chip_row = QHBoxLayout(self.chips); self.chip_row.setContentsMargins(0, 0, 0, 0); self.chip_row.setSpacing(8)
        box.addWidget(self.chips); box.addStretch(1); box.addWidget(self.keyboard)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row)
        for text, fn, name in (('Soru seç', self.pick, ''), ('Listeyi temizle', self.clear, ''), ('Önizle', self.preview, ''), ('Gönder', self.send, 'primary'), ('Kapat', self.close_save, '')):
            b = QPushButton(text); b.setObjectName(name); b.setMinimumHeight(52); b.clicked.connect(fn); row.addWidget(b, 1)
        self.refresh()
    def eventFilter(self, obj, e):
        # Tahtanın kendi klavyesi her zaman açılmıyor: alana dokununca uygulamanın klavyesi çıkar.
        if e.type() in (QEvent.MouseButtonPress, QEvent.FocusIn) and obj in (self.topic, self.teacher):
            self.keyboard.attach(obj)
            if self.keyboard.isHidden():
                self.keyboard.show(); scr = QApplication.primaryScreen().availableGeometry()
                self.resize(self.width(), min(scr.height()-40, max(self.height(), self.sizeHint().height())))
                self.move(self.x(), max(scr.top()+10, min(self.y(), scr.bottom()-self.height()-10)))
        return False
    def refresh(self):
        items = self.main.daily['items']
        while self.chip_row.count():
            w = self.chip_row.takeAt(0).widget()
            if w: w.deleteLater()
        for i, it in enumerate(items):
            b = QPushButton(str(i+1) + ('' if it['done'] else ' · çözülmedi')); b.setCheckable(True); b.setChecked(it.get('include', it['done']))
            b.setMinimumHeight(44); b.setStyleSheet('QPushButton{padding:0 14px;} QPushButton:!checked{color:#7f8fa6;text-decoration:line-through;}')
            b.toggled.connect(lambda v, it_=it: (it_.__setitem__('include', v), self.main.save_daily(), self.refresh_title())); self.chip_row.addWidget(b)
        self.chip_row.addStretch(1); self.refresh_title()
        self.note.setText('Numaraya dokunarak soruyu sayfaya alın ya da çıkarın. Seçilenler 1’den yeniden sıralanır.' if items else
                          'Henüz soru yok. Dersin başında “Soru seç” ile soruları çerçeveleyin; seçmezseniz derste açtığınız çözüm alanları buraya kendiliğinden gelir.')
    def refresh_title(self):
        k = len(self.main.daily_selected()); self.title.setText('Günün soruları · %d soru' % k)
    def values(self):
        topic = self.topic.text().strip() if self.topic_on.isChecked() else ''
        teacher = self.teacher.text().strip() if self.teacher_on.isChecked() else ''
        self.main.save_daily_cfg(dict(konu_on=self.topic_on.isChecked(), konu=self.topic.text().strip(), konu_gun=daily_today(),
                                      ogretmen_on=self.teacher_on.isChecked(), ogretmen=self.teacher.text().strip()))
        return topic, teacher
    def close_save(self): self.values(); self.accept()
    def pick(self): self.values(); self.accept(); self.main.set_tool('pick')
    def clear(self):
        if QMessageBox.question(self, 'Listeyi temizle', 'Günün soruları listesi boşaltılsın mı? (Çözümler kitapta kalır.)', QMessageBox.Yes|QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
        self.main.clear_daily(); self.refresh()
    def preview(self):
        if not self.main.daily_selected(): self.note.setText('Sayfaya alınacak soru yok.'); return
        topic, teacher = self.values(); path = os.path.join(tempfile.gettempdir(), 'umal-gunun-onizleme.pdf')
        try: self.main.write_daily(path, topic, teacher)
        except Exception as e: QMessageBox.warning(self, 'Önizleme yapılamadı', str(e)); return
        d = QDialog(self); d.setWindowTitle('Önizleme'); scr = QApplication.primaryScreen().availableGeometry(); d.resize(min(900, scr.width()-60), scr.height()-80)
        lay = QVBoxLayout(d); sc = QScrollArea(); sc.setWidgetResizable(True); lay.addWidget(sc, 1); holder = QWidget(); v = QVBoxLayout(holder); v.setSpacing(16)
        doc = fitz.open(path); width = min(820, scr.width()-120)
        for pg in doc:
            z = width/pg.rect.width; pix = pg.get_pixmap(matrix=fitz.Matrix(z, z), alpha=False)
            lab = QLabel(); lab.setPixmap(QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy())); lab.setAlignment(Qt.AlignCenter); v.addWidget(lab)
        doc.close(); sc.setWidget(holder)
        b = QPushButton('Kapat'); b.setMinimumHeight(48); b.clicked.connect(d.accept); lay.addWidget(b); d.exec_()
    def send(self):
        if not self.main.daily_selected(): self.note.setText('Sayfaya alınacak soru yok.'); return
        topic, teacher = self.values()
        try: name = self.main.send_daily(topic, teacher)
        except Exception as e: QMessageBox.warning(self, 'Gönderilemedi', str(e)); return
        self.accept(); self.main.show_toast('Günün soruları hazır: %s\nDrive’daki “Günün Soruları” klasörüne yükleniyor.' % name)

class TouchKeyboard(QWidget):
    """Uygulamanın kendi Türkçe Q klavyesi (dokunmatik tahtada sistem klavyesi açılmayabiliyor)."""
    ROWS = [list('1234567890') + ['⌫'], list('qwertyuıopğü'), list('asdfghjklşi'), ['⇧'] + list('zxcvbnmöç.'), [',', '-', ' ', 'Tamam']]
    def __init__(self, parent):
        super().__init__(parent); self.target = None; self.shift = False; self.keys = []
        from PyQt5.QtWidgets import QGridLayout
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 6, 0, 0); lay.setSpacing(6)
        for row in self.ROWS:
            r = QHBoxLayout(); r.setSpacing(6); lay.addLayout(r)
            for k in row:
                b = QPushButton('boşluk' if k == ' ' else k); b.setFocusPolicy(Qt.NoFocus); b.setFixedHeight(56)
                b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed); b.setStyleSheet('QPushButton{font-size:22px;padding:0;min-height:56px;max-height:56px;}')
                if k == 'Tamam': b.setObjectName('primary')
                b.clicked.connect(lambda checked=False, k_=k: self.press(k_)); r.addWidget(b, 5 if k == ' ' else 2 if k in ('Tamam', '⌫', '⇧') else 1)
                self.keys.append((k, b))
    def attach(self, edit):
        self.target = edit; self.set_shift(not edit.text())   # boş alanda büyük harfle başla
    def set_shift(self, on):
        self.shift = on
        for k, b in self.keys:
            if len(k) == 1 and k.isalpha(): b.setText(self.upper(k) if on else k)
            if k == '⇧': b.setStyleSheet('QPushButton{font-size:22px;padding:0;min-height:56px;max-height:56px;%s}' % ('background:#2f6fd6;color:white;' if on else ''))
    @staticmethod
    def upper(k): return {'i': 'İ', 'ı': 'I'}.get(k, k.upper())
    def press(self, k):
        t = self.target
        if k == 'Tamam': self.hide(); return
        if k == '⇧': self.set_shift(not self.shift); return
        if t is None: return
        if k == '⌫': t.backspace(); return
        t.insert(self.upper(k) if self.shift and k.isalpha() else k)
        if self.shift: self.set_shift(False)

def daily_today():
    import datetime; return datetime.date.today().isoformat()
def daily_date_text():
    import datetime; d = datetime.date.today()
    return '%d %s %d %s' % (d.day, TR_MONTHS[d.month-1], d.year, TR_DAYS[d.weekday()])

class HavuzDialog(QDialog):
    """PDF Havuzu: every board's shared PDFs. Tap to open, remove from this
    board only, add a PDF for all boards, bring back removed ones."""
    def __init__(self, main):
        super().__init__(main); self.main = main
        self.setWindowTitle('PDF Havuzu'); self.setModal(True)
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(900, scr.width()-80), min(760, scr.height()-80))
        box = QVBoxLayout(self); box.setContentsMargins(18, 16, 18, 16); box.setSpacing(10)
        title = QLabel('PDF Havuzu'); title.setStyleSheet('font-size:20px;font-weight:bold;'); box.addWidget(title)
        self.note = QLabel(); self.note.setWordWrap(True); self.note.setStyleSheet('color:#a9b9cf;'); box.addWidget(self.note)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); box.addWidget(self.scroll, 1)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row)
        # One-time: link the pool to the school's Google account (opens the board's browser).
        self.link_button = QPushButton('Havuzu Google hesabına bağla (bir kez)'); self.link_button.setMinimumHeight(48)
        self.link_button.clicked.connect(self.link); self.link_button.hide(); box.insertWidget(2, self.link_button)
        for text, fn, name in (('Havuza PDF ekle', self.add_pdf, 'primary'), ('Şimdi eşitle', self.sync_now, ''), ('Kapat', self.accept, '')):
            b = QPushButton(text); b.setObjectName(name); b.setMinimumHeight(48); b.clicked.connect(fn); row.addWidget(b, 1)
        self.auth = None
        self.shown = None; self.show_removed = False
        self.timer = QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(2000); self.refresh()
    def state(self):
        try:
            with open(os.path.join(havuz_data(), 'durum.json'), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {'known': {}, 'removed': []}
    def status(self):
        try:
            with open(os.path.join(havuz_data(), 'son.json'), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {}
    def refresh(self):
        os.makedirs(HAVUZ_DIR, exist_ok=True)
        files = sorted((n for n in os.listdir(HAVUZ_DIR) if n.lower().endswith('.pdf') and not n.startswith('.')), key=str.lower)
        busy = [n[len('.indiriliyor-'):] for n in os.listdir(HAVUZ_DIR) if n.startswith('.indiriliyor-')]
        removed = self.state().get('removed', []); st = self.status()
        self.link_button.setVisible(st.get('durum') == 'bagli-degil' and os.path.isfile(HAVUZ_RCLONE) and self.auth is None)
        if not havuz_ready(): note = 'Bu cihazda havuz eşitleyicisi kurulu değil; yalnızca bu tahtadaki PDF\'ler görünür.'
        elif st.get('durum') == 'bagli-degil': note = 'Havuz henüz okul hesabına bağlanmadı.'
        elif st.get('durum') == 'hata': note = 'Son eşitleme yapılamadı: ' + st.get('mesaj', '')
        elif st.get('zaman'): note = '%s · son eşitleme %s' % (st.get('mesaj', ''), time.strftime('%H:%M', time.localtime(st['zaman'])))
        else: note = 'İlk eşitleme bekleniyor…'
        if busy: note += '\nİndiriliyor: ' + ', '.join(busy)
        self.note.setText(note)
        key = (tuple(files), tuple(removed), self.show_removed)
        if key == self.shown: return
        self.shown = key
        holder = QWidget(); lay = QVBoxLayout(holder); lay.setContentsMargins(0, 0, 8, 0); lay.setSpacing(6)
        if not files:
            empty = QLabel('Havuzda henüz PDF yok. "Havuza PDF ekle" ile ilk dosyayı ekleyin; birkaç dakika içinde bütün tahtalarda görünür.')
            empty.setWordWrap(True); lay.addWidget(empty)
        for name in files:
            line = QHBoxLayout(); line.setSpacing(6)
            size = os.path.getsize(os.path.join(HAVUZ_DIR, name)) / 1048576
            b = QPushButton('%s   ·   %s MB' % (os.path.splitext(name)[0], ('%.1f' % size).replace('.', ','))); b.setIcon(tool_icon('PDF aç'))
            b.setStyleSheet('QPushButton{text-align:left;padding:8px 14px;font-size:16px;}'); b.setMinimumHeight(52)
            b.clicked.connect(lambda checked=False, n=name: self.open(n)); line.addWidget(b, 1)
            r = QPushButton('Bu tahtadan kaldır'); r.setMinimumHeight(52); r.clicked.connect(lambda checked=False, n=name: self.remove(n)); line.addWidget(r)
            lay.addLayout(line)
        if removed:
            t = QPushButton(('▾ ' if self.show_removed else '▸ ') + 'Bu tahtadan kaldırılanlar (%d)' % len(removed)); t.setMinimumHeight(44)
            t.setStyleSheet('QPushButton{text-align:left;padding:6px 14px;}'); t.clicked.connect(self.toggle_removed); lay.addWidget(t)
            if self.show_removed:
                for name in removed:
                    line = QHBoxLayout(); lab = QLabel('   ' + os.path.splitext(name)[0]); line.addWidget(lab, 1)
                    g = QPushButton('Geri al'); g.setMinimumHeight(44); g.clicked.connect(lambda checked=False, n=name: self.restore(n)); line.addWidget(g)
                    lay.addLayout(line)
        lay.addStretch(); self.scroll.setWidget(holder)
    def toggle_removed(self):
        self.show_removed = not self.show_removed; self.shown = None; self.refresh()
    def open(self, name):
        self.accept(); self.main.open_pdf_path(os.path.join(HAVUZ_DIR, name))
    def remove(self, name):
        if QMessageBox.question(self, 'Bu tahtadan kaldır', '“%s” bu tahtadan kaldırılsın mı?\n\nHavuzda ve diğer tahtalarda kalır. İsterseniz “Bu tahtadan kaldırılanlar” listesinden geri alabilirsiniz.' % os.path.splitext(name)[0],
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
        try: os.remove(os.path.join(HAVUZ_DIR, name))
        except OSError as e: QMessageBox.warning(self, 'Kaldırılamadı', str(e)); return
        self.main.run_havuz('--hemen'); self.shown = None; self.refresh()
    def restore(self, name):
        self.main.run_havuz('--geri-al', name); self.note.setText('“%s” yeniden indiriliyor…' % os.path.splitext(name)[0])
    def add_pdf(self):
        paths, _ = QFileDialog.getOpenFileNames(self, 'Havuza PDF ekle', os.path.expanduser('~'), 'PDF dosyaları (*.pdf)')
        added = 0
        for path in paths:
            if os.path.realpath(os.path.dirname(path)) == os.path.realpath(HAVUZ_DIR): continue
            name = os.path.basename(path); target = os.path.join(HAVUZ_DIR, name); k = 2
            while os.path.exists(target): target = os.path.join(HAVUZ_DIR, '%s (%d).pdf' % (os.path.splitext(name)[0], k)); k += 1
            try: shutil.copy2(path, target); added += 1
            except OSError as e: QMessageBox.warning(self, 'Eklenemedi', str(e))
        if added:
            self.shown = None; self.refresh()
            self.note.setText('%d PDF eklendi, havuza gönderiliyor…' % added); self.main.run_havuz('--hemen')
    def sync_now(self):
        self.main.run_havuz('--hemen'); self.note.setText('Eşitleniyor…')
    def link(self):
        self.auth = QProcess(self); self.auth.setProcessChannelMode(QProcess.MergedChannels)
        self.auth.finished.connect(self.linked); self.link_button.hide()
        self.auth.start(HAVUZ_RCLONE, ['authorize', 'drive', '--drive-scope', 'drive.file'])
        self.note.setText('Tarayıcı açılıyor: okul hesabıyla giriş yapıp izin verin, sonra buraya dönün…')
    def linked(self, *args):
        out = bytes(self.auth.readAll()).decode('utf-8', 'replace'); self.auth = None
        token = token_from_authorize(out)
        if not token:
            self.note.setText('Bağlantı tamamlanamadı. Yeniden deneyin.'); self.shown = None; self.refresh(); return
        conf = '[havuz]\ntype = drive\nscope = drive.file\ntoken = %s\n' % token
        folder = havuz_data(); os.makedirs(folder, exist_ok=True); path = os.path.join(folder, 'rclone.conf')
        with open(path, 'w', encoding='utf-8') as f: f.write(conf)
        os.chmod(path, 0o600); self.main.run_havuz('--hemen')
        # Other boards get the link through the update: show it once to send to Claude.
        box = QDialog(self); box.setWindowTitle('Havuz bağlandı'); lay = QVBoxLayout(box)
        lab = QLabel('Bu tahta havuza bağlandı. Diğer tahtaların da bağlanması için aşağıdaki metni kopyalayıp Claude\'a gönderin; güncelleme ile bütün tahtalara dağıtılır.')
        lab.setWordWrap(True); lay.addWidget(lab)
        from PyQt5.QtWidgets import QPlainTextEdit
        text = QPlainTextEdit(conf); text.setReadOnly(True); text.setMinimumSize(700, 180); lay.addWidget(text)
        copy = QPushButton('Kopyala'); copy.setMinimumHeight(48); copy.clicked.connect(lambda: (QApplication.clipboard().setText(conf), copy.setText('Kopyalandı')))
        lay.addWidget(copy); box.exec_()
UPDATE_REQUEST = '/var/lib/umal-tahta/denetle'
UPDATE_LOG = '/var/log/umal-guncelle.log'
UPDATE_RESULTS = ('Güncel:', 'Kuruldu:', 'Bağlantı yok', 'TUTMADI', 'başarısız', 'yapılamadı', 'uyuşmuyor', 'geçersiz', 'okunamadı')

def installed_version():
    try:
        import subprocess
        v = subprocess.run(['dpkg-query', '-W', '-f=${Version}', 'umal-tahta'], capture_output=True, text=True, timeout=5).stdout.strip()
        return v or 'bilinmiyor'
    except Exception:
        return 'bilinmiyor'

class PanelSettings(QDialog):
    """Ayarlar: tick the buttons the left panel should show."""
    def __init__(self, main):
        super().__init__(main); self.main = main
        self.setWindowTitle('Ayarlar'); self.setModal(True)
        box = QVBoxLayout(self); box.setContentsMargins(18, 16, 18, 16); box.setSpacing(10)
        head = QLabel('Tahta görünümü'); head.setStyleSheet('font-size:18px;font-weight:bold;'); box.addWidget(head)
        look = QHBoxLayout(); look.setSpacing(8); box.addLayout(look)
        for text, fn, enabled in (('Tahta arka planı', main.open_backgrounds, main.background is not None), ('Tema', main.open_theme_picker, True)):
            b = QPushButton(text); b.setMinimumHeight(46); b.setEnabled(enabled); look.addWidget(b, 1)
            b.clicked.connect(lambda checked=False, f_=fn: (self.accept(), f_()))
            if not enabled: b.setToolTip('Arka plan boş tahtada seçilir; PDF\'de kullanılmaz')
        title = QLabel('Paneldeki düğmeler'); title.setStyleSheet('font-size:18px;font-weight:bold;margin-top:8px;'); box.addWidget(title)
        note = QLabel('İşaretli olanlar sol panelde görünür. Kaldırılanlar silinmez, istediğiniz an geri açılır.'); note.setWordWrap(True); box.addWidget(note)
        grid = QGridLayout(); grid.setHorizontalSpacing(8); grid.setVerticalSpacing(8); box.addLayout(grid)
        self.checks = {}
        for i, (key, label, widgets) in enumerate(main.panel_items):
            c = QCheckBox(label); c.setChecked(key not in main.panel_hidden); c.setMinimumHeight(46)
            c.setStyleSheet('QCheckBox{font-size:16px;padding:4px 10px;border:1px solid #526780;border-radius:8px;}QCheckBox::indicator{width:26px;height:26px;}')
            c.toggled.connect(self.changed); grid.addWidget(c, i//3, i%3); self.checks[key] = c
        # Güncelleme: the button writes to a request file; a systemd path unit
        # starts the signed-package updater (no password needed).
        upd = QHBoxLayout(); upd.setSpacing(10); box.addLayout(upd)
        self.update_button = QPushButton('Güncellemeyi denetle'); self.update_button.setIcon(tool_icon('İleri al'))
        self.update_button.setMinimumHeight(46); self.update_button.clicked.connect(self.check_update); upd.addWidget(self.update_button)
        self.update_note = QLabel('Kurulu sürüm: ' + installed_version()); self.update_note.setWordWrap(True); upd.addWidget(self.update_note, 1)
        self.update_timer = QTimer(self); self.update_timer.setInterval(1000); self.update_timer.timeout.connect(self.poll_update)
        row = QHBoxLayout(); box.addLayout(row)
        reset = QPushButton('Varsayılana dön'); reset.clicked.connect(self.reset); row.addWidget(reset)
        meter = QPushButton('Kalem ölçümü'); meter.setIcon(tool_icon('Kalem')); meter.setToolTip('10 saniye yazın: tahtanın kalem hızını ölçer')
        meter.clicked.connect(lambda: (self.accept(), QTimer.singleShot(0, self.main.start_pen_meter))); row.addWidget(meter); row.addStretch()
        ok = QPushButton('Tamam'); ok.setObjectName('primary'); ok.clicked.connect(self.accept); row.addWidget(ok)
        for b in (reset, meter, ok): b.setMinimumHeight(46); b.setMinimumWidth(150)
    def check_update(self):
        try:
            self.log_start = os.path.getsize(UPDATE_LOG) if os.path.exists(UPDATE_LOG) else 0
            with open(UPDATE_REQUEST, 'w') as f: f.write(str(time.time()))
        except OSError:
            self.update_note.setText('Güncelleyici bu cihazda kurulu değil.'); return
        self.update_button.setEnabled(False); self.update_note.setText('Denetleniyor…')
        self.update_waited = 0; self.update_timer.start()
    def poll_update(self):
        self.update_waited += 1
        try:
            with open(UPDATE_LOG, encoding='utf-8', errors='replace') as f: f.seek(self.log_start); lines = [l.strip() for l in f if l.strip()]
        except OSError: lines = []
        text = lines[-1].split('  ', 1)[-1] if lines else ''   # drop the time stamp
        done = [k for k in UPDATE_RESULTS if k in text]
        if text and not done: self.update_note.setText(text)   # e.g. "Yeni sürüm bulundu … İndiriliyor…"
        if done or self.update_waited >= 300:
            self.update_timer.stop(); self.update_button.setEnabled(True)
            if not done: self.update_note.setText('Yanıt alınamadı. Biraz sonra yeniden deneyin.')
            elif 'Kuruldu' in text: self.update_note.setText('Kuruldu: %s. Uygulamayı kapatıp açınca yeni sürüm başlar.' % text.split(':', 1)[1].strip().split(' ')[0].rstrip('.'))
            elif 'Güncel' in text: self.update_note.setText('Uygulama güncel · ' + installed_version())
            elif 'Bağlantı yok' in text: self.update_note.setText('İnternete ulaşılamadı. Bağlantı gelince tahta kendisi de denetler.')
            else: self.update_note.setText(text)
    def changed(self):
        self.main.apply_panel({k for k, c in self.checks.items() if not c.isChecked()})
    def reset(self):
        for c in self.checks.values(): c.blockSignals(True); c.setChecked(True); c.blockSignals(False)
        self.main.apply_panel(set())

AUTO_PEN_MS = 4000
AUTO_PEN_TOOLS = ('eraser', 'area_eraser')

class Board(QWidget):
    def __init__(self, owner):
        super().__init__()
        self.owner = owner
        self.image = QImage()
        self.scale = 1
        self.active = None
        self.erasing = False
        self.pointer = None
        self.pan = None
        self.raw = []
        # Fast ink (screen mode): committed strokes are cached once per stroke;
        # only the new segment is drawn and only its small area is repainted.
        self.snapshot = None; self.drawn = 0; self.cum = []
        self.last_erase = None
        self.layers = None; self.tip = None; self.fl = None
        self.fading = []   # Neon kalem strokes: [stroke, page, (fade end)]
        self.fade_timer = QTimer(self); self.fade_timer.timeout.connect(self.fade_tick)
        self.selected=[];self.selection_page=None;self.transform=None
        self.snapped=False;self.hold_anchor=None
        self.hold_timer=QTimer(self);self.hold_timer.setSingleShot(True)
        self.hold_timer.timeout.connect(self.snap_shape)
        self.pending_snap=None
        # 4 s after the last erase with no new erase, the pen comes back by itself.
        self.auto_pen=QTimer(self);self.auto_pen.setSingleShot(True);self.auto_pen.setInterval(AUTO_PEN_MS)
        self.auto_pen.timeout.connect(lambda:self.owner.tool in AUTO_PEN_TOOLS and self.owner.set_tool('pen'))
        self.erasing=False
        self.release_timer=QTimer(self);self.release_timer.setSingleShot(True)
        self.release_timer.timeout.connect(self.snap_released_shape)
        self.setAttribute(Qt.WA_AcceptTouchEvents)
        self.setMouseTracking(True)

    def paintEvent(self, event):
        p = QPainter(self)
        if self.snapshot is not None and self.active and not self.snapped and self.snap_rect.contains(event.rect()):
            r = event.rect(); dpr = self.snapshot.devicePixelRatio(); o = self.snap_rect.topLeft()
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.drawPixmap(QRectF(r), self.snapshot, QRectF((r.x()-o.x())*dpr, (r.y()-o.y())*dpr, r.width()*dpr, r.height()*dpr))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
            first = max(0, self.drawn-1)
            if self.layers:
                # Styled pen: each pass = committed layer + the moving tail,
                # made grainy / see-through as a whole, then laid on the page.
                src = QRectF((r.x()-o.x())*dpr, (r.y()-o.y())*dpr, r.width()*dpr, r.height()*dpr).toAlignedRect()
                for layer, (pen, opacity, mask) in zip(self.layers, style_passes(self.active)):
                    tmp = layer.copy(src); tmp.setDevicePixelRatio(dpr)
                    q = QPainter(tmp); q.setRenderHint(QPainter.Antialiasing); q.translate(-r.x(), -r.y()); q.scale(self.scale, self.scale)
                    self.draw_segment(q, self.active, first, len(self.active['points']), pens=[pen])
                    if mask: apply_mask(q, mask, r)
                    q.end(); p.setOpacity(opacity); p.drawPixmap(QRectF(r), tmp, QRectF(tmp.rect())); p.setOpacity(1)
            else:
                p.scale(self.scale, self.scale); p.setRenderHint(QPainter.Antialiasing)
                self.draw_segment(p, self.active, first, len(self.active['points']), self.cum[first] if first < len(self.cum) else 0, self.direct_pens())
            self.paint_tip(p)
            return
        if self.cacheable(True) and self.base_valid(event.rect()):
            r = event.rect(); dpr = self.base.devicePixelRatio(); o = self.base_rect.topLeft()
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.drawPixmap(QRectF(r), self.base, QRectF((r.x()-o.x())*dpr, (r.y()-o.y())*dpr, r.width()*dpr, r.height()*dpr))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
            if self.active:   # çizilmekte olan şekil/pergel: hazır sayfanın üstüne
                p.save(); p.scale(self.scale, self.scale); p.setRenderHint(QPainter.Antialiasing); self.draw_mark(p, self.active, QRectF(r)); p.restore()
            self.paint_tip(p); return
        if getattr(self.owner,'overlay_mode',False):
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.fillRect(self.rect(),QColor(getattr(self.owner,'backdrop',None) or QColor(0,0,0,1)))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
        else:
            p.fillRect(self.rect(), Qt.white)
            p.setRenderHint(QPainter.SmoothPixmapTransform)
            page_rect = self.owner.doc[self.owner.page].rect
            top = getattr(self, 'image_height', None) or page_rect.height
            pattern = getattr(self, 'pattern', None); r = event.rect(); k = self.scale
            if pattern in BOARD_FILLS:   # same colours as make_board()
                p.fillRect(QRectF(r.left(), max(r.top(), top*k), r.width()+1, r.bottom()+1-max(r.top(), top*k)), QColor.fromRgbF(*BOARD_FILLS[pattern]))
            if pattern == 'grid':   # same lines as make_board('grid')
                p.setPen(QPen(QColor.fromRgbF(.55,.64,.76), .9*k)); p.setRenderHint(QPainter.Antialiasing)
                for x in range(int(r.left()/k/24)*24, int(r.right()/k)+25, 24): p.drawLine(QPointF(x*k, max(r.top(), top*k)), QPointF(x*k, r.bottom()+1))
                for y in range(max(int(r.top()/k/24)*24, math.ceil(top/24)*24), int(r.bottom()/k)+25, 24): p.drawLine(QPointF(r.left(), y*k), QPointF(r.right()+1, y*k))
            elif pattern == 'dots':   # same dots as make_board('dots')
                p.setPen(Qt.NoPen); p.setBrush(QColor.fromRgbF(.40,.50,.64)); p.setRenderHint(QPainter.Antialiasing)
                for x in range(max(24, int(r.left()/k/24)*24), min(int(self.width()/k), int(r.right()/k)+25), 24):
                    for y in range(max(int(r.top()/k/24)*24, math.ceil(top/24)*24, 24), int(r.bottom()/k)+25, 24): p.drawEllipse(QPointF(x*k, y*k), 1.6*k, 1.6*k)
                p.setBrush(Qt.NoBrush)
            p.drawImage(QRectF(0,0,page_rect.width*self.scale,top*self.scale),self.image)
        p.scale(self.scale, self.scale)
        p.setRenderHint(QPainter.Antialiasing)
        for s in self.owner.marks.get(self.owner.page, []) + ([self.active] if self.active else []):
            self.draw_mark(p, s, QRectF(event.rect()))
        self.paint_daily(p)
        self.paint_fading(p, QRectF(event.rect()))
        r=self.selection_rect()
        if r is not None and self.owner.tool=='smart':
            p.setOpacity(1);p.setBrush(Qt.NoBrush)
            p.setPen(QPen(QColor('#2394ff'),2/self.scale,Qt.DashLine));p.drawRect(r)
            p.setPen(QPen(QColor('#2394ff'),1/self.scale));p.setBrush(Qt.white)
            for corner in (r.topLeft(),r.topRight(),r.bottomLeft(),r.bottomRight()):
                p.drawRect(QRectF(corner.x()-6/self.scale,corner.y()-6/self.scale,12/self.scale,12/self.scale))
            # delete badge (trash) beside the selection
            c=self.delete_badge(r);rad=20/self.scale
            p.setPen(QPen(QColor('#ffffff'),2/self.scale));p.setBrush(QColor('#e23b4d'));p.drawEllipse(c,rad,rad)
            k=1/self.scale;p.setPen(QPen(QColor('#ffffff'),2.2*k,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
            p.drawPolyline(QPolygonF([QPointF(c.x()-7*k,c.y()-5*k),QPointF(c.x()-5.5*k,c.y()+9*k),QPointF(c.x()+5.5*k,c.y()+9*k),QPointF(c.x()+7*k,c.y()-5*k)]))
            p.drawLine(QPointF(c.x()-10*k,c.y()-7*k),QPointF(c.x()+10*k,c.y()-7*k));p.drawLine(QPointF(c.x()-3*k,c.y()-10*k),QPointF(c.x()+3*k,c.y()-10*k))
        self.paint_tip(p)

    def draw_mark(self, p, s, rect):
        """Tek bir işareti çizer (tam çizimde ve hazır sayfa görüntüsüne eklerken aynı yol)."""
        if s['tool'] == 'geo':
            r_ = self.owner.doc[self.owner.page].rect
            try: draw_geo(p, s, r_.width, r_.height, getattr(self, 'geo_sel', ()))
            except Exception as ex: print('geo çizim:', ex)
            sig = (id(s), s.get('rev'))
            if sig != getattr(self, 'geo_sig', None): self.geo_sig = sig; QTimer.singleShot(0, self.owner.geo_panel_sync)
            return
        if s['tool'] == 'compass':   # pergel önizlemesi: kılavuz daire, merkez, açıklık, yay
            c = QPointF(*s['center']); r = s['r']; k = 1/self.scale; p.setOpacity(1)
            if r > 0:
                p.setPen(QPen(QColor(139, 92, 246, 150), 1.6*k, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, r, r)
                q = QPointF(*s.get('pen', s['center'])); p.setPen(QPen(QColor('#8b5cf6'), 2.2*k)); p.drawLine(c, q)
                p.save(); p.translate((c.x()+q.x())/2, (c.y()+q.y())/2); p.scale(k, k)   # ekranda sabit, okunaklı etiket
                f = p.font(); f.setPixelSize(24); f.setBold(True); p.setFont(f); txt = 'r = %s cm' % fmt_num(r/28.3465, 1)
                bw = p.fontMetrics().horizontalAdvance(txt) + 24; box = QRectF(14, -50, bw, 38)
                p.setPen(QPen(QColor('#8b5cf6'), 2)); p.setBrush(QColor(255, 255, 255, 235)); p.drawRoundedRect(box, 19, 19)
                p.setPen(QColor('#5b21b6')); p.drawText(box, Qt.AlignCenter, txt); p.restore(); p.setBrush(Qt.NoBrush)
            p.setPen(Qt.NoPen); p.setBrush(QColor('#8b5cf6')); p.drawEllipse(c, 5*k, 5*k); p.setBrush(Qt.NoBrush)
            if len(s['points']) > 1: p.setPen(stroke_pen(dict(s, tool='pen'))); p.drawPath(stroke_path(s['points']))
            return
        if s['tool'] in ('select', 'smart', 'solution', 'whiteout', 'erase_frame', 'postit_frame', 'pick_frame'):
            if len(s['points']) < 2: return
            r = QRectF(QPointF(*s['points'][0]),QPointF(*s['points'][1])).normalized()
            p.setOpacity(1)
            if s['tool'] == 'whiteout':
                p.setRenderHint(QPainter.Antialiasing,False)
                p.fillRect(r,Qt.white)
                p.setRenderHint(QPainter.Antialiasing,True)
            elif s['tool'] == 'pick_frame':
                p.setPen(QPen(QColor('#ffb400'),3/self.scale,Qt.DashLine)); p.setBrush(QColor(255,180,0,30)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            elif s['tool'] == 'postit_frame':
                p.setPen(QPen(QColor('#d9a400'),2.5/self.scale,Qt.DashLine)); p.setBrush(QColor(255,226,122,40)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            elif s['tool'] == 'erase_frame':
                p.setPen(QPen(QColor('#e23b4d'),2/self.scale,Qt.DashLine)); p.setBrush(QColor(226,59,77,28)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            else:
                p.setPen(QPen(QColor('#109c70'),2/self.scale,Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(r)
            return
        p.setOpacity(.3 if s['tool'] == 'highlight' else 1)
        outline = nib_outline(s)
        if outline:
            p.setPen(Qt.NoPen); p.setBrush(QColor(s['color']))
            p.drawPolygon(QPolygonF([QPointF(*pt) for pt in outline]),Qt.WindingFill)
            if s.get('w'):   # Akıcı: round, tapered ends
                for i in (0, -1):
                    r = max(.25, s['width']/2*s['w'][i]); p.drawEllipse(QPointF(*s['points'][i]), r, r)
            p.setBrush(Qt.NoBrush)
            return
        pts = s['points']; passes = style_passes(s)
        if passes: paint_passes(p, stroke_path(pts), passes, rect, self.devicePixelRatioF()); return
        p.setPen(stroke_pen(s))
        if len(pts) == 1: p.drawPoint(QPointF(*pts[0]))
        else: p.drawPath(stroke_path(pts))
    # --- Hazır sayfa görüntüsü: her yeni çizgide eski çizgiler yeniden çizilmez -------
    def mark_key(self):
        o = self.owner; ms = o.marks.get(o.page, [])
        fp = tuple((id(m), len(m['points']), tuple(m['points'][0]) if m['points'] else (), tuple(m['points'][-1]) if m['points'] else (), m.get('color'), m.get('width'), m.get('rev')) for m in ms)
        return (id(o.doc), o.page, round(self.scale, 6), self.width(), self.height(), self.image.cacheKey(),
                getattr(self, 'pattern', None), getattr(self, 'image_height', None), tuple(getattr(self, 'geo_sel', ()))), fp
    def cacheable(self, active_ok=False):
        o = self.owner
        if getattr(o, 'overlay_mode', False) or self.fading or self.transform or (self.active and not active_ok): return False
        if o.tool == 'smart' and self.selection_rect() is not None: return False
        d = getattr(o, 'daily', None)
        if d and o.solution_origin is None and any(it['tab'] == o.current_tab() and it['page'] == o.page for it in d['items']): return False
        return True
    def ensure_base(self):
        """Önizleme için görünen sayfanın hazır görüntüsü (yoksa bir kez çizilir)."""
        r = self.visibleRegion().boundingRect()
        if r.isEmpty() or not self.cacheable(): return
        if not (self.base_valid(r) and self.base_rect == r):
            self.base = self.grab(r); self.base_rect = QRect(r); self.base_key = self.mark_key()
    def base_valid(self, rect):
        return getattr(self, 'base', None) is not None and self.base_rect.contains(rect) and self.base_key == self.mark_key()
    def refresh_base(self, added):
        """Biten çizgiyi hazır görüntüye ekler (çizim sırası aynı: sonuç tam çizimle aynı)."""
        if getattr(self, 'base', None) is None: return
        if not self.cacheable(): self.base = None; return
        page, fp = self.mark_key()
        if not fp or fp[-1][0] != id(added) or self.base_key != (page, fp[:-1]): self.base = None; return
        q = QPainter(self.base); o = self.base_rect.topLeft(); q.translate(-o.x(), -o.y()); q.scale(self.scale, self.scale)
        q.setRenderHint(QPainter.Antialiasing); self.draw_mark(q, added, QRectF(0, 0, self.base_rect.width(), self.base_rect.height())); q.end()
        self.base_key = (page, fp)
    def paint_daily(self, p):
        o = self.owner
        if getattr(o, 'daily', None) is None or o.solution_origin is not None or getattr(o, 'overlay_mode', False): return
        tab = o.current_tab(); k = 1/self.scale; f = p.font(); f.setPixelSize(max(1, int(14*k))); f.setBold(True); p.setFont(f); p.setOpacity(1)
        for i, it in enumerate(o.daily['items']):
            if it['tab'] != tab or it['page'] != o.page: continue
            r = QRectF(QPointF(it['rect'][0], it['rect'][1]), QPointF(it['rect'][2], it['rect'][3]))
            p.setPen(QPen(QColor('#ffb400'), 2.5*k, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawRect(r)
            b = QRectF(r.left()-12*k, r.top()-12*k, 24*k, 24*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#00a24a') if it['done'] else QColor('#ffb400')); p.drawEllipse(b)
            p.setPen(QColor('white') if it['done'] else QColor('#3d2a00')); p.drawText(b, Qt.AlignCenter, str(i+1))
        p.setBrush(Qt.NoBrush)
    @staticmethod
    def draw_segment(p, s, a, b, offset=0, pens=None):
        pts = s['points'][a:b]
        if not pts: return
        ws = s.get('w')
        if ws and len(ws) == len(s['points']):   # Akıcı kalem: width per point
            half = s['width']/2; p.setPen(Qt.NoPen); p.setBrush(QColor(s['color']))
            for i in range(a, min(b, len(ws))):
                x, y = s['points'][i]; r = max(.25, half*ws[i]); p.drawEllipse(QPointF(x, y), r, r)
                if i > a:
                    (x0, y0), r0 = s['points'][i-1], max(.25, half*ws[i-1]); d = math.hypot(x-x0, y-y0)
                    if d > 1e-6:
                        nx, ny = -(y-y0)/d, (x-x0)/d
                        p.drawPolygon(QPolygonF([QPointF(x0+nx*r0, y0+ny*r0), QPointF(x+nx*r, y+ny*r), QPointF(x-nx*r, y-ny*r), QPointF(x0-nx*r0, y0-ny*r0)]))
            p.setBrush(Qt.NoBrush); return
        for pen in (pens if pens is not None else [stroke_pen(s, offset)]):
            p.setPen(pen)
            if len(pts) == 1: p.drawPoint(QPointF(*pts[0]))
            else: p.drawPath(stroke_path(pts))
    # Kalem ucu göstergesi: a ring at the pen tip showing the ink size (or the
    # eraser size), drawn in dark and light so it shows on any background.
    TIP_TOOLS = ('pen', 'dash', 'highlight', 'eraser')
    ERASER_TOOLS = ('eraser',)   # ring stays while rubbing; pens show it only when hovering
    def tip_radius(self):
        tool = self.owner.tool
        if tool == 'eraser': return 12
        w = self.owner.width.value()*(4 if tool == 'highlight' else 1)
        style = getattr(self.owner, 'pen_style', 'normal') if tool == 'pen' else None
        w *= {'neon': .9}.get(style, STYLE_SPAN.get(style, 1))
        return max(5, w*self.scale/2 + 2)
    def tip_rect(self):
        if self.tip is None: return None
        r = self.tip_radius() + 3
        return QRectF(self.tip.x()-r, self.tip.y()-r, 2*r, 2*r).toAlignedRect()
    def set_tip(self, pos):
        new = QPointF(pos) if pos is not None and self.owner.tool in self.TIP_TOOLS and not self.pan else None
        old = self.tip_rect(); self.tip = new; now = self.tip_rect()
        for r in (old, now):
            if r is not None: self.update(r)
    def paint_tip(self, p):
        if self.tip is None or self.snapped: return
        p.save(); p.resetTransform(); p.setOpacity(1); p.setRenderHint(QPainter.Antialiasing); p.setBrush(Qt.NoBrush)
        r = self.tip_radius()
        p.setPen(QPen(QColor(10, 20, 35, 215), 3.4)); p.drawEllipse(self.tip, r, r)
        p.setPen(QPen(QColor(255, 255, 255, 235), 1.4)); p.drawEllipse(self.tip, r, r)
        p.restore()
    def cr_steps(self, a, b): return cr_steps(a, b, self.scale)
    def ruler_point(self, vp):
        """Görüntü noktasını cetvel kenarına izdüşürüp sayfa koordinatına çevirir."""
        (ox, oy), (dx, dy), (t0, t1) = self.ruler_edge
        t = max(t0, min(t1, (vp.x() - ox)*dx + (vp.y() - oy)*dy))
        q = self.mapFrom(self.owner.ruler.parentWidget(), QPoint(0, 0))   # cetvel katmanından tahtaya kayma
        x, y = ox + dx*t + q.x(), oy + dy*t + q.y()
        return [x/self.scale, y/self.scale]
    # ---- Canlı koordinat düzlemi ----
    def geo_model(self, create=False):
        ms = self.owner.marks.setdefault(self.owner.page, []); m = geo_find(ms)
        if m is None and create:
            m = dict(tool='geo', points=[[-1000.0, -1000.0]], color='#000000', width=1, rev=0, P=[], O=[]); ms.insert(0, m)
        return m
    def geo_math(self, pt):
        r = self.owner.doc[self.owner.page].rect
        return (pt[0] - r.width/2)/GEO_U, (r.height/2 - pt[1])/GEO_U
    def geo_touch(self, m):
        m['rev'] = m.get('rev', 0) + 1; self.owner.changed(); self.update()
        gb = getattr(self.owner, 'geo_bar', None)
        if gb is not None: gb.sync()
        self.owner.geo_panel_sync()
    def geo_valid_sel(self, m):
        n = len(m['P']) if m else 0; k = len(m['O']) if m else 0
        self.geo_sel = [t for t in getattr(self, 'geo_sel', []) if (t[0] == 'p' and t[1] < n) or (t[0] == 'o' and t[1] < k and m['O'][t[1]]['t'] in GEO_LINES)]
    def geo_select(self, item):
        sel = list(getattr(self, 'geo_sel', []))
        if item in sel: sel.remove(item)
        else: sel = (sel + [item])[-2:]
        self.geo_sel = sel
    def geo_point(self, x, y):
        """(x, y) noktasını koyar; orada nokta varsa onu seçer."""
        m = self.geo_model(True); self.geo_valid_sel(m)
        for i, (px, py, _) in enumerate(m['P']):
            if gq(px) == x and gq(py) == y: self.geo_select(('p', i)); self.geo_touch(m); return
        self.owner.checkpoint(); used = {n for _, _, n in m['P']}
        name = next((c for c in GEO_LETTERS if c not in used), None) or next(c + str(i) for i in range(1, 99) for c in GEO_LETTERS if c + str(i) not in used)
        m['P'].append([float(x), float(y), name]); self.geo_select(('p', len(m['P']) - 1)); self.geo_touch(m)
    def geo_begin(self, pt):
        self.clear_selection(); m = self.geo_model(); tol = 18/self.scale
        if m is not None:
            self.geo_valid_sel(m); P, vals = geo_eval(m); r = self.owner.doc[self.owner.page].rect
            cx, cy = r.width/2, r.height/2
            best = None
            for i, (x, y) in enumerate(P):
                d = math.hypot(cx + float(x)*GEO_U - pt[0], cy - float(y)*GEO_U - pt[1])
                if d <= tol and (best is None or d < best[0]): best = (d, i)
            if best is not None:
                self.geo_drag = dict(i=best[1], moved=False); return
            mx, my = self.geo_math(pt)
            for k, v in enumerate(vals):
                L = v.get('L')
                if L is None: continue
                A, B, C = (float(t) for t in L)
                if abs(A*mx + B*my - C)/math.hypot(A, B)*GEO_U <= tol*.7:
                    self.geo_select(('o', k)); self.geo_touch(m); return
        mx, my = self.geo_math(pt); self.geo_point(_Fr(round(mx)), _Fr(round(my)))
    def geo_move(self, pt):
        d = self.geo_drag; m = self.geo_model()
        if m is None or d['i'] >= len(m['P']): return
        x, y = (round(v) for v in self.geo_math(pt)); P = m['P'][d['i']]
        if (gq(P[0]), gq(P[1])) == (x, y): return
        if any(gq(a) == x and gq(b) == y for j, (a, b, _) in enumerate(m['P']) if j != d['i']): return
        if not d['moved']: self.owner.checkpoint(); d['moved'] = True
        P[0], P[1] = float(x), float(y); self.geo_touch(m)
    def geo_end(self):
        d = self.geo_drag; self.geo_drag = None; m = self.geo_model()
        if m is not None and not d['moved']: self.geo_select(('p', d['i'])); self.geo_touch(m)

    def compass_move(self, pt):
        s = self.active; c = s['center']; st = self.compass
        r = math.dist(pt, c); ang = math.atan2(pt[1]-c[1], pt[0]-c[0]); s['pen'] = list(pt)
        prev = st['prev']; st['prev'] = (r, ang)
        if prev is None: s['r'] = r; return
        da = (ang - prev[1] + math.pi) % (2*math.pi) - math.pi
        if st['phase'] == 'radius':
            s['r'] = r
            if r > 14/self.scale and r*abs(da) > 1.5*abs(r - prev[0]):
                st['sweep'] += da
                if abs(st['sweep']) > math.radians(8):   # çevirmeye başladı: açıklık sabit
                    st['phase'] = 'arc'; st['a0'] = ang - st['sweep']; st['a'] = ang
            else: st['sweep'] = 0.0
        else:
            st['a'] = max(st['a0'] - 2*math.pi, min(st['a0'] + 2*math.pi, st['a'] + da))
        if st['phase'] == 'arc':
            R = s['r']; a0, a1 = st['a0'], st['a']; n = max(2, int(abs(a1 - a0)/math.radians(2)) + 1)
            s['points'] = [[c[0] + R*math.cos(a0 + (a1 - a0)*i/(n-1)), c[1] + R*math.sin(a0 + (a1 - a0)*i/(n-1))] for i in range(n)]
    def smooth_append(self):
        """Incremental smooth_points(): identical result, but only the newest
        curve piece is computed (no full recompute on every pen movement)."""
        raw, pts = self.raw, self.active['points']
        if self.fl is not None:
            # Akıcı: Catmull–Rom through the samples. The piece up to the
            # second-last sample is final (drawn once into the cache); the
            # last piece stays a provisional straight tail until the next
            # sample (or the lift) settles its curve.
            if len(raw) < 3: self.active['points'] = [list(p) for p in raw]; return
            pts.pop(); n = len(raw)
            p0 = raw[n-4] if n >= 4 else raw[n-3]
            pts.extend(catmull_rom(p0, raw[n-3], raw[n-2], raw[n-1], self.cr_steps(raw[n-3], raw[n-2])))
            pts.append(list(raw[-1])); return
        if len(raw) < 3: self.active['points'] = list(raw); return
        pts.pop()
        start = pts[-1] if len(raw) > 3 else raw[0]
        if len(raw) == 3: del pts[1:]
        i = len(raw)-2; control = raw[i]
        end = [(raw[i][j]+raw[i+1][j])/2 for j in (0,1)]
        steps = max(2,min(16,int(math.hypot(end[0]-start[0],end[1]-start[1])/1.2)+1))
        for k in range(1,steps+1):
            t = k/steps
            pts.append([(1-t)**2*start[j]+2*(1-t)*t*control[j]+t*t*end[j] for j in (0,1)])
        pts.append(raw[-1])
    def fast_ink(self):
        """Draw newly stable segments into the cached layer; repaint only the
        small rectangle around the pen tip."""
        s = self.active; pts = s['points']; stable = len(pts)-1
        first = max(0, self.drawn-1)
        while len(self.cum) < stable:   # path length to each stable point (dash continuity)
            i = len(self.cum); self.cum.append(self.cum[-1]+math.dist(pts[i-1],pts[i]) if i else 0)
        if stable > self.drawn:
            o = self.snap_rect.topLeft()
            if self.layers: targets = [(layer, [pen]) for layer, (pen, _, _) in zip(self.layers, style_passes(s))]
            else: targets = [(self.snapshot, self.direct_pens(self.cum[first]))]
            for target, pens in targets:
                painter = QPainter(target); painter.translate(-o.x(), -o.y()); painter.scale(self.scale, self.scale)
                painter.setRenderHint(QPainter.Antialiasing)
                self.draw_segment(painter, s, first, stable, pens=pens); painter.end()
        area = pts[first:] + self.raw[-2:]
        xs = [q[0] for q in area]; ys = [q[1] for q in area]
        pad = s['width']*(STYLE_SPAN.get(s.get('style'), 1) if s['tool'] in STYLED_TOOLS else 1)*self.scale/2 + 3
        self.drawn = max(self.drawn, stable)
        self.update(QRectF(min(xs)*self.scale-pad, min(ys)*self.scale-pad,
                           (max(xs)-min(xs))*self.scale+2*pad, (max(ys)-min(ys))*self.scale+2*pad).toAlignedRect())
    # --- Akıcı kalem ---------------------------------------------------
    FLUID_START = .35   # tapered start/end (share of full width)
    def fluid_input(self, pt):
        """Steady the pen: slow, shaky movement is smoothed more, fast strokes
        almost not at all. The smoothing is set per unit of time, not per
        sample, so a board that reports 60 times a second does not lag twice
        as much as one at 120 (measured with kalem_olcum.py)."""
        fl = self.fl; fl['true'] = pt; last = self.raw[-1]
        now = time.monotonic(); dt = max(.001, min(.1, now-fl.get('tin', fl['t']))); fl['tin'] = now
        v = math.hypot(pt[0]-last[0], pt[1]-last[1])*self.scale/(dt*1000)   # screen px per ms
        fl['v'] = v
        a = max(.45, min(1.0, .45+v*.35))       # share of the move taken at 120 Hz
        a = 1-(1-a)**(dt/.008)                  # same steadiness per second at any sample rate
        return [last[0]+(pt[0]-last[0])*a, last[1]+(pt[1]-last[1])*a]
    def fluid_widths(self):
        """Width factor per drawn point: slow = fuller, fast = thinner,
        growing in from a fine tip at the start (kept in step with
        smooth_append, which only rewrites the tail of the stroke)."""
        fl = self.fl; s = self.active; pts = s['points']
        fl['t'] = time.monotonic()
        target = .5 + .8*math.exp(-fl.get('v', 0)/.9)
        fl['f'] += .3*(target-fl['f'])
        fw, arc, ws = fl['fw'], fl['arc'], s['w']
        keep = 0 if len(self.raw) < 3 else 1 if len(self.raw) == 3 else max(0, len(fw)-1)
        del fw[keep:]; del arc[keep:]; del ws[keep:]
        f0 = fw[-1] if fw else fl['f']; n = max(1, len(pts)-keep); grow = s['width']*3
        for k in range(keep, len(pts)):
            arc.append(arc[-1]+math.dist(pts[k-1], pts[k]) if k else 0.0)
            fw.append(f0+(fl['f']-f0)*(k-keep+1)/n)
            ws.append(fw[k]*self._taper(arc[k], grow))
    def _taper(self, arc, grow):
        return self.FLUID_START+(1-self.FLUID_START)*min(1, arc/grow) if grow else 1
    def fluid_finish(self):
        """Reach the real lift point, then let the stroke end in a fine tip."""
        s, fl = self.active, self.fl
        if s['tool'] != 'pen': return   # snapped into a shape
        true = fl['true']; last = self.raw[-1]
        if math.hypot(true[0]-last[0], true[1]-last[1])*self.scale >= .5:
            self.raw.append(true); self.smooth_append()
            if 'w' in s: self.fluid_widths()
        raw = self.raw
        if 'w' not in s and len(raw) >= 3:   # last piece: from the straight tail to its curve, ending on the lift point
            n = len(raw); pts = s['points']; pts.pop()
            pts.extend(catmull_rom(raw[n-3], raw[n-2], raw[n-1], raw[n-1], self.cr_steps(raw[n-2], raw[n-1])))
        if 'w' not in s: return   # even-width Akıcı: done
        pts, ws = s['points'], s['w']
        if len(ws) != len(pts): ws[:] = [1.0]*len(pts)
        total = fl['arc'][-1] if fl['arc'] else 0; grow = s['width']*3
        if total < s['width']*2:   # a dot or a tiny tick: keep it full
            ws[:] = [max(1.0, w) for w in ws]; return
        for k in range(len(pts)):
            rest = total-fl['arc'][k] if k < len(fl['arc']) else 0
            ws[k] *= self._taper(rest, grow)
    # --- Neon kalem: strokes glow for a while, then fade away ------------
    NEON_HOLD, NEON_FADE = 3.0, .8
    def hold_fading(self):
        for item in self.fading: item[1:] = item[1:2]   # writing again: keep them all lit
    def release_fading(self):
        end = time.monotonic()+self.NEON_HOLD
        for item in self.fading: item[1:] = [item[1], end]
        if self.fading and not self.fade_timer.isActive(): self.fade_timer.start(40)
    def fade_tick(self):
        now = time.monotonic(); before = self.fading_rect()
        self.fading = [it for it in self.fading if len(it) < 3 or now < it[2]]
        if not self.fading: self.fade_timer.stop()
        if before is not None: self.update(before)
    def fading_rect(self):
        rect = None
        for it in self.fading:
            if it[1] != self.owner.page: continue
            b = stroke_bounds(it[0]); pad = it[0]['width']*STYLE_SPAN['laser']/2+2
            b = QRectF((b.x()-pad)*self.scale, (b.y()-pad)*self.scale, (b.width()+2*pad)*self.scale, (b.height()+2*pad)*self.scale)
            rect = b if rect is None else rect.united(b)
        return rect.toAlignedRect() if rect is not None else None
    def paint_fading(self, p, clip):
        if not self.fading: return
        now = time.monotonic()
        for it in self.fading:
            if it[1] != self.owner.page: continue
            alpha = 1 if len(it) < 3 else max(0.0, min(1.0, (it[2]-now)/self.NEON_FADE))
            if alpha <= 0: continue
            p.save(); p.setOpacity(alpha); paint_passes(p, stroke_path(it[0]['points']), style_passes(it[0]), clip, self.devicePixelRatioF()); p.restore()
    def direct_pens(self, offset=0):
        """Pens for strokes drawn straight onto the page (normal, dashed, felt)."""
        passes = style_passes(self.active)
        return [passes[0][0]] if passes else [stroke_pen(self.active, offset)]
    def clear_selection(self):
        self.release_timer.stop();self.pending_snap=None
        self.selected=[];self.selection_page=None;self.update()
    def selection_rect(self):
        if self.selection_page!=self.owner.page:return None
        marks=self.owner.marks.get(self.owner.page,[])
        rect=None
        for i in self.selected:
            if i>=len(marks):return None
            b=stroke_bounds(marks[i]);rect=b if rect is None else rect.united(b)
        return rect
    def snap_shape(self):
        if not self.active or self.active['tool']!='pen' or self.snapped:return
        if is_scribble(self.raw,self.scale) and scribble_hits(self.owner.marks.get(self.owner.page,[]),self.active,self.scale):
            self.erase_on_finish=True;self.snapped=True;self.snapshot=None;self.update()
            self.shape_feedback('Karalama: kalemi kaldırınca altındaki yazılar silinecek');return
        result=recognize_shape(self.raw)
        if result:
            self.active['tool'],self.active['points']=result
            self.active.pop('nib',None);self.active.pop('w',None);self.snapped=True;self.snapshot=None;self.update()
            self.shape_feedback('Şekil düzeltildi')

    def shape_feedback(self,text):
        if hasattr(self.owner,'statusBar'):self.owner.statusBar().showMessage(text,4000)
        elif hasattr(self.owner,'hint'):self.owner.hint.setText(text)

    def erase_scribble(self,stroke,page):
        marks=self.owner.marks.get(page,[])
        if page!=self.owner.page or not any(s is stroke for s in marks):return
        hits=scribble_hits(marks,stroke,self.scale)
        if not hits:return
        gone={id(s) for s in hits}|{id(stroke)}
        # No new checkpoint: one Geri al returns to the state before the scribble.
        self.owner.marks[page]=[s for s in marks if id(s) not in gone]
        self.owner.changed();self.update();self.shape_feedback('Karalanan yazılar silindi · Geri al ile geri getirebilirsiniz')
    def snap_released_shape(self):
        erase=getattr(self,'pending_erase',None);self.pending_erase=None
        if erase and not self.active and not self.transform:self.erase_scribble(*erase);return
        pending=self.pending_snap;self.pending_snap=None
        if not pending or self.active or self.transform:return
        stroke,page,result=pending
        marks=self.owner.marks.get(page,[])
        if page!=self.owner.page or not any(s is stroke for s in marks):return
        self.owner.checkpoint()
        stroke['tool'],stroke['points']=result;stroke.pop('nib',None);stroke.pop('w',None)
        self.owner.changed();self.update();self.shape_feedback('Şekil düzeltildi · Geri al ile el çizimine dönebilirsiniz')

    def delete_badge(self,r):
        page=self.owner.doc[self.owner.page].rect;m=24/self.scale
        return QPointF(min(max(r.right()+28/self.scale,m),page.width-m),min(max(r.top()-28/self.scale,m),page.height-m))
    def delete_selection(self):
        marks=self.owner.marks.get(self.owner.page,[])
        if self.selection_page!=self.owner.page or not self.selected:return
        self.owner.checkpoint()
        gone=set(self.selected);self.owner.marks[self.owner.page]=[s for i,s in enumerate(marks) if i not in gone]
        self.clear_selection();self.owner.changed();self.update()
        self.shape_feedback('Seçilenler silindi · Geri al ile geri getirebilirsiniz')
    def start_smart(self,pt):
        r=self.selection_rect();corner=None
        if r is not None:
            c=self.delete_badge(r)
            if math.hypot(pt[0]-c.x(),pt[1]-c.y())<=24/self.scale:self.delete_selection();return
            corners=[r.topLeft(),r.topRight(),r.bottomLeft(),r.bottomRight()]
            for i,c in enumerate(corners):
                if math.hypot(pt[0]-c.x(),pt[1]-c.y())<=16/self.scale:corner=i;break
            if corner is not None or r.contains(QPointF(*pt)):
                self.transform=dict(before=copy.deepcopy(self.owner.marks),rect=r,point=pt,corner=corner)
                return
        self.clear_selection()
        self.active=dict(tool='smart',points=[pt],color='#2394ff',width=1)

    def move_selection(self,pt):
        t=self.transform;r=t['rect'];page=self.owner.doc[self.owner.page].rect
        scale=1;dx=dy=0;anchor=QPointF(0,0)
        if t['corner'] is None:
            dx=max(-r.left(),min(page.width-r.right(),pt[0]-t['point'][0]))
            dy=max(-r.top(),min(page.height-r.bottom(),pt[1]-t['point'][1]))
        else:
            corners=[r.topLeft(),r.topRight(),r.bottomLeft(),r.bottomRight()]
            anchor=corners[3-t['corner']];drag=corners[t['corner']]
            vx,vy=drag.x()-anchor.x(),drag.y()-anchor.y()
            scale=max(.1,min(8,((pt[0]-anchor.x())*vx+(pt[1]-anchor.y())*vy)/max(vx*vx+vy*vy,.01)))
            maxx=(page.width-anchor.x())/vx if vx>0 else -anchor.x()/vx
            maxy=(page.height-anchor.y())/vy if vy>0 else -anchor.y()/vy
            scale=max(.01,min(scale,maxx,maxy))
        for i in self.selected:
            s=copy.deepcopy(t['before'][self.owner.page][i])
            s['points']=[[anchor.x()+(x-anchor.x())*scale+dx,anchor.y()+(y-anchor.y())*scale+dy] for x,y in s['points']]
            s['width']=max(.05,min(100,s['width']*scale));s.pop('origin',None)
            self.owner.marks[self.owner.page][i]=s
        self.update()

    def point(self, pos):
        r = self.owner.doc[self.owner.page].rect
        return [max(0, min(r.width, pos.x()/self.scale)), max(0, min(r.height, pos.y()/self.scale))]

    def begin(self, pos):
        self.release_timer.stop();self.pending_snap=None;self.pending_erase=None;self.erase_on_finish=False
        self.snapped=False;self.hold_timer.stop()
        self.auto_pen.stop();self.erasing=self.owner.tool in AUTO_PEN_TOOLS
        # The ring must be gone before the fast-ink snapshot is taken.
        self.set_tip(pos if self.owner.tool in self.ERASER_TOOLS else None)
        if self.owner.tool == 'hand':
            self.pan = (pos, self.owner.scroll.horizontalScrollBar().value(), self.owner.scroll.verticalScrollBar().value())
            return
        pt = self.point(pos)
        self.ruler_edge = None
        if self.owner.tool=='smart':self.start_smart(pt);self.update();return
        if self.owner.tool == 'place_tri' and getattr(self.owner, 'pending_triangle', None):   # Ölçülü üçgen: dokunulan yere
            self.owner.checkpoint(); ms = self.owner.marks.setdefault(self.owner.page, [])
            for m in self.owner.pending_triangle: ms.append(dict(m, points=[[x + pt[0], y + pt[1]] for x, y in m['points']]))
            self.owner.pending_triangle = None; self.owner.changed(); self.update(); self.owner.set_tool('pen')
            self.shape_feedback('Üçgen kondu · Akıllı seçimle taşıyabilir, Geri al ile kaldırabilirsiniz'); return
        if self.owner.tool == 'geo': self.geo_begin(pt); return
        if self.owner.tool == 'compass':   # Pergel: merkez burada; sürükle = açıklık, çevir = yay
            self.clear_selection(); self.ensure_base(); self.raw = []; self.compass = dict(r=0.0, prev=None, sweep=0.0, phase='radius', a0=0.0, a=0.0)
            self.active = dict(tool='compass', center=list(pt), r=0.0, points=[], color=self.owner.color, width=self.owner.width.value())
            self.update(); return
        ruler = getattr(self.owner, 'ruler', None)
        if self.owner.tool in ('pen', 'dash', 'highlight') and ruler is not None and ruler.isVisible():
            vp = QPointF(pos) + QPointF(self.mapTo(ruler.parentWidget(), QPoint(0, 0)))
            edge = ruler.edge_for(vp, self.owner.width.value()*self.scale/2 + 2)
            if edge is not None:   # cetvelin kenarına yakın: çizgi kenara yapışır, dümdüz
                self.ensure_base(); self.ruler_edge = edge; a = self.ruler_point(vp)
                self.active = dict(tool='line', color=self.owner.color, width=self.owner.width.value()*(4 if self.owner.tool == 'highlight' else 1), points=[a, a])
                if self.owner.tool == 'dash': self.active['dash'] = True
                if self.owner.tool == 'highlight': self.active['tool'] = 'highlight'
                self.raw = [a]; self.update(); return
        if self.owner.tool == 'pick':   # Günün soruları: soru seç
            self.clear_selection(); self.active = dict(tool='pick_frame', points=[pt], color='#ffb400', width=1)
            self.update(); return
        if self.owner.tool == 'postit':   # Post-it: frame what to pin to the side board
            self.clear_selection(); self.active = dict(tool='postit_frame', points=[pt], color='#ffe27a', width=1)
            self.update(); return
        if self.owner.tool == 'area_eraser':   # Alan silgisi: frame like Akıllı seçim, deleted on release
            self.clear_selection(); self.active = dict(tool='erase_frame', points=[pt], color='#e23b4d', width=1)
            self.update(); return
        if self.owner.tool == 'eraser':
            self.owner.checkpoint()
            self.erasing = True; self.last_erase = None
            self.erase(pt)
        else:
            self.raw = [pt]
            self.snapshot = None; self.drawn = 0; self.cum = []
            # "Kesikli çizgi" is its own tool: a pen stroke drawn dashed.
            tool = 'pen' if self.owner.tool == 'dash' else 'line' if self.owner.tool == 'arrow' else self.owner.tool
            if tool == 'laser': self.hold_fading()
            if tool in ('line', 'rect', 'circle', 'triangle'): self.ensure_base()   # şekil önizlemesi hazır sayfanın üstünde
            if tool in ('pen', 'laser') and self.owner.nib.currentData() not in ('fountain','marker'):
                # Cache only what is on screen (a 333% page can be huge).
                self.snap_rect = self.visibleRegion().boundingRect()
                if not self.snap_rect.isEmpty():
                    ok = self.cacheable()
                    if ok and self.base_valid(self.snap_rect) and self.base_rect == self.snap_rect: self.snapshot = self.base.copy()
                    else:
                        self.snapshot = self.grab(self.snap_rect)
                        if ok: self.base = self.snapshot.copy(); self.base_rect = QRect(self.snap_rect); self.base_key = self.mark_key()
                        else: self.base = None
            self.active = dict(tool=tool, color=self.owner.color,
                width=self.owner.width.value() * (4 if tool == 'highlight' else 1), points=[pt])
            if self.owner.tool == 'dash': self.active['dash'] = True
            if self.owner.tool == 'arrow': self.active['arrow'] = True
            style = getattr(self.owner, 'pen_style', 'normal')
            if tool == 'pen' and self.owner.tool == 'pen' and style in STYLE_SPAN: self.active['style'] = style
            if tool == 'laser': self.active['style'] = 'laser'
            self.fl = None
            if self.active.get('style') == 'fluid':
                # Akıcı: even width with round ends (no pointed tips); only the
                # hand tremor is smoothed away.
                self.fl = dict(t=time.monotonic(), f=1.0, true=pt, arc=[0.0], fw=[1.0])
            self.layers = None
            passes = style_passes(self.active)
            if self.snapshot is not None and passes and any(o < 1 or m for _, o, m in passes):
                self.layers = []
                for _ in passes:
                    layer = QPixmap(self.snapshot.size()); layer.setDevicePixelRatio(self.snapshot.devicePixelRatio())
                    layer.fill(Qt.transparent); self.layers.append(layer)
            if tool == 'pen':
                self.active['nib'] = self.owner.nib.currentData()
                if self.active['nib'] == 'fine': self.active['width'] *= .45
                self.hold_anchor=pt;self.hold_timer.start(900)
        self.update()

    def move(self, pos):
        if self.pan:
            start, x, y = self.pan
            # Global pointer coordinates avoid feedback as the widget scrolls.
            self.owner.scroll.horizontalScrollBar().setValue(x+int(start.x()-pos.x()))
            self.owner.scroll.verticalScrollBar().setValue(y+int(start.y()-pos.y()))
            return
        if self.erasing: self.set_tip(pos)
        pt = self.point(pos)
        if getattr(self, 'geo_drag', None) is not None: self.geo_move(pt); return
        if self.transform:self.move_selection(pt);return
        if self.snapped:return
        if self.erasing: self.erase(pt)
        if self.active and self.active['tool'] == 'compass': self.compass_move(pt); self.update(); return
        if self.active and getattr(self, 'ruler_edge', None) is not None:
            self.active['points'][1] = self.ruler_point(QPointF(pos) + QPointF(self.mapTo(self.owner.ruler.parentWidget(), QPoint(0, 0)))); self.update(); return
        if self.active:
            s = self.active
            a = s['points'][0]
            if s['tool'] in ('pen', 'highlight', 'laser'):
                last = self.raw[-1]
                if self.fl is not None: pt = self.fluid_input(pt)
                # Samples closer than 0.8 screen px are skipped: measured, keeping
                # them only adds quantisation jitter to slow writing.
                if pt is not None and math.hypot(pt[0]-last[0],pt[1]-last[1])*self.scale >= .8:
                    self.raw.append(pt)
                    self.smooth_append()
                    if self.fl is not None and 'w' in s: self.fluid_widths()
                    if s['tool']=='pen' and math.dist(pt,self.hold_anchor)*self.scale>12:
                        self.hold_anchor=pt;self.hold_timer.start(900)
                    if self.snapshot is not None and not self.snapped:
                        self.fast_ink();return
                elif self.snapshot is not None and not self.snapped:return
            elif s['tool'] == 'line' and s.get('arrow'): s['points'] = arrow_points(a, pt, s['width'])
            elif s['tool'] in ('line','select','smart','solution','erase_frame','postit_frame','pick_frame'): s['points'] = [a, pt]
            elif s['tool'] == 'rect': s['points'] = [a, [pt[0],a[1]], pt, [a[0],pt[1]], a]
            elif s['tool'] == 'triangle': s.setdefault('origin', a); s['points'] = tri_points(s['origin'], pt)
            elif s['tool'] == 'circle':
                # Keep the press position separately because ellipse starts at its right edge.
                a = s.setdefault('origin', a)
                cx, cy = (a[0]+pt[0])/2, (a[1]+pt[1])/2
                rx, ry = abs(pt[0]-a[0])/2, abs(pt[1]-a[1])/2
                s['points'] = [[cx+rx*math.cos(t*math.pi/32),cy+ry*math.sin(t*math.pi/32)] for t in range(65)]
        self.update()

    def finish(self, cancel=False):
        self.hold_timer.stop();self.snapped=False
        if getattr(self, 'geo_drag', None) is not None: self.geo_end(); return
        if self.erasing:
            self.erasing=False
            if self.owner.tool in AUTO_PEN_TOOLS:self.auto_pen.start()
        if self.active and self.active['tool'] == 'laser':   # Neon kalem: not saved, fades out
            if not cancel and self.active['points']:
                self.fading.append([self.active, self.owner.page])
            self.active = None; self.snapshot = None; self.layers = None; self.release_fading(); self.update(); return
        if self.active and self.fl is not None and not cancel and not self.snapped: self.fluid_finish()
        if self.active and self.active['tool']=='solution':
            pts=self.active['points'];self.active=None
            if not cancel and len(pts)==2:self.owner.make_solution(pts)
        if self.transform:
            after=copy.deepcopy(self.owner.marks);before=self.transform['before'];self.transform=None
            self.owner.marks=before
            if not cancel and after!=before:
                self.owner.checkpoint();self.owner.marks=after;self.owner.changed()
        if self.active and self.active['tool']=='smart':
            pts=self.active['points'];self.active=None
            if not cancel:
                self.selection_page=self.owner.page;self.selected=self.framed(pts)
        if self.active and self.active['tool']=='pick_frame':
            pts=self.active['points'];self.active=None;self.update()
            if not cancel and len(pts)==2 and hasattr(self.owner,'add_planned'):self.owner.add_planned(pts)
        if self.active and self.active['tool']=='postit_frame':
            pts=self.active['points'];self.active=None;self.update()
            if not cancel and len(pts)==2 and hasattr(self.owner,'make_postit'):self.owner.make_postit(pts)
        if self.active and self.active['tool']=='erase_frame':
            pts=self.active['points'];self.active=None
            gone=set(self.framed(pts)) if not cancel else set()
            if gone:
                marks=self.owner.marks.get(self.owner.page,[])
                self.owner.checkpoint();self.owner.marks[self.owner.page]=[s for i,s in enumerate(marks) if i not in gone]
                self.owner.changed();self.shape_feedback('Seçilen yazılar silindi · Geri al ile geri getirebilirsiniz')
        if self.active and self.active['tool'] == 'select':
            pts = self.active['points']
            self.active = None
            if not cancel and len(pts) == 2:
                getattr(self.owner,'select_area',self.owner.apply_selection)(pts)
        if self.active and self.active['tool'] == 'compass':   # yalnızca çizilen yay kalır
            s_ = self.active
            self.active = dict(tool='pen', color=s_['color'], width=s_['width'], points=s_['points']) if len(s_['points']) > 1 and not cancel else None
            if self.active is None: self.update()
        self.ruler_edge = None
        added = None
        if self.active and not cancel:
            self.owner.checkpoint()
            self.owner.marks.setdefault(self.owner.page, []).append(self.active); added = self.active
            self.owner.changed()
            if hasattr(self.owner, 'maybe_extend'): self.owner.maybe_extend(self.active)
            if self.active['tool']=='pen':
                if getattr(self,'erase_on_finish',False):
                    self.erase_on_finish=False;self.erase_scribble(self.active,self.owner.page)
                elif is_scribble(self.raw,self.scale) and scribble_hits(self.owner.marks.get(self.owner.page,[]),self.active,self.scale):
                    # Scratch over writing and wait ~1 s: the writing is erased.
                    self.pending_erase=(self.active,self.owner.page);self.release_timer.start(1000)
                else:
                    result=recognize_shape(self.raw)
                    if result:
                        self.pending_snap=(self.active,self.owner.page,result)
                        self.release_timer.start(900)
        self.active = None; self.snapshot = None; self.layers = None
        self.erasing = False; self.last_erase = None
        if added is not None: self.refresh_base(added)
        self.pan = None; self.set_tip(None)
        self.update()

    def framed(self, pts):
        """Strokes inside a dragged frame, or the stroke under a single tap
        (same rule for Akıllı seçim and Alan silgisi)."""
        r=QRectF(QPointF(*pts[0]),QPointF(*pts[-1])).normalized();found=[]
        for i,s in enumerate(self.owner.marks.get(self.owner.page,[])):
            if s['tool']=='whiteout':continue
            if r.width()+r.height()<8/self.scale:
                hit=any(segment_distance(pts[0],a,b)<12/self.scale+s['width']/2 for a,b in zip(s['points'],s['points'][1:] or s['points']))
            else:hit=r.contains(stroke_bounds(s))
            if hit:found.append(i)
        return found
    def erase(self, pt):
        strokes = self.owner.marks.get(self.owner.page, [])
        def hit(s):
            if s['tool'] == 'whiteout': return False
            pts = s['points']
            return any(segment_distance(pt,a,b) <= 12/self.scale+s['width']/2 for a,b in zip(pts,pts[1:] or pts))
        left = [s for s in strokes if not hit(s)]
        if len(left) != len(strokes):
            self.owner.marks[self.owner.page] = left
            self.owner.changed()

    PALM_PX = 45   # contact wider than this (screen px) is treated as a palm
    TAP_S = .35        # two-finger tap (Geri al): shorter than this…
    TAP_MOVE_PX = 20   # …and no finger moving further than this
    @staticmethod
    def contact_size(p):
        try: d = p.ellipseDiameters(); return max(d.width(), d.height())
        except AttributeError: r = p.rect(); return max(r.width(), r.height())
    def erase_area(self, pt, radius):
        strokes = self.owner.marks.get(self.owner.page, [])
        def hit(s):
            if s['tool'] == 'whiteout': return False
            pts = s['points']
            return any(segment_distance(pt,a,b) <= radius+s['width']/2 for a,b in zip(pts,pts[1:] or pts))
        left = [s for s in strokes if not hit(s)]
        if len(left) != len(strokes):
            if getattr(self, 'palm', False) and not getattr(self, 'palm_saved', False):
                self.owner.checkpoint(); self.palm_saved = True   # one undo step per palm gesture
            self.owner.marks[self.owner.page] = left; self.owner.changed(); self.update()
    def multi_touch(self, e, pts):
        """Palm/fist rubbing erases; two fingers pinch-zoom and pan the page.
        Returns True when the event was handled as a multi-touch gesture."""
        active = [p for p in pts if p.state() != Qt.TouchPointReleased]
        palm = len(active) >= 3 or any(self.contact_size(p) >= self.PALM_PX for p in active)
        if palm or getattr(self, 'palm', False):
            if not active: return True
            if not getattr(self, 'palm', False):
                if self.active or self.transform: self.finish(cancel=True)
                self.gesture = None; self.palm = True; self.palm_saved = False
                self.shape_feedback('Avuçla silme')
            cx = sum(p.pos().x() for p in active)/len(active); cy = sum(p.pos().y() for p in active)/len(active)
            spread = max([math.hypot(p.pos().x()-cx, p.pos().y()-cy) for p in active]+[max(self.contact_size(p) for p in active)/2, 28])
            self.erase_area(self.point(QPointF(cx, cy)), spread/self.scale)
            return True
        # Screen mode has no page to zoom: two fingers are only a Geri al tap there.
        tap_only = getattr(self.owner, 'overlay_mode', False) or not hasattr(self.owner, 'scroll')
        if len(active) == 2 or getattr(self, 'gesture', None):
            if len(active) < 2: return True       # wait until all fingers lift
            a, b = active[0].screenPos(), active[1].screenPos()
            center = QPointF((a.x()+b.x())/2, (a.y()+b.y())/2); dist = max(1.0, math.hypot(a.x()-b.x(), a.y()-b.y()))
            if not getattr(self, 'gesture', None):
                if self.active or self.transform: self.finish(cancel=True)
                local = self.mapFromGlobal(center.toPoint())
                self.gesture = dict(d0=dist, z0=getattr(self.owner, 'zoom', 1), anchor=(local.x()/self.scale, local.y()/self.scale), last=0,
                                    t0=time.monotonic(), start={p.id(): QPointF(p.screenPos()) for p in active}, moved=False, tap_only=tap_only)
                return True
            g = self.gesture
            # Two-finger tap = Geri al: only if the fingers stay put.
            for p in active:
                q = g['start'].get(p.id())
                if q is None or math.hypot(p.screenPos().x()-q.x(), p.screenPos().y()-q.y()) > self.TAP_MOVE_PX: g['moved'] = True
            if g['tap_only']: return True
            zoom = max(.15, min(8, g['z0']*dist/g['d0']))
            if abs(zoom-self.owner.zoom)/self.owner.zoom > .03 and time.monotonic()-g['last'] > .06:
                self.owner.set_zoom(zoom); g['last'] = time.monotonic(); g['moved'] = True
            local = self.mapFromGlobal(center.toPoint()); ax, ay = g['anchor']
            h, v = self.owner.scroll.horizontalScrollBar(), self.owner.scroll.verticalScrollBar()
            h.setValue(int(h.value()+ax*self.scale-local.x())); v.setValue(int(v.value()+ay*self.scale-local.y()))
            return True
        return False
    def event(self, e):
        if e.type() in (QEvent.TouchBegin, QEvent.TouchUpdate, QEvent.TouchEnd, QEvent.TouchCancel):
            pts = e.touchPoints()
            if e.type() in (QEvent.TouchEnd, QEvent.TouchCancel):
                if getattr(self, 'palm', False) or getattr(self, 'gesture', None):
                    g = self.gesture
                    tap = (g is not None and not getattr(self, 'palm', False) and not g['moved']
                           and time.monotonic()-g['t0'] <= self.TAP_S and e.type() == QEvent.TouchEnd)
                    self.palm = False; self.gesture = None; self.pointer = None
                    if tap:
                        self.owner.undo(); self.shape_feedback('İki parmak: Geri al')
                    if hasattr(self.owner, 'render'): self.owner.render()
                    e.accept(); return True
            elif self.multi_touch(e, pts):
                e.accept(); return True
            if e.type() == QEvent.TouchBegin and pts:
                self.pointer = pts[0].id()
                self.begin(pts[0].screenPos() if self.owner.tool == 'hand' else pts[0].pos())
            elif e.type() == QEvent.TouchUpdate:
                for p in pts:
                    if p.id() == self.pointer: self.move(p.screenPos() if self.pan else p.pos())
            else:
                self.finish(e.type() == QEvent.TouchCancel)
                self.pointer = None
            e.accept()
            return True
        return super().event(e)

    def mousePressEvent(self, e):
        if e.source()!=Qt.MouseEventNotSynthesized:return
        if e.button() == Qt.LeftButton: self.begin(e.globalPos() if self.owner.tool == 'hand' else e.localPos())
    def mouseMoveEvent(self, e):
        if e.source()!=Qt.MouseEventNotSynthesized:return
        if e.buttons() & Qt.LeftButton: self.move(e.globalPos() if self.pan else e.localPos())
        elif not self.active: self.set_tip(e.localPos())   # mouse hover shows the ring too
    def leaveEvent(self, e):
        self.set_tip(None); super().leaveEvent(e)
    def mouseReleaseEvent(self, e):
        if e.source()!=Qt.MouseEventNotSynthesized:return
        if e.button() == Qt.LeftButton:
            if self.active or self.transform: self.move(e.localPos())
            self.finish()
    def tabletEvent(self, e):
        if e.type() == QEvent.TabletPress: self.begin(e.globalPosF() if self.owner.tool == 'hand' else e.posF())
        elif e.type() == QEvent.TabletMove: self.move(e.globalPosF() if self.pan else e.posF())
        elif e.type() == QEvent.TabletRelease:
            if self.active or self.transform:self.move(e.posF())
            self.finish()
        e.accept()
    def closeEvent(self,e):
        if getattr(self.owner,'overlay_mode',False):e.ignore();self.owner.leave()
        else:super().closeEvent(e)

def x11_compositing_running():
    """EWMH check: a compositor owns the _NET_WM_CM_S<screen> selection.
    Pardus/Debian PyQt5 builds lack QX11Info.isCompositingManagerRunning,
    so libX11 is queried directly. Returns True when it cannot be determined
    so the overlay is never blocked by a detection failure."""
    from PyQt5.QtX11Extras import QX11Info
    if hasattr(QX11Info,'isCompositingManagerRunning'):
        return QX11Info.isCompositingManagerRunning()
    import ctypes, ctypes.util
    try:
        x11=ctypes.CDLL(ctypes.util.find_library('X11') or 'libX11.so.6')
        x11.XOpenDisplay.restype=ctypes.c_void_p; x11.XOpenDisplay.argtypes=[ctypes.c_char_p]
        x11.XDefaultScreen.restype=ctypes.c_int; x11.XDefaultScreen.argtypes=[ctypes.c_void_p]
        x11.XInternAtom.restype=ctypes.c_ulong; x11.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int]
        x11.XGetSelectionOwner.restype=ctypes.c_ulong; x11.XGetSelectionOwner.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
        x11.XCloseDisplay.argtypes=[ctypes.c_void_p]
        display=x11.XOpenDisplay(None)
        if not display: return True
        try:
            atom=x11.XInternAtom(display,('_NET_WM_CM_S%d' % x11.XDefaultScreen(display)).encode(),0)
            return x11.XGetSelectionOwner(display,atom)!=0
        finally: x11.XCloseDisplay(display)
    except (OSError, AttributeError): return True

def page_number_dialog(parent, count, current):
    """Touch-friendly number pad: no on-screen keyboard needed."""
    from PyQt5.QtWidgets import QDialog
    dialog=QDialog(parent);dialog.setWindowTitle('Sayfaya git');dialog.setModal(True)
    dialog.setStyleSheet('''QDialog,QWidget{background:#122034;color:#edf4ff;font-family:"DejaVu Sans";font-size:22px;}
        QPushButton{background:#22344c;border:1px solid #364a63;border-radius:10px;min-width:84px;min-height:64px;}
        QPushButton:hover{background:#304b68;} QPushButton#primary{background:#c61d2d;font-weight:bold;}''')
    layout=QVBoxLayout(dialog)
    info=QLabel('Sayfa numarası (1 – %d)' % count);info.setStyleSheet('font-size:16px;color:#b9c6d8;');layout.addWidget(info)
    shown=QLabel('');shown.setAlignment(Qt.AlignCenter);shown.setMinimumHeight(64)
    shown.setStyleSheet('font-size:36px;font-weight:bold;background:#091423;border:1px solid #364a63;border-radius:10px;');layout.addWidget(shown)
    grid=QGridLayout();grid.setSpacing(8);layout.addLayout(grid)
    value=['']
    def update():
        shown.setText(value[0] or str(current))
        go.setEnabled(bool(value[0]) and 1<=int(value[0])<=count)
    def press(d):
        if len(value[0])<5 and not (d=='0' and not value[0]):value[0]+=d;update()
    def back():value[0]=value[0][:-1];update()
    for i,d in enumerate('123456789'):
        b=QPushButton(d);b.clicked.connect(lambda checked=False,d=d:press(d));grid.addWidget(b,i//3,i%3)
    erase=QPushButton('Sil');erase.clicked.connect(back);grid.addWidget(erase,3,0)
    zero=QPushButton('0');zero.clicked.connect(lambda:press('0'));grid.addWidget(zero,3,1)
    go=QPushButton('Git');go.setObjectName('primary');go.clicked.connect(dialog.accept);grid.addWidget(go,3,2)
    cancel=QPushButton('Vazgeç');cancel.clicked.connect(dialog.reject);layout.addWidget(cancel)
    update()
    return int(value[0]) if dialog.exec_()==QDialog.Accepted and value[0] else None

class Window(QMainWindow):
    @property
    def color(self): return self._color
    @color.setter
    def color(self, value):
        self._color = value; self.refresh_colors()
    def refresh_colors(self):
        if not hasattr(self,'color_buttons') or not hasattr(self,'tool_buttons'): return
        for c,b in self.color_buttons: b.setChecked(c == self._color)
        paint_tool_buttons(self.tool_buttons, self.tool_labels, self.tool, self._color)
        if hasattr(self,'shape_button'):   # Şekiller shows the chosen shape, in the ink colour
            b=self.shape_button;chosen=self.tool in SHAPE_TOOLS;b.setChecked(chosen)
            if chosen:
                q=QColor(self._color);ink='#122034' if .299*q.redF()+.587*q.greenF()+.114*q.blueF()>.6 else '#ffffff'
                b.setStyleSheet('QPushButton:checked{background:%s;color:%s;border:3px solid #ffffff;}'%(self._color,ink))
                b.setIcon(tool_icon(self.tool_labels[self.tool],ink));b.setText('Şekiller')
            else:b.setStyleSheet('');b.setIcon(tool_icon('Şekiller'));b.setText('Şekiller')
        if hasattr(self,'solution_button'):   # folder buttons stay lit while one of their tools is on
            self.solution_button.setChecked(self.tool in ('solution','select'))
            self.tool_buttons['eraser'].setChecked(self.tool in ('eraser','area_eraser'))
    # ---- Post-it panosu --------------------------------------------------
    POSTIT_COLORS = ('#ffe27a', '#ffb3c7', '#b8f0c8', '#b9dcff')
    def postit_file(self): return os.path.join(self.data_dir, 'postit', 'postit.json')
    def load_postits(self):
        """One Post-it panosu for every screen (boş tahta and every PDF tab)."""
        self.pano_dir = 'ortak'; self.pano.clear()
        self.merge_tab_postits()
        try:
            with open(self.postit_file(), encoding='utf-8') as f: items = json.load(f)
        except (OSError, ValueError): items = []
        for it in items:
            pix = QPixmap(os.path.join(os.path.dirname(self.postit_file()), os.path.basename(str(it.get('file','')))))
            if not pix.isNull(): self.pano.add(pix, it.get('color', self.POSTIT_COLORS[0]), it['file'])
        try:
            with open(os.path.join(os.path.dirname(self.postit_file()), 'pano.json'), encoding='utf-8') as f: self.pano_hidden = bool(json.load(f).get('gizli'))
        except (OSError, ValueError, AttributeError): self.pano_hidden = False
        self.show_pano()
    def merge_tab_postits(self):
        """Earlier versions kept post-its per tab: move them onto the shared board once."""
        folder = os.path.dirname(self.postit_file())
        try: tabs = [d for d in os.listdir(self.data_dir) if d != 'postit' and os.path.isfile(os.path.join(self.data_dir, d, 'postit', 'postit.json'))]
        except OSError: return
        if not tabs: return
        try:
            with open(self.postit_file(), encoding='utf-8') as f: items = json.load(f)
        except (OSError, ValueError): items = []
        os.makedirs(folder, exist_ok=True)
        for d in tabs:
            old = os.path.join(self.data_dir, d, 'postit')
            try:
                with open(os.path.join(old, 'postit.json'), encoding='utf-8') as f: olds = json.load(f)
                for it in olds:
                    name = os.path.basename(str(it.get('file', '')))
                    if name and os.path.isfile(os.path.join(old, name)) and not os.path.exists(os.path.join(folder, name)):
                        shutil.copy2(os.path.join(old, name), os.path.join(folder, name)); items.append(dict(file=name, color=it.get('color', self.POSTIT_COLORS[0])))
                os.replace(os.path.join(old, 'postit.json'), os.path.join(old, 'postit.json.tasindi'))
            except (OSError, ValueError, TypeError): pass
        try:
            with open(self.postit_file(), 'w', encoding='utf-8') as f: json.dump(items, f)
        except OSError: pass
    def show_pano(self):
        """Pano or, when the teacher hid it, a slim tab to bring it back."""
        has = bool(self.pano.cards)
        self.pano.setVisible(has and not self.pano_hidden)
        self.pano_tab.setVisible(has and self.pano_hidden)
        self.pano_tab.setText(str(len(self.pano.cards)))
    def set_pano_hidden(self, hidden):
        self.pano_hidden = hidden; self.show_pano()
        try:
            os.makedirs(os.path.dirname(self.postit_file()), exist_ok=True)
            with open(os.path.join(os.path.dirname(self.postit_file()), 'pano.json'), 'w', encoding='utf-8') as f: json.dump(dict(gizli=hidden), f)
        except OSError: pass
    def save_postits(self):
        try:
            os.makedirs(os.path.dirname(self.postit_file()), exist_ok=True)
            with open(self.postit_file(), 'w', encoding='utf-8') as f:
                json.dump([dict(file=c.name, color=c.color) for c in self.pano.cards], f)
        except OSError: pass
    def make_postit(self, pts):
        """Peel the framed part off the board and stick it to the side board."""
        a, b = pts; k = self.board.scale
        r = QRectF(QPointF(a[0]*k, a[1]*k), QPointF(b[0]*k, b[1]*k)).normalized().toAlignedRect() & self.board.rect()
        if r.width() < 24 or r.height() < 24: return
        pix = self.board.grab(r)
        if pix.width() > 900: pix = pix.scaledToWidth(900, Qt.SmoothTransformation)
        folder = os.path.dirname(self.postit_file()); os.makedirs(folder, exist_ok=True)
        name = 'postit-%s.png' % uuid.uuid4().hex[:10]; pix.save(os.path.join(folder, name))
        color = self.POSTIT_COLORS[len(self.pano.cards) % len(self.POSTIT_COLORS)]
        start = QRect(self.board.mapTo(self.centralWidget(), r.topLeft()), r.size())
        card = self.pano.add(pix, color, name, pending=True)
        if self.pano_hidden: self.set_pano_hidden(False)   # a new post-it must land somewhere visible
        self.show_pano()
        self.centralWidget().layout().activate(); self.pano.box.activate(); QApplication.processEvents(); self.pano.ensureWidgetVisible(card)
        end = QRect(card.mapTo(self.centralWidget(), QPoint(0, 0)), card.size())
        self.save_postits(); self.set_tool('pen')
        PostItFlight(self.centralWidget(), pix, color, start, end, card.tilt, lambda: self.postit_landed(card))
    def postit_landed(self, card):
        card.pending = False; card.update()
        play_sound(rapt_sound_file(self.data_dir))
        self.statusBar().showMessage('Post-it panoya yapıştı · dokununca büyür, × ile kaldırılır')
    def remove_postit(self, card):
        self.pano.remove(card); self.save_postits(); self.show_pano()
        try: os.remove(os.path.join(os.path.dirname(self.postit_file()), card.name))
        except OSError: pass
    def show_postit(self, card):
        PostItBig(self.scroll, card.pix, card.color)
    def open_backgrounds(self, anchor=None):
        self.open_folder(self.bg_popup, anchor or self.gear)
    # ---- Çizimleri gizle / iki çözüm: the page keeps a second solution.
    # Tap: the drawings go away (kept) and the page is clean; tap again: back
    # to the first solution; the second one is kept too, so the teacher can
    # switch between the two solutions as often as wanted.
    def saved_marks(self):
        alt, showing = getattr(self, 'alt_ink', {}), getattr(self, 'alt_showing', set())
        if not showing: return self.marks
        out = dict(self.marks)
        for p in showing: out[p] = alt.get(p, [])   # the first solution is always the page's own drawings
        return out
    def second_solutions(self):
        alt, showing = getattr(self, 'alt_ink', {}), getattr(self, 'alt_showing', set())
        out = {}
        for p in alt:
            second = self.marks.get(p, []) if p in showing else alt[p]
            if second: out[str(p)] = second
        return out
    def toggle_hidden_ink(self):
        self.board.finish(); self.board.clear_selection(); p = self.page
        if p not in self.alt_ink and not self.marks.get(p):
            self.statusBar().showMessage('Bu sayfada gizlenecek çizim yok.'); self.sync_hide_button(); return
        cur = self.marks.get(p, []); self.marks[p] = self.alt_ink.get(p, []); self.alt_ink[p] = cur
        self.alt_showing ^= {p}
        if p not in self.alt_showing and not self.alt_ink[p]: del self.alt_ink[p]   # no second solution left: plain page again
        # Geri al works inside one solution; it does not mix the two.
        self.sync_history(); self.undo_stack.clear(); self.redo_stack.clear()
        if p in self.alt_showing:
            self.statusBar().showMessage('İkinci çözüm · temiz sayfada yeniden çözün · tekrar basınca ilk çözüme dönersiniz (bu çözüm de saklanır)')
        else: self.statusBar().showMessage('İlk çözüm' + (' · ikinci çözüm saklandı, düğmeyle geçebilirsiniz' if p in self.alt_ink else ''))
        self.changed(); self.board.update(); self.sync_hide_button()
    def sync_hide_button(self):
        b = getattr(self, 'hide_button', None)
        if b is None: return
        p = self.page; second = p in self.alt_showing
        b.setText('  1. çözümü göster' if second else '  2. çözümü göster' if self.alt_ink.get(p) else '  Çizimleri gizle')
        b.setChecked(second); b.adjustSize(); self.place_overlays()
    def toggle_curtain(self, on=None):
        on = (self.curtain is None) if on is None else on
        if self.curtain is not None: self.curtain.hide(); self.curtain.deleteLater(); self.curtain = None
        if on: self.curtain = Curtain(self); self.place_overlays(); self.curtain.show()
        self.curtain_button.setChecked(on)
        if on: self.statusBar().showMessage('Perde: tutamağı aşağı çektikçe çözüm açılır · ⇅ perdeyi üste alır · × kaldırır')
    def toggle_spot(self, on=None):
        on = (self.spot is None) if on is None else on
        if self.spot is not None: self.spot.hide(); self.spot.deleteLater(); self.spot = None
        if on: self.spot = Spotlight(self); self.place_overlays(); self.spot.show()
        self.spot_button.setChecked(on)
        if on: self.statusBar().showMessage('Spot ışığı: aydınlık kalacak yeri kalemle çerçeveleyin · köşelerden büyütün, “Taşı” ile kaydırın · × kapatır')
    def place_overlays(self):
        sc=self.scroll;vp=sc.viewport().geometry()
        for o in (getattr(self,'spot',None),getattr(self,'curtain',None)):
            if o is not None: o.fit(vp); o.raise_()
        self.nav.adjustSize();self.nav.move(vp.x()+10,vp.bottom()-self.nav.height()-10);self.nav.raise_()   # lower left
        fb=getattr(self,'float_bell',None)
        if fb is not None:fb.place();fb.raise_()
        ds=getattr(self,'daily_strip',None)
        if ds is not None:   # Günün soruları: sağ üst; yüzen saat oradaysa onun altında
            top_=vp.y()+12
            if fb is not None and fb.isVisible() and fb.offset is None:top_=fb.geometry().bottom()+10
            ds.move(vp.right()-ds.width()-12,top_);ds.raise_()
        gb=getattr(self,'geo_bar',None)
        if gb is not None and gb.isVisible(): gb.place()
        gp=getattr(self,'geo_panel',None)
        if gp is not None and gp.isVisible(): gp.place()
        hb=getattr(self,'hide_button',None)
        if hb is not None:   # Çizimleri gizle: bottom centre of the board
            hb.adjustSize();hb.move(vp.x()+(vp.width()-hb.width())//2,vp.bottom()-hb.height()-10);hb.raise_()
        if getattr(self,'side_arrows',None):
            show=getattr(self,"doc",None) is not None and len(self.doc)>1 and not self.in_solution()
            # Both on the left edge, one above the other: Sonraki on top, Önceki below.
            left,right=self.side_arrows;y=vp.y()+(vp.height()-2*SIDE_ARROW_H-12)//2
            right.move(vp.x()+8,y);left.move(vp.x()+8,y+SIDE_ARROW_H+12)
            left.setEnabled(self.page>0);right.setEnabled(self.page<len(self.doc)-1)
            for a in self.side_arrows:a.setVisible(show);a.raise_()
        if self.toast.isVisible():
            # bottom right, beside the page controls: the top of the page stays readable
            room=max(240,min(760,vp.width()-self.nav.width()-40))
            self.toast.setFixedWidth(min(room,self.toast.fontMetrics().horizontalAdvance(self.toast.text())+48));self.toast.adjustSize()
            lift=0
            if hb is not None and self.toast.width()+20>vp.right()-hb.geometry().right():lift=hb.height()+10   # keep clear of Çizimleri gizle
            self.toast.move(vp.right()-self.toast.width()-10,vp.bottom()-self.toast.height()-10-lift);self.toast.raise_()
    # ---- Ayarlar: which buttons the left panel shows --------------------
    def apply_panel(self,hidden,save=True):
        self.panel_hidden=set(hidden)
        for key,label,widgets in self.panel_items:
            for w_ in widgets:w_.setVisible(key not in self.panel_hidden)
        # App buttons stay in two even columns whatever is hidden.
        for label,b in self.app_buttons:self.apps_grid.removeWidget(b)
        self.apps_grid.removeWidget(self.gear)
        shown=[(label,b) for label,b in self.app_buttons if 'app:'+label not in self.panel_hidden]+[('Ayarlar',self.gear)]   # Ayarlar hep görünür
        cells=[];row=[]
        for label,b in shown:   # iki sütun; adı uzun olan (Günün soruları) tam satır
            if label in ('Günün soruları',):
                if row:cells.append(row);row=[]
                cells.append([b])
            else:
                row.append(b)
                if len(row)==2:cells.append(row);row=[]
        if row:cells.append(row)
        for r,cs in enumerate(cells):
            if len(cs)==1:self.apps_grid.addWidget(cs[0],r,0,1,2)
            else:self.apps_grid.addWidget(cs[0],r,0);self.apps_grid.addWidget(cs[1],r,1)
        if save:
            try:
                with open(os.path.join(self.data_dir,'panel.json'),'w',encoding='utf-8') as f:json.dump(dict(hidden=sorted(self.panel_hidden)),f,ensure_ascii=False)
            except OSError as e:self.statusBar().showMessage('Ayarlar kaydedilemedi: '+str(e))
    def open_panel_settings(self):
        PanelSettings(self).exec_()
    def show_toast(self,text):
        if not text:return
        self.toast.setText(text);self.toast.show();self.place_overlays();self.toast_timer.start(4000)
    def eventFilter(self,obj,e):
        if obj is getattr(self,'scroll',None) and e.type() in (QEvent.Resize,QEvent.Show):self.place_overlays()
        return super().eventFilter(obj,e)
    def open_shapes(self):
        self.refresh_colors()   # a tap must not change the button's own state
        self.shape_popup.adjustSize()
        self.shape_popup.move(self.shape_button.mapToGlobal(QPoint(self.shape_button.width()+6,0)))
        self.shape_popup.show()
    def open_folder(self,popup,anchor):
        """Open a button's folder beside the panel, kept on screen."""
        self.refresh_colors();popup.adjustSize()
        screen=(self.windowHandle().screen() if self.windowHandle() else QApplication.primaryScreen()).availableGeometry()
        g=anchor.mapToGlobal(QPoint(anchor.width()+6,0))
        popup.move(max(screen.left(),min(g.x(),screen.right()-popup.width()-8)),max(screen.top()+8,min(g.y(),screen.bottom()-popup.height()-8)))
        if popup is self.erase_popup:self.unselect_button.setVisible(any(m['tool']=='whiteout' for m in self.marks.get(self.page,[])));popup.adjustSize()
        popup.show()
    def pick_shape(self,key):
        self.shape_popup.hide();self.set_tool(key)
    def __init__(self):
        super().__init__()
        self.doc = make_board()
        self.background = 'white'
        self.screen_session = None
        self.solution_origin=None;self.solutions={};self.view_by_undo=False
        self.data_dir=os.path.join(QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation),'umal-tahta')
        self.session_dir=os.path.join(self.data_dir,'son-pdf')
        self.tabs=None   # PDF tabs: [{'id','name','source'}], newest first; each tab has its own autosave folder
        self.session_pdf_pending=False
        self.session_pdf_name=None
        self.alt_ink={};self.alt_showing=set();self.alt_store={}   # Çizimleri gizle: second solution per page
        # PDF Havuzu: eşitleyici her dakika arka planda çalışır.
        self.havuz_timer=QTimer(self);self.havuz_timer.setInterval(60*1000);self.havuz_timer.timeout.connect(self.run_havuz);self.havuz_timer.start()
        QTimer.singleShot(20000,self.run_havuz)
        self.session_timer=QTimer(self);self.session_timer.setSingleShot(True)
        self.session_timer.timeout.connect(self.save_session)
        self.marks, self.undo_stack, self.redo_stack = {}, [], []
        # One ordered history across PDF pages, solution areas, tabs and screen ink:
        # each entry names where the edit happened, so Geri al can go there.
        self.histories = {}; self.history_ctx = None; self.undo_log = []; self.redo_log = []
        self.page, self.zoom, self.tool, self.color = 0, 1, 'pen', PEN_DEFAULT
        self.dirty, self.source = False, ''
        self.resize(1360, 850)
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(QIcon(LOGO))
        root = QWidget(); self.setCentralWidget(root)
        # Wide writing area: ONE slim top bar (logo, PDF tabs, icon buttons),
        # pen settings in the left panel, page controls floating on the board.
        layout = QVBoxLayout(root); layout.setContentsMargins(4,2,4,4); layout.setSpacing(4)
        top = QHBoxLayout(); top.setSpacing(6); layout.addLayout(top)
        logo = QLabel(); logo.setPixmap(QPixmap(LOGO).copy(5,50,600,600).scaled(40,40,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        logo.setToolTip(APP_NAME); top.addWidget(logo)
        self.return_pdf=QPushButton('Asıl PDF’ye dön');self.return_pdf.clicked.connect(self.return_to_pdf)
        self.return_pdf.setObjectName('primary');self.return_pdf.setIcon(tool_icon('Tahtaya dön'));self.return_pdf.setIconSize(QSize(22,22))
        self.return_pdf.setFixedHeight(40);top.addWidget(self.return_pdf);self.return_pdf.hide()
        # PDF tabs (kept across restarts): tap to switch, × to remove, + to open.
        self.tab_scroll=QScrollArea();self.tab_scroll.setWidgetResizable(True);self.tab_scroll.setFixedHeight(44)
        self.tab_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.tab_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.tab_scroll.setObjectName('tabs')
        self.tab_holder=QWidget();self.tab_row=QHBoxLayout(self.tab_holder);self.tab_row.setContentsMargins(0,0,0,0);self.tab_row.setSpacing(6)
        self.tab_scroll.setWidget(self.tab_holder);top.addWidget(self.tab_scroll,1)
        self.bell=BellClock(show_time=False);self.bell.sound_dir=self.data_dir;top.addWidget(self.bell);self.bell.hide()   # zil uyarısı (5 dk) burada çalışır; görünen saat tahtanın üstünde yüzer   # saat ve zile kalan süre: üst şeritte, yazma alanında yer kaplamaz
        self.filename = QLabel('Boş tahta · Kalemle yazmaya başlayın',self);self.filename.hide()   # name is on the tab
        body = QHBoxLayout(); body.setSpacing(4); layout.addLayout(body,1)
        tool_panel = QWidget()
        # Panel düğmeleri: ikon solda, adı yanında (iOS ayarlar düzeni)
        tool_panel.setStyleSheet('QPushButton{text-align:left;padding:8px 4px 8px 8px;font-size:15px;} QPushButton[ortala="true"]{text-align:center;padding-left:0;}')
        tools = QVBoxLayout(tool_panel); tools.setContentsMargins(0,0,6,0); tools.setSpacing(5)
        tool_scroll = QScrollArea(); tool_scroll.setWidgetResizable(True)
        tool_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        tool_scroll.setWidget(tool_panel); tool_scroll.setFixedWidth(256)   # room for big colours and a scroll bar
        body.addWidget(tool_scroll)
        top_row=QHBoxLayout();top_row.setSpacing(4);tools.addLayout(top_row)
        self.button(top_row,'Tam ekran',self.fullscreen)   # first, at the very top
        gear=self.gear=QPushButton('Ayarlar');gear.setIcon(tool_icon('Ayarlar'));gear.setIconSize(QSize(28,28));gear.clicked.connect(self.open_panel_settings)
        gear.setToolTip('Ayarlar: tahta görünümü, paneldeki düğmeler, güncelleme');gear.setAccessibleName('Ayarlar')
        gear.setFixedHeight(42)
        # Renk (7 dots in one row) and Kalınlık at the top of the panel.
        dots=QGridLayout();dots.setSpacing(4);dots.setContentsMargins(0,0,0,0);tools.addLayout(dots)
        self.color_buttons = []
        for color,label in [('#111111','Siyah'),('#e8132b','Kırmızı'),('#0057ff','Mavi'),('#00a24a','Yeşil'),('#8a2be2','Mor'),('#ff2d95','Pembe'),('#ffe14d','Sarı'),('#ffffff','Beyaz')]:
            b = QPushButton(); b.clicked.connect(lambda checked=False,c=color:self.set_color(c)); dots.addWidget(b, len(self.color_buttons)//4, len(self.color_buttons)%4, Qt.AlignCenter)
            b.setToolTip(label); b.setAccessibleName(label); b.setFixedSize(50,50)   # big enough for a fingertip
            b.setStyleSheet('QPushButton{padding:0;min-height:50px;max-height:50px;min-width:50px;max-width:50px;background:'+color+';border:2px solid #8292a8;border-radius:25px;}QPushButton:checked{border:4px solid #ffffff;}')
            b.setCheckable(True); self.color_buttons.append((color,b))
        pen_settings=QHBoxLayout();pen_settings.setSpacing(4);tools.addLayout(pen_settings)
        self.width = QSpinBox(); self.width.setRange(1,16); self.width.setValue(3); self.width.setSuffix(' pt')
        self.width.setButtonSymbols(QSpinBox.NoButtons); self.width.setAlignment(Qt.AlignCenter)
        self.width.setReadOnly(True); self.width.setFixedHeight(42); self.width.setToolTip('Kalınlık')
        self.width.setStyleSheet('QSpinBox{padding:0;}')
        minus=self.button(pen_settings,'−',self.width.stepDown);minus.setFixedSize(48,42);minus.setAccessibleName('Kalemi incelt');minus.setToolTip('Kalemi incelt')
        pen_settings.addWidget(self.width,1)
        plus=self.button(pen_settings,'+',self.width.stepUp);plus.setFixedSize(48,42);plus.setAccessibleName('Kalemi kalınlaştır');plus.setToolTip('Kalemi kalınlaştır')
        for w_ in (minus,plus):w_.setStyleSheet('QPushButton{padding:0;min-height:0;}')
        tools.addSpacing(4)
        self.tool_buttons = {}; self.tool_labels = {}
        # Çizgi, Dikdörtgen, Elips, Kesikli çizgi live in one Şekiller folder:
        # tap it and the four open beside the panel.
        def folder():   # klasör menüleri: panel gibi ikon solda, adı yanında
            w_=QWidget(self,Qt.Popup);l_=QVBoxLayout(w_);l_.setContentsMargins(6,6,6,6);l_.setSpacing(6)
            w_.setStyleSheet('QPushButton{text-align:left;padding-left:12px;}');return w_,l_
        self.shape_popup,shapes=folder()
        # Çözüm alanı: one button, kareli or beyaz inside. Silgi: tap = rub
        # out, and Alan silgisi / Tümünü sil open beside it.
        self.sol_popup,sols=folder();self.erase_popup,ers=folder()
        for key,label in [('pen','Kalem'),('solution','Çözüm alanı'),('select','Alan seç'),('highlight','Fosforlu'),('eraser','Silgi'),('area_eraser','Alan silgisi'),('hand','Taşı'),('smart','Akıllı seçim'),('line','Çizgi'),('arrow','Ok'),('rect','Dikdörtgen'),('circle','Elips'),('triangle','Üçgen'),('dash','Kesikli çizgi')]:
            if key=='line':self.shape_button=self.button(tools,'Şekiller',self.open_shapes);self.shape_button.setCheckable(True)
            if key=='solution':self.solution_button=self.button(tools,'Çözüm alanı',lambda checked=False:self.set_tool('solution'));self.solution_button.setCheckable(True)   # tek dokunuş: kareli çözüm alanı
            if key in SHAPE_TOOLS:
                b=self.button(shapes,label,lambda checked=False,k=key:self.pick_shape(k));b.setMinimumWidth(240)
            elif key in ('solution','select'):
                b=self.button(sols,label,lambda checked=False,k=key:(self.sol_popup.hide(),self.set_tool(k)));b.setMinimumWidth(260)
                b.setText({'solution':'Kareli çözüm alanı','select':'Beyaz çözüm alanı'}[key])
            elif key=='area_eraser':
                b=self.button(ers,label,lambda checked=False:(self.erase_popup.hide(),self.set_tool('area_eraser')));b.setMinimumWidth(260)
            elif key=='eraser':
                b=self.button(tools,label,lambda checked=False:(self.set_tool('eraser'),self.open_folder(self.erase_popup,self.tool_buttons['eraser'])))
            else:b = self.button(tools,label,lambda checked=False,k=key:self.set_tool(k))
            b.setCheckable(True); self.tool_buttons[key] = b; self.tool_labels[key] = label
            if key == 'area_eraser':
                self.clear_button=self.button(ers,'Tümünü sil',lambda checked=False:(self.erase_popup.hide(),self.clear_page()));self.clear_button.setMinimumWidth(260)
                # old "Alan seç" pages may still carry the white cover: removable here
                self.unselect_button=self.button(ers,'Seçimi kaldır',lambda checked=False:(self.erase_popup.hide(),self.remove_selection()));self.unselect_button.setMinimumWidth(260)
        self.tool_buttons['pen'].setChecked(True)
        # Kalem stili: Normal, Tebeşir, Keçeli, Kurşun kalem, Neon.
        # The five pen tips sit on the Kalem row itself (keeps the tool list
        # short enough to fit the board screen without scrolling).
        self.pen_style='fluid';chips=QWidget();row=QHBoxLayout(chips);row.setContentsMargins(0,0,0,0);row.setSpacing(3)
        pen=self.tool_buttons['pen'];tools.removeWidget(pen);pen.setText('');pen.setToolTip('Kalem');pen.setAccessibleName('Kalem')
        pen.setFixedSize(42,42);pen.setIconSize(QSize(26,26));pen.setStyleSheet('padding:0;');row.addWidget(pen)
        self.style_buttons={}
        for key,label in PEN_STYLES:
            short={'fluid':'Akıcı','laser':'Neon'}.get(key,label)
            b=QPushButton(short);b.setIcon(tool_icon(short) if short in PREMIUM_ICONS else style_icon(key,18));b.setIconSize(QSize(24,24));b.setMinimumWidth(21);b.setFixedHeight(42);b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed);b.setCheckable(True)
            b.setToolTip('Kalem ucu: '+label);b.setAccessibleName('Kalem ucu: '+label)
            if key=='laser':b.setToolTip('Neon kalem: yazdıklarınız birkaç saniye parlar, sonra kendiliğinden söner (kaydedilmez)')
            b.setStyleSheet('QPushButton{padding:0 0 0 8px;text-align:left;min-height:42px;max-height:42px;min-width:21px;}')
            b.clicked.connect(lambda checked=False,k=key:self.set_pen_style(k));row.addWidget(b);self.style_buttons[key]=b
        self.style_buttons['fluid'].setChecked(True)
        self.style_name=QLabel('Akıcı',self);self.style_name.hide()
        tools.insertWidget(4,chips)
        # Taşı: only the hand symbol, right under the pen row.
        hand=self.tool_buttons['hand'];tools.removeWidget(hand);hand.setText('Taşı');hand.setToolTip('Taşı (sayfayı kaydır)')
        hand.setAccessibleName('Taşı');hand.setIconSize(QSize(28,28));hand.setFixedHeight(42)
        tools.insertWidget(5,hand)
        self.nib = QComboBox(self);self.nib.addItem('Yuvarlak uç','round');self.nib.hide()
        b=self.button(tools,'Post-it',lambda checked=False:self.set_tool('postit'))
        self.tool_buttons['postit']=b;self.tool_labels['postit']='Post-it';b.setCheckable(True)
        b.setToolTip('Post-it: soruyu ve çözümünü çerçeveleyin; küçülüp sağdaki panoya yapışır')
        # Perde (reveal the solution step by step) and Spot ışığı (darken all but one part).
        show_row=QHBoxLayout();show_row.setSpacing(4);tools.addLayout(show_row)
        self.curtain_button=self.button(show_row,'Perde',lambda checked=False:self.toggle_curtain())
        self.spot_button=self.button(show_row,'Spot ışığı',lambda checked=False:self.toggle_spot());self.spot_button.setText('Spot')
        for b_ in (self.curtain_button,self.spot_button):
            b_.setCheckable(True);b_.setMinimumWidth(60);b_.setFixedHeight(42);b_.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        self.curtain_button.setToolTip('Perde: çözümü örter; tutamağı çektikçe adım adım açılır')
        self.spot_button.setToolTip('Spot ışığı: tahta kararır, çerçevelediğiniz yer aydınlık kalır')
        self.curtain=None;self.spot=None
        # Alkış: tahtaya kalkan öğrenciyi onurlandırmak için roketler, konfeti ve alkış sesi.
        self.cheer_button=self.button(tools,'Alkış',lambda checked=False:self.celebrate());self.cheer_button.setFixedHeight(42)
        self.cheer_button.setToolTip('Alkış: roketler, konfeti ve alkış sesi (yaklaşık 6 saniye)')
        # Tahta arka planı: a folder like Şekiller.
        # Arka plan and Tema live in Ayarlar now (set once, rarely changed).
        self.bg_button=QPushButton('Arka plan');self.theme_button=QPushButton('Tema')
        self.bg_popup=QWidget(self,Qt.Popup);bgs=QVBoxLayout(self.bg_popup);bgs.setContentsMargins(6,6,6,6);bgs.setSpacing(6)
        self.bg_buttons = {}
        for label,key in BACKGROUNDS:
            b = self.button(bgs,label,lambda checked=False,k=key:(self.bg_popup.hide(),self.set_background(k)))
            b.setCheckable(True); b.setMinimumWidth(240); self.bg_buttons[key]=b
        self.bg_buttons['white'].setChecked(True)
        history=QHBoxLayout();history.setSpacing(4);tools.addLayout(history)
        self.history_buttons=(self.button(history,'Geri al',self.undo),self.button(history,'İleri al',self.redo))
        for b in self.history_buttons:
            b.setMinimumWidth(60);b.setFixedHeight(42);b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        # App buttons right under İleri al: two columns of labelled buttons.
        self.app_buttons=[];apps=QGridLayout();apps.setHorizontalSpacing(4);apps.setVerticalSpacing(tools.spacing());apps.setContentsMargins(0,0,0,0);tools.addLayout(apps)
        self.tools_popup,tl=folder()
        for text,fn in (('Sayaç',self.open_timer),('Hesap makinesi',self.open_calc),('Grafik çizici',self.open_graph),('Şablonlar',self.open_templates),
                        ('Cetvel',lambda:self.toggle_ruler()),('Pergel',lambda:self.set_tool('compass'))):
            b=self.button(tl,text,lambda checked=False,f_=fn:(self.tools_popup.hide(),f_()));b.setMinimumWidth(260)
        for i,(label,text,fn,name) in enumerate([('Ekrana yaz','Ekrana yaz',self.screen_ink,''),('PDF kaydet','Kaydet',self.save_pdf,'primary'),
                              ('Günün soruları','Günün soruları',self.open_daily,''),
                              ('Araçlar','Araçlar',lambda checked=False:self.open_folder(self.tools_popup,self.tools_button),'')]):
            b=QPushButton(text);b.setObjectName(name);b.setIcon(tool_icon(label));b.setIconSize(QSize(22,22));b.clicked.connect(fn)
            b.setToolTip(label);b.setAccessibleName(label);b.setMinimumWidth(60);b.setFixedHeight(42);b.setIconSize(QSize(26,26))
            b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
            apps.addWidget(b,i//2,i%2);self.app_buttons.append((label,b))
            if label=='Araçlar':self.tools_button=b
        self.apps_grid=apps;apps.setColumnStretch(0,1);apps.setColumnStretch(1,1)   # iki sütun eşit
        tri_b=self.button(shapes,'Ölçülü üçgen',lambda checked=False:(self.shape_popup.hide(),self.open_triangle()));tri_b.setMinimumWidth(240)
        for b_ in tool_panel.findChildren(QPushButton):   # yazısız / tek işaretli düğmeler (renkler, −, +, uçlar, el) ortada kalır
            if len(b_.text().strip()) <= 2: b_.setProperty('ortala', True)
            elif b_ is not self.tool_buttons.get('pen'): b_.setIconSize(QSize(26,26))   # bütün panelde aynı ikon boyu
        gear.setFixedHeight(42);gear.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed);apps.addWidget(gear,9,0,1,2)   # Ayarlar: Araçlar'ın yanına (yerleşim aşağıda)
        self.panel_clock=PanelClock();tools.addWidget(self.panel_clock,1)   # saat ve tarih: the empty space below
        self.panel_items=[('renkler','Renkler',[b for c,b in self.color_buttons]),('kalinlik','Kalınlık',[minus,self.width,plus]),
            ('kalem','Kalem',[self.tool_buttons['pen']]),('uclar','Kalem uçları',list(self.style_buttons.values())),('tasi','Taşı (el)',[self.tool_buttons['hand']])]
        self.panel_items+=[('solution','Çözüm alanı',[self.solution_button]),('highlight','Fosforlu',[self.tool_buttons['highlight']]),('eraser','Silgi',[self.tool_buttons['eraser']]),
            ('smart','Akıllı seçim',[self.tool_buttons['smart']]),('sekiller','Şekiller',[self.shape_button]),('postit','Post-it',[self.tool_buttons['postit']]),
            ('perde','Perde',[self.curtain_button]),('spot','Spot ışığı',[self.spot_button]),('alkis','Alkış',[self.cheer_button]),
            ('geri_al','Geri al',[self.history_buttons[0]]),('ileri_al','İleri al',[self.history_buttons[1]])]
        self.panel_items+=[('app:'+label,b.text(),[b]) for label,b in self.app_buttons]
        try:
            with open(os.path.join(self.data_dir,'panel.json'),encoding='utf-8') as f:hidden=json.load(f).get('hidden',[])
        except (OSError,ValueError,AttributeError):hidden=[]
        self.apply_panel(set(hidden) if isinstance(hidden,list) else set(),save=False)
        self.scroll = PageScroll(); self.scroll.setAlignment(Qt.AlignCenter); self.scroll.setObjectName('page')   # sayfanın arkası: desen, ışık, gölge
        self.board = Board(self); self.scroll.setWidget(self.board); body.addWidget(self.scroll,1)
        self.board.setAttribute(Qt.WA_OpaquePaintEvent)   # sayfa kendini tam boyar: arka planla birlikte yeniden çizilmez
        self.pano = PostItPano(self); body.addWidget(self.pano); self.pano.hide(); self.pano_dir = None; self.pano_hidden = False
        # Hidden pano leaves this slim tab at the right edge: tap to open again.
        self.pano_tab = QPushButton('0'); self.pano_tab.setIcon(tool_icon('Post-it')); self.pano_tab.setIconSize(QSize(26, 26))
        self.pano_tab.setToolTip('Post-it panosunu aç'); self.pano_tab.setAccessibleName('Post-it panosunu aç')
        self.pano_tab.setFixedSize(52, 120); self.pano_tab.setStyleSheet('QPushButton{padding:0;min-height:120px;max-height:120px;font-size:16px;font-weight:bold;}')
        self.pano_tab.clicked.connect(lambda: self.set_pano_hidden(False))
        tab_col = QVBoxLayout(); tab_col.setContentsMargins(0, 0, 0, 0); tab_col.addWidget(self.pano_tab); tab_col.addStretch(); body.addLayout(tab_col)
        self.pano_tab.hide()
        # Page and zoom controls float in the board's lower right corner.
        self.nav=QWidget(self.scroll);self.nav.setObjectName('nav')
        self.nav.setStyleSheet('QWidget#nav{background:rgba(14,28,50,215);border:1px solid rgba(255,255,255,0.14);border-radius:16px;}'
                               'QWidget#nav QPushButton{padding:0 8px;min-height:36px;max-height:36px;font-size:14px;} QWidget#nav QLabel{background:transparent;font-size:14px;}')
        bottom=QHBoxLayout(self.nav);bottom.setContentsMargins(6,4,6,4);bottom.setSpacing(4)
        prev=self.button(bottom,'Önceki',lambda:self.goto(-1));prev.setText('‹')
        self.page_label = QLabel(); bottom.addWidget(self.page_label)
        nxt=self.button(bottom,'Sonraki',lambda:self.goto(1));nxt.setText('›')
        prev.hide();nxt.hide()   # the big arrows on both sides of the screen turn pages
        self.side_arrows=[]
        for text,delta,name in (('‹',-1,'Önceki sayfa'),('›',1,'Sonraki sayfa')):
            a=QPushButton(text,self.scroll);a.setObjectName('side_arrow');a.setFixedSize(SIDE_ARROW_W,SIDE_ARROW_H);a.setToolTip(name);a.setAccessibleName(name)
            a.setFocusPolicy(Qt.NoFocus);a.clicked.connect(lambda checked=False,d=delta:self.goto(d))
            g_,css_=glyph_style(0xe13a if delta>0 else 0xe138, 40); a.setText(g_)
            a.setStyleSheet('QPushButton#side_arrow{background:rgba(14,28,50,200);color:white;border:1px solid rgba(255,255,255,0.16);border-radius:18px;padding:0;min-height:0;%s}'
                            'QPushButton#side_arrow:pressed{background:rgba(40,110,232,220);}QPushButton#side_arrow:disabled{background:rgba(14,28,50,80);color:rgba(255,255,255,70);border-color:rgba(255,255,255,0.06);}' % css_)
            self.side_arrows.append(a)
        self.button(bottom,'Sayfaya git',self.go_to_page)
        zo=self.button(bottom,'−',lambda:self.set_zoom(self.zoom/1.2))
        self.button(bottom,'Sığdır',self.fit_page)
        zi=self.button(bottom,'+',lambda:self.set_zoom(self.zoom*1.2))
        for b_,c_,n_ in ((zo,0xe32a,'Küçült'),(zi,0xe3d4,'Büyüt')):
            g_,css_=glyph_style(c_,18);b_.setText(g_);b_.setStyleSheet('QPushButton{%s}'%css_);b_.setToolTip(n_);b_.setAccessibleName(n_)
        for b in self.nav.findChildren(QPushButton):
            b.setToolTip(b.accessibleName() or b.text())
            if b.text() in ('−','+'):b.setMinimumWidth(48)
        # Messages appear briefly on the board instead of a status line.
        self.hide_button=QPushButton('  Çizimleri gizle',self.scroll);self.hide_button.setObjectName('hideink');self.hide_button.setCheckable(True)
        self.hide_button.setIcon(tool_icon('Gizle'));self.hide_button.setIconSize(QSize(24,24));self.hide_button.setFocusPolicy(Qt.NoFocus)
        self.hide_button.setToolTip('Bu sayfadaki bütün çizimleri gizler; tekrar basınca geri getirir')
        self.hide_button.setStyleSheet('QPushButton#hideink{background:rgba(14,28,50,215);color:white;border:1px solid rgba(255,255,255,0.14);border-radius:22px;padding:0 22px;min-height:44px;max-height:44px;font-size:16px;font-weight:bold;}'
                                       'QPushButton#hideink:checked{background:#ffc526;color:#122034;border:2px solid #ffffff;}')
        self.hide_button.clicked.connect(lambda checked=False:self.toggle_hidden_ink())
        self.hide_button.adjustSize()
        self.toast=QLabel(self.scroll);self.toast.setObjectName('toast');self.toast.setWordWrap(True);self.toast.setAlignment(Qt.AlignCenter)
        self.toast.setStyleSheet('QLabel#toast{background:rgba(10,32,62,235);color:white;border:1px solid #526780;border-radius:10px;padding:8px 14px;font-size:15px;}')
        self.toast.hide();self.toast_timer=QTimer(self);self.toast_timer.setSingleShot(True);self.toast_timer.timeout.connect(self.toast.hide)
        self.float_bell=None;self.daily_strip=None;self.load_daily();self.daily_strip=DailyStrip(self);self.daily_strip.sync()
        self.float_bell=FloatingBell(self)   # yüzen zil saati (sağ üst)   # Günün soruları: sağ üstte 1, 2, 3…
        self.statusBar().messageChanged.connect(self.show_toast);self.statusBar().hide()

        self.scroll.installEventFilter(self)
        self.scroll.verticalScrollBar().valueChanged.connect(self.scrolled)
        try:
            with open(os.path.join(self.data_dir,'tema.json'),encoding='utf-8') as f:saved=json.load(f).get('theme')
        except (OSError,ValueError,AttributeError):saved=None
        self.apply_theme(saved if saved in THEMES else 'default',save=False)
        for key,fn in [('Ctrl+O',self.open_pdf),('Ctrl+S',self.save_pdf),('Ctrl+Z',self.undo),('Ctrl+Shift+Z',self.redo),('F11',self.fullscreen),('Escape',self.showNormal),('PageDown',lambda:self.goto(1)),('PageUp',lambda:self.goto(-1))]:
            QShortcut(QKeySequence(key),self,activated=fn)
        QTimer.singleShot(0,self.fit_page)
        self.refresh_colors()

    def screen_ink(self):
        self.board.finish()
        if sys.platform!='win32' and QApplication.platformName() != 'xcb':
            QMessageBox.information(self,'Ekrana yaz','Masaüstüne yazma modu X11 oturumu gerektirir. Pardus giriş ekranında X11/Xorg oturumunu seçin. Tahta ve PDF özelliklerini bu oturumda kullanabilirsiniz.')
            return
        try:
            if sys.platform=='win32':compositing=True
            else:
                compositing=x11_compositing_running()
            if not compositing:
                QMessageBox.information(self,'Ekrana yaz','Saydam ekran için masaüstünün birleştirme (compositing) özelliği açık olmalı. Pardus Pencere Yöneticisi Ayarları içinden etkinleştirin.')
                return
        except ImportError:
            QMessageBox.warning(self,'Eksik bileşen','python3-pyqt5.qtx11extras paketini yüklemek için uygulama kurulumunu tamamlayın.')
            return
        if self.screen_session is None: self.screen_session = ScreenSession(self)
        self.screen_session.enter()

    def set_background(self, key):
        if self.background is None: return
        self.board.finish()
        old = self.doc; r=old[0].rect
        self.doc = make_board(key,r.width,r.height); old.close()
        self.background = key
        if key in DARK_BACKGROUNDS and self.color in ('#172b4d','#000000',PEN_DEFAULT): self.color='#ffffff'
        elif key not in DARK_BACKGROUNDS and self.color=='#ffffff': self.color=PEN_DEFAULT
        for k,b in self.bg_buttons.items(): b.setChecked(k==key)
        self.session_pdf_pending=True
        self.changed(); self.render()

    def select_area(self, points):
        """Alan seç: the chosen part opens like Çözüm alanı, on a white,
        endless writing area (inside a solution area it frames as before)."""
        if self.solution_origin is None: self.make_solution(points, 'white')
        else: self.apply_selection(points)
    def make_solution(self, points, bg=None):
        a,b=points;clip=fitz.Rect(min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1]))
        if min(clip.width,clip.height)*self.board.scale<12:return
        if self.solution_origin is not None:
            self.statusBar().showMessage('Yeni bir soru seçmek için önce Asıl PDF’ye dön düğmesini kullanın.');return
        try:
            # The original stays in the autosaved base PDF (written once);
            # only its name and the notes are kept, never a full re-export.
            if not self.save_session():raise ValueError('Otomatik kayıt yapılamadı.')
            # Same question selected again (mostly overlapping frame on the
            # same page): reopen its saved solution instead of a blank one.
            previous=max(((solution_overlap(v['rect'],clip),k) for k,v in self.solutions.items() if v.get('page')==self.page),default=(0,None))
            key=previous[1] if previous[0]>=.5 else '%d:%.1f,%.1f,%.1f,%.1f'%(self.page,*clip)
            if previous[0]>=.5:clip=fitz.Rect(self.solutions[key]['rect'])
            origin=dict(pdf=self.session_pdf_name,marks=copy.deepcopy(self.marks),source=self.source,page=self.page,zoom=self.zoom,dirty=self.dirty,
                        solutions=copy.deepcopy(self.solutions),key=key,rect=list(clip))
            stored=self.solutions.get(key,{}) if previous[0]>=.5 else {}
            origin['bg']=stored.get('bg') or bg or 'grid'   # a reopened question keeps its own background
            with open(os.path.join(self.session_dir,'soru-kaynagi.json'),'w',encoding='utf-8') as f:
                json.dump(dict({k:origin[k] for k in ('source','page','zoom','dirty','pdf','key','rect','bg')},marks={str(k):v for k,v in origin['marks'].items()},
                               solutions={k:dict(v,marks={str(p):m for p,m in v['marks'].items()}) for k,v in origin['solutions'].items()}),f,ensure_ascii=False)
            with tempfile.TemporaryDirectory() as folder:
                single=fitz.open();single.insert_pdf(self.doc,from_page=self.page,to_page=self.page)
                path=os.path.join(folder,'soru.pdf');export_document(single,{0:self.marks.get(self.page,[])},path);single.close()
                rendered=fitz.open(path)
                scale=min(3,math.sqrt(6000000/(clip.width*clip.height)))
                pix=rendered[0].get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,alpha=False)
                png=pix.tobytes('png');rendered.close()
            card_width=864;card_height=min(300,card_width*clip.height/clip.width)
            doc=make_board(origin['bg'],960,max(800,float(stored.get('height',800))));page=doc[0]
            page.draw_rect(fitz.Rect(24,20,936,card_height+52),color=(.78,.82,.88),fill=(1,1,1),width=.8)
            page.insert_image(fitz.Rect(48,36,912,36+card_height),stream=png,keep_proportion=True)
            doc.set_metadata({'title':'Soru ve çözüm — '+APP_NAME,'keywords':'UMAL-solution'})
            self.replace(doc,persist=False);self.solution_origin=origin
            self.return_pdf.show();self.filename.setText('Soru kartı · Altındaki alana çözümünüzü yazın')
            self.set_tool('pen');self.color=PEN_DEFAULT;self.dirty=True
            if key in origin['solutions']:
                self.marks={0:copy.deepcopy(origin['solutions'][key]['marks'].get(0,[]))}
                self.statusBar().showMessage('Bu sorunun önceki çözümü açıldı. Asıl PDF’ye dön ile kitaba dönebilirsiniz.')
            QTimer.singleShot(0,self.solution_zoom);self.session_pdf_pending=True;self.save_session()
        except Exception as e:QMessageBox.warning(self,'Çözüm alanı açılamadı',str(e))

    # ---- Günün soruları -------------------------------------------------
    def daily_dir(self): return os.path.join(self.data_dir, 'gunun-sorulari')
    def load_daily(self):
        try:
            with open(os.path.join(self.daily_dir(), 'liste.json'), encoding='utf-8') as f: d = json.load(f)
        except (OSError, ValueError): d = {}
        self.daily = dict(date=daily_today(), items=[])
        ok = lambda it: all(os.path.isfile(os.path.join(self.daily_dir(), it.get(k) or '')) for k in ('snap', 'qsnap'))
        if d.get('date') == daily_today(): self.daily['items'] = [it for it in d.get('items', []) if ok(it)]
        else: self.clear_daily(save=False)
        self.save_daily()
    def save_daily(self):
        os.makedirs(self.daily_dir(), exist_ok=True)
        try:
            with open(os.path.join(self.daily_dir(), 'liste.json'), 'w', encoding='utf-8') as f: json.dump(self.daily, f, ensure_ascii=False)
        except OSError: pass
        if getattr(self, 'daily_strip', None) is not None: self.daily_strip.sync(); self.place_overlays()
    def clear_daily(self, save=True):
        folder = self.daily_dir()
        if os.path.isdir(folder):
            for n in os.listdir(folder):
                if n.endswith('.pdf'):
                    try: os.remove(os.path.join(folder, n))
                    except OSError: pass
        self.daily = dict(date=daily_today(), items=[])
        if save: self.save_daily(); self.board.update()
    def daily_cfg(self):
        try:
            with open(os.path.join(self.daily_dir(), 'ayar.json'), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {}
    def save_daily_cfg(self, cfg):
        os.makedirs(self.daily_dir(), exist_ok=True)
        try:
            with open(os.path.join(self.daily_dir(), 'ayar.json'), 'w', encoding='utf-8') as f: json.dump(cfg, f, ensure_ascii=False)
        except OSError: pass
    def daily_selected(self): return [it for it in self.daily['items'] if it.get('include', it['done'])]
    def daily_store(self, item, data, crop, kind='snap'):
        os.makedirs(self.daily_dir(), exist_ok=True)
        old = item.get(kind); item[kind] = 'soru-%s.pdf' % uuid.uuid4().hex[:10]; item['qcrop' if kind == 'qsnap' else 'crop'] = crop
        with open(os.path.join(self.daily_dir(), item[kind]), 'wb') as f: f.write(data)
        if old:
            try: os.remove(os.path.join(self.daily_dir(), old))
            except OSError: pass
    def daily_match(self, tab, page, rect):
        best = max(((solution_overlap(it['rect'], list(rect)), i) for i, it in enumerate(self.daily['items']) if it['tab'] == tab and it['page'] == page), default=(0, None))
        return best[1] if best[0] >= .5 else None
    def daily_current(self):
        o = self.solution_origin
        return None if o is None else self.daily_match(self.current_tab(), o['page'], o['rect'])
    def add_planned(self, pts):
        """Soru seç: dersin başında seçilen soru listeye (sırayla) eklenir."""
        if self.solution_origin is not None: self.show_toast('Soru seçmek için önce Asıl PDF’ye dönün.'); return
        a, b = pts; clip = fitz.Rect(min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1]))
        if min(clip.width, clip.height)*self.board.scale < 12: return
        if self.daily_match(self.current_tab(), self.page, clip) is not None: self.show_toast('Bu soru zaten listede.'); return
        if self.daily.get('date') != daily_today(): self.clear_daily(save=False)
        try: data, crop, qcrop = question_card(self.doc, self.page, self.marks.get(self.page, []), clip)
        except Exception as e: QMessageBox.warning(self, 'Soru eklenemedi', str(e)); return
        it = dict(tab=self.current_tab(), source=self.source, page=self.page, rect=list(clip), done=False)
        self.daily_store(it, data, crop); self.daily_store(it, data, qcrop, 'qsnap'); self.daily['items'].append(it); self.save_daily(); self.board.update()
        self.show_toast('%d. soru listede. Sıradakini çerçeveleyin; bitince başka bir araç seçin.' % len(self.daily['items']))
    def daily_solved(self, origin, written):
        """Çözüm alanından çıkarken: soru listedeyse çözümü eklenir, değilse sona eklenir."""
        if self.daily.get('date') != daily_today(): self.clear_daily(save=False)
        tab = self.current_tab(); i = self.daily_match(tab, origin['page'], origin['rect'])
        if i is None and not written: return
        base = os.path.join(self.session_dir, origin['pdf']) if origin.get('pdf') else None
        src = fitz.open(base) if base and os.path.isfile(base) else fitz.open(stream=origin['data'], filetype='pdf')
        pm = origin['marks'].get(origin['page'], [])
        try:
            data, crop, _ = question_card(src, origin['page'], pm, origin['rect'], written)
            blank = question_card(src, origin['page'], pm, origin['rect']) if i is None or not self.daily['items'][i].get('qsnap') else None
        finally: src.close()
        if i is None:
            it = dict(tab=tab, source=origin.get('source', ''), page=origin['page'], rect=list(origin['rect']), done=True)
            self.daily['items'].append(it)
        else:
            it = self.daily['items'][i]; it['done'] = bool(written)
            if written: it['include'] = True
        self.daily_store(it, data, crop)
        if blank: self.daily_store(it, blank[0], blank[2], 'qsnap')
        self.save_daily()
    def daily_open(self, i):
        it = self.daily['items'][i]
        if self.solution_origin is not None:
            if self.daily_current() == i: return
            self.return_to_pdf()
        if it['tab'] != self.current_tab():
            if any(t['id'] == it['tab'] for t in self.tabs or []): self.switch_tab(it['tab'])
            elif it.get('source') and os.path.isfile(it['source']): self.open_pdf_path(it['source']); it['tab'] = self.current_tab(); self.save_daily()
            else: self.show_toast('Bu sorunun PDF’si tahtada açık değil.'); return
        if it['page'] >= len(self.doc): return
        self.goto(it['page'] - self.page); r = it['rect']; self.make_solution([[r[0], r[1]], [r[2], r[3]]]); self.daily_strip.update()
    def write_daily(self, target, topic, teacher):
        build_daily_pdf(self.daily_selected(), self.daily_dir(), daily_date_text(), topic, teacher, target)
    def send_daily(self, topic, teacher):
        if self.solution_origin is not None: self.return_to_pdf()
        os.makedirs(GUNUN_DIR, exist_ok=True)
        safe = ''.join(c for c in topic if c not in '\\/:*?"<>|').strip()
        base = daily_today() + (' ' + safe if safe else ''); name = base + '.pdf'; k = 2
        while os.path.exists(os.path.join(GUNUN_DIR, name)): name = '%s (%d).pdf' % (base, k); k += 1
        tmp = os.path.join(GUNUN_DIR, '.' + name + '.yeni'); self.write_daily(tmp, topic, teacher); os.replace(tmp, os.path.join(GUNUN_DIR, name))
        self.clear_daily(); self.run_havuz('--simdi')
        return name
    def celebrate(self):
        self.board.finish()
        if getattr(self, 'celebration', None) is None: self.celebration = Celebration(self)
        self.celebration.start()
        try: play_sound(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sesler', 'alkis.wav'), 1.0)   # tam ses
        except Exception: pass
    def toggle_ruler(self, on=None):
        if getattr(self, 'ruler', None) is None: self.ruler = Ruler(self)
        on = not self.ruler.isVisible() if on is None else on
        if on: self.ruler.place(); self.ruler.show(); self.ruler.raise_(); self.statusBar().showMessage('Cetvel: gövdesinden sürükleyin, sağ uçtaki tutamakla döndürün; kenarına yakın çizdiğiniz çizgi dümdüz olur. Sol uçtaki × kaldırır.')
        else: self.ruler.hide()
        if on and self.tool not in ('pen', 'dash', 'highlight'): self.set_tool('pen')
    def geo_action(self, key):
        b = self.board; m = b.geo_model(); b.finish()
        if key == 'nokta': self.set_tool('pen' if self.tool == 'geo' else 'geo'); return
        if key == 'gir': self.set_tool('geo'); GeoInput(self).exec_(); return
        if key == 'gizle':
            self.geo_hide = not getattr(self, 'geo_hide', False); self.geo_bar.sync()
            self.statusBar().showMessage('Yeni sonuçlar “?” olarak gelir; açmak için sonuç kutusuna dokunun.' if self.geo_hide else 'Yeni sonuçlar açık gösterilir.'); return
        if key == 'temizle':
            if m is None: return
            self.checkpoint(); self.marks[self.page] = [s for s in self.marks.get(self.page, []) if s is not m]; b.geo_sel = []; self.changed(); b.update(); self.geo_bar.sync(); self.geo_panel_sync(); return
        if m is None: self.statusBar().showMessage('Önce “Nokta koy” ile ızgaraya dokunarak nokta koyun.'); return
        b.geo_valid_sel(m); sel = b.geo_sel; pts = [i for t, i in sel if t == 'p']; lns = [i for t, i in sel if t == 'o']
        if key == 'sil':
            if not sel: self.statusBar().showMessage('Silmek için bir nokta ya da doğru seçin.'); return
            self.checkpoint(); gone_p = set(pts); gone_o = set(lns)
            for k, o in enumerate(m['O']):   # silinenlere bağlı sonuçlar da gider
                refs_p = [o[x] for x in ('a', 'b', 'p') if x in o]; refs_o = [o[x] for x in ('l', 'm') if x in o]
                if any(r in gone_p for r in refs_p) or any(r in gone_o for r in refs_o): gone_o.add(k)
            pmap = {}; newP = []
            for i, q in enumerate(m['P']):
                if i not in gone_p: pmap[i] = len(newP); newP.append(q)
            omap = {}; newO = []
            for k, o in enumerate(m['O']):
                if k in gone_o: continue
                o = dict(o)
                for x in ('a', 'b', 'p'):
                    if x in o: o[x] = pmap[o[x]]
                for x in ('l', 'm'):
                    if x in o: o[x] = omap[o[x]]
                omap[k] = len(newO); newO.append(o)
            m['P'], m['O'] = newP, newO; b.geo_sel = []; b.geo_touch(m); return
        need = {'dist': 'iki nokta', 'line': 'iki nokta', 'slope': 'iki nokta', 'mid': 'iki nokta', 'par': 'bir doğru ve bir nokta', 'perp': 'bir doğru ve bir nokta', 'cut': 'iki doğru'}[key]
        if key in ('dist', 'line', 'slope', 'mid') and len(pts) == 2: o = dict(t=key, a=pts[0], b=pts[1])
        elif key in ('par', 'perp') and len(pts) == 1 and len(lns) == 1: o = dict(t=key, l=lns[0], p=pts[0])
        elif key == 'cut' and len(lns) == 2: o = dict(t=key, l=lns[0], m=lns[1])
        else: self.statusBar().showMessage('Bunun için %s seçin (dokunarak).' % need); return
        if any({k_: v for k_, v in q.items() if k_ != 'h'} == o for q in m['O']): self.statusBar().showMessage('Bu zaten tahtada.'); return
        if getattr(self, 'geo_hide', False): o['h'] = True
        self.checkpoint(); m['O'].append(o); b.geo_touch(m)
    def geo_after_history(self):
        if getattr(self, 'geo_bar', None) is not None and self.geo_bar.isVisible():
            self.board.geo_valid_sel(self.board.geo_model()); self.geo_bar.sync(); self.geo_panel_sync()
    def geo_reveal(self, k):
        m = self.board.geo_model()
        if m is not None and k < len(m['O']): m['O'][k]['h'] = False; self.board.geo_touch(m)
    def geo_panel_sync(self):
        gb = getattr(self, 'geo_bar', None); on = gb is not None and gb.isVisible()
        m = self.board.geo_model() if on else None
        if getattr(self, 'geo_panel', None) is None:
            if m is None or not m['O']: return
            self.geo_panel = GeoPanel(self)
        if m is None or not self.geo_panel.fill(m): self.geo_panel.hide(); return
        self.geo_panel.show(); self.geo_panel.place()
    def geo_sync_bar(self):
        """Araç çubuğu yalnızca koordinat düzlemi sekmesinde."""
        try: on = (self.doc.metadata.get('keywords') or '') == 'UMAL-template:koordinat'
        except Exception: on = False
        if getattr(self, 'geo_bar', None) is None:
            if not on: return
            self.geo_bar = GeoBar(self)
        if on:
            self.board.geo_valid_sel(self.board.geo_model()); self.geo_bar.sync(); self.geo_bar.show(); self.geo_bar.place()
        else:
            self.geo_bar.hide()
            if self.tool == 'geo': self.set_tool('pen')
        self.geo_panel_sync()
    def open_graph(self):
        self.board.finish(); GraphDialog(self).exec_()
    def open_templates(self):
        self.board.finish(); TemplateDialog(self).exec_()
    def open_triangle(self):
        self.board.finish(); TriangleDialog(self).exec_()
    def start_pen_meter(self):
        self.board.finish(); self.pen_meter = PenMeter(self); self.pen_meter.start()
    def open_daily(self):
        self.board.finish(); DailyDialog(self).exec_(); self.daily_strip.sync()

    def return_to_pdf(self):
        if self.solution_origin is None:return
        self.board.finish();self.view_by_undo=False
        # No save prompt: the solution is kept with the book automatically.
        origin=self.solution_origin
        solutions=origin.setdefault('solutions',{});key=origin.get('key')
        written=copy.deepcopy(self.marks.get(0,[]))
        changed=False
        if key:
            old=solutions.get(key,{}).get('marks',{}).get(0,[])
            changed=written!=old
            if written:solutions[key]=dict(page=origin['page'],rect=origin['rect'],marks={0:written},height=self.doc[0].rect.height,bg=origin.get('bg','grid'))
            else:solutions.pop(key,None)
        try:self.daily_solved(origin,written)   # Günün soruları
        except Exception as e:self.statusBar().showMessage('Günün sorularına eklenemedi: %s'%e)
        base=os.path.join(self.session_dir,origin['pdf']) if origin.get('pdf') else None
        if base:
            try:doc=fitz.open(base)
            except Exception as e:QMessageBox.warning(self,'Asıl PDF açılamadı',str(e));return
        else:doc=fitz.open(stream=origin['data'],filetype='pdf')
        self.replace(doc,origin['source'],persist=False)
        self.marks=origin['marks'];self.page=origin['page'];self.dirty=origin['dirty'] or changed
        self.solutions=solutions
        if changed:self.setWindowTitle(APP_NAME+' • Kaydedilmemiş değişiklikler')
        self.solution_origin=None;self.return_pdf.hide();self.set_tool('pen');self.set_zoom(origin['zoom'])
        if base:self.session_pdf_name=origin['pdf'];self.session_pdf_pending=False
        else:self.session_pdf_pending=True
        self.save_session()

    def button(self, layout, label, fn, name=''):
        b = QPushButton(label); b.setObjectName(name); b.setIcon(tool_icon(label)); b.setIconSize(QSize(28,28)); b.clicked.connect(fn); layout.addWidget(b); return b
    def tool_hint(self, text):
        """Araç ipucu yalnızca ilk birkaç seçimde çıkar (sonra sayfanın köşesini kapatmasın)."""
        path = os.path.join(self.data_dir, 'ipuclari.json')
        if not hasattr(self, 'hints_seen'):
            try:
                with open(path, encoding='utf-8') as f: self.hints_seen = json.load(f)
            except (OSError, ValueError): self.hints_seen = {}
        n = self.hints_seen.get(text[:40], 0)
        if n >= 3: return
        self.hints_seen[text[:40]] = n + 1
        try:
            with open(path, 'w', encoding='utf-8') as f: json.dump(self.hints_seen, f, ensure_ascii=False)
        except OSError: pass
        self.statusBar().showMessage(text)
    def set_tool(self, tool):
        self.board.finish()
        if tool!='smart':self.board.clear_selection()
        self.tool = tool
        if tool=='highlight':self.color='#ffc526'
        for k,b in self.tool_buttons.items(): b.setChecked(k == tool)
        self.refresh_colors(); self.sync_tips()
        self.board.setCursor(Qt.OpenHandCursor if tool == 'hand' else Qt.CrossCursor)
        if tool == 'select': self.tool_hint('Görünmesini istediğiniz alanı sürükleyerek seçin. Dışı beyaz olur; ardından kalemle yazabilirsiniz.')
        if tool == 'smart': self.tool_hint('Yazılarınızı çerçeve içine alın. İçinden sürükleyerek taşıyın; köşelerinden büyütün veya küçültün.')
        if tool == 'solution':self.tool_hint('Soruyu çerçeve içine alın: üstte soru kartı, altında geniş çözüm alanı açılacak.')
        if getattr(self,'daily_strip',None) is not None: self.daily_strip.sync(); self.place_overlays()
        if getattr(self, 'geo_bar', None) is not None and self.geo_bar.isVisible(): self.geo_bar.sync()
        if tool == 'geo': self.tool_hint('Koordinat düzlemi: ızgaraya dokunun, nokta konur. Noktaya dokunmak seçer, sürüklemek taşır. İki nokta seçince Mesafe, Doğru, Eğim, Orta nokta; bir doğru ve bir nokta seçince Paralel, Dik.')
        if tool == 'compass': self.tool_hint('Pergel: merkeze dokunun, açıklığı sürükleyin, kalemi kaldırmadan çevirin; yay ya da daire çizilir.')
        if tool == 'triangle': self.tool_hint('Üçgen: köşeden köşeye sürükleyin. Ölçülü üçgen için Şekiller → Ölçülü üçgen.')
        if tool == 'place_tri': self.statusBar().showMessage('Üçgeni koymak istediğiniz yere dokunun.')
        if tool == 'pick': self.tool_hint('Soru seç: günün sorularını sırayla çerçeveleyin. Bitince başka bir araç seçin.')
        if tool == 'postit': self.tool_hint('Post-it: soruyu ve çözümünü çerçeve içine alın; kalemi kaldırınca sağdaki panoya yapışır.')
        if tool == 'laser': self.tool_hint('Neon kalem: yazdıklarınız parlar; yazmayı bırakınca 3 saniye sonra kendiliğinden söner. Kaydedilmez.')
        if tool == 'area_eraser': self.tool_hint('Alan silgisi: silmek istediğiniz yazıları çerçeve içine alın (ya da yazıya dokunun); kalemi kaldırınca silinir. Geri al ile geri getirebilirsiniz.')
        if tool == 'arrow': self.tool_hint('Ok: başladığınız yerden kalemi kaldırdığınız yere doğru ok çizilir (kuvvet, yön, vektör).')
        if tool == 'dash': self.tool_hint('Kesikli çizgi: kalem gibi yazın. Düz çizgi, dikdörtgen veya elips çizip 1 saniye beklerseniz kesikli şekle dönüşür.')
        if tool == 'pen': self.tool_hint('Şekil çizin ve 1 saniye bekleyin; kalemi kaldırabilirsiniz. Çizgi, üçgen, dikdörtgen veya elips düzeltilir.')
    def apply_selection(self, points):
        a,b = points
        x0,x1 = sorted((a[0],b[0])); y0,y1 = sorted((a[1],b[1]))
        if min(x1-x0,y1-y0)*self.board.scale < 6: return
        page = self.doc[self.page].rect
        self.checkpoint()
        marks = [s for s in self.marks.get(self.page,[]) if s['tool'] != 'whiteout']
        for l,t,r,b in [(0,0,page.width,y0),(0,y1,page.width,page.height),(0,y0,x0,y1),(x1,y0,page.width,y1)]:
            if r>l and b>t:
                marks.append(dict(tool='whiteout',color='#ffffff',width=1,points=[[l,t],[r,b]]))
        self.marks[self.page] = marks
        self.changed()
        self.set_tool('pen')
        self.statusBar().showMessage('Seçilen alan kaldı. Beyaz alana da yazabilirsiniz. Geri al veya Seçimi kaldır ile tüm sayfayı gösterin.')
    def remove_selection(self):
        marks = self.marks.get(self.page,[])
        if any(s['tool']=='whiteout' for s in marks):
            self.checkpoint()
            self.marks[self.page] = [s for s in marks if s['tool'] != 'whiteout']
            self.changed(); self.board.update()
    def set_pen_style(self, key):
        if key == 'laser': self.set_tool('laser'); return   # Neon kalem is a tool of its own
        self.pen_style = key
        name = dict(PEN_STYLES)[key]; self.style_name.setText(name)
        if self.tool != 'pen': self.set_tool('pen')
        self.sync_tips(); self.statusBar().showMessage('Kalem stili: %s' % name)
    def sync_tips(self):
        """Tips row: Neon lit while the Neon kalem is in use, else the pen style."""
        if not hasattr(self, 'style_buttons'): return
        on = 'laser' if self.tool == 'laser' else (self.pen_style if self.tool == 'pen' else None)
        for k, b in self.style_buttons.items(): b.setChecked(k == on)
    def set_color(self, color):
        self.color = color
        if self.tool not in COLOR_TOOLS: self.set_tool('pen')
        self.statusBar().showMessage('Kalem rengi seçildi. Kalınlık: %s pt' % self.width.value())
    def current_ctx(self):
        tab = os.path.basename(self.session_dir)
        if self.solution_origin is not None and self.solution_origin.get('key'): return ('sol', tab, self.solution_origin['key'])
        return ('doc', tab)
    def sync_history(self):
        """Keep a separate undo/redo stack per place (document, solution area)."""
        ctx = self.current_ctx()
        if ctx == self.history_ctx: return
        if self.history_ctx is not None: self.histories[self.history_ctx] = (self.undo_stack, self.redo_stack)
        self.undo_stack, self.redo_stack = self.histories.get(ctx, ([], []))
        self.history_ctx = ctx
    def checkpoint(self):
        self.view_by_undo = False   # a new edit: Geri al may leave this view again
        self.sync_history()
        self.undo_stack.append(copy.deepcopy(self.marks)); self.undo_stack = self.undo_stack[-80:]; self.redo_stack.clear()
        self.undo_log.append(self.current_ctx()); self.undo_log = self.undo_log[-400:]; self.redo_log.clear()
    def changed(self):
        # Notes are autosaved as JSON; the base PDF is rewritten only when
        # the document itself changes (new document or board background).
        self.dirty = True; self.setWindowTitle(APP_NAME+' • Kaydedilmemiş değişiklikler')
        self.session_timer.start(1200)

    def save_session(self):
        self.session_timer.stop()
        try:
            os.makedirs(self.session_dir,mode=0o700,exist_ok=True)
            pdf_path=os.path.join(self.session_dir,self.session_pdf_name or 'belge.pdf')
            if self.session_pdf_pending or not os.path.isfile(pdf_path):
                # The clean base PDF is written once per document; notes go
                # to the small JSON below, so large textbooks never re-save
                # on every stroke (that froze the UI for many seconds).
                name='belge-'+uuid.uuid4().hex+'.pdf';pdf_path=os.path.join(self.session_dir,name)
                fd,tmp_pdf=tempfile.mkstemp(dir=self.session_dir,suffix='.pdf');os.close(fd)
                try:
                    self.doc.save(tmp_pdf,garbage=1);os.replace(tmp_pdf,pdf_path)
                finally:
                    if os.path.exists(tmp_pdf):os.unlink(tmp_pdf)
            else:name=self.session_pdf_name or 'belge.pdf'
            meta=dict(source=self.source,page=self.page,zoom=self.zoom,dirty=self.dirty,pdf=name,
                      marks={str(k):v for k,v in self.saved_marks().items()},ikinci_cozum=self.second_solutions(),
                      solutions={k:dict(v,marks={str(p):m for p,m in v['marks'].items()}) for k,v in self.solutions.items()})
            def write_meta(path,data):
                fd,tmp=tempfile.mkstemp(dir=self.session_dir,suffix='.json')
                try:
                    with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
                    os.replace(tmp,path)
                finally:
                    if os.path.exists(tmp):os.unlink(tmp)
            meta_path=os.path.join(self.session_dir,'durum.json');old=None
            if os.path.isfile(meta_path):
                try:
                    with open(meta_path,encoding='utf-8') as f:old=json.load(f)
                    if old.get('pdf','belge.pdf')!=name:write_meta(os.path.join(self.session_dir,'yedek.json'),old)
                except (ValueError,OSError):pass
            fd,tmp=tempfile.mkstemp(dir=self.session_dir,suffix='.json')
            try:
                with os.fdopen(fd,'w',encoding='utf-8') as f:
                    json.dump(meta,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
                os.replace(tmp,os.path.join(self.session_dir,'durum.json'))
            finally:
                if os.path.exists(tmp):os.unlink(tmp)
            self.session_pdf_name=name;self.session_pdf_pending=False
            keep={name}
            if self.solution_origin and self.solution_origin.get('pdf'):keep.add(self.solution_origin['pdf'])
            try:
                with open(os.path.join(self.session_dir,'yedek.json'),encoding='utf-8') as f:keep.add(json.load(f).get('pdf','belge.pdf'))
            except (OSError,ValueError):pass
            for candidate in os.listdir(self.session_dir):
                if candidate.startswith('belge-') and candidate.endswith('.pdf') and candidate not in keep:
                    try:os.unlink(os.path.join(self.session_dir,candidate))
                    except OSError:pass
            return True
        except Exception as e:
            self.statusBar().showMessage('Otomatik kayıt yapılamadı. PDF kaydet düğmesini kullanın: '+str(e))
            return False

    def restore_session(self):
        meta_path=os.path.join(self.session_dir,'durum.json')
        if not os.path.isfile(meta_path):return False
        doc=None
        try:
            for candidate in ['durum.json','yedek.json']:
                try:
                    with open(os.path.join(self.session_dir,candidate),encoding='utf-8') as f:meta=json.load(f)
                    pdf_path=os.path.join(self.session_dir,os.path.basename(meta.get('pdf','belge.pdf')))
                    doc=fitz.open(pdf_path)
                    if doc.page_count and not doc.needs_pass:break
                    doc.close();doc=None
                except Exception:doc=None
            if doc is None:raise ValueError('Son kayıt ve yedek açılamadı.')
            if not doc.page_count or doc.needs_pass:raise ValueError('Kayıtlı belge okunamadı.')
            self.replace(doc,str(meta.get('source') or ''),persist=False)
            if 'marks' in meta:self.marks=load_marks(meta['marks'])
            self.alt_ink=load_marks(meta.get('ikinci_cozum'));self.alt_showing=set();self.sync_hide_button()
            if 'solutions' in meta:self.solutions={k:dict(v,marks=load_marks(v.get('marks'))) for k,v in meta['solutions'].items()}
            self.page=max(0,min(len(doc)-1,int(meta.get('page',0))))
            self.set_zoom(float(meta.get('zoom',1)))
            self.dirty=bool(meta.get('dirty',False));self.session_pdf_pending=False
            self.session_pdf_name=os.path.basename(meta.get('pdf','belge.pdf'))
            if self.doc.metadata.get('keywords')=='UMAL-solution':
                try:
                    with open(os.path.join(self.session_dir,'soru-kaynagi.json'),encoding='utf-8') as f:origin=json.load(f)
                    if origin.get('pdf'):
                        if not os.path.isfile(os.path.join(self.session_dir,os.path.basename(origin['pdf']))):raise ValueError
                        origin['pdf']=os.path.basename(origin['pdf']);origin['marks']=load_marks(origin.get('marks'))
                        origin['solutions']={k:dict(v,marks=load_marks(v.get('marks'))) for k,v in (origin.get('solutions') or {}).items()}
                    else:
                        original=fitz.open(os.path.join(self.session_dir,'soru-kaynagi.pdf'))
                        origin['marks']=recover_marks(original);origin['data']=original.tobytes();original.close()
                    self.solution_origin=origin;self.return_pdf.show()
                except Exception:pass
            self.statusBar().showMessage('Cihazdaki son PDF açıldı · Sayfa %s · Notlarınız korundu' % (self.page+1))
            return True
        except Exception as e:
            if doc is not None and doc is not self.doc:doc.close()
            self.statusBar().showMessage('Son çalışma açılamadı; PDF aç ile dosyanızı seçebilirsiniz. '+str(e))
            return False
    def undo(self):
        # Geri al always removes the last thing written (also in Çözüm alanı,
        # Alan seç and Akıllı seçim); Asıl PDF'ye dön leaves those views.
        r_ = self.step_history(self.undo_log, self.redo_log, True); QTimer.singleShot(0, self.geo_after_history); return r_
    def leave_view(self):
        """Geri al in a solution area, an Alan seç frame or an Akıllı seçim
        first returns to the plain PDF in one tap, without a question; what
        was written stays. The next taps undo as usual."""
        b = self.board; tab = os.path.basename(self.session_dir)
        if self.solution_origin is not None and not self.view_by_undo:
            o = self.solution_origin; self.redo_log.append(('view', tab, 'sol', (o['page'], list(o['rect']))))
            b.finish(); self.return_to_pdf()
            self.statusBar().showMessage('Asıl PDF’ye dönüldü · Çözüm alanındaki yazılar kayıtlı'); return True
        if b.selection_page == self.page and b.selected:
            self.redo_log.append(('view', tab, 'smart', (self.page, list(b.selected))))
            b.clear_selection(); self.statusBar().showMessage('Seçim kapatıldı · Yazılar yerinde'); return True
        if any(m['tool'] == 'whiteout' for m in self.marks.get(self.page, [])) and self.solution_origin is None:
            frame = [copy.deepcopy(m) for m in self.marks[self.page] if m['tool'] == 'whiteout']
            b.finish(); self.strip_frame(self.page); b.update()
            self.redo_log.append(('view', tab, 'frame', (self.page, frame)))
            self.statusBar().showMessage('Asıl PDF görünümüne dönüldü · Yazılar yerinde'); return True
        return False
    def strip_frame(self, page):
        """Remove the Alan seç frame of a page from the notes and from their
        history, so later Geri al taps never bring the frame back."""
        self.sync_history()
        strip = lambda m: {p: [x for x in v if not (p == page and x['tool'] == 'whiteout')] for p, v in m.items()}
        self.marks = strip(self.marks)
        for stack in (self.undo_stack, self.redo_stack):
            out = []
            for m in map(strip, stack):
                if not out or out[-1] != m: out.append(m)   # steps that only moved the frame vanish
            if stack is self.undo_stack and out and out[-1] == self.marks: out.pop()
            stack[:] = out
        self.changed()
    def redo(self):
        # İleri al right after a one-tap return: back to the screen that was left.
        if self.redo_log and self.redo_log[-1][0] == 'view': return self.back_to_view(self.redo_log.pop())
        r_ = self.step_history(self.redo_log, self.undo_log, False); QTimer.singleShot(0, self.geo_after_history); return r_
    def back_to_view(self, record):
        _, tab, kind, (page, data) = record
        self.board.finish()
        if tab != os.path.basename(self.session_dir):
            if not (self.tabs and any(t['id'] == tab for t in self.tabs)): return False
            self.switch_tab(tab)
        if self.solution_origin is not None: self.return_to_pdf()
        if page >= len(self.doc): return False
        self.page = page; self.render()
        if kind == 'sol':
            self.make_solution([[data[0], data[1]], [data[2], data[3]]]); self.view_by_undo = False
        elif kind == 'frame':
            self.marks[page] = [m for m in self.marks.get(page, []) if m['tool'] != 'whiteout'] + data
            self.changed(); self.set_tool('pen')
        elif kind == 'smart':
            n = len(self.marks.get(page, []))
            self.set_tool('smart'); self.board.selection_page = page; self.board.selected = [i for i in data if i < n]
        self.board.update(); self.statusBar().showMessage('Önceki ekrana dönüldü')
        return True
    def step_history(self, log, other, undo):
        """Undo/redo the most recent edit wherever it was made, and show it."""
        self.board.finish();self.board.clear_selection()
        while log:
            ctx = log.pop()
            if ctx[0] == 'view':
                if not undo and self.back_to_view(ctx): return True
                continue
            if ctx == ('screen',):
                s = self.screen_session
                stack = s.undo_stack if (s and undo) else (s.redo_stack if s else [])
                if not stack: continue
                self.screen_ink()
                (s.undo if undo else s.redo)(record=False); other.append(ctx); return True
            if not self.go_to_ctx(ctx): continue
            self.sync_history()
            stack, back = (self.undo_stack, self.redo_stack) if undo else (self.redo_stack, self.undo_stack)
            if not stack: continue
            before = self.marks; back.append(copy.deepcopy(self.marks)); self.marks = stack.pop()
            other.append(ctx); self.changed(); self.show_change(before, self.marks); return True
        self.statusBar().showMessage('Geri alınacak düzenleme yok.' if undo else 'İleri alınacak düzenleme yok.')
        return False
    def show_change(self, before, after):
        pages = sorted(p for p in set(before) | set(after) if before.get(p, []) != after.get(p, []))
        if pages and self.page not in pages and pages[0] < len(self.doc):
            self.page = pages[0]; self.render()
        self.board.update()
    def go_to_ctx(self, ctx):
        tab = ctx[1]
        known = tab == os.path.basename(self.session_dir) or (self.tabs is not None and any(t['id'] == tab for t in self.tabs))
        if not known: return False
        if ctx == self.current_ctx(): return True
        if self.solution_origin is not None and ctx[0] == 'doc' and tab == os.path.basename(self.session_dir):
            self.return_to_pdf(); return ctx == self.current_ctx()
        if tab != os.path.basename(self.session_dir): self.switch_tab(tab)
        if self.solution_origin is not None and ctx != self.current_ctx(): self.return_to_pdf()
        if ctx[0] == 'sol':
            sol = self.solutions.get(ctx[2])
            if not sol:   # emptied solution: its page and frame are in the key
                try:
                    page, rect = ctx[2].split(':'); sol = dict(page=int(page), rect=[float(v) for v in rect.split(',')])
                except ValueError: return False
            self.page = int(sol['page']); self.render(); r = sol['rect']
            self.make_solution([[r[0], r[1]], [r[2], r[3]]])
            self.view_by_undo = True   # opened by Geri al itself: keep undoing here
        return ctx == self.current_ctx()
    def confirm_leave(self):
        if not self.dirty: return True
        answer = QMessageBox.question(self,'Kaydedilmemiş notlar','Notlarınızı PDF olarak kaydetmek ister misiniz?',QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
        if answer == QMessageBox.Save: return self.save_pdf()
        return answer == QMessageBox.Discard
    def replace(self, doc, source='',persist=True):
        # Second solutions belong to this document: park them (first solutions shown).
        if self.alt_ink or self.alt_showing:
            for p in list(self.alt_showing):
                self.marks[p], self.alt_ink[p] = self.alt_ink.get(p, []), self.marks.get(p, [])
            self.alt_store[(self.session_dir, self.source)] = {p: m for p, m in self.alt_ink.items() if m}
        self.alt_ink, self.alt_showing = {}, set()
        self.sync_history()
        if self.history_ctx is not None: self.histories[self.history_ctx] = (self.undo_stack, self.redo_stack)
        self.history_ctx = None
        self.session_timer.stop()
        self.board.clear_selection()
        self.solution_origin=None;self.return_pdf.hide()
        old = self.doc
        marks = recover_marks(doc)
        self.solutions = read_solutions(doc)
        self.doc, self.marks, self.source = doc, marks, source
        keywords = doc.metadata.get('keywords') or ''
        key = keywords[len('UMAL-board:'):] if keywords.startswith('UMAL-board:') else ''
        self.background = key if key in dict((v,k) for k,v in BACKGROUNDS) and len(doc)==1 else None
        for k,b in self.bg_buttons.items(): b.setEnabled(self.background is not None); b.setChecked(k==self.background)
        self.bg_button.setEnabled(self.background is not None)   # backgrounds are for boards, not PDFs
        if self.background in DARK_BACKGROUNDS: self.color='#ffffff'
        elif self.color=='#ffffff': self.color=PEN_DEFAULT
        old.close()
        self.page = 0; self.undo_stack, self.redo_stack = [], []; self.dirty = False
        self.alt_ink = self.alt_store.pop((self.session_dir, source), {}); self.sync_hide_button()
        self.setWindowTitle(APP_NAME); self.filename.setText(os.path.basename(source) if source else 'Boş tahta · Kalemle yazmaya başlayın')
        self.fit_page()
        self.session_pdf_pending=True
        if persist:self.save_session()
    def open_pdf(self):
        # Work is autosaved per tab, so opening another PDF never asks to save.
        self.board.finish()
        path,_ = QFileDialog.getOpenFileName(self,'PDF aç','','PDF dosyaları (*.pdf)')
        if not path: return
        self.open_pdf_path(path)
    def open_pdf_path(self, path):
        self.board.finish()
        if self.tabs is None: self.init_tabs(restore=False)
        same=next((t for t in self.tabs if t.get('source') and os.path.realpath(t['source'])==os.path.realpath(path)),None)
        if same:
            self.switch_tab(same['id']); self.statusBar().showMessage('Bu PDF zaten açık; sekmesine geçildi.'); return
        doc = None
        try:
            doc = fitz.open(path)
            if doc.needs_pass:
                pw,ok = QInputDialog.getText(self,'Şifreli PDF','PDF şifresi:',2)
                if not ok: doc.close(); return
                if not doc.authenticate(pw): raise ValueError('PDF şifresi doğru değil.')
            if not doc.page_count: raise ValueError('Bu PDF’de sayfa yok.')
            self.start_tab(os.path.splitext(os.path.basename(path))[0],path)
            self.replace(doc,path);self.tabs_changed()
        except Exception as e:
            if doc and doc is not self.doc: doc.close()
            QMessageBox.warning(self,'PDF açılamadı',str(e))
    def new_board(self):
        self.board.finish()
        self.start_tab('Boş tahta')
        self.replace(make_board(self.background or 'white'));self.tabs_changed()
        # A new blank board must not inherit Hand, Eraser, or Selection mode
        # from a PDF. Start with visible round ink, ready to write immediately.
        self.set_tool('pen');self.nib.setCurrentIndex(0)
        self.color='#ffffff' if self.background in DARK_BACKGROUNDS else PEN_DEFAULT
        self.width.setValue(3)
        self.statusBar().showMessage('Boş tahta hazır · PDF açmadan yazabilirsiniz · Yuvarlak kalem, 3 pt')
    # ---- PDF tabs -------------------------------------------------------
    def tabs_file(self): return os.path.join(self.data_dir,'sekmeler.json')
    def current_tab(self): return os.path.basename(self.session_dir)
    def load_tabs(self):
        try:
            with open(self.tabs_file(),encoding='utf-8') as f:data=json.load(f)
            tabs=[t for t in data.get('tabs',[]) if t.get('id') and os.sep not in t['id'] and os.path.isfile(os.path.join(self.data_dir,t['id'],'durum.json'))]
            active=data.get('active')
        except (OSError,ValueError,AttributeError):tabs,active=[],None
        if not tabs and os.path.isfile(os.path.join(self.data_dir,'son-pdf','durum.json')):
            # earlier versions kept only the last PDF here: it becomes the first tab
            try:
                with open(os.path.join(self.data_dir,'son-pdf','durum.json'),encoding='utf-8') as f:src=json.load(f).get('source') or ''
            except (OSError,ValueError):src=''
            tabs=[dict(id='son-pdf',name=os.path.splitext(os.path.basename(src))[0] if src else 'Boş tahta',source=src)];active='son-pdf'
        self.tabs=tabs
        return active
    def write_tabs(self):
        try:
            os.makedirs(self.data_dir,exist_ok=True)
            fd,tmp=tempfile.mkstemp(dir=self.data_dir,suffix='.json')
            with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(dict(tabs=self.tabs,active=self.current_tab()),f,ensure_ascii=False)
            os.replace(tmp,self.tabs_file())
        except OSError as e:self.statusBar().showMessage('Sekmeler kaydedilemedi: '+str(e))
    def init_tabs(self,restore=True):
        active=self.load_tabs()
        if restore and self.tabs:
            tab=next((t for t in self.tabs if t['id']==active),self.tabs[0])
            self.session_dir=os.path.join(self.data_dir,tab['id']);self.session_pdf_name=None
            if not self.restore_session():
                self.tabs=[t for t in self.tabs if t['id']!=tab['id']]
        if not self.tabs and (restore or self.source or any(self.marks.values())):
            # keep the current board/PDF as the first tab
            name=os.path.splitext(os.path.basename(self.source))[0] if self.source else 'Boş tahta'
            self.tabs=[dict(id=self.new_tab_folder(),name=name,source=self.source)]
            self.session_dir=os.path.join(self.data_dir,self.tabs[0]['id']);self.session_pdf_name=None;self.session_pdf_pending=True
            self.save_session()
        self.tabs_changed()
    def new_tab_folder(self):
        tid='sekme-'+uuid.uuid4().hex[:12];os.makedirs(os.path.join(self.data_dir,tid),mode=0o700,exist_ok=True);return tid
    def start_tab(self,name,source=''):
        """Save the current tab, then route autosave to a new tab placed first."""
        if self.tabs is None:self.init_tabs(restore=False)
        if self.tabs:self.save_session()
        tid=self.new_tab_folder()
        self.session_dir=os.path.join(self.data_dir,tid);self.session_pdf_name=None;self.session_pdf_pending=True
        self.tabs.insert(0,dict(id=tid,name=name,source=source))
    def switch_tab(self,tid):
        if tid==self.current_tab():self.tabs_changed();return
        self.board.finish();self.save_session()
        previous=self.session_dir
        self.session_dir=os.path.join(self.data_dir,tid);self.session_pdf_name=None
        if not self.restore_session():
            self.session_dir=previous
            QMessageBox.warning(self,'Sekme açılamadı','Bu sekmenin kaydı okunamadı. Sekmeyi kapatıp PDF’yi yeniden açabilirsiniz.')
        self.tabs_changed()
    def close_tab(self,tid):
        tab=next((t for t in self.tabs if t['id']==tid),None)
        if tab is None:return
        if QMessageBox.question(self,'Sekmeyi kapat','“%s” listeden kaldırılsın mı?\n\nBu PDF’nin tahtadaki kopyası ve üzerine yazdığınız notlar silinir. Bilgisayardaki asıl dosya silinmez.' % tab['name'],
                                QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        index=self.tabs.index(tab)
        if tid==self.current_tab():
            rest=[t for t in self.tabs if t['id']!=tid]
            if rest:self.switch_tab(rest[min(index,len(rest)-1)]['id'])
            else:
                self.start_tab('Boş tahta');self.replace(make_board(self.background or 'white'))
        self.tabs=[t for t in self.tabs if t['id']!=tid]
        self.undo_log=[c for c in self.undo_log if c==('screen',) or c[1]!=tid]; self.redo_log=[c for c in self.redo_log if c==('screen',) or c[1]!=tid]
        self.histories={k:v for k,v in self.histories.items() if k[1]!=tid}
        folder=os.path.realpath(os.path.join(self.data_dir,tid))
        if os.path.dirname(folder)==os.path.realpath(self.data_dir) and folder!=os.path.realpath(self.session_dir):
            shutil.rmtree(folder,ignore_errors=True)
        self.tabs_changed()
    def open_new_menu(self, anchor):
        from PyQt5.QtWidgets import QMenu
        m=QMenu(self);m.setStyleSheet('QMenu{font-size:17px;padding:6px;} QMenu::item{padding:14px 36px 14px 18px;}')
        m.addAction(tool_icon('PDF aç'),'PDF aç',self.open_pdf);m.addAction(tool_icon('Yeni tahta'),'Boş tahta',self.new_board)
        m.exec_(anchor.mapToGlobal(QPoint(0,anchor.height()+4)))
    def tabs_changed(self):
        if self.tabs is not None: self.write_tabs()
        while self.tab_row.count():
            item=self.tab_row.takeAt(0)
            if item.widget():item.widget().deleteLater()
        current=self.current_tab()
        for t in (self.tabs or []):   # + Yeni and Havuz are always there, even before the tabs load
            name=t['name'] if len(t['name'])<=26 else t['name'][:24]+'…'
            b=QPushButton(name);b.setObjectName('tab');b.setCheckable(True);b.setChecked(t['id']==current);b.setToolTip(t.get('source') or t['name'])
            b.clicked.connect(lambda checked=False,tid=t['id']:self.switch_tab(tid))
            x=QPushButton('×');x.setObjectName('tabclose');x.setCheckable(True);x.setChecked(t['id']==current);x.setFixedSize(40,40);x.setToolTip('Sekmeyi kapat')
            x.clicked.connect(lambda checked=False,tid=t['id']:self.close_tab(tid))
            pair=QWidget();h=QHBoxLayout(pair);h.setContentsMargins(0,0,0,0);h.setSpacing(0);b.setFixedHeight(40);h.addWidget(b);h.addWidget(x)
            self.tab_row.addWidget(pair)
        plus=QPushButton('+ Yeni');plus.setObjectName('primary');plus.setFixedHeight(40);plus.setToolTip('PDF aç ya da boş tahta');plus.clicked.connect(lambda checked=False,b_=plus:self.open_new_menu(b_))
        self.tab_row.addWidget(plus)
        # PDF Havuzu sits with the PDFs in the top bar (not in the left panel).
        pool=QPushButton();pool.setObjectName('havuz_tab');pool.setAccessibleName('PDF Havuzu');pool.setIcon(havuz_icon(30));pool.setIconSize(QSize(47,30));pool.setFixedWidth(72)
        pool.setFixedHeight(40);pool.setToolTip('PDF Havuzu: bütün tahtalarda ortak PDF\'ler');pool.clicked.connect(self.open_havuz)
        self.tab_row.addWidget(pool);self.tab_row.addStretch()
    def save_pdf(self):
        self.board.finish()
        suggested = os.path.splitext(self.source)[0]+'-notlu.pdf' if self.source else 'Tahta-notlari.pdf'
        if self.source and os.path.realpath(os.path.dirname(self.source)) == os.path.realpath(HAVUZ_DIR):
            # Notlu kopya havuza düşerse bütün tahtalara giderdi: kişisel klasöre öner.
            suggested = os.path.join(os.path.expanduser('~'), os.path.basename(suggested))
        target,_ = QFileDialog.getSaveFileName(self,'Notlu PDF’yi kaydet',suggested,'PDF dosyaları (*.pdf)')
        if not target: return False
        if not target.lower().endswith('.pdf'): target += '.pdf'
        if self.source and os.path.realpath(target) == os.path.realpath(self.source):
            QMessageBox.information(self,'Farklı ad seçin','Orijinal PDF’yi korumak için farklı bir dosya adı seçin.'); return False
        try:
            export_document(self.doc,self.marks,target,None if self.solution_origin else self.solutions)
            self.dirty = False; self.setWindowTitle(APP_NAME); self.statusBar().showMessage('Kaydedildi: '+target)
            return True
        except Exception as e:
            QMessageBox.warning(self,'PDF kaydedilemedi',str(e)); return False
    def clear_page(self):
        if not self.marks.get(self.page): return
        if QMessageBox.question(self,'Tümünü sil','Bu sayfaya eklediğiniz bütün notlar silinsin mi?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No) == QMessageBox.Yes:
            self.checkpoint(); self.marks[self.page] = []; self.changed(); self.board.update()
    def goto(self, delta):
        self.board.finish();self.board.clear_selection()
        if delta and getattr(self,'curtain',None) is not None: self.toggle_curtain(False)   # a new page starts uncovered
        self.page = max(0,min(len(self.doc)-1,self.page+delta)); self.render(); self.sync_hide_button()
        self.save_session()
    def set_zoom(self, value):
        self.board.finish(); self.zoom = max(.15,min(8,value)); self.render()
    def theme_tile(self,key):
        folder=os.path.join(self.data_dir,'temalar');os.makedirs(folder,exist_ok=True)
        path=os.path.join(folder,key+'-v3.png')
        return path if os.path.isfile(path) else make_theme_tile(key,path)
    def apply_theme(self,key,save=True):
        self.theme=key
        try:tile=self.theme_tile(key)
        except Exception:tile=''
        self.setStyleSheet(theme_style(THEMES[key],tile))
        # pattern applied on the page backdrop itself (a global selector does not reach it)
        self.scroll.set_theme(THEMES[key]['view'],THEMES[key]['sel'],tile)
        if hasattr(self,'tool_buttons'):self.refresh_colors()
        if save:
            try:
                with open(os.path.join(self.data_dir,'tema.json'),'w',encoding='utf-8') as f:json.dump(dict(theme=key),f)
            except OSError:pass
            self.statusBar().showMessage('Tema: '+THEMES[key]['name'])
    def open_theme_picker(self, anchor=None):
        picker=ThemePicker(self);picker.adjustSize()
        # Open beside the panel (like Şekiller) and keep it fully on screen:
        # under the button it ran off the bottom of the board.
        screen=(self.windowHandle().screen() if self.windowHandle() else QApplication.primaryScreen()).availableGeometry()
        anchor=anchor or self.gear
        g=anchor.mapToGlobal(QPoint(anchor.width()+6,0))
        x=min(g.x(),screen.right()-picker.width()-8)
        y=max(screen.top()+8,min(g.y(),screen.bottom()-picker.height()-8))
        picker.move(max(screen.left(),x),y);picker.show()
    # ---- PDF Havuzu ------------------------------------------------------
    def run_havuz(self, *args):
        if not havuz_ready(): return
        if HAVUZ_PYTHON: QProcess.startDetached(HAVUZ_PYTHON, [HAVUZ_TOOL] + list(args))
        else: QProcess.startDetached(HAVUZ_TOOL, list(args))
    def open_havuz(self):
        self.board.finish(); HavuzDialog(self).exec_()
    def open_calc(self):
        if getattr(self,'calculator',None) is None: self.calculator = CalculatorPanel(self)
        self.calculator.open_calc()
    def open_timer(self):
        if getattr(self,'timer_screen',None) is None: self.timer_screen = TimerScreen(self)
        self.timer_screen.open_timer()
    def maybe_extend(self, stroke):
        """Endless solution area / blank board: writing near the bottom adds more space below."""
        if not self.endless(): return
        low = max(q[1] for q in stroke['points'])
        # Always at least one screen of empty space below the lowest writing.
        need = low + self.scroll.viewport().height()/max(self.zoom, .1) + 48
        if need > self.doc[0].rect.height: self.resize_solution(need)
    SOLUTION_MAX = 60000
    def endless(self):   # Çözüm alanı ve boş tahta aşağı doğru sınırsız uzar
        return self.in_solution() or (self.background is not None and self.solution_origin is None and len(self.doc) == 1)
    def in_solution(self):
        return self.solution_origin is not None and (self.doc.metadata.get('keywords') or '') == 'UMAL-solution'
    def scrolled(self, value):
        """Scrolling to the bottom of a solution area adds another screen."""
        bar = self.scroll.verticalScrollBar()
        if self.endless() and bar.maximum() > 0 and value >= bar.maximum() - 4:
            self.resize_solution(self.doc[0].rect.height + self.scroll.viewport().height()/max(self.zoom, .1))
    def resize_solution(self, height):
        old = self.doc; page = old[0].rect
        height = min(self.SOLUTION_MAX, math.ceil(height/24)*24)
        if height <= page.height: return
        if not self.in_solution():   # boş tahta: zemin yeniden çizilir, yazılar ayrı tutulur
            new = make_board(self.background, page.width, height)
        else:
            bg = (self.solution_origin or {}).get('bg', 'grid')
            new = make_board(bg, page.width, height); new[0].show_pdf_page(page, old, 0)
            new.set_metadata(dict(old.metadata or {}, keywords='UMAL-solution'))
        self.doc = new; old.close(); self.session_pdf_pending = True
        self.render(); self.changed()
    def solution_zoom(self):
        # Solution area always opens at 200%, starting from the question card.
        self.set_zoom(2.0)
        self.scroll.horizontalScrollBar().setValue(0);self.scroll.verticalScrollBar().setValue(0)
    def go_to_page(self):
        target=page_number_dialog(self,len(self.doc),self.page+1)
        if target: self.goto(target-1-self.page)
    def content_rect(self):
        """Area actually used on the page (text, drawings, images, notes),
        ignoring white margins and full-page backgrounds."""
        page=self.doc[self.page];full=page.rect;area=full.width*full.height;r=fitz.Rect()
        try:
            for kind,box in page.get_bboxlog():
                b=fitz.Rect(box)&full
                if b.is_empty or b.width*b.height>.9*area:continue
                r|=b
        except Exception:return full
        for s in self.marks.get(self.page,[]):
            if s['tool']=='whiteout':continue
            xs=[q[0] for q in s['points']];ys=[q[1] for q in s['points']];w=s.get('width',3)
            r|=fitz.Rect(min(xs)-w,min(ys)-w,max(xs)+w,max(ys)+w)&full
        if r.is_empty or r.width<20 or r.height<20:return full
        pad=max(8,min(r.width,r.height)*.03)
        return fitz.Rect(r.x0-pad,r.y0-pad,r.x1+pad,r.y1+pad)&full
    def fit_page(self):
        # Sığdır: show the questions as large as possible (content, not margins).
        r=self.content_rect();vw=self.scroll.viewport().width()-8;vh=self.scroll.viewport().height()-8
        if self.endless() and not self.in_solution():   # uzamış boş tahta: genişliğe sığdır, en üstten başla
            w=self.doc[0].rect.width;r=fitz.Rect(0,0,w,min(self.doc[0].rect.height,w*vh/max(vw,1)))
        self.set_zoom(min(vw/r.width,vh/r.height))
        self.scroll.horizontalScrollBar().setValue(int(r.x0*self.zoom-(vw-r.width*self.zoom)/2))
        self.scroll.verticalScrollBar().setValue(int(r.y0*self.zoom-(vh-r.height*self.zoom)/2))
    def render(self):
        if getattr(self, 'pano', None) is not None and self.pano_dir is None: self.load_postits()
        try:
            page = self.doc[self.page]; QTimer.singleShot(0, self.geo_sync_bar)
            # Endless solution area: only the top (question card) is a picture;
            # the grid/white below is painted by the board, so it stays sharp
            # and light however long the area grows.
            self.board.pattern = (self.solution_origin or {}).get('bg','grid') if self.in_solution() else (self.background if self.endless() else None)
            clip = fitz.Rect(0,0,page.rect.width,min(page.rect.height,800)) if self.board.pattern else page.rect
            self.board.image_height = clip.height if self.board.pattern else None
            # Bound rendering memory even for oversized engineering pages.
            scale = min(self.zoom, math.sqrt(14000000/(clip.width*clip.height)))
            pix = page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,colorspace=fitz.csRGB,alpha=False)
            # Limit raster memory without reducing display zoom or pen coordinates.
            self.board.scale = self.zoom
            self.board.image = QImage(pix.samples,pix.width,pix.height,pix.stride,QImage.Format_RGB888).copy()
            al = (Qt.AlignHCenter | Qt.AlignTop) if self.endless() else Qt.AlignCenter   # sonsuz sayfa büyürken yerinden zıplamasın
            if self.scroll.alignment() != al: self.scroll.setAlignment(al)
            self.board.setFixedSize(math.ceil(page.rect.width*self.zoom),math.ceil(page.rect.height*self.zoom)); self.board.update()
            QTimer.singleShot(0,self.scroll.viewport().update)   # gölge sayfanın yeni yerine
            self.page_label.setText('%s / %s  ·  %%%s' % (self.page+1,len(self.doc),round(self.zoom*100)))
            if hasattr(self,'nav'):self.place_overlays()
        except Exception as e: QMessageBox.warning(self,'Sayfa görüntülenemedi',str(e))
    def fullscreen(self):
        going = not self.isFullScreen()
        self.showNormal() if self.isFullScreen() else self.showFullScreen()
        QTimer.singleShot(100,self.fit_page)
        if going: QTimer.singleShot(180, self.play_intro)   # tam ekrana geçerken açılış animasyonu
    def play_intro(self):
        old = getattr(self, 'intro', None)
        if old is not None: old.finish()
        try: self.intro = IntroOverlay(self)
        except Exception as ex: print('açılış animasyonu:', ex); self.intro = None
    def closeEvent(self, e):
        self.board.finish()
        self.save_session()
        if not self.confirm_leave(): e.ignore(); return
        if self.screen_session:
            if not self.screen_session.confirm_close(): e.ignore(); return
            self.screen_session.active=False
            self.screen_session.board.hide(); self.screen_session.toolbar.hide();self.screen_session.floating.hide()
        e.accept()

# ---------------------------------------------------------------------------
# Açılış animasyonu (Tam ekran'a basınca): logo küresi 4 kez seker, ışıkla
# patlar, içinden kalem, pergel ve kitap çıkar; tahta belirir. Dokunmak geçer.
INTRO_LOGO = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'acilis-logo.png')
INTRO_SOUND = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sesler', 'acilis.wav')
def intro_plan(H):
    """Zamanlar ekran yüksekliğinden bağımsız (ses dosyasıyla aynı)."""
    G = 3.4*H; R = H*.165; FY = H*.8; top = -R - H*.36
    hs = [FY - R - top, H*.33, H*.21, H*.12, H*.055]
    segs = [(0.0, math.sqrt(2*hs[0]/G), None)]; t = segs[0][1]
    for h in hs[1:]:
        d = 2*math.sqrt(2*h/G); segs.append((t, d, h)); t += d
    return G, R, FY, top, segs, t
def intro_pencil(p):
    p.setPen(Qt.NoPen); p.setBrush(QColor('#ffc21a')); p.drawRect(QRectF(-12, -70, 24, 110)); p.setBrush(QColor('#e9a100')); p.drawRect(QRectF(4, -70, 8, 110))
    p.setBrush(QColor('#f3c99a')); p.drawPolygon(QPolygonF([QPointF(-12, 40), QPointF(12, 40), QPointF(0, 72)]))
    p.setBrush(QColor('#333333')); p.drawPolygon(QPolygonF([QPointF(-4.5, 60), QPointF(4.5, 60), QPointF(0, 72)]))
    p.setBrush(QColor('#c0c4cc')); p.drawRect(QRectF(-12, -84, 24, 14)); p.setBrush(QColor('#f472b6')); p.drawRoundedRect(QRectF(-12, -102, 24, 22), 8, 8)
def intro_compass(p):
    p.setPen(QPen(QColor('#d6dde8'), 9, Qt.SolidLine, Qt.RoundCap)); p.drawLine(QPointF(0, -60), QPointF(-34, 62)); p.drawLine(QPointF(0, -60), QPointF(34, 62))
    p.setPen(QPen(QColor('#64748b'), 3, Qt.SolidLine, Qt.RoundCap)); p.drawLine(QPointF(-34, 62), QPointF(-37, 82))
    p.setPen(Qt.NoPen); p.setBrush(QColor('#334155')); p.drawPolygon(QPolygonF([QPointF(29, 62), QPointF(40, 62), QPointF(36, 84)]))
    p.setPen(QPen(QColor('#94a3b8'), 4)); p.drawLine(QPointF(-16, 0), QPointF(16, 0))
    p.setPen(Qt.NoPen); p.setBrush(QColor('#2f7cf6')); p.drawEllipse(QPointF(0, -62), 13, 13); p.setBrush(QColor('#1e3a8a')); p.drawRect(QRectF(-5, -94, 10, 26))
def intro_book(p):
    from PyQt5.QtGui import QPainterPath
    p.setPen(Qt.NoPen); p.setBrush(QColor('#1e40af'))
    p.drawPolygon(QPolygonF([QPointF(-84, -48), QPointF(0, -38), QPointF(84, -48), QPointF(84, 54), QPointF(0, 64), QPointF(-84, 54)]))
    p.setBrush(Qt.white)
    for sg in (-1, 1):
        pa = QPainterPath(QPointF(sg*76, -44)); pa.quadTo(QPointF(sg*36, -50), QPointF(0, -34)); pa.lineTo(0, 57); pa.quadTo(QPointF(sg*36, 41), QPointF(sg*76, 47)); pa.closeSubpath(); p.drawPath(pa)
    p.setPen(QPen(QColor('#cbd5e1'), 3)); p.setBrush(Qt.NoBrush)
    for sg in (-1, 1):
        for i in range(4):
            pa = QPainterPath(QPointF(sg*63, -24 + i*18)); pa.quadTo(QPointF(sg*34, -28 + i*18), QPointF(sg*10, -18 + i*18)); p.drawPath(pa)
    p.setPen(QPen(QColor('#d1262f'), 4)); p.drawLine(QPointF(0, -34), QPointF(0, 57))

class IntroOverlay(QWidget):
    def __init__(self, main, sound=True):
        super().__init__(main); self.main = main; self.setGeometry(main.rect()); self.setFocusPolicy(Qt.StrongFocus)
        from PyQt5.QtCore import QElapsedTimer
        W, H = self.width(), self.height(); self.W, self.H = W, H
        self.G, self.R, self.FY, self.top, self.segs, self.tEnd = intro_plan(H)
        self.bg = self.make_bg(); self.ball = self.make_ball(); self.items = [self.make_item(f) for f in (intro_pencil, intro_compass, intro_book)]
        self.clock = QElapsedTimer(); self.clock.start(); self.done = False
        self.timer = QTimer(self); self.timer.timeout.connect(self.update); self.timer.start(16)
        if sound and os.path.isfile(INTRO_SOUND): play_sound(INTRO_SOUND, .9)
        self.show(); self.raise_(); self.setFocus()
    def make_bg(self):
        from PyQt5.QtGui import QRadialGradient, QLinearGradient
        W, H = self.W, self.H; pm = QPixmap(W, H); p = QPainter(pm)
        g = QRadialGradient(QPointF(W/2, H*.45), W*.75); g.setColorAt(0, QColor('#1d3566')); g.setColorAt(.6, QColor('#0d1a33')); g.setColorAt(1, QColor('#060c18')); p.fillRect(pm.rect(), g)
        fl = QLinearGradient(0, self.FY, 0, H); fl.setColorAt(0, QColor(110, 150, 255, 90)); fl.setColorAt(.08, QColor(40, 70, 150, 40)); fl.setColorAt(1, QColor(0, 0, 0, 0))
        p.fillRect(QRectF(0, self.FY, W, H - self.FY), fl); p.end(); return pm
    def make_ball(self):
        """Logo küresi: ışıma + logo + küre gölgesi + parlak yansıma (bir kez çizilir)."""
        from PyQt5.QtGui import QRadialGradient, QPainterPath
        r = self.R; m = r*1.4; pm = QPixmap(int(2*m), int(2*m)); pm.fill(Qt.transparent); p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform); p.translate(m, m)
        for k, a in ((1.35, 18), (1.18, 34), (1.07, 60)):
            g = QRadialGradient(0, 0, r*k); g.setColorAt(.7, QColor(90, 130, 255, a)); g.setColorAt(1, QColor(90, 130, 255, 0)); p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(QPointF(0, 0), r*k, r*k)
        clip = QPainterPath(); clip.addEllipse(QPointF(0, 0), r, r); p.setClipPath(clip)
        logo = QImage(INTRO_LOGO)
        if logo.isNull(): logo = QImage(LOGO)
        p.drawImage(QRectF(-r, -r, 2*r, 2*r), logo)
        g = QRadialGradient(QPointF(-r*.3, -r*.35), r*1.15); g.setColorAt(0, QColor(255, 255, 255, 30)); g.setColorAt(.68, QColor(0, 0, 0, 0)); g.setColorAt(.9, QColor(0, 0, 30, 45)); g.setColorAt(1, QColor(0, 0, 20, 120))
        p.setBrush(g); p.drawEllipse(QPointF(0, 0), r, r)
        g = QRadialGradient(QPointF(0, 0), r*.46); g.setColorAt(0, QColor(255, 255, 255, 215)); g.setColorAt(.4, QColor(255, 255, 255, 70)); g.setColorAt(1, QColor(255, 255, 255, 0))
        p.setBrush(g); p.save(); p.translate(-r*.36, -r*.46); p.rotate(-35); p.scale(1, .65); p.drawEllipse(QPointF(0, 0), r*.46, r*.46); p.restore(); p.end(); return pm
    def make_item(self, fn):
        from PyQt5.QtGui import QRadialGradient
        sc = self.H/760*1.05; m = 160*sc; pm = QPixmap(int(2*m), int(2*m)); pm.fill(Qt.transparent); p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing); p.translate(m, m)
        g = QRadialGradient(QPointF(0, 0), m); g.setColorAt(0, QColor(120, 160, 255, 60)); g.setColorAt(1, QColor(120, 160, 255, 0)); p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(QPointF(0, 0), m, m)
        p.scale(sc, sc); fn(p); p.end(); return pm
    def finish(self):
        if self.done: return
        self.done = True; self.timer.stop(); self.hide(); self.deleteLater()
        if getattr(self.main, 'intro', None) is self: self.main.intro = None
        try:
            from PyQt5.QtMultimedia import QSoundEffect
            k = getattr(play_sound, 'keep', None)
            if k is not None and k.source().toLocalFile() == INTRO_SOUND: k.stop()
        except Exception: pass
    def mousePressEvent(self, e): self.finish()
    def keyPressEvent(self, e): self.finish()
    def event(self, e):
        if e.type() == QEvent.TouchBegin: self.finish(); return True
        return super().event(e)
    def paintEvent(self, e):
        from PyQt5.QtGui import QRadialGradient
        pw = self.parentWidget()
        ps = pw.size() if pw is not None else None
        if ps is not None and (ps.width(), ps.height()) != (self.W, self.H):   # tam ekrana geçiş animasyon sırasında biterse
            self.setGeometry(pw.rect()); self.W, self.H = ps.width(), ps.height()
            self.G, self.R, self.FY, self.top, self.segs, self.tEnd = intro_plan(self.H)
            self.bg = self.make_bg(); self.ball = self.make_ball(); self.items = [self.make_item(f) for f in (intro_pencil, intro_compass, intro_book)]
        t = self.clock.elapsed()/1000; W, H, R, FY, segs, tEnd = self.W, self.H, self.R, self.FY, self.segs, self.tEnd; X0 = W/2
        u = t - tEnd
        if u > 2.0: QTimer.singleShot(0, self.finish); return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
        fade = min(1.0, max(0.0, (u - 1.25)/.6)); base = 1 - fade   # sonda her şey solar, tahta görünür
        p.setOpacity(base); p.drawPixmap(0, 0, self.bg)
        sq = 1.0
        if t < segs[0][1]: y = self.top + .5*self.G*t*t
        elif t < tEnd:
            y = FY - R
            for t0, d, h in segs[1:]:
                if t0 <= t < t0 + d:
                    v = (t - t0)/d; y = FY - R - h*4*v*(1 - v); e_ = min(v, 1 - v)*d
                    if e_ < .045: sq = 1 - (.045 - e_)*(h/(H*.02) + 2)
                    break
        else: y = FY - R
        sq = max(.74, sq); hgt = FY - R - y; k = max(.2, 1 - hgt/(H*.7)); sh = 1.0 if t < tEnd else max(0.0, 1 - u/.16)
        if sh > 0:
            g = QRadialGradient(QPointF(X0, FY), R*1.25*k); g.setColorAt(0, QColor(0, 0, 0, int(150*k*sh))); g.setColorAt(1, QColor(0, 0, 0, 0))
            p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(QPointF(X0, FY), R*1.25*k, R*.26*k)
        p.setBrush(Qt.NoBrush)
        for t0, d, h in segs[1:] + [(tEnd, 0, 0)]:   # her vuruşta yerde ışık halkası
            v = (t - t0)/.38
            if 0 < v < 1: p.setPen(QPen(QColor(157, 184, 255, int(160*(1 - v))), 4*(1 - v) + .5)); p.drawEllipse(QPointF(X0, FY), R*(1 + v*1.7), R*.22*(1 + v*1.7))
        bw = self.ball.width()/2
        if t < tEnd:
            p.save(); p.translate(X0, y + R*(1 - sq)); p.scale(1/sq, sq); p.rotate(math.sin(t*2.2)*6); p.drawPixmap(QPointF(-bw, -bw), self.ball); p.restore()
        else:
            s_ = max(0.0, 1 - u/.16)
            if s_ > 0: p.save(); p.translate(X0, FY - R); k_ = s_*(1 + .2*(1 - s_)); p.scale(k_, k_); p.drawPixmap(QPointF(-bw, -bw), self.ball); p.restore()
            a = max(0.0, 1 - u/.6)
            if a > 0:
                g = QRadialGradient(QPointF(X0, FY - R), R*3.2*min(1, u/.45) + 1); g.setColorAt(0, QColor(255, 255, 255, int(245*a))); g.setColorAt(.4, QColor(160, 190, 255, int(100*a))); g.setColorAt(1, QColor(100, 140, 255, 0))
                p.fillRect(self.rect(), g)
            p.setPen(Qt.NoPen)
            for i in range(30):   # konfeti
                an = i*2.399; sp = H*.45 + (i*97 % 220)*H/700
                px = X0 + math.cos(an)*sp*u; py = FY - R + math.sin(an)*sp*u + 600*H/760*u*u
                if py > H + 20: continue
                p.save(); p.translate(px, py); p.rotate((u*8 + i)*57); p.setOpacity(base*max(0.0, 1 - u/1.2))
                p.setBrush(QColor(('#d1262f', '#ffffff', '#8fb0ff')[i % 3])); p.drawRect(QRectF(-6, -3.5, 12, 7)); p.restore()
            for i, (pm, dx, dy, spin) in enumerate(zip(self.items, (-.25, 0, .25), (-.33, -.43, -.33), (-2.2, 1.3, .7))):
                v = min(1.0, u/.75); e_ = 1 - (1 - v)**3; f_ = max(0.0, 1 - (u - 1.3)/.45) if u > 1.3 else 1
                if f_ <= 0: continue
                px = X0 + dx*W*e_; py = FY - R + dy*H*e_ + (math.sin((u - .75)*5 + i)*6 if v >= 1 else 0)
                p.save(); p.setOpacity(f_); p.translate(px, py); p.rotate(math.degrees(spin*(1 - e_)*3 + (math.sin(u*3 + i)*.06 if v >= 1 else 0)))
                sc = .3 + .7*e_; p.scale(sc, sc); p.drawPixmap(QPointF(-pm.width()/2, -pm.height()/2), pm); p.restore()
        p.end()

# ---------------------------------------------------------------------------
# Full-screen classroom timer (Sayaç): ring, digital and analog faces.
TIMER_STYLES = [('ring','Halka'),('digital','Dijital'),('analog','Analog')]
TIMER_PRESETS = [1,3,5,10,15,20,30,40]

def soft_chime_file(folder):
    """A very soft two-note bell, generated once (no external sound file)."""
    import wave, struct
    path = os.path.join(folder, 'yumusak-zil.wav')
    if os.path.isfile(path): return path
    os.makedirs(folder, exist_ok=True)
    rate = 44100; frames = []
    notes = [(0.0, 659.25), (0.55, 523.25)]          # E5 → C5, gentle descending
    length = int(rate*3.2)
    for i in range(length):
        t = i/rate; v = 0.0
        for start, f in notes:
            dt = t-start
            if dt < 0: continue
            env = min(1, dt/0.02) * math.exp(-dt*1.6)   # soft attack, long fade
            v += env*(math.sin(2*math.pi*f*dt) + .35*math.sin(2*math.pi*2*f*dt) + .12*math.sin(2*math.pi*3*f*dt))
        frames.append(struct.pack('<h', int(max(-1, min(1, v*.16))*32767)))
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b''.join(frames))
    return path

def play_sound(path, volume=.7):
    try:
        from PyQt5.QtMultimedia import QSoundEffect
        from PyQt5.QtCore import QUrl
        effect = QSoundEffect(); effect.setSource(QUrl.fromLocalFile(path)); effect.setVolume(volume); effect.play()
        play_sound.keep = effect; return True
    except Exception: pass
    import subprocess
    for cmd in (['paplay', path], ['pw-play', path], ['aplay', '-q', path]):
        try: subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
        except OSError: continue
    return False

class TimerScreen(QWidget):
    def __init__(self, main):
        super().__init__(None, Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.main = main
        self.setWindowTitle('Sayaç • '+APP_NAME); self.setWindowIcon(QIcon(LOGO))
        self.cfg_path = os.path.join(main.data_dir, 'sayac.json')
        try:
            with open(self.cfg_path, encoding='utf-8') as f: cfg = json.load(f)
        except (OSError, ValueError): cfg = {}
        self.total = max(10, min(3*3600, int(cfg.get('seconds', 600))))
        self.face = cfg.get('style', 'ring') if cfg.get('style') in dict(TIMER_STYLES) else 'ring'
        self.state = 'setup'; self.remaining = self.total; self.end_at = None; self.done_at = None
        self.ticker = QTimer(self); self.ticker.setInterval(40); self.ticker.timeout.connect(self.tick)
        self.setStyleSheet('''QPushButton{background:rgba(255,255,255,.07);color:#e8eefc;border:1px solid rgba(255,255,255,.16);
                border-radius:26px;font-family:"DejaVu Sans";font-size:20px;padding:0 22px;min-height:52px;}
            QPushButton:hover{background:rgba(255,255,255,.13);}
            QPushButton:checked{background:rgba(125,211,252,.22);border:2px solid #7dd3fc;}
            QPushButton#start{background:#3b82f6;border:none;font-weight:bold;font-size:22px;}
            QPushButton#close{background:rgba(251,113,133,.16);border:1px solid rgba(251,113,133,.6);}''')
        def btn(text, fn, name=''):
            b = QPushButton(text, self); b.setObjectName(name); b.clicked.connect(fn); b.setFocusPolicy(Qt.NoFocus); return b
        self.close_btn = btn('✕  Kapat', self.close_timer, 'close')
        self.face_btns = {}
        for key, label in TIMER_STYLES:
            b = btn(label, lambda checked=False, k=key: self.set_face(k)); b.setCheckable(True); self.face_btns[key] = b
        self.presets = [btn('%d dk' % m, lambda checked=False, m=m: self.set_total(m*60)) for m in TIMER_PRESETS]
        self.adjust = [btn(t, lambda checked=False, d=d: self.set_total(self.total+d)) for t, d in
                       (('−5 dk',-300),('−1 dk',-60),('−10 sn',-10),('+10 sn',10),('+1 dk',60),('+5 dk',300))]
        self.start_btn = btn('▶  Başlat', self.start, 'start')
        self.pause_btn = btn('❚❚  Duraklat', self.toggle_pause)
        self.restart_btn = btn('↺  Yeniden başlat', self.start)
        self.change_btn = btn('Süreyi değiştir', self.back_to_setup)
        self.set_face(self.face, save=False); self.update_controls()

    # ---- state ----------------------------------------------------------
    def save_cfg(self):
        try:
            os.makedirs(os.path.dirname(self.cfg_path), exist_ok=True)
            with open(self.cfg_path, 'w', encoding='utf-8') as f: json.dump(dict(seconds=self.total, style=self.face), f)
        except OSError: pass
    def set_face(self, key, save=True):
        self.face = key
        for k, b in self.face_btns.items(): b.setChecked(k == key)
        if save: self.save_cfg()
        self.update()
    def set_total(self, seconds):
        self.total = max(10, min(3*3600, int(seconds)))
        if self.state == 'setup': self.remaining = self.total
        self.update()
    def start(self):
        import time
        self.save_cfg()   # the last started duration becomes the default
        self.state = 'running'; self.remaining = self.total; self.end_at = time.monotonic()+self.total
        self.ticker.start(); self.update_controls(); self.update()
    def toggle_pause(self):
        import time
        if self.state == 'running':
            self.remaining = max(0, self.end_at-time.monotonic()); self.state = 'paused'
        elif self.state == 'paused':
            self.end_at = time.monotonic()+self.remaining; self.state = 'running'
        self.update_controls(); self.update()
    def back_to_setup(self):
        self.state = 'setup'; self.remaining = self.total; self.ticker.stop(); self.update_controls(); self.update()
    def tick(self):
        import time
        if self.state == 'running':
            self.remaining = max(0, self.end_at-time.monotonic())
            if self.remaining <= 0:
                self.state = 'done'; self.done_at = time.monotonic(); self.update_controls()
                try: play_sound(soft_chime_file(self.main.data_dir))
                except Exception: pass
        elif self.state == 'done' and time.monotonic()-self.done_at > 30: self.ticker.stop()
        self.update()
    def open_timer(self):
        if getattr(self, 'mini_timer', None) is not None: self.mini_timer.hide()
        screen = self.main.windowHandle().screen() if self.main.windowHandle() else QApplication.primaryScreen()
        self.setGeometry(screen.geometry()); self.showFullScreen(); self.raise_(); self.activateWindow()
    def close_timer(self):
        # Süre işliyorsa "Kapat" sayacı kapatmaz: tahtanın kenarına küçük sayaç olarak iner.
        if self.state in ('running', 'paused'):
            self.hide(); self.mini().show_mini(); return
        self.stop_timer()
    def stop_timer(self):
        """Sayacı tamamen kapatır (küçük sayaçtaki ✕)."""
        self.ticker.stop(); self.state = 'setup'; self.remaining = self.total; self.update_controls(); self.hide()
        if getattr(self, 'mini_timer', None) is not None: self.mini_timer.hide()
    def mini(self):
        if getattr(self, 'mini_timer', None) is None: self.mini_timer = MiniTimer(self)
        return self.mini_timer
    def closeEvent(self, e):
        self.ticker.stop(); self.state = 'setup'; self.remaining = self.total; self.update_controls(); super().closeEvent(e)

    # ---- layout ----------------------------------------------------------
    def update_controls(self):
        setup = self.state == 'setup'
        for b in self.presets+self.adjust+[self.start_btn]: b.setVisible(setup)
        for b in (self.pause_btn, self.restart_btn, self.change_btn): b.setVisible(not setup)
        self.pause_btn.setVisible(self.state in ('running','paused'))
        self.pause_btn.setText('▶  Devam' if self.state == 'paused' else '❚❚  Duraklat')
        self.layout_controls()
    def row(self, buttons, y, gap=14):
        widths = [230 if b is self.start_btn else (128 if b in self.presets+self.adjust else max(150, b.fontMetrics().boundingRect(b.text()).width()+64)) for b in buttons]
        x = (self.width()-sum(widths)-gap*(len(buttons)-1))//2
        for b, w in zip(buttons, widths): b.setGeometry(x, y, w, 56); x += w+gap
    def layout_controls(self):
        W, H = self.width(), self.height()
        self.close_btn.setGeometry(W-200, 28, 172, 56)
        self.row([self.face_btns[k] for k, _ in TIMER_STYLES], 28)
        if self.state == 'setup':
            self.row(self.presets, H-212); self.row(self.adjust[:3]+[self.start_btn]+self.adjust[3:], H-136)
        else:
            self.row([b for b in (self.pause_btn, self.restart_btn, self.change_btn) if b.isVisible()], H-120)
    def resizeEvent(self, e): self.layout_controls(); super().resizeEvent(e)

    # ---- drawing ---------------------------------------------------------
    def palette(self):
        frac = self.remaining/self.total if self.total else 0
        if self.state == 'done': return QColor('#34d399'), QColor('#6ee7b7')
        if frac <= .1: return QColor('#fb7185'), QColor('#f43f5e')
        if frac <= .25: return QColor('#fbbf24'), QColor('#f59e0b')
        return QColor('#38bdf8'), QColor('#818cf8')
    def time_text(self):
        s = int(math.ceil(self.remaining-1e-6)); h, m, sec = s//3600, s%3600//60, s%60
        return '%d:%02d:%02d' % (h, m, sec) if h else '%02d:%02d' % (m, sec)
    def end_text(self):
        import datetime
        if self.state == 'setup': return 'Süre: %d dakika%s' % (self.total//60, ' %d saniye' % (self.total%60) if self.total%60 else '')
        if self.state == 'done': return 'Süre doldu'
        if self.state == 'paused': return 'Duraklatıldı'
        return 'Bitiş  %s' % (datetime.datetime.now()+datetime.timedelta(seconds=self.remaining)).strftime('%H:%M')
    def font(self, px, bold=False, light=False):
        from PyQt5.QtGui import QFont
        f = QFont('DejaVu Sans'); f.setPixelSize(max(8, int(px))); f.setBold(bold)
        if light: f.setWeight(QFont.Light)
        return f
    def paintEvent(self, e):
        from PyQt5.QtGui import QLinearGradient, QRadialGradient
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height()
        g = QLinearGradient(0, 0, W, H); g.setColorAt(0, QColor('#070d1a')); g.setColorAt(1, QColor('#111c33'))
        p.fillRect(self.rect(), g)
        a, b = self.palette()
        glow = QRadialGradient(W/2, H/2, min(W, H)*.55); c = QColor(a); c.setAlpha(28); glow.setColorAt(0, c); glow.setColorAt(1, QColor(0,0,0,0))
        p.fillRect(self.rect(), glow)
        p.setPen(QColor(232,238,252,150)); p.setFont(self.font(20, True)); p.drawText(QRectF(32, 28, 300, 56), Qt.AlignVCenter, '◷  Sayaç')
        bottom = 240 if self.state == 'setup' else 150
        R = QRectF(0, 100, W, H-100-bottom)
        getattr(self, 'draw_'+self.face)(p, R, a, b)
    def pulse(self):
        import time
        if self.state != 'done': return 1
        return .55+.45*(.5+.5*math.cos((time.monotonic()-self.done_at)*2.4))
    def frac(self): return 1.0 if self.state == 'setup' else (self.remaining/self.total if self.total else 0)
    def draw_ring(self, p, R, a, b):
        from PyQt5.QtGui import QConicalGradient
        size = min(R.width(), R.height())*.92; c = R.center(); r = size/2; thick = size*.055
        box = QRectF(c.x()-r+thick/2, c.y()-r+thick/2, size-thick, size-thick)
        p.setPen(QPen(QColor(255,255,255,22), thick, Qt.SolidLine, Qt.RoundCap)); p.drawEllipse(box)
        f = self.frac()
        if self.state == 'done': f = 1
        if f > 0:
            grad = QConicalGradient(c, 90); grad.setColorAt(0, a); grad.setColorAt(1, b)
            pen = QPen(grad, thick, Qt.SolidLine, Qt.RoundCap); p.setPen(pen); p.setOpacity(self.pulse())
            p.drawArc(box, 90*16, int(-f*360*16)); p.setOpacity(1)
            ang = math.radians(90-f*360); hx = c.x()+math.cos(ang)*box.width()/2; hy = c.y()-math.sin(ang)*box.height()/2
            p.setPen(Qt.NoPen); p.setBrush(QColor('#ffffff')); p.drawEllipse(QPointF(hx, hy), thick*.32, thick*.32)
        self.center_text(p, c, size, a)
    def center_text(self, p, c, size, a):
        p.setPen(QColor(232,238,252,140)); p.setFont(self.font(size*.045, True))
        p.drawText(QRectF(c.x()-size/2, c.y()-size*.24, size, size*.08), Qt.AlignCenter, 'KALAN SÜRE' if self.state != 'setup' else 'SÜRE')
        p.setPen(QColor('#f4f7ff')); p.setFont(self.font(size*(.2 if self.remaining >= 3600 else .26), light=True))
        p.setOpacity(self.pulse()); p.drawText(QRectF(c.x()-size/2, c.y()-size*.17, size, size*.3), Qt.AlignCenter, self.time_text()); p.setOpacity(1)
        p.setPen(a); p.setFont(self.font(size*.05, True))
        p.drawText(QRectF(c.x()-size/2, c.y()+size*.15, size, size*.09), Qt.AlignCenter, self.end_text())
    def draw_digital(self, p, R, a, b):
        from PyQt5.QtGui import QLinearGradient
        import time
        text = self.time_text(); px = min(R.height()*.5, R.width()/(len(text)*.62))
        p.setFont(self.font(px, True)); fm = p.fontMetrics()
        cy = R.center().y()-R.height()*.06
        tw = fm.horizontalAdvance(text) if hasattr(fm, 'horizontalAdvance') else fm.width(text)
        x = R.center().x()-tw/2
        blink = self.state == 'running' and (time.monotonic() % 1) > .5
        p.setOpacity(self.pulse())
        for ch in text:
            w = fm.horizontalAdvance(ch) if hasattr(fm, 'horizontalAdvance') else fm.width(ch)
            col = QColor('#f4f7ff') if ch != ':' else QColor(a)
            if ch == ':' and blink: col.setAlpha(70)
            p.setPen(col); p.drawText(QRectF(x, cy-px*.6, w, px*1.2), Qt.AlignCenter, ch); x += w
        p.setOpacity(1)
        bw = R.width()*.62; bh = max(10, R.height()*.03); bx = R.center().x()-bw/2; by = cy+px*.62
        p.setPen(Qt.NoPen); p.setBrush(QColor(255,255,255,22)); p.drawRoundedRect(QRectF(bx, by, bw, bh), bh/2, bh/2)
        f = 1 if self.state == 'done' else self.frac()
        if f > 0:
            g = QLinearGradient(bx, 0, bx+bw, 0); g.setColorAt(0, a); g.setColorAt(1, b); p.setBrush(g)
            p.drawRoundedRect(QRectF(bx, by, max(bh, bw*f), bh), bh/2, bh/2)
        p.setPen(a); p.setFont(self.font(R.height()*.05, True))
        p.drawText(QRectF(R.left(), by+bh*2.2, R.width(), R.height()*.09), Qt.AlignCenter, self.end_text())
    def draw_analog(self, p, R, a, b):
        size = min(R.width(), R.height())*.9; c = R.center(); r = size/2
        scale = 60*60 if self.total <= 3600 else int(math.ceil(self.total/1800.0))*1800
        p.setPen(Qt.NoPen); p.setBrush(QColor(255,255,255,12)); p.drawEllipse(c, r, r)
        p.setPen(QPen(QColor(255,255,255,40), 2)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, r, r)
        for i in range(60):
            ang = math.radians(90-i*6); major = i % 5 == 0
            r1 = r*(.86 if major else .91); r2 = r*.95
            p.setPen(QPen(QColor(232,238,252,200 if major else 70), 4 if major else 2, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(QPointF(c.x()+math.cos(ang)*r1, c.y()-math.sin(ang)*r1), QPointF(c.x()+math.cos(ang)*r2, c.y()-math.sin(ang)*r2))
            if major:
                label = str(int(i/60*scale/60)); tr = r*.76
                p.setPen(QColor(232,238,252,170)); p.setFont(self.font(size*.045, True))
                p.drawText(QRectF(c.x()+math.cos(ang)*tr-size*.06, c.y()-math.sin(ang)*tr-size*.035, size*.12, size*.07), Qt.AlignCenter, label)
        rem = self.total if self.state == 'setup' else self.remaining
        span = 0 if self.state == 'done' else min(1, rem/scale)
        sr = r*.68
        if span > 0:
            col = QColor(a); col.setAlpha(225); p.setPen(Qt.NoPen); p.setBrush(col)
            p.drawPie(QRectF(c.x()-sr, c.y()-sr, 2*sr, 2*sr), 90*16, int(-span*360*16))
            ang = math.radians(90-span*360)
            p.setPen(QPen(QColor('#ffffff'), 5, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(c, QPointF(c.x()+math.cos(ang)*sr, c.y()-math.sin(ang)*sr))
        p.setPen(QPen(QColor(255,255,255,60), 2)); p.setBrush(QColor('#0b1426')); p.drawEllipse(c, size*.07, size*.07)
        p.setPen(QColor('#f4f7ff')); p.setFont(self.font(size*.045, True)); p.setOpacity(self.pulse())
        p.drawText(QRectF(c.x()-size*.07, c.y()-size*.03, size*.14, size*.06), Qt.AlignCenter, self.time_text() if len(self.time_text()) <= 5 else self.time_text()[:-3])
        p.setOpacity(1); p.setPen(a); p.setFont(self.font(size*.05, True))
        p.drawText(QRectF(R.left(), c.y()+r*.3, R.width(), size*.08), Qt.AlignCenter, self.end_text() if self.state != 'setup' else '')
# ---------------------------------------------------------------------------
# Scientific calculator (touch friendly, safe evaluation — no eval()).
class Celebration(QWidget):
    """Alkış gösterisi: art arda roketler havada patlar, iki yandan ve üstten konfeti
    yağar; yaklaşık 6 saniye sonra kendiliğinden biter. Yazılara dokunmaz, dokunmayı engellemez."""
    DUR = 6.0; COLS = ['#e8132b', '#0057ff', '#00a24a', '#ffe14d', '#ff2d95', '#8a2be2', '#ff8a00', '#ffffff', '#38bdf8']
    def __init__(self, main):
        super().__init__(main); self.main = main
        self.setAttribute(Qt.WA_TransparentForMouseEvents); self.setAttribute(Qt.WA_NoSystemBackground); self.hide()
        self.timer = QTimer(self); self.timer.setInterval(30); self.timer.timeout.connect(self.step)
        self.cols = [QColor(c) for c in self.COLS]
    def start(self):
        import random
        R = random.Random(); self.rnd = R.uniform
        self.setGeometry(self.main.rect()); W, H = self.width(), self.height(); self.W, self.H = W, H; k = max(.6, H/1000)
        self.k = k; self.conf = []; self.sparks = []; self.rockets = []
        for side in (0, 1):   # konfeti topları
            x0 = W*(.97 if side else .03)
            for _ in range(230):
                a = R.uniform(.28, .62)*math.pi; v = R.uniform(14, 30)*k
                self.add_conf(x0, H*.98, (-1 if side else 1)*math.cos(a)*v, -math.sin(a)*v)
        for _ in range(200): self.add_conf(R.uniform(0, W), R.uniform(-H*.6, 0), R.uniform(-1, 1)*k, R.uniform(0, 3)*k)
        for i in range(9):   # roketler: alkış sesindeki gümbürtülerle aynı an (i·0.42 s'de kalkar, 0.95 s sonra patlar)
            self.rockets.append(dict(x=W*R.uniform(.15, .85), t=i*.42, vx=R.uniform(-1.5, 1.5)*k, c=R.randrange(7), peak=R.uniform(.55, .78), done=False, trail=[]))
        self.t0 = time.monotonic(); self.last = self.t0; self.show(); self.raise_(); self.timer.start()
    def add_conf(self, x, y, vx, vy):
        self.conf.append([x, y, vx, vy, self.rnd(8, 16)*self.k, self.rnd(4, 8)*self.k, self.rnd(0, 6), self.rnd(-.3, .3), int(self.rnd(0, len(self.COLS)-.01)), self.rnd(0, 6)])
    def rocket_pos(self, r, el):
        t = el - r['t']; H = self.H; fl = .95
        y = H - H*r['peak']*(1 - (1 - min(t, fl)/fl)**2); x = r['x'] + r['vx']*t*30
        return x, y
    def step(self):
        now = time.monotonic(); el = now - self.t0; f = min(3.0, (now - self.last)/.03); self.last = now
        if el > self.DUR: self.timer.stop(); self.hide(); self.conf = []; self.sparks = []; return
        g = .5*self.k*f
        for c in self.conf:
            c[3] += g; c[2] *= .985**f; c[3] *= .985**f; c[9] += .12*f
            c[0] += (c[2] + math.sin(c[9])*.8*self.k)*f; c[1] += c[3]*f; c[6] += c[7]*f
        for r in self.rockets:
            if el < r['t'] or r['done']: continue
            x, y = self.rocket_pos(r, el); r['trail'] = (r['trail'] + [(x, y)])[-12:]
            if el - r['t'] >= .95:
                r['done'] = True
                for i in range(80):
                    a = i/80*math.pi*2; v = self.rnd(4, 10)*self.k
                    self.sparks.append([x, y, math.cos(a)*v, math.sin(a)*v, 1.0, r['c'] if self.rnd(0, 1) > .25 else 7])
                for _ in range(30): self.add_conf(x, y, self.rnd(-7, 7)*self.k, self.rnd(-9, 3)*self.k)
        for s_ in self.sparks:
            s_[2] *= .96**f; s_[3] = s_[3]*.96**f + .12*self.k*f; s_[0] += s_[2]*f; s_[1] += s_[3]*f; s_[4] -= .016*f
        self.sparks = [s_ for s_ in self.sparks if s_[4] > 0]
        self.conf = [c for c in self.conf if c[1] < self.H + 40]
        self.update()
    def paintEvent(self, e):
        el = time.monotonic() - self.t0; p = QPainter(self)
        fade = 1.0 if el < 5.2 else max(0.0, 1 - (el - 5.2)/.8); p.setOpacity(fade); p.setPen(Qt.NoPen)
        for c in self.conf:   # dönen kâğıt: döndürülmüş dikdörtgen (dönüşümsüz, hızlı)
            x, y, w, h, r = c[0], c[1], c[4]/2, c[5]/2*abs(math.cos(c[6]*2)) + .5, c[6]
            ca, sa = math.cos(r), math.sin(r)
            p.setBrush(self.cols[c[8]])
            p.drawPolygon(QPolygonF([QPointF(x + ca*dx - sa*dy, y + sa*dx + ca*dy) for dx, dy in ((-w, -h), (w, -h), (w, h), (-w, h))]))
        p.setRenderHint(QPainter.Antialiasing)
        for r in self.rockets:
            if el < r['t'] or r['done'] or not r['trail']: continue
            n = len(r['trail'])
            for i, (x, y) in enumerate(r['trail']):
                a = (i + 1)/n; col = QColor(255, int(120 + 120*a), 40); col.setAlphaF(a); p.setBrush(col)
                rr = (1.5 + 3.5*a)*self.k; p.drawEllipse(QPointF(x, y + (n - i)*2*self.k), rr, rr)
            x, y = r['trail'][-1]; p.setBrush(self.cols[r['c']]); p.drawEllipse(QPointF(x, y), 4*self.k, 4*self.k)
        for s_ in self.sparks:
            col = QColor(self.cols[s_[5]]); col.setAlphaF(max(0.0, min(1.0, s_[4]))); p.setBrush(col)
            p.drawEllipse(QPointF(s_[0], s_[1]), 2.6*self.k, 2.6*self.k)

class MiniTimer(QWidget):
    """Küçük sayaç: tam ekran sayaç kapatılınca süre kenarda işlemeye devam eder.
    Dokun: tam ekrana döner · sürükle: yerini değiştirir · ✕: sayacı tamamen kapatır."""
    W, H = 236, 64
    def __init__(self, timer):
        super().__init__(None, Qt.Tool|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.timer = timer; self.press = None; self.moved = False; self.placed = False
        self.setFixedSize(self.W, self.H); self.setCursor(Qt.PointingHandCursor)
        from PyQt5.QtGui import QPainterPath
        path = QPainterPath(); path.addRoundedRect(QRectF(0, 0, self.W, self.H), 16, 16)
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))
        self.refresh = QTimer(self); self.refresh.setInterval(250); self.refresh.timeout.connect(self.update)
    def show_mini(self):
        if not self.placed:   # ilk kez: tahtanın sol üstü (oklar ve soru listesiyle çakışmaz)
            m = self.timer.main; vp = m.scroll.viewport(); g = vp.mapToGlobal(QPoint(14, 14)); self.move(g); self.placed = True
        self.refresh.start(); self.show(); self.raise_()
    def hideEvent(self, e): self.refresh.stop(); super().hideEvent(e)
    def close_rect(self): return QRectF(self.W-46, (self.H-34)/2, 34, 34)
    def paintEvent(self, e):
        t = self.timer; p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        done = t.state == 'done'; col = t.palette()[0]; paused = t.state == 'paused'
        p.setPen(QPen(col if done else QColor('#3a5577'), 2)); p.setBrush(QColor('#0f2442')); p.drawRoundedRect(QRectF(1, 1, self.W-2, self.H-2), 15, 15)
        c = QPointF(32, self.H/2); r = 18
        p.setPen(QPen(QColor('#24344f'), 5)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, r, r)
        frac = 1.0 if done else (t.remaining/t.total if t.total else 0)
        p.setPen(QPen(col, 5, Qt.SolidLine, Qt.RoundCap)); p.drawArc(QRectF(c.x()-r, c.y()-r, 2*r, 2*r), 90*16, int(-360*16*frac))
        if paused:
            p.setPen(Qt.NoPen); p.setBrush(col); p.drawRect(QRectF(c.x()-6, c.y()-7, 4, 14)); p.drawRect(QRectF(c.x()+2, c.y()-7, 4, 14))
        f = p.font(); f.setPixelSize(19 if done else 26); f.setBold(True); p.setFont(f)
        p.setPen(col if (paused or done) else QColor('#f4f7ff'))
        p.drawText(QRectF(60, 0, self.W-112, self.H), Qt.AlignVCenter|Qt.AlignLeft, 'Süre doldu' if done else t.time_text())
        x = self.close_rect(); p.setPen(QPen(QColor(251, 113, 133, 160), 1)); p.setBrush(QColor(251, 113, 133, 40)); p.drawEllipse(x)
        p.setPen(QPen(QColor('#fb7185'), 2.2)); k = 6
        p.drawLine(QPointF(x.center().x()-k, x.center().y()-k), QPointF(x.center().x()+k, x.center().y()+k))
        p.drawLine(QPointF(x.center().x()-k, x.center().y()+k), QPointF(x.center().x()+k, x.center().y()-k))
    def mousePressEvent(self, e):
        self.press = (e.globalPos(), self.pos()); self.moved = False
    def mouseMoveEvent(self, e):
        if self.press is None: return
        d = e.globalPos() - self.press[0]
        if self.moved or abs(d.x()) + abs(d.y()) > 10: self.moved = True; self.move(self.press[1] + d)
    def mouseReleaseEvent(self, e):
        if self.press is None: return
        self.press = None
        if self.moved: return
        if self.close_rect().adjusted(-8, -8, 8, 8).contains(QPointF(e.pos())): self.timer.stop_timer()
        else: self.timer.open_timer()

def calc_evaluate(expr, degrees=True):
    import ast, re
    text = expr.replace('×','*').replace('÷','/').replace('−','-').replace(',','.').replace('π','pi').replace('^','**')
    text = text.replace('√','sqrt').replace('²','**2')
    text = re.sub(r'(\d+(?:\.\d+)?|\))\s*%', r'(\1/100)', text)
    # postfix factorial: number! or (...)!  ->  fact(...)
    while '!' in text:
        i = text.index('!'); j = i-1
        if j >= 0 and text[j] == ')':
            depth = 0
            while j >= 0:
                depth += text[j] == ')'; depth -= text[j] == '('
                if depth == 0: break
                j -= 1
        else:
            while j >= 0 and (text[j].isdigit() or text[j] == '.'): j -= 1
            j += 1
        if j < 0 or j >= i: raise ValueError('Hata')
        text = text[:j]+'fact('+text[j:i]+')'+text[i+1:]
    text = re.sub(r'(\d|\))\s*(?=\(|pi|e\b|sqrt|sin|cos|tan|ln|log|fact)', r'\1*', text)   # 2π, 3(4), 2sin(30)
    trig = (lambda f: (lambda x: f(math.radians(x)))) if degrees else (lambda f: f)
    def tan(x):
        a = math.radians(x) if degrees else x
        if abs(math.cos(a)) < 1e-12: raise ZeroDivisionError
        return math.tan(a)
    def fact(x):
        if x != int(x) or x < 0 or x > 170: raise ValueError('Hata')
        return float(math.factorial(int(x)))
    funcs = dict(sin=trig(math.sin), cos=trig(math.cos), tan=tan, ln=math.log, log=math.log10, sqrt=math.sqrt, fact=fact)
    names = dict(pi=math.pi, e=math.e)
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return float(n.value)
        if isinstance(n, ast.Name) and n.id in names: return names[n.id]
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            v = ev(n.operand); return v if isinstance(n.op, ast.UAdd) else -v
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add): return a+b
            if isinstance(n.op, ast.Sub): return a-b
            if isinstance(n.op, ast.Mult): return a*b
            if isinstance(n.op, ast.Div): return a/b
            if isinstance(n.op, ast.Pow):
                if abs(b) > 1000 or (abs(a) > 1 and abs(b*math.log10(abs(a))) > 300): raise OverflowError
                return a**b
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in funcs and len(n.args) == 1 and not n.keywords:
            return funcs[n.func.id](ev(n.args[0]))
        raise ValueError('Hata')
    value = ev(ast.parse(text, mode='eval'))
    if isinstance(value, complex) or math.isnan(value) or math.isinf(value): raise ValueError('Hata')
    return value

def calc_format(v):
    if abs(v) < 1e-12: v = 0.0
    if v == int(v) and abs(v) < 1e15: return '{:,}'.format(int(v)).replace(',', '.')
    s = ('%.12g' % v)
    if 'e' in s: m, ex = s.split('e'); return m.replace('.', ',')+' × 10^'+str(int(ex))
    return s.replace('.', ',')

class CalculatorPanel(QWidget):
    KEYS = [['sin','cos','tan','ln','log'],
            ['√','x²','xʸ','(',')'],
            ['π','e','n!','1/x','%'],
            ['7','8','9','÷','AC'],
            ['4','5','6','×','⌫'],
            ['1','2','3','−','Ans'],
            ['0',',','±','+','=']]
    def __init__(self, main):
        super().__init__(None, Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.main = main; self.expr = ''; self.result = ''; self.ans = 0.0; self.degrees = True; self.drag_from = None; self.just_evaluated = False
        self.setWindowTitle('Hesap makinesi • '+APP_NAME); self.setWindowIcon(QIcon(LOGO))
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet('''QWidget#calc{background:#0b1426;border:1px solid #2a3b57;border-radius:18px;}
            QLabel{color:#e8eefc;font-family:"DejaVu Sans";background:transparent;}
            QPushButton{font-family:"DejaVu Sans";font-size:22px;color:#e8eefc;background:#16233a;border:1px solid #24344f;border-radius:14px;}
            QPushButton:pressed{background:#24395c;}
            QPushButton#fn{font-size:19px;color:#a5c8ff;background:#111d31;}
            QPushButton#op{font-size:26px;color:#7dd3fc;background:#132a46;}
            QPushButton#eq{font-size:28px;font-weight:bold;background:#3b82f6;border:none;color:white;}
            QPushButton#ac{color:#fda4af;background:#2a1724;border:1px solid #4a2236;}
            QPushButton#mode{font-size:16px;border-radius:16px;padding:0 14px;}
            QPushButton#close{font-size:17px;border-radius:18px;padding:0 16px;color:#fecdd3;background:rgba(251,113,133,.16);border:1px solid rgba(251,113,133,.6);}''')
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0)
        panel = QWidget(); panel.setObjectName('calc'); outer.addWidget(panel)
        layout = QVBoxLayout(panel); layout.setContentsMargins(16,12,16,16); layout.setSpacing(10)
        bar = QHBoxLayout(); layout.addLayout(bar)
        title = QLabel('⋮⋮  Hesap makinesi'); title.setStyleSheet('font-size:17px;font-weight:bold;color:#9fb3d1;'); bar.addWidget(title, 1)
        self.mode = QPushButton('DEG'); self.mode.setObjectName('mode'); self.mode.setFixedHeight(36); self.mode.setToolTip('Derece / Radyan')
        self.mode.clicked.connect(self.toggle_mode); bar.addWidget(self.mode)
        close = QPushButton('✕  Kapat'); close.setObjectName('close'); close.setFixedHeight(40); close.clicked.connect(self.hide); bar.addWidget(close)
        screen = QWidget(); screen.setStyleSheet('background:#060c18;border-radius:14px;'); sl = QVBoxLayout(screen); sl.setContentsMargins(16,10,16,10); sl.setSpacing(2)
        self.expr_label = QLabel(''); self.expr_label.setAlignment(Qt.AlignRight|Qt.AlignVCenter); self.expr_label.setStyleSheet('font-size:20px;color:#8aa0c2;'); self.expr_label.setMinimumHeight(30)
        self.main_label = QLabel('0'); self.main_label.setAlignment(Qt.AlignRight|Qt.AlignVCenter); self.main_label.setStyleSheet('font-size:46px;color:#f4f7ff;'); self.main_label.setMinimumHeight(64)
        sl.addWidget(self.expr_label); sl.addWidget(self.main_label); layout.addWidget(screen)
        grid = QGridLayout(); grid.setSpacing(8); layout.addLayout(grid)
        for r, row in enumerate(self.KEYS):
            for c, key in enumerate(row):
                b = QPushButton(key); b.setFixedSize(84, 62); b.setFocusPolicy(Qt.NoFocus)
                b.setObjectName('eq' if key == '=' else 'ac' if key in ('AC','⌫') else 'op' if key in ('÷','×','−','+') else 'fn' if r < 3 or key == 'Ans' else '')
                b.clicked.connect(lambda checked=False, k=key: self.press(k)); grid.addWidget(b, r, c)
        self.adjustSize()
    def toggle_mode(self):
        self.degrees = not self.degrees; self.mode.setText('DEG' if self.degrees else 'RAD'); self.preview()
    def press(self, k):
        if k == 'AC': self.expr = ''; self.result = ''; self.just_evaluated = False; self.refresh(); return
        if k == '⌫':
            for token in ('sin(','cos(','tan(','ln(','log(','√('):
                if self.expr.endswith(token): self.expr = self.expr[:-len(token)]; break
            else: self.expr = self.expr[:-1]
            self.just_evaluated = False; self.refresh(); return
        if k == '=':
            if not self.expr: return
            try:
                v = calc_evaluate(self.expr, self.degrees); self.ans = v
                self.result = self.expr; self.expr = calc_format(v).replace('.', '') if ' × 10^' not in calc_format(v) else repr(v).replace('.', ',')
                self.just_evaluated = True
            except ZeroDivisionError: self.result = self.expr; self.expr = ''; self.main_label.setText('Tanımsız'); self.expr_label.setText(self.result+' ='); return
            except Exception: self.result = self.expr; self.expr = ''; self.main_label.setText('Hata'); self.expr_label.setText(self.result+' ='); return
            self.expr_label.setText(self.result+' ='); self.main_label.setText(calc_format(self.ans)); return
        operator = k in ('÷','×','−','+','xʸ','x²','n!','%')
        if self.just_evaluated and not operator: self.expr = ''
        self.just_evaluated = False
        insert = {'sin':'sin(','cos':'cos(','tan':'tan(','ln':'ln(','log':'log(','√':'√(','x²':'²','xʸ':'^','n!':'!','Ans':'Ans'}.get(k, k)
        if k == 'Ans': insert = calc_format(self.ans).replace('.', '') if ' × 10^' not in calc_format(self.ans) else repr(self.ans).replace('.', ',')
        if k == '1/x': self.expr = '1÷(' + (self.expr or '0') + ')'; self.refresh(); return
        if k == '±': self.expr = '−(' + self.expr + ')' if self.expr else '−'; self.refresh(); return
        self.expr += insert; self.refresh()
    def preview(self):
        try: return calc_format(calc_evaluate(self.expr, self.degrees))
        except Exception: return ''
    def refresh(self):
        self.main_label.setText(self.expr or '0')
        p = self.preview() if self.expr else ''
        self.expr_label.setText(('= '+p) if p and p != self.expr else '')
        f = self.main_label.font(); f.setPixelSize(46 if len(self.expr) < 15 else max(22, int(46*15/len(self.expr)))); self.main_label.setFont(f)
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton: self.drag_from = e.globalPos()-self.frameGeometry().topLeft()
    def mouseMoveEvent(self, e):
        if self.drag_from is not None: self.move(e.globalPos()-self.drag_from)
    def mouseReleaseEvent(self, e): self.drag_from = None
    def open_calc(self):
        screen = self.main.windowHandle().screen() if self.main.windowHandle() else QApplication.primaryScreen()
        g = screen.availableGeometry(); self.adjustSize()
        if not self.isVisible(): self.move(g.right()-self.width()-40, g.top()+120)
        self.show(); self.raise_(); self.activateWindow()
# ---------------------------------------------------------------------------
# Themes: colours + a subtle subject pattern around the page.
THEMES = {
    'default':  dict(name='Ümraniye Merkez Anadolu Lisesi', bg='#122034', btn='#22344c', btn2='#1b2b41', border='#364a63', hover='#304b68', sel='#bb1826', sel2='#d42335', selb='#e23b4d', view='#091423', ink='#3d5a80'),
    'turkiye':  dict(name='Türkiye',    bg='#1d0a0d', btn='#4a141b', btn2='#38101a', border='#7a2330', hover='#5e1a24', sel='#e30a17', sel2='#ff2a36', selb='#ffffff', view='#140507', ink='#e30a17'),
    'matematik':dict(name='Matematik',  bg='#10173a', btn='#222d66', btn2='#1a2352', border='#3a4a96', hover='#2c3a80', sel='#5b5bf0', sel2='#7c7cff', selb='#c7d2fe', view='#0a0f29', ink='#6d7cff'),
    'kimya':    dict(name='Kimya',      bg='#082425', btn='#10403f', btn2='#0c3231', border='#1d6966', hover='#145250', sel='#0d9488', sel2='#14b8a6', selb='#99f6e4', view='#051a1b', ink='#2dd4bf'),
    'cografya': dict(name='Coğrafya',   bg='#1a2214', btn='#33421f', btn2='#283418', border='#5a6e35', hover='#3f5226', sel='#b7791f', sel2='#d69e2e', selb='#fde68a', view='#11180c', ink='#a3b86c'),
    'fizik':    dict(name='Fizik',      bg='#140d2b', btn='#2a1c55', btn2='#211646', border='#4b3590', hover='#35246b', sel='#7c3aed', sel2='#9f67ff', selb='#ddd6fe', view='#0d081f', ink='#a78bfa'),
    'biyoloji': dict(name='Biyoloji',   bg='#0b2015', btn='#14402a', btn2='#103321', border='#23683f', hover='#1a5233', sel='#16a34a', sel2='#22c55e', selb='#bbf7d0', view='#06150d', ink='#4ade80'),
    'resim':    dict(name='Resim',      bg='#21141c', btn='#43263a', btn2='#351d2e', border='#74435f', hover='#56304a', sel='#d9482b', sel2='#f26b3f', selb='#ffd8a8', view='#170c13', ink='#f2a07b'),
}
THEME_ORDER = ['default','turkiye','matematik','kimya','cografya','fizik','biyoloji','resim']

def rgba(hexcol, a):
    c = QColor(hexcol); return 'rgba(%d,%d,%d,%.2f)' % (c.red(), c.green(), c.blue(), a)

def theme_style(t, tile):
    """Gece iskeleti (her temada aynı): cam görünümlü düğmeler, hap biçiminde sekmeler,
    yuvarlak köşeler; tema yalnızca rengi verir."""
    d = dict(t, glass='rgba(255,255,255,0.055)', glassb='rgba(255,255,255,0.11)', hover='rgba(255,255,255,0.10)',
             on=rgba(t['sel'], .34), onb=t['sel2'], font=(ui_fonts().get('Poppins-Regular') or 'DejaVu Sans'))
    return """QMainWindow,QWidget{background:%(bg)s;color:#eef3ff;font-family:"%(font)s","DejaVu Sans";font-size:15px;}
        QPushButton{background:%(glass)s;border:1px solid %(glassb)s;border-radius:12px;padding:8px 12px;min-height:24px;color:#eef3ff;}
        QPushButton:hover{background:%(hover)s;}
        QPushButton:pressed{background:rgba(255,255,255,0.14);}
        QPushButton:checked{background:%(on)s;border:2px solid %(onb)s;}
        QPushButton:disabled{color:rgba(238,243,255,0.35);}
        QPushButton#primary{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %(sel2)s,stop:1 %(sel)s);color:white;font-weight:600;border:1px solid rgba(255,255,255,0.22);}
        QScrollArea{background:%(view)s;border:none;border-radius:14px;}
        QScrollArea#tabs,QScrollArea#tabs > QWidget#qt_scrollarea_viewport{background:transparent;}
        QPushButton#tab{padding:6px 14px;border-radius:16px;border-top-right-radius:0;border-bottom-right-radius:0;border-right:none;}
        QPushButton#tabclose{padding:0;border-radius:16px;border-top-left-radius:0;border-bottom-left-radius:0;font-size:18px;}
        QPushButton#tab:checked,QPushButton#tabclose:checked{background:%(on)s;border:2px solid %(onb)s;}
        QPushButton#tab:checked{border-right:none;}
        QSpinBox,QLineEdit{padding:8px 10px;background:%(glass)s;border:1px solid %(glassb)s;border-radius:10px;}
        QLineEdit:focus{border:2px solid %(onb)s;}
        QComboBox{background:%(glass)s;border:1px solid %(glassb)s;border-radius:10px;padding:6px 10px;}
        QMenu{background:%(bg)s;border:1px solid %(glassb)s;border-radius:12px;padding:6px;}
        QMenu::item{border-radius:8px;} QMenu::item:selected{background:%(on)s;}
        QScrollBar:vertical{background:transparent;width:12px;margin:2px;} QScrollBar::handle:vertical{background:rgba(255,255,255,0.18);border-radius:5px;min-height:40px;}
        QScrollBar:horizontal{background:transparent;height:12px;margin:2px;} QScrollBar::handle:horizontal{background:rgba(255,255,255,0.18);border-radius:5px;min-width:40px;}
        QScrollBar::add-line,QScrollBar::sub-line{width:0;height:0;} QScrollBar::add-page,QScrollBar::sub-page{background:transparent;}
        QCheckBox{spacing:10px;background:transparent;}
        QCheckBox::indicator{width:22px;height:22px;border-radius:7px;border:1.5px solid rgba(255,255,255,0.40);background:rgba(255,255,255,0.06);}
        QCheckBox::indicator:checked{background:%(sel2)s;border:1.5px solid %(sel2)s;}
        QLabel{padding:2px;background:transparent;}""" % d

class PageScroll(QScrollArea):
    """Sayfanın arkası: konu deseni, tema renginde yumuşak ışık ve sayfanın gölgesi.
    Yalnızca sayfanın çevresi açıldığında çizilir; kalem yazarken çalışmaz."""
    def __init__(self):
        super().__init__(); self.tile = None; self.view = QColor('#091423'); self.accent = QColor('#bb1826')
        for bar in (self.horizontalScrollBar(), self.verticalScrollBar()): bar.valueChanged.connect(lambda _v: self.viewport().update())
    def set_theme(self, view, accent, tile_path):
        self.view = QColor(view); self.accent = QColor(accent)
        self.tile = QPixmap(tile_path) if tile_path and os.path.isfile(tile_path) else None
        self.bg = None; self.viewport().update()
    def background(self, size):
        """Desen + ışık bir kez hazır görüntüye çizilir (kaydırırken yalnızca kopyalanır)."""
        if getattr(self, 'bg', None) is not None and self.bg.size() == size: return self.bg
        from PyQt5.QtGui import QRadialGradient
        bg = QPixmap(size); bg.fill(self.view); p = QPainter(bg); r = QRect(QPoint(0, 0), size)
        if self.tile is not None and not self.tile.isNull(): p.drawTiledPixmap(r, self.tile)
        glow = QRadialGradient(QPointF(r.center()), max(r.width(), r.height())*.62)
        a = QColor(self.accent); a.setAlpha(80); glow.setColorAt(0, a); a2 = QColor(self.accent); a2.setAlpha(26); glow.setColorAt(.5, a2); glow.setColorAt(1, QColor(0, 0, 0, 0))
        p.fillRect(r, glow); p.end(); self.bg = bg; return bg
    def shadow(self, w, h):
        """Sayfa gölgesi: köşe/kenar parçaları bir kez çizilir (dokuz parça), her boyuta uyar."""
        if getattr(self, 'sh', None) is None:
            S = 40; img = QPixmap(3*S, 3*S); img.fill(Qt.transparent); p = QPainter(img); p.setRenderHint(QPainter.Antialiasing); p.setPen(Qt.NoPen)
            g = QRectF(S, S, S, S)
            for k in range(16, 0, -1): p.setBrush(QColor(0, 0, 0, int(4 + (16-k)*1.5))); p.drawRoundedRect(g.adjusted(-k, -k*.5, k, k*1.4), k, k)
            p.end(); self.sh = img
        return self.sh
    def paintEvent(self, e):
        vp = self.viewport(); p = QPainter(vp); er = e.rect()
        bg = self.background(vp.size()); p.drawPixmap(er, bg, er)
        b = self.widget()
        if b is not None and b.isVisible():   # yumuşak gölge: sayfa zeminden yükselmiş gibi
            g = b.geometry(); S = 40; sh = self.shadow(g.width(), g.height())
            x0, y0, x1, y1 = g.left()-S, g.top()-S, g.right()+1, g.bottom()+1
            parts = [(QRect(x0, y0, S, S), QRect(0, 0, S, S)), (QRect(x1, y0, S, S), QRect(2*S, 0, S, S)), (QRect(x0, y1, S, S), QRect(0, 2*S, S, S)), (QRect(x1, y1, S, S), QRect(2*S, 2*S, S, S)),
                     (QRect(g.left(), y0, g.width(), S), QRect(S, 0, S, S)), (QRect(g.left(), y1, g.width(), S), QRect(S, 2*S, S, S)),
                     (QRect(x0, g.top(), S, g.height()), QRect(0, S, S, S)), (QRect(x1, g.top(), S, g.height()), QRect(2*S, S, S, S))]
            for dst, src in parts:
                if dst.intersects(er): p.drawPixmap(dst, sh, src)

def make_theme_tile(key, path):
    """Seamless 480×480 pattern of faint subject motifs (drawn, no image files)."""
    import random
    from PyQt5.QtGui import QFont, QPainterPath, QTransform
    t = THEMES[key]; size = 480
    img = QImage(size, size, QImage.Format_RGB32); img.fill(QColor(t['view']))
    p = QPainter(img); p.setRenderHint(QPainter.Antialiasing); rnd = random.Random(key)
    ink = QColor(t['ink'])
    soft = 1.8 if key == 'default' else 1.0   # konu desenleri soluk: sayfayla yarışmasın
    def col(a): c = QColor(ink); c.setAlpha(min(255, int(a*soft))); return c
    def pen(a, w=2): p.setPen(QPen(col(a), w, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.setBrush(Qt.NoBrush)
    def text(s, x, y, px, a, serif=False, rot=0):
        f = QFont('DejaVu Serif' if serif else 'DejaVu Sans'); f.setPixelSize(px); f.setBold(not serif)
        p.save(); p.translate(x, y); p.rotate(rot); p.setFont(f); p.setPen(col(a)); p.drawText(QRectF(-200, -px, 400, px*2), Qt.AlignCenter, s); p.restore()
    def around(fn):   # draw at offsets so the tile repeats seamlessly
        for dx in (-size, 0, size):
            for dy in (-size, 0, size):
                p.save(); p.translate(dx, dy); fn(); p.restore()
    if key == 'default':
        def f():
            pen(22, 1)
            for i in range(0, size, 24): p.drawLine(i, 0, i, size); p.drawLine(0, i, size, i)
        around(f)
    elif key == 'turkiye':
        def crescent(cx, cy, r, a, rot):
            p.save(); p.translate(cx, cy); p.rotate(rot)
            outer = QPainterPath(); outer.addEllipse(QPointF(0, 0), r, r)
            inner = QPainterPath(); inner.addEllipse(QPointF(r*.25, 0), r*.8, r*.8)
            p.setPen(Qt.NoPen); p.setBrush(col(a)); p.drawPath(outer.subtracted(inner))
            star = QPolygonF([QPointF(r*.95+math.cos(math.radians(-90+i*36))*(r*.38 if i % 2 == 0 else r*.15),
                                      math.sin(math.radians(-90+i*36))*(r*.38 if i % 2 == 0 else r*.15)) for i in range(10)])
            p.drawPolygon(star); p.restore()
        def f():
            crescent(120, 120, 46, 70, -8); crescent(360, 330, 34, 52, 10); crescent(380, 90, 20, 40, 0); crescent(110, 380, 24, 44, -14)
            pen(30, 1.5)
            for k in range(3): p.drawArc(QRectF(-80+k*40, 200+k*14, 640, 240), 20*16, 140*16)
        around(f)
    elif key == 'matematik':
        def f():
            pen(26, 1)
            for i in range(0, size, 40): p.drawLine(i, 0, i, size); p.drawLine(0, i, size, i)
            pen(60, 2.5); path = QPainterPath(QPointF(40, 120))
            for x in range(40, 260, 4): path.lineTo(x, 120-((x-150)/40.0)**2*-6-60)
            p.drawPath(path)
            p.drawPolygon(QPolygonF([QPointF(300, 420), QPointF(440, 420), QPointF(300, 300)]))
            for s, x, y, px, a, r in [('π',380,90,64,70,-8),('∑',90,300,58,60,6),('√x',250,250,40,62,0),('∫',420,230,70,55,10),
                                       ('∞',170,430,44,55,0),('x²+y²=r²',230,40,22,60,0),('Δ',60,200,40,55,-6),('θ',340,190,36,55,4),('f(x)',140,190,26,55,0)]:
                text(s, x, y, px, a, True, r)
        around(f)
    elif key == 'kimya':
        def hexagon(cx, cy, r, a):
            pen(a, 2.5); p.drawPolygon(QPolygonF([QPointF(cx+r*math.cos(math.radians(30+60*i)), cy+r*math.sin(math.radians(30+60*i))) for i in range(6)]))
            p.drawEllipse(QPointF(cx, cy), r*.55, r*.55)
        def f():
            hexagon(110, 110, 52, 70); hexagon(110+90, 110+52, 52, 50); hexagon(380, 360, 40, 55)
            pen(60, 2.5); flask = QPainterPath(QPointF(330, 60)); flask.lineTo(330, 120); flask.lineTo(290, 200); flask.lineTo(410, 200); flask.lineTo(370, 120); flask.lineTo(370, 60)
            p.drawPath(flask); p.drawLine(QPointF(320, 60), QPointF(380, 60)); p.drawLine(QPointF(300, 180), QPointF(400, 180))
            for r in (0, 60, 120):
                p.save(); p.translate(120, 360); p.rotate(r); p.drawEllipse(QPointF(0, 0), 58, 20); p.restore()
            p.setBrush(col(70)); p.drawEllipse(QPointF(120, 360), 7, 7)
            for s, x, y, px, a in [('H₂O',260,300,30,65),('CO₂',420,250,26,55),('NaCl',250,440,26,55),('pH',40,260,30,60)]:
                text(s, x, y, px, a)
        around(f)
    elif key == 'cografya':
        def f():
            pen(40, 1.6)
            for k in range(6): p.drawEllipse(QPointF(130, 330), 30+k*22, 18+k*15)
            for k in range(4): p.drawEllipse(QPointF(380, 120), 20+k*20, 14+k*13)
            pen(28, 1)
            for y in range(40, size, 80):
                path = QPainterPath(QPointF(0, y))
                for x in range(0, size+1, 10): path.lineTo(x, y+math.sin(x/76.4)*8)
                p.drawPath(path)
            cx, cy = 360, 360; p.setPen(Qt.NoPen); p.setBrush(col(60))
            p.drawPolygon(QPolygonF([QPointF(cx+math.cos(math.radians(-90+i*45))*(52 if i % 2 == 0 else 14), cy+math.sin(math.radians(-90+i*45))*(52 if i % 2 == 0 else 14)) for i in range(8)]))
            text('K', cx, cy-72, 24, 80)
            p.setBrush(col(45)); p.drawPolygon(QPolygonF([QPointF(30, 170), QPointF(80, 90), QPointF(130, 170)])); p.drawPolygon(QPolygonF([QPointF(95, 170), QPointF(135, 110), QPointF(180, 170)]))
        around(f)
    elif key == 'fizik':
        def f():
            for r in (0, 60, 120):
                pen(55, 2); p.save(); p.translate(120, 130); p.rotate(r); p.drawEllipse(QPointF(0, 0), 70, 24); p.restore()
            p.setPen(Qt.NoPen); p.setBrush(col(80)); p.drawEllipse(QPointF(120, 130), 9, 9)
            pen(55, 2.5); path = QPainterPath(QPointF(220, 320))
            for x in range(220, 470, 3): path.lineTo(x, 320+math.sin((x-220)/20.0)*26)
            p.drawPath(path)
            pen(45, 2); p.drawEllipse(QPointF(70, 380), 14, 60); p.drawLine(QPointF(0, 380), QPointF(160, 380))
            for s, x, y, px, a, r in [('E = mc²',350,90,34,70,0),('F = m·a',300,200,28,60,-4),('λ',420,420,50,60,0),('Ω',240,430,40,50,0),('ħ',30,250,40,55,0),('v = λ·f',170,270,22,55,0)]:
                text(s, x, y, px, a, True, r)
        around(f)
    elif key == 'biyoloji':
        def f():
            for phase in (0, math.pi):
                pen(70, 3); path = QPainterPath()
                for i, y in enumerate(range(0, size+1, 4)):
                    x = 90+math.sin(y/30.0+phase)*36
                    path.moveTo(x, y) if i == 0 else path.lineTo(x, y)
                p.drawPath(path)
            pen(40, 2)
            for y in range(0, size, 16):
                p.drawLine(QPointF(90+math.sin(y/30.0)*36, y), QPointF(90+math.sin(y/30.0+math.pi)*36, y))
            pen(60, 2.5); leaf = QPainterPath(QPointF(300, 160)); leaf.cubicTo(330, 60, 430, 60, 440, 40); leaf.cubicTo(430, 140, 360, 190, 300, 160)
            p.drawPath(leaf); p.drawLine(QPointF(300, 160), QPointF(420, 60))
            p.drawEllipse(QPointF(330, 350), 80, 60); p.setBrush(col(45)); p.drawEllipse(QPointF(350, 340), 24, 20)
            p.setBrush(Qt.NoBrush); p.drawEllipse(QPointF(290, 370), 16, 8)
            for s, x, y, px, a in [('DNA',200,250,28,60),('ATP',220,440,24,50),('H₂O + CO₂',420,250,18,45)]:
                text(s, x, y, px, a)
        around(f)
    elif key == 'resim':
        paints = ('#e04f3a', '#f2b33d', '#3f7fd9', '#3fae6a', '#b05cc9', '#f2f2f2')
        def blob(cx, cy, r, c, a):
            q = QColor(c); q.setAlpha(a); p.setPen(Qt.NoPen); p.setBrush(q); p.drawEllipse(QPointF(cx, cy), r, r*.86)
        def f():
            # Palet: thumb hole and notch, with paint blobs
            pal = QPainterPath(); pal.addEllipse(QPointF(130, 130), 92, 66)
            hole = QPainterPath(); hole.addEllipse(QPointF(92, 158), 13, 11); notch = QPainterPath(); notch.addEllipse(QPointF(46, 168), 24, 18)
            pen(70, 2.6); p.drawPath(pal.subtracted(hole).subtracted(notch))
            for (x, y), c in zip([(110, 95), (150, 88), (188, 108), (196, 148), (160, 176), (128, 128)], paints): blob(x, y, 12, c, 95)
            # Fırça and its stroke
            p.save(); p.translate(380, 120); p.rotate(-38)
            pen(70, 7); p.drawLine(QPointF(0, -95), QPointF(0, 10))
            pen(70, 2.4); p.drawRect(QRectF(-6, 10, 12, 22))
            tip = QPainterPath(QPointF(-6, 32)); tip.cubicTo(-10, 54, -2, 70, 0, 78); tip.cubicTo(2, 70, 10, 54, 6, 32)
            q = QColor(paints[0]); q.setAlpha(120); p.setBrush(q); p.drawPath(tip); p.restore()
            stroke = QPainterPath(QPointF(250, 250)); stroke.cubicTo(300, 205, 360, 290, 420, 235); stroke.cubicTo(445, 215, 465, 230, 470, 250)
            q = QColor(paints[0]); q.setAlpha(70); p.setPen(QPen(q, 12, Qt.SolidLine, Qt.RoundCap)); p.setBrush(Qt.NoBrush); p.drawPath(stroke)
            # Renk çemberi
            for i, c in enumerate(paints[:5] + ('#f27b3a',)):
                q = QColor(c); q.setAlpha(85); p.setPen(Qt.NoPen); p.setBrush(q)
                p.drawPie(QRectF(320, 315, 110, 110), (90+i*60)*16, 60*16)
            p.setBrush(QColor(t['view'])); p.drawEllipse(QPointF(375, 370), 20, 20)
            # Kurşun kalem
            p.save(); p.translate(70, 400); p.rotate(-30); pen(60, 2.4)
            p.drawPolygon(QPolygonF([QPointF(0, -8), QPointF(120, -8), QPointF(120, 8), QPointF(0, 8)]))
            p.drawPolygon(QPolygonF([QPointF(120, -8), QPointF(146, 0), QPointF(120, 8)])); p.drawLine(QPointF(20, -8), QPointF(20, 8)); p.restore()
            # Çerçeve içinde küçük manzara
            pen(55, 2.4); p.drawRect(QRectF(200, 330, 104, 78)); pen(40, 1.6); p.drawRect(QRectF(208, 338, 88, 62))
            pen(55, 2); p.drawPolyline(QPolygonF([QPointF(210, 396), QPointF(236, 362), QPointF(254, 380), QPointF(272, 354), QPointF(294, 396)]))
            blob(282, 352, 7, paints[1], 110)
            # Boya damlaları
            for (x, y, r), c in zip([(250, 60, 6), (300, 150, 4), (40, 260, 7), (460, 420, 5), (180, 280, 4), (440, 40, 3)], paints*2): blob(x, y, r, c, 80)
        around(f)
    p.end(); img.save(path); return path

# --- Ders zaman çizelgesi (Ümraniye Merkez Anadolu Lisesi, 2026-2027) ---
_LESSONS = [('1. Ders','08:00','08:40'),('2. Ders','08:50','09:30'),('3. Ders','09:40','10:20'),
            ('4. Ders','10:30','11:10'),('5. Ders','11:20','12:00')]
BELL_DAYS = {   # weekday() -> periods; gaps between them are teneffüs
    'normal': [('Derse hazırlık','07:30','08:00')]+_LESSONS+[('Öğle arası','12:00','12:30'),('6. Ders','12:30','13:10'),
               ('7. Ders','13:20','14:00'),('8. Ders','14:10','14:50'),('DYK 1. Ders','15:00','15:40'),('DYK 2. Ders','15:50','16:30')],
    # Cuma: öğle arası (yine 30 dk) 6. dersten sonra; 7. dersten itibaren saatler aynı
    'cuma':   [('Derse hazırlık','07:30','08:00')]+_LESSONS+[('6. Ders','12:10','12:50'),('Öğle arası','12:50','13:20'),
               ('7. Ders','13:20','14:00'),('8. Ders','14:10','14:50'),('DYK 1. Ders','15:00','15:40'),('DYK 2. Ders','15:50','16:30')]}
TR_DAYS = ['Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi','Pazar']
TR_MONTHS = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık']

def bell_periods(weekday):
    """[(name, start_s, end_s, kind)] with teneffüs filling the gaps; seconds of day."""
    if weekday >= 5: return []
    sec = lambda t: int(t[:2])*3600+int(t[3:])*60
    out = []
    for name, a, b in BELL_DAYS['cuma' if weekday == 4 else 'normal']:
        a, b = sec(a), sec(b)
        if out and a > out[-1][2]: out.append(('Teneffüs', out[-1][2], a, 'break'))
        kind = 'break' if name == 'Öğle arası' else ('prep' if name == 'Derse hazırlık' else 'lesson')
        out.append((name, a, b, kind))
    return out

def bell_state(now):
    """What the corner clock shows at datetime `now`."""
    t = now.hour*3600+now.minute*60+now.second
    periods = bell_periods(now.weekday())
    st = dict(kind='off', tag='', span='', left=None, frac=0, next='')
    hm = lambda x: '%02d.%02d' % (x//3600, x%3600//60)
    if not periods:
        st.update(tag='HAFTA SONU'); return st
    if t < periods[0][1]:
        st.update(kind='before', tag='GÜNAYDIN', left=periods[0][1]-t, next='Derse hazırlık %s' % hm(periods[0][1])); return st
    if t >= periods[-1][2]:
        st.update(tag='OKUL BİTTİ'); return st
    for i, (name, a, b, kind) in enumerate(periods):
        if a <= t < b:
            nxt = periods[i+1] if i+1 < len(periods) else None
            st.update(kind=kind, tag=name.replace('i','İ').upper(), span='%s – %s' % (hm(a), hm(b)), left=b-t, frac=(t-a)/(b-a),
                      next=('Sonra: %s %s – %s' % (nxt[0], hm(nxt[1]), hm(nxt[2]))) if nxt else 'Sonra: okul bitiyor')
            return st
    return st

class Curtain(QWidget):
    """Perde: covers the solution; drag the handle to reveal it step by step.
    Screen-only (never saved). Below the line by default; ⇅ flips it to cover the top."""
    GRIP = 46
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.ratio = .45; self.top_side = False
        self.drag = None; self.vp = QRect(); self.setCursor(Qt.SizeVerCursor)
    def fit(self, vp):
        self.vp = QRect(vp); line = int(vp.height()*self.ratio)
        if self.top_side: self.setGeometry(vp.x(), vp.y(), vp.width(), max(self.GRIP, line))
        else: self.setGeometry(vp.x(), vp.y()+min(line, vp.height()-self.GRIP), vp.width(), max(self.GRIP, vp.height()-line))
    def strip(self):   # the handle strip faces the open part
        return QRectF(0, self.height()-self.GRIP, self.width(), self.GRIP) if self.top_side else QRectF(0, 0, self.width(), self.GRIP)
    def buttons(self):
        s = self.strip(); y = s.center().y()
        return QRectF(self.width()-58, y-19, 38, 38), QRectF(self.width()-106, y-19, 38, 38)   # ×, ⇅
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(11, 22, 38))   # opaque: nothing of the answer shows through
        p.setPen(QPen(QColor(255, 255, 255, 14), 1))
        for y in range(0, self.height(), 18): p.drawLine(0, y, self.width(), y)   # cloth folds
        s = self.strip(); p.fillRect(s, QColor('#1d3150'))
        edge = s.top() if not self.top_side else s.bottom()-1
        p.setPen(QPen(QColor('#ffc526'), 3)); p.drawLine(QPointF(0, edge), QPointF(self.width(), edge))
        grip = QRectF(s.center().x()-90, s.center().y()-15, 180, 30)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#ffc526')); p.drawRoundedRect(grip, 15, 15)
        p.setPen(QColor('#122034')); p.setFont(BellClock.font(15, True))
        p.drawText(grip, Qt.AlignCenter, ('▲ Perdeyi çek' if self.top_side else '▼ Perdeyi çek'))
        x, flip = self.buttons()
        for r, t in ((x, '×'), (flip, '⇅')):
            p.setPen(Qt.NoPen); p.setBrush(QColor('#30496d')); p.drawEllipse(r)
            p.setPen(Qt.white); p.setFont(BellClock.font(22, True)); p.drawText(r, Qt.AlignCenter, t)
        p.end()
    def mousePressEvent(self, e):
        x, flip = self.buttons(); pos = QPointF(e.pos())
        if x.adjusted(-6, -6, 6, 6).contains(pos): self.main.toggle_curtain(False); return
        if flip.adjusted(-6, -6, 6, 6).contains(pos):
            self.top_side = not self.top_side; self.ratio = 1-self.ratio; self.fit(self.vp); self.update(); return
        self.drag = e.globalPos().y()
    def mouseMoveEvent(self, e):
        if self.drag is None or not self.vp.height(): return
        dy = e.globalPos().y()-self.drag; self.drag = e.globalPos().y()
        self.ratio = max(.0, min(1.0, self.ratio + dy/self.vp.height())); self.fit(self.vp); self.update()
    def mouseReleaseEvent(self, e):
        self.drag = None
        if (not self.top_side and self.ratio >= .97) or (self.top_side and self.ratio <= .03): self.main.toggle_curtain(False)   # pulled all the way: gone

class Spotlight(QWidget):
    """Spot ışığı: the board darkens; the framed part stays lit. The lit part is
    left out of this widget's mask, so the pen keeps writing there."""
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.hole = None; self.round = False
        self.mode = None; self.start = None; self.corner = None
    def fit(self, vp):
        self.setGeometry(vp); self.remask()
    def remask(self):
        if self.hole is None or self.hole.width() < 4: self.clearMask(); return
        h = self.hole.toAlignedRect().adjusted(2, 2, -2, -2)
        self.setMask(QRegion(self.rect()).subtracted(QRegion(h, QRegion.Ellipse if self.round else QRegion.Rectangle)))
    def corners(self):
        h = self.hole; return [h.topLeft(), h.topRight(), h.bottomLeft(), h.bottomRight()]
    def controls(self):
        h = self.hole; y = h.top()-46 if h.top() > 56 else h.bottom()+8
        return QRectF(h.center().x()-55, y, 110, 38), QRectF(h.right()-38, y, 38, 38), QRectF(h.right()-84, y, 38, 38)   # taşı, ×, şekil
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(3, 8, 18, 205))
        if self.hole is None:
            p.setPen(Qt.white); p.setFont(BellClock.font(22, True))
            p.drawText(self.rect(), Qt.AlignCenter, 'Aydınlık kalacak yeri kalemle çerçeveleyin'); return
        h = self.hole
        p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor(255, 225, 77, 200), 4))
        (p.drawEllipse if self.round else p.drawRect)(h.adjusted(-2, -2, 2, 2))
        if self.mode == 'draw': return
        p.setPen(Qt.NoPen); p.setBrush(QColor('#ffe14d'))
        for c in self.corners(): p.drawEllipse(c, 12, 12)
        move, x, shape = self.controls()
        p.setBrush(QColor('#ffe14d')); p.drawRoundedRect(move, 19, 19)
        p.setPen(QColor('#122034')); p.setFont(BellClock.font(16, True)); p.drawText(move, Qt.AlignCenter, '✥ Taşı')
        for r, t in ((x, '×'), (shape, '▢' if self.round else '◯')):
            p.setPen(Qt.NoPen); p.setBrush(QColor('#30496d')); p.drawEllipse(r)
            p.setPen(Qt.white); p.setFont(BellClock.font(20, True)); p.drawText(r, Qt.AlignCenter, t)
        p.end()
    def mousePressEvent(self, e):
        pos = QPointF(e.pos()); self.start = pos; self.corner = None
        if self.hole is not None:
            move, x, shape = self.controls()
            if x.adjusted(-6, -6, 6, 6).contains(pos): self.main.toggle_spot(False); return
            if shape.adjusted(-6, -6, 6, 6).contains(pos): self.round = not self.round; self.remask(); self.update(); return
            if move.adjusted(-6, -6, 6, 6).contains(pos): self.mode = 'move'; return
            for i, c in enumerate(self.corners()):
                if math.hypot(pos.x()-c.x(), pos.y()-c.y()) <= 30: self.mode = 'resize'; self.corner = i; return
        self.mode = 'draw'; self.hole = QRectF(pos, pos); self.remask(); self.update()   # frame a new lit part
    def mouseMoveEvent(self, e):
        pos = QPointF(e.pos())
        if self.mode == 'draw': self.hole = QRectF(self.start, pos).normalized(); self.remask()
        elif self.mode == 'move': d = pos-self.start; self.start = pos; self.hole.translate(d); self.remask()
        elif self.mode == 'resize':
            h = self.hole
            if self.corner in (0, 2): h.setLeft(min(pos.x(), h.right()-60))
            else: h.setRight(max(pos.x(), h.left()+60))
            if self.corner in (0, 1): h.setTop(min(pos.y(), h.bottom()-40))
            else: h.setBottom(max(pos.y(), h.top()+40))
            self.remask()
        else: return
        self.update()
    def mouseReleaseEvent(self, e):
        if self.mode == 'draw' and (self.hole.width() < 40 or self.hole.height() < 30): self.hole = None
        self.mode = None; self.remask(); self.update()

class PanelClock(QWidget):
    """Büyük saat ve tarih: sol panelin altındaki boşlukta."""
    def __init__(self, parent=None):
        super().__init__(parent); self.setMinimumHeight(110); self.now = None
        self.timer = QTimer(self); self.timer.timeout.connect(self.update); self.timer.start(1000)
    def paintEvent(self, e):
        import datetime
        now = self.now or datetime.datetime.now(); p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = self.rect(); cy = r.height()/2
        p.setPen(QPen(QColor('#364a63'), 1)); p.drawLine(QPointF(12, 2), QPointF(r.width()-12, 2))
        p.setPen(Qt.white); p.setFont(BellClock.font(52, True)); p.drawText(QRectF(0, cy-60, r.width(), 64), Qt.AlignCenter, now.strftime('%H:%M'))
        p.setPen(QColor('#a9b9cf')); p.setFont(BellClock.font(16))
        p.drawText(QRectF(0, cy+6, r.width(), 22), Qt.AlignCenter, '%d %s %d' % (now.day, TR_MONTHS[now.month-1], now.year))
        p.drawText(QRectF(0, cy+28, r.width(), 22), Qt.AlignCenter, TR_DAYS[now.weekday()])
        p.end()

class PenMeter:
    """Kalem ölçümü: 10 saniye yazılır; tahtanın nokta sıklığı, işleme ve çizim süresi,
    sırada bekleme ölçülür, sonuç ekranda gösterilir (Terminal gerekmez)."""
    SECONDS = 10
    def __init__(self, main):
        self.main = main; self.b = main.board; self.events = []; self.paints = []; self.kinds = {}; self.t0 = None
    def start(self):
        m = self.main; m.new_board()
        m.set_tool('pen'); b = self.b
        self.orig = (b.event, b.paintEvent)
        def event(e):
            t = e.type()
            if t in (QEvent.TouchUpdate, QEvent.MouseMove, QEvent.TabletMove):
                st = time.perf_counter(); r = self.orig[0](e); dur = (time.perf_counter() - st)*1000
                if self.t0 is None: self.t0 = time.monotonic()
                try: ts = e.timestamp()
                except Exception: ts = 0
                self.events.append((time.monotonic(), ts, dur, b.active is not None))
                k = {QEvent.TouchUpdate: 'dokunma', QEvent.MouseMove: 'fare', QEvent.TabletMove: 'kalem'}[t]; self.kinds[k] = self.kinds.get(k, 0) + 1
                return r
            return self.orig[0](e)
        def paint(e):
            st = time.perf_counter(); self.orig[1](e); self.paints.append((time.perf_counter() - st)*1000)
        b.event = event; b.paintEvent = paint
        self.banner = QLabel(m.scroll); self.banner.setAlignment(Qt.AlignCenter)
        self.banner.setStyleSheet('background:rgba(14,28,50,230);color:white;border:2px solid #3d8bff;border-radius:16px;padding:14px 26px;font-size:22px;')
        self.timer = QTimer(); self.timer.timeout.connect(self.tick); self.timer.start(200); self.tick()
    def tick(self):
        left = self.SECONDS if self.t0 is None else max(0, self.SECONDS - (time.monotonic() - self.t0))
        self.banner.setText('Kalem ölçümü · ' + ('normal hızda yazmaya başlayın' if self.t0 is None else 'yazmaya devam edin · %d sn' % math.ceil(left)))
        self.banner.adjustSize(); vp = self.main.scroll.viewport().geometry()
        self.banner.move(vp.x() + (vp.width() - self.banner.width())//2, vp.y() + 16); self.banner.show(); self.banner.raise_()
        if self.t0 is not None and left <= 0: self.stop()
    def stop(self):
        self.timer.stop(); self.banner.hide(); b = self.b
        del b.event; del b.paintEvent   # özgün yöntemlere dön
        self.main.pen_meter = None; self.show(self.result())
    @staticmethod
    def pct(v, q):
        if not v: return 0.0
        v = sorted(v); return v[min(len(v)-1, int(len(v)*q))]
    def result(self):
        ev = [e for e in self.events if e[3]]   # yalnızca yazarken
        gaps = [(b_[1]-a_[1]) for a_, b_ in zip(ev, ev[1:]) if 0 < b_[1]-a_[1] < 200]
        hz = 1000/self.pct(gaps, .5) if gaps else 0
        lag = []   # sırada bekleme: her çizginin içinde, en hızlı işlenen noktaya göre gecikme
        if ev and ev[0][1]:
            stroke = [ev[0]]
            for prev, cur in list(zip(ev, ev[1:])) + [(ev[-1], None)]:
                if cur is None or cur[0] - prev[0] > .2:
                    base = [e[0]*1000 - e[1] for e in stroke]; lo = min(base); lag += [x - lo for x in base]
                    stroke = [cur] if cur is not None else []
                else: stroke.append(cur)
        proc = [e[2] for e in ev]
        r = dict(nokta=len(ev), hz=round(hz), isleme_ort=round(sum(proc)/len(proc), 2) if proc else 0, isleme_95=round(self.pct(proc, .95), 2),
                 cizim_ort=round(sum(self.paints)/len(self.paints), 2) if self.paints else 0, cizim_95=round(self.pct(self.paints, .95), 2),
                 bekleme_95=round(self.pct(lag, .95), 1), bekleme_max=round(max(lag), 1) if lag else 0, giris=self.kinds, surum=installed_version())
        try:
            with open(os.path.join(self.main.data_dir, 'kalem-olcum.json'), 'w', encoding='utf-8') as f: json.dump(r, f, ensure_ascii=False)
        except OSError: pass
        return r
    def show(self, r):
        if r['nokta'] < 20: verdict = 'Yeterli yazı alınamadı. Ölçümü yeniden başlatıp 10 saniye boyunca sürekli yazın.'
        elif r['isleme_95'] > 8 or r['cizim_95'] > 16: verdict = 'Uygulama yavaş kalıyor: işleme ya da çizim süresi uzun. Kodda iyileştirilecek yer var.'
        elif r['bekleme_95'] > 25: verdict = 'Noktalar sırada bekliyor: tahta meşgul. Kodda iyileştirilecek yer var.'
        elif r['hz'] and r['hz'] < 80: verdict = 'Tahta seyrek nokta gönderiyor (%d/sn). Uç tahmini en çok bu durumda fayda sağlar.' % r['hz']
        else: verdict = 'Uygulama tarafı hızlı. Kalan gecikme büyük ölçüde dokunmatik panel ve ekrandan geliyor; uç tahmini bunu azaltabilir.'
        giris = ', '.join('%s %d' % kv for kv in r['giris'].items()) or '-'
        rows = [('Tahtanın gönderdiği nokta', '%d / saniye' % r['hz']), ('Noktayı işleme (ort / %95)', '%.2f / %.2f ms' % (r['isleme_ort'], r['isleme_95'])),
                ('Ekrana çizme (ort / %95)', '%.2f / %.2f ms' % (r['cizim_ort'], r['cizim_95'])), ('Sırada bekleme (%95 / en çok)', '%.1f / %.1f ms' % (r['bekleme_95'], r['bekleme_max'])),
                ('Ölçülen nokta', str(r['nokta'])), ('Giriş türü', giris), ('Sürüm', r['surum'])]
        d = QDialog(self.main); d.setWindowTitle('Kalem ölçümü'); lay = QVBoxLayout(d); lay.setContentsMargins(26, 22, 26, 22); lay.setSpacing(12)
        t = QLabel('Kalem ölçümü sonucu'); t.setStyleSheet('font-size:24px;font-weight:600;'); lay.addWidget(t)
        g = QGridLayout(); g.setHorizontalSpacing(30); g.setVerticalSpacing(10); lay.addLayout(g)
        for i, (a, v) in enumerate(rows):
            la = QLabel(a); la.setStyleSheet('font-size:19px;color:#a9b9cf;'); lv = QLabel(v); lv.setStyleSheet('font-size:21px;font-weight:600;')
            g.addWidget(la, i, 0); g.addWidget(lv, i, 1)
        v = QLabel(verdict); v.setWordWrap(True); v.setStyleSheet('font-size:18px;padding:12px;border-radius:12px;background:rgba(61,139,255,0.18);'); lay.addWidget(v)
        n = QLabel('Bu ekranın fotoğrafını gönderebilirsiniz.'); n.setStyleSheet('color:#a9b9cf;font-size:15px;'); lay.addWidget(n)
        ok = QPushButton('Kapat'); ok.setObjectName('primary'); ok.setMinimumHeight(48); ok.clicked.connect(d.accept); lay.addWidget(ok)
        d.resize(720, 560); d.exec_()


# ---------------------------------------------------------------------------
# Ölçülü üçgen: kenar/açıdan üçgeni hesaplar; tahtaya normal çizgilerle konur.
TRI_MODES = [('sss', '3 kenar', ('|AB|', '|BC|', '|CA|')), ('sas', '2 kenar + aradaki açı', ('|AB|', '|AC|', 'A açısı')),
             ('asa', '1 kenar + 2 açı', ('|AB|', 'A açısı', 'B açısı')), ('aaa', 'Yalnız açılar', ('A açısı', 'B açısı'))]

def triangle_solve(mode, vals):
    """Döner: (a=|BC|, b=|CA|, c=|AB|, A, B, C derece) ya da hata metni."""
    d = math.degrees; r_ = math.radians
    try:
        if mode == 'sss':
            c, a, b = vals
            if min(a, b, c) <= 0: return 'Kenarlar sıfırdan büyük olmalı.'
            for x, y, z in ((a, b, c), (b, c, a), (c, a, b)):
                if x + y <= z: return 'Bu kenarlarla üçgen olmaz (%s + %s ≤ %s).' % (fmt_num(x), fmt_num(y), fmt_num(z))
            A = d(math.acos((b*b + c*c - a*a)/(2*b*c))); B = d(math.acos((a*a + c*c - b*b)/(2*a*c)))
        elif mode == 'sas':
            c, b, A = vals
            if min(b, c) <= 0: return 'Kenarlar sıfırdan büyük olmalı.'
            if not 0 < A < 180: return 'Açı 0° ile 180° arasında olmalı.'
            a = math.sqrt(b*b + c*c - 2*b*c*math.cos(r_(A))); B = d(math.acos(max(-1, min(1, (a*a + c*c - b*b)/(2*a*c)))))
        elif mode == 'asa':
            c, A, B = vals
            if c <= 0: return 'Kenar sıfırdan büyük olmalı.'
            if A <= 0 or B <= 0 or A + B >= 180: return 'Açıların toplamı 180°\'den küçük olmalı.'
            C = 180 - A - B; a = c*math.sin(r_(A))/math.sin(r_(C)); b = c*math.sin(r_(B))/math.sin(r_(C))
        else:
            A, B = vals
            if A <= 0 or B <= 0 or A + B >= 180: return 'Açıların toplamı 180° olmalı (iki açının toplamı 180°\'den küçük).'
            C = 180 - A - B; c = 6.0; a = c*math.sin(r_(A))/math.sin(r_(C)); b = c*math.sin(r_(B))/math.sin(r_(C))
        C = 180 - A - B
        return (a, b, c, A, B, C)
    except (ValueError, ZeroDivisionError):
        return 'Bu değerlerle üçgen çizilemiyor.'

def label_half(text, h):
    """text_strokes yazısının yarı genişlik/yükseklik kutusu."""
    xs = [q[0] for m in text_strokes(text, 0, 0, h, '#000', 1) for q in m['points']]
    ys = [q[1] for m in text_strokes(text, 0, 0, h, '#000', 1) for q in m['points']]
    if not xs: return h*.3, h*.5
    return max(abs(min(xs)), abs(max(xs))), max(abs(min(ys)), abs(max(ys)))

def triangle_marks(sol, mode, opts, size, color, width):
    """Üçgeni (ağırlık merkezi 0,0) çizgi listesi olarak üretir; size: en uzun kenar (sayfa birimi)."""
    a, b, c, A, B, C = sol; k = size/max(a, b, c)
    P = {'A': (0.0, 0.0), 'B': (c*k, 0.0), 'C': (b*k*math.cos(math.radians(A)), -b*k*math.sin(math.radians(A)))}
    gx = sum(v[0] for v in P.values())/3; gy = sum(v[1] for v in P.values())/3
    P = {n: (x - gx, y - gy) for n, (x, y) in P.items()}
    h = max(9.0, size*.075); blue, red, grey = '#0057ff', '#e8132b', '#64748b'
    out = [dict(tool='pen', color=color, width=width, points=[list(P['A']), list(P['B']), list(P['C']), list(P['A'])])]
    def unit(x, y): n = math.hypot(x, y) or 1; return x/n, y/n
    edges = [(P['A'], P['B']), (P['B'], P['C']), (P['C'], P['A'])]; boxes = []
    Ax, Ay = P['A']; Bx, By = P['B']; Cx, Cy = P['C']
    if opts.get('height'):   # yardımcı çizgiler de etiketlerin kaçınacağı yerler
        t_ = ((Cx - Ax)*(Bx - Ax) + (Cy - Ay)*(By - Ay))/((Bx - Ax)**2 + (By - Ay)**2); edges.append(((Cx, Cy), (Ax + t_*(Bx - Ax), Ay + t_*(By - Ay))))
    if opts.get('bisector'): t_ = c/(b + c); edges.append(((Ax, Ay), (Bx + (Cx - Bx)*t_, By + (Cy - By)*t_)))
    if opts.get('median'): edges.append(((Ax, Ay), ((Bx + Cx)/2, (By + Cy)/2)))
    def seg_hits(box, p0, p1):   # doğru parçası kutuya giriyor mu (Liang–Barsky)
        x0, y0, x1, y1 = box; t0, t1 = 0.0, 1.0; dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        for pp, qq in ((-dx, p0[0] - x0), (dx, x1 - p0[0]), (-dy, p0[1] - y0), (dy, y1 - p0[1])):
            if pp == 0:
                if qq < 0: return False
            else:
                r_ = qq/pp
                if pp < 0: t0 = max(t0, r_)
                else: t1 = min(t1, r_)
                if t0 > t1: return False
        return True
    def free(box):
        g = h*.18; bb = (box[0] - g, box[1] - g, box[2] + g, box[3] + g)
        if any(seg_hits(bb, p0, p1) for p0, p1 in edges): return False
        return not any(bb[0] < q[2] and q[0] < bb[2] and bb[1] < q[3] and q[1] < bb[3] for q in boxes)
    def place(txt, hs, col, wid, tries):
        """tries: [(px, py, ux, uy, t0, t1)] sırayla denenir; çizgiye/etikete değmeyen ilk yer."""
        hw, hh = label_half(txt, hs); last = None
        for px, py, ux, uy, t0, t1 in tries:
            t = t0
            while t <= t1:
                cx, cy = px + ux*t, py + uy*t; box = (cx - hw, cy - hh, cx + hw, cy + hh)
                if free(box):
                    boxes.append(box); return text_strokes(txt, cx, cy, hs, col, wid)
                last = last or (cx, cy, box); t += h*.2
        cx, cy, box = last; boxes.append(box); return text_strokes(txt, cx, cy, hs, col, wid)
    angs = {'A': A, 'B': B, 'C': C}; bis = {}
    for n_ in 'ABC':
        others = [m for m in 'ABC' if m != n_]; vx, vy = P[n_]
        d1 = unit(P[others[0]][0] - vx, P[others[0]][1] - vy); d2 = unit(P[others[1]][0] - vx, P[others[1]][1] - vy)
        bis[n_] = (d1, d2, unit(d1[0] + d2[0], d1[1] + d2[1]))
    if opts.get('names', True):
        for n_ in 'ABC':   # köşe adı: açının tam dışına
            bx, by = bis[n_][2]; out += place(n_, h, color, max(1.2, width*.7), [(P[n_][0], P[n_][1], -bx, -by, h*.7, h*4)])
    given_s = {'sss': ('c', 'a', 'b'), 'sas': ('c', 'b'), 'asa': ('c',), 'aaa': ()}[mode]
    given_a = {'sss': (), 'sas': ('A',), 'asa': ('A', 'B'), 'aaa': ('A', 'B')}[mode]
    sides = {'c': ('A', 'B', c), 'a': ('B', 'C', a), 'b': ('C', 'A', b)}
    rr = size*.09; jobs = []
    for n_, val in angs.items():
        show = n_ in given_a and opts.get('angles', True); calc = n_ not in given_a and opts.get('calc', False)
        right = abs(val - 90) < 1e-6
        if not (show or calc or right): continue
        d1, d2, (bx, by) = bis[n_]; vx, vy = P[n_]; col = red if show else grey
        if right:   # dik açı: küçük kare
            q = rr*.6; out.append(dict(tool='pen', color=red, width=max(1.2, width*.7), points=[[vx + d1[0]*q, vy + d1[1]*q], [vx + (d1[0] + d2[0])*q, vy + (d1[1] + d2[1])*q], [vx + d2[0]*q, vy + d2[1]*q]]))
        else:
            a0 = math.atan2(d1[1], d1[0]); a1 = math.atan2(d2[1], d2[0]); da = (a1 - a0 + math.pi) % (2*math.pi) - math.pi
            out.append(dict(tool='pen', color=col, width=max(1.2, width*.7), points=[[vx + rr*math.cos(a0 + da*i/16), vy + rr*math.sin(a0 + da*i/16)] for i in range(17)]))
        if show or calc:
            txt = ('≈ ' if calc and not show else '') + fmt_num(val, 1) + '°'
            # önce açının içinde (yayın ötesinde), sığmazsa köşenin dışında
            o1, o2 = (P[m] for m in 'ABC' if m != n_)   # karşı kenara kadar olan iç mesafe
            ex_, ey_ = o2[0] - o1[0], o2[1] - o1[1]; den = bx*ey_ - by*ex_
            reach = ((o1[0] - vx)*ey_ - (o1[1] - vy)*ex_)/den if abs(den) > 1e-9 else size
            tries = [(vx, vy, bx, by, rr*1.1, min(size*.45, reach*.85))] if val >= 30 else []   # çok dar açı: doğrudan dışarı
            tries.append((vx, vy, -bx, -by, h*.8, h*6))
            jobs.append((0 if show else 1, txt, h*(.75 if show else .64), col, max(1.1, width*.55), tries))
    for key, (u, v, val) in sides.items():
        show = key in given_s and mode != 'aaa' and opts.get('sides', True)
        calc = key not in given_s and mode != 'aaa' and opts.get('calc', False)
        if not (show or calc): continue
        mx, my = (P[u][0] + P[v][0])/2, (P[u][1] + P[v][1])/2
        ex, ey = unit(P[v][0] - P[u][0], P[v][1] - P[u][1]); nx, ny = -ey, ex
        if nx*mx + ny*my < 0: nx, ny = -nx, -ny   # kenarın dış normali
        L = math.hypot(P[v][0] - P[u][0], P[v][1] - P[u][1])
        tries = [(mx + ex*o, my + ey*o, nx, ny, h*.3, h*3) for o in (0, L*.15, -L*.15, L*.28, -L*.28)]
        jobs.append((0 if show else 1, ('≈ ' if calc else '') + fmt_num(val), h*(.9 if show else .78), blue if show else grey, max(1.2, width*.6), tries))
    for _, txt, hs, col, wid, tries in sorted(jobs, key=lambda j: j[0]):   # verilenler önce yerini alır
        out += place(txt, hs, col, wid, tries)
    Ax, Ay = P['A']; Bx, By = P['B']; Cx, Cy = P['C']
    if opts.get('height'):   # C'den AB'ye yükseklik (kesikli), ayağında dik açı
        t = ((Cx - Ax)*(Bx - Ax) + (Cy - Ay)*(By - Ay))/((Bx - Ax)**2 + (By - Ay)**2); Hx, Hy = Ax + t*(Bx - Ax), Ay + t*(By - Ay)
        out.append(dict(tool='pen', color=grey, width=max(1.2, width*.7), dash=True, points=[[Cx, Cy], [Hx, Hy]]))
        if not 0 <= t <= 1: out.append(dict(tool='pen', color=grey, width=max(1.0, width*.5), dash=True, points=[[Ax, Ay] if t < 0 else [Bx, By], [Hx, Hy]]))
        q = size*.04; out.append(dict(tool='pen', color=grey, width=max(1.0, width*.5), points=[[Hx + q, Hy], [Hx + q, Hy - q], [Hx, Hy - q]]))
    if opts.get('bisector'):   # A'dan açıortay
        t = c/(b + c); Dx, Dy = Bx + (Cx - Bx)*t, By + (Cy - By)*t
        out.append(dict(tool='pen', color='#16a34a', width=max(1.2, width*.7), dash=True, points=[[Ax, Ay], [Dx, Dy]]))
    if opts.get('median'):   # A'dan kenarortay
        out.append(dict(tool='pen', color='#d946ef', width=max(1.2, width*.7), dash=True, points=[[Ax, Ay], [(Bx + Cx)/2, (By + Cy)/2]]))
    return out

class NumPad(QWidget):
    """Sayı tuş takımı (ölçü girişleri için): rakamlar, virgül, sil."""
    def __init__(self, parent, on_key):
        super().__init__(parent); g = QGridLayout(self); g.setSpacing(6); g.setContentsMargins(0, 0, 0, 0)
        for i, k in enumerate(['7', '8', '9', '⌫', '4', '5', '6', 'Temizle', '1', '2', '3', ',', '0', '00', '.', '°']):
            if k in ('.', '°'): continue
            b = QPushButton(k); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(52); b.setStyleSheet('font-size:21px;')
            b.clicked.connect(lambda checked=False, k_=k: on_key(k_)); g.addWidget(b, i//4, i % 4)

# ---- Canlı koordinat düzlemi: noktalar, doğrular, sonuçlar (kesir + ondalık) ----
from fractions import Fraction as _Fr
from PyQt5.QtGui import QFont, QFontMetricsF, QPainterPath
from PyQt5.QtWidgets import QFrame
from html import escape as html_escape
GEO_U = 24   # make_template('koordinat') birimi
GEO_COL = {'line': '#16a34a', 'par': '#0d9488', 'perp': '#ea580c', 'dist': '#0057ff', 'slope': '#c026d3', 'mid': '#b45309', 'cut': '#7c3aed'}
GEO_LINES = ('line', 'par', 'perp')
GEO_LETTERS = 'ABCDEFGHLNPRSTUVYZ'
def gq(v): return _Fr(str(v)).limit_denominator(100000)
def _minus(t): return t.replace('-', '−')
def gexact(q):   # sonlu ondalık mı (paydada yalnız 2 ve 5)
    d = q.denominator
    for f in (2, 5):
        while d % f == 0: d //= f
    return d == 1
def gdec(q, nd=2):
    t = ('%.*f' % (nd, float(q))).rstrip('0').rstrip('.')
    return _minus(t.replace('.', ',')) if t not in ('-0', '') else '0'
def gnum(q):   # koordinat yazımı: tam, sonlu ondalık ya da kesir
    if q.denominator == 1: return _minus(str(q.numerator))
    if gexact(q) and q.denominator <= 1000: return gdec(q, 4)
    return gfrac(q)
def gfrac(q): return _minus(str(q.numerator)) if q.denominator == 1 else _minus('%d/%d' % (q.numerator, q.denominator))
def gboth(q):   # 4/5 = 0,8  ·  1/3 ≈ 0,33  ·  2
    if q.denominator == 1: return gfrac(q)
    return gfrac(q) + (' = ' if gexact(q) and q.denominator <= 100 else ' ≈ ') + gdec(q)
def gpt(x, y):
    sep = ', ' if x.denominator == 1 and y.denominator == 1 else ' ; '
    return '(' + gnum(x) + sep + gnum(y) + ')'
def gpt_both(x, y):
    t = gpt(x, y)
    if all(q.denominator == 1 or (gexact(q) and q.denominator <= 1000) for q in (x, y)): return t
    return t + ' ≈ (' + gdec(x) + ' ; ' + gdec(y) + ')'
def _isqrt_q(q):
    import math as _m
    a, b = _m.isqrt(q.numerator), _m.isqrt(q.denominator)
    return _Fr(a, b) if a*a == q.numerator and b*b == q.denominator else None
def gdist(d2):
    import math as _m
    r = _isqrt_q(d2)
    if r is not None: return gnum(r)
    approx = ' ≈ ' + gdec(_Fr(_m.sqrt(d2)))
    if d2.denominator == 1:
        n = d2.numerator; k = 1; i = 2
        while i*i <= n:
            while n % (i*i) == 0: n //= i*i; k *= i
            i += 1
        return ('' if k == 1 else str(k)) + '√' + str(n) + approx
    return approx.strip()
def geq(L, dec=False):
    A, B, C = L; f = gdec if dec else gfrac
    if B == 0: return 'x = ' + f(C/A)
    m, c = -A/B, C/B; t = 'y = '
    if m != 0: t += ('' if m == 1 else '−' if m == -1 else f(m)) + 'x'
    if m == 0: t += f(c)
    elif c != 0: t += (' − ' if c < 0 else ' + ') + f(abs(c))
    return t
def geq_both(L):
    A, B, C = L; e = geq(L)
    if B == 0: frac_ = (C/A).denominator != 1
    else: frac_ = (A/B).denominator != 1 or (C/B).denominator != 1
    return e + ('   (' + geq(L, True) + ')' if frac_ else '')
def geo_find(marks):
    for m in marks:
        if m.get('tool') == 'geo': return m
    return None
def geo_eval(m):
    """Her nesnenin değeri: doğrular (A, B, C: Ax + By = C), noktalar, adlar."""
    P = [(gq(x), gq(y)) for x, y, _ in m['P']]; lines = {}; names = {}; nd = nm = nk = 0; out = []
    sub = '₀₁₂₃₄₅₆₇₈₉'
    def nm_(base, n): return base + ('' if n == 1 and base in 'MK' else ''.join(sub[int(c)] for c in str(n)))
    for k, o in enumerate(m['O']):
        t = o['t']; v = dict(t=t)
        try:
            if t in ('dist', 'line', 'slope', 'mid'):
                (ax, ay), (bx, by) = P[o['a']], P[o['b']]; v['ab'] = m['P'][o['a']][2] + m['P'][o['b']][2]
                if t == 'line':
                    A, B = by - ay, ax - bx
                    if A == 0 and B == 0: raise ValueError
                    lines[k] = (A, B, A*ax + B*ay)
                elif t == 'mid': nm += 1; v['pt'] = ((ax + bx)/2, (ay + by)/2); v['name'] = nm_('M', nm)
                elif t == 'dist': v['d2'] = (bx - ax)**2 + (by - ay)**2; v['seg'] = ((ax, ay), (bx, by))
                else: v['seg'] = ((ax, ay), (bx, by)); v['m'] = None if bx == ax else (by - ay)/(bx - ax); v['dx'] = bx - ax; v['dy'] = by - ay
            elif t in ('par', 'perp'):
                A, B, _ = lines[o['l']]; rx, ry = P[o['p']]
                if t == 'perp': A, B = -B, A
                lines[k] = (A, B, A*rx + B*ry); v['of'] = names[o['l']]; v['p'] = m['P'][o['p']][2]
                if t == 'perp':
                    A1, B1, C1 = lines[o['l']]; A2, B2, C2 = lines[k]; det = A1*B2 - A2*B1
                    v['foot'] = ((C1*B2 - C2*B1)/det, (A1*C2 - A2*C1)/det); v['dir'] = (-B1, A1)
            elif t == 'cut':
                (A1, B1, C1), (A2, B2, C2) = lines[o['l']], lines[o['m']]; v['of'] = (names[o['l']], names[o['m']])
                det = A1*B2 - A2*B1
                if det == 0: v['pt'] = None; v['same'] = A1*C2 == A2*C1 and B1*C2 == B2*C1
                else: nk += 1; v['pt'] = ((C1*B2 - C2*B1)/det, (A1*C2 - A2*C1)/det); v['name'] = nm_('K', nk)
            if k in lines: nd += 1; names[k] = 'd' + ''.join(sub[int(c)] for c in str(nd)); v['name'] = names[k]; v['L'] = lines[k]
        except (KeyError, IndexError, ZeroDivisionError, ValueError):
            v['bad'] = True
        out.append(v)
    return P, out
def geo_rows(m, vals):
    """Sonuç panosu satırları: (nesne no, renk, başlık, değer)."""
    rows = []
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        t = o['t']; c = GEO_COL[t]
        if t == 'dist': rows.append((k, c, '|%s| = ' % v['ab'], gdist(v['d2'])))
        elif t == 'slope': rows.append((k, c, 'm(%s) = Δy/Δx = ' % v['ab'], 'tanımsız (dikey doğru)' if v['m'] is None else gboth(v['m'])))
        elif t == 'mid': rows.append((k, c, '%s, %s’nin orta noktası: ' % (v['name'], v['ab']), v['name'] + gpt_both(*v['pt'])))
        elif t == 'line':
            L = v['L']; extra = []
            if L[1] != 0: extra.append(gpt(_Fr(0), L[2]/L[1]))
            if L[0] != 0 and not (L[1] != 0 and L[2] == 0): extra.append(gpt(L[2]/L[0], _Fr(0)))
            rows.append((k, c, '%s (%s): ' % (v['name'], v['ab']), geq_both(L) + ('   · eksenleri keser: ' + ' ve '.join(extra) if extra else '')))
        elif t in ('par', 'perp'):
            rows.append((k, c, '%s %s %s, %s’den: ' % (v['name'], '∥' if t == 'par' else '⊥', v['of'], v['p']), geq_both(v['L'])))
        elif t == 'cut':
            a, b = v['of']
            if v['pt'] is None: rows.append((k, c, '%s ∩ %s: ' % (a, b), 'çakışık (aynı doğru)' if v['same'] else 'kesişmez (paralel)'))
            else: rows.append((k, c, '%s ∩ %s = ' % (a, b), v['name'] + gpt_both(*v['pt'])))
    return rows
def halo_text(p, x, y, text, px, color, bold=False, align='l'):
    """Izgara üstünde okunaklı yazı: beyaz kenarlı."""
    f = QFont(p.font()); f.setPixelSize(max(1, int(px))); f.setBold(bold); fm = QFontMetricsF(f)
    w = fm.horizontalAdvance(text); x0 = x - w/2 if align == 'c' else x - w if align == 'r' else x
    path = QPainterPath(); path.addText(QPointF(x0, y), f, text)
    p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor(255, 255, 255, 235), px*.28, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.drawPath(path)
    p.setPen(Qt.NoPen); p.setBrush(QColor(color)); p.drawPath(path); p.setBrush(Qt.NoBrush)
    return QRectF(x0, y - fm.ascent(), w, fm.height())
def geo_layout(m, vals, W):
    """Panonun satır kutuları (sayfa birimi): [(nesne no, kutu, gizli mi)]."""
    rows = geo_rows(m, vals); f = QFont(); f.setPixelSize(13); fm = QFontMetricsF(f); fb = QFont(f); fb.setBold(True); fmb = QFontMetricsF(fb)
    out = []; y = 12
    for k, c, head, val in rows:
        hid = m['O'][k].get('h'); vtxt = '?' if hid else val
        w = 26 + fm.horizontalAdvance(head) + (34 if hid else fmb.horizontalAdvance(vtxt)) + 12
        out.append((k, QRectF(12, y, min(w, W*.62), 24), hid, c, head, vtxt)); y += 28
    return out
def geo_strokes(m, W, H):
    """PDF'ye: aynı çizim kalem çizgileri olarak (gizli cevaplar gizli kalır)."""
    P, vals = geo_eval(m); cx, cy, U = W/2, H/2, GEO_U; out = []
    X = lambda x: cx + float(x)*U; Y = lambda y: cy - float(y)*U
    def ln(a, b, col, w): out.append(dict(tool='pen', color=col, width=w, points=[list(a), list(b)]))
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        col = GEO_COL[o['t']]
        if 'L' in v:
            A, B, C = (float(t) for t in v['L'])
            if B == 0: ln((X(C/A), 0), (X(C/A), H), col, 2.2)
            else:
                xa, xb = -cx/U, cx/U; ya, yb = (C - A*xa)/B, (C - A*xb)/B
                pts = []
                for xx, yy in ((xa, ya), (xb, yb)):
                    if abs(yy) > cy/U: yy = math.copysign(cy/U, yy); xx = (C - B*yy)/A if A else xx
                    pts.append((X(xx), Y(yy)))
                ln(pts[0], pts[1], col, 2.2)
        elif o['t'] == 'dist': (ax, ay), (bx, by) = v['seg']; ln((X(ax), Y(ay)), (X(bx), Y(by)), col, 3)
        elif o['t'] == 'slope' and v['m'] is not None:
            (ax, ay), (bx, by) = v['seg']
            for (x0, y0), (x1, y1) in (((X(ax), Y(ay)), (X(bx), Y(ay))), ((X(bx), Y(ay)), (X(bx), Y(by)))):   # kesikli Δx, Δy
                L_ = math.hypot(x1 - x0, y1 - y0); n_ = max(1, int(L_/7))
                for j in range(0, n_, 2): ln((x0 + (x1 - x0)*j/n_, y0 + (y1 - y0)*j/n_), (x0 + (x1 - x0)*(j + 1)/n_, y0 + (y1 - y0)*(j + 1)/n_), col, 1.6)
            if not o.get('h'):
                if v['dx']: out += text_strokes('Δx = ' + gnum(v['dx']), (X(ax) + X(bx))/2, Y(ay) + (12 if by > ay else -8), 8, col, 1.1)
                if v['dy']: out += text_strokes('Δy = ' + gnum(v['dy']), X(bx) + 6, (Y(ay) + Y(by))/2, 8, col, 1.1, 'l')
        elif o['t'] in ('mid', 'cut') and v.get('pt') is not None:
            x, y = v['pt']; out += text_strokes(v['name'] + ('' if o.get('h') else gpt_canvas(x, y)), X(x) + 8, Y(y) + 12, 9, col, 1.2, 'l')
            out.append(dict(tool='pen', color=col, width=8, points=[[X(x), Y(y)]]))
    for i, (x, y) in enumerate(P):
        out.append(dict(tool='pen', color='#e8132b', width=9, points=[[X(x), Y(y)]]))
        out += text_strokes(m['P'][i][2] + gpt(x, y), X(x) + 8, Y(y) - 12, 10, '#111827', 1.3, 'l')
    y0 = 18
    for k, c, head, val in geo_rows(m, vals):
        for part in (head + ('?' if m['O'][k].get('h') else val)).split('   · '):
            out += text_strokes(part, 14, y0, 9, c, 1.1, 'l'); y0 += 16
    return out

def gpt_canvas(x, y):   # tahtadaki kısa yazım: tam/sonlu ondalık, değilse ≈ iki basamak
    if all(q.denominator == 1 or (gexact(q) and q.denominator <= 1000) for q in (x, y)): return gpt(x, y)
    return '≈(' + gdec(x) + ' ; ' + gdec(y) + ')'
def draw_geo(p, m, W, H, sel=()):
    P, vals = geo_eval(m); cx, cy, U = W/2, H/2, GEO_U
    X = lambda x: cx + float(x)*U; Y = lambda y: cy - float(y)*U
    p.save(); p.setClipRect(QRectF(0, 0, W, H)); p.setOpacity(1)
    placed = [QRectF(X(x) - 7, Y(y) - 7, 14, 14) for x, y in P]   # noktaların kendisi de dolu sayılır
    def label(ax, ay, text, px, color, bold=True, offs=None):
        """Yazıyı çevresindeki ilk boş yere koyar (öteki yazılara/noktalara binmez)."""
        f = QFont(p.font()); f.setPixelSize(max(1, int(px))); f.setBold(bold); fm = QFontMetricsF(f); w = fm.horizontalAdvance(text)
        offs = offs or [(9, -9, 'l'), (9, 19, 'l'), (-9, -9, 'r'), (-9, 19, 'l2'), (0, -14, 'c'), (0, 26, 'c'), (14, -24, 'l'), (14, 32, 'l'), (-14, -24, 'r'), (-14, 32, 'r')]
        first = None
        for dx, dy, al in offs:
            x0 = ax + dx - (w if al in ('r', 'l2') else w/2 if al == 'c' else 0); y0 = ay + dy
            box = QRectF(x0 - 2, y0 - fm.ascent() - 1, w + 4, fm.height() + 2)
            if first is None: first = (x0, y0, box)
            if 0 <= box.left() and box.right() <= W and 0 <= box.top() and box.bottom() <= H and not any(box.intersects(q) for q in placed):
                placed.append(box); halo_text(p, x0, y0, text, px, color, bold); return
        placed.append(first[2]); halo_text(p, first[0], first[1], text, px, color, bold)
    def line_seg(L):
        A, B, C = (float(v) for v in L)
        if B == 0: x = C/A; return (QPointF(X(x), 0), QPointF(X(x), H))
        xa, xb = -cx/U - 1, cx/U + 1
        return (QPointF(X(xa), Y((C - A*xa)/B)), QPointF(X(xb), Y((C - A*xb)/B)))
    hidden = lambda k: m['O'][k].get('h')
    names = []
    for k, (o, v) in enumerate(zip(m['O'], vals)):   # doğrular en altta
        if v.get('bad') or 'L' not in v: continue
        col = QColor(GEO_COL[o['t']]); a, b = line_seg(v['L'])
        if ('o', k) in sel: p.setPen(QPen(QColor(47, 124, 246, 70), 10, Qt.SolidLine, Qt.RoundCap)); p.drawLine(a, b)
        p.setPen(QPen(col, 2.4, Qt.SolidLine, Qt.RoundCap)); p.drawLine(a, b)
        names.append((a, b, v['name'], col.name()))
        if o['t'] == 'perp' and v.get('foot'):
            fx, fy = (float(t_) for t_ in v['foot']); A1, B1 = (float(t_) for t_ in v['dir'])
            n1 = math.hypot(A1, B1) or 1; u1 = (A1/n1, -B1/n1); A2, B2, _ = (float(t_) for t_ in v['L']); n2 = math.hypot(A2, B2) or 1; u2 = (-B2/n2, -A2/n2)
            e = 9; o_ = QPointF(X(fx), Y(fy)); a1 = QPointF(u1[0]*e, u1[1]*e); a2 = QPointF(u2[0]*e, u2[1]*e)
            p.setPen(QPen(col, 1.6)); p.drawPolyline(QPolygonF([o_ + a1, o_ + a1 + a2, o_ + a2]))
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        t = o['t']; col = QColor(GEO_COL[t])
        if t == 'dist':
            (ax, ay), (bx, by) = v['seg']; p.setPen(QPen(col, 3.4, Qt.SolidLine, Qt.RoundCap)); p.drawLine(QPointF(X(ax), Y(ay)), QPointF(X(bx), Y(by)))
        elif t == 'slope' and v['m'] is not None:
            (ax, ay), (bx, by) = v['seg']; pen = QPen(col, 2, Qt.DashLine); pen.setDashPattern([4, 3]); p.setPen(pen)
            p.drawPolyline(QPolygonF([QPointF(X(ax), Y(ay)), QPointF(X(bx), Y(ay)), QPointF(X(bx), Y(by))]))
    # noktalar
    for i, (x, y) in enumerate(P):
        c = QPointF(X(x), Y(y))
        if ('p', i) in sel: p.setPen(QPen(QColor('#2f7cf6'), 2.6)); p.setBrush(QColor(47, 124, 246, 40)); p.drawEllipse(c, 12, 12)
        p.setPen(QPen(Qt.white, 1.6)); p.setBrush(QColor('#e8132b')); p.drawEllipse(c, 5.5, 5.5); p.setBrush(Qt.NoBrush)
    for k, (o, v) in enumerate(zip(m['O'], vals)):   # türetilen noktalar
        if v.get('bad') or o['t'] not in ('mid', 'cut') or v.get('pt') is None: continue
        x, y = v['pt']; col = QColor(GEO_COL[o['t']]); p.setPen(QPen(Qt.white, 1.4)); p.setBrush(col); p.drawEllipse(QPointF(X(x), Y(y)), 5, 5); p.setBrush(Qt.NoBrush)
        placed.append(QRectF(X(x) - 6, Y(y) - 6, 12, 12))
    icpts = []   # doğruların eksenleri kestiği yerler
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad') or o['t'] != 'line': continue
        A, B, C = v['L']; col = GEO_COL['line']
        for ix, iy in ([(_Fr(0), C/B)] if B != 0 else []) + ([(C/A, _Fr(0))] if A != 0 and C != 0 else []):
            if abs(float(ix)) > cx/U or abs(float(iy)) > cy/U: continue
            p.setPen(QPen(QColor(col), 2)); p.setBrush(Qt.white); p.drawEllipse(QPointF(X(ix), Y(iy)), 4, 4); p.setBrush(Qt.NoBrush)
            placed.append(QRectF(X(ix) - 5, Y(iy) - 5, 10, 10)); icpts.append((ix, iy, col, not hidden(k)))
    # yazılar: önce asıl noktalar, sonra türetilenler, en son eksen kesimleri ve doğru adları
    for i, (x, y) in enumerate(P): label(X(x), Y(y), m['P'][i][2] + gpt(x, y), 15, '#111827')
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        col = GEO_COL[o['t']]
        if o['t'] in ('mid', 'cut') and v.get('pt') is not None:
            x, y = v['pt']; label(X(x), Y(y), v['name'] + ('' if hidden(k) else gpt_canvas(x, y)), 14, col)
        elif o['t'] == 'slope' and v['m'] is not None:
            (ax, ay), (bx, by) = v['seg']; h = hidden(k)
            if v['dx']: label((X(ax) + X(bx))/2, Y(ay), 'Δx = ' + ('?' if h else gnum(v['dx'])), 13, col, offs=[(0, 17 if by > ay else -8, 'c'), (0, -8 if by > ay else 17, 'c'), (0, 32, 'c')])
            if v['dy']: label(X(bx), (Y(ay) + Y(by))/2 + 5, 'Δy = ' + ('?' if h else gnum(v['dy'])), 13, col, offs=[(8, 0, 'l') if bx > ax else (-8, 0, 'r'), (-8, 0, 'r') if bx > ax else (8, 0, 'l'), (8, 18, 'l')])
    for ix, iy, col, show in icpts:
        if show: label(X(ix), Y(iy), gpt_canvas(ix, iy), 12, col, False)
    for a, b, name, col in names:   # doğru adı: sayfanın içinde, uca yakın boş yer
        d = b - a; n = math.hypot(d.x(), d.y()) or 1; nx, ny = -d.y()/n, d.x()/n
        if ny > 0: nx, ny = -nx, -ny
        for i in range(60):
            q = a + d*(.95 - i*.015)
            if 30 < q.x() < W - 30 and 30 < q.y() < H - 30: break
        label(q.x(), q.y(), name, 15, col, True, [(nx*16, ny*16 + 5, 'c'), (-nx*16, -ny*16 + 5, 'c'), (nx*30, ny*30 + 5, 'c')])
    p.restore()

class GeoPanel(QWidget):
    """Sonuçlar: ekranın sağında, katlanır, başlığından sürüklenir; “?” dokununca açılır."""
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.setObjectName('geopanel'); self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet('#geopanel{background:rgba(15,26,46,238);border:1px solid #2b3b5a;border-radius:16px;}'
                           '#geopanel QLabel{color:#dbe5f7;font-size:17px;background:transparent;}'
                           '#geopanel QPushButton{background:#22314d;color:#e8eefc;border:1px solid #33456a;border-radius:10px;font-size:17px;padding:2px 10px;}'
                           '#geopanel QPushButton#soru{background:#fef3c7;color:#92400e;border:1.5px solid #d97706;font-weight:700;min-width:46px;}')
        from PyQt5.QtWidgets import QLayout
        self.box = QVBoxLayout(self); self.box.setContentsMargins(14, 10, 14, 12); self.box.setSpacing(6); self.box.setSizeConstraint(QLayout.SetFixedSize)
        head = QHBoxLayout(); self.title = QLabel('Sonuçlar'); self.title.setStyleSheet('font-size:18px;font-weight:600;color:#ffffff;'); head.addWidget(self.title); head.addStretch(1)
        self.fold = QPushButton('–'); self.fold.setFocusPolicy(Qt.NoFocus); self.fold.setFixedSize(40, 34); self.fold.clicked.connect(self.toggle); head.addWidget(self.fold)
        self.box.addLayout(head); self.body = QWidget(); self.rows = QVBoxLayout(self.body); self.rows.setContentsMargins(0, 0, 0, 0); self.rows.setSpacing(6); self.box.addWidget(self.body)
        self.offset = None; self.drag = None; self.folded = False; self.hide()
    def toggle(self):
        self.folded = not self.folded; self.body.setVisible(not self.folded); self.fold.setText('+' if self.folded else '–'); self.adjustSize(); self.place()
    def fill(self, m):
        old = self.body; self.body = QWidget(); self.rows = QVBoxLayout(self.body); self.rows.setContentsMargins(0, 0, 0, 0); self.rows.setSpacing(6)
        self.box.replaceWidget(old, self.body); old.deleteLater(); self.body.setVisible(not self.folded)
        P, vals = geo_eval(m); rows = geo_rows(m, vals); n = 0
        for k, c, head, val in rows:
            line = QHBoxLayout(); line.setSpacing(8); hid = m['O'][k].get('h')
            dot = QLabel('●'); dot.setStyleSheet('color:%s;font-size:16px;' % c); line.addWidget(dot, 0, Qt.AlignTop)
            if hid:
                h_ = QLabel(head.strip()); line.addWidget(h_); q = QPushButton('?'); q.setObjectName('soru'); q.setFocusPolicy(Qt.NoFocus)
                q.clicked.connect(lambda checked=False, k_=k: self.main.geo_reveal(k_)); line.addWidget(q); line.addStretch(1)
            else:
                v_ = html_escape(val).replace('   · ', '<br>').replace('   (', '&nbsp;&nbsp;(')
                lab = QLabel('%s<b style="color:%s">%s</b>' % (html_escape(head), QColor(c).lighter(135).name(), v_)); lab.setTextFormat(Qt.RichText); line.addWidget(lab, 1)
            self.rows.addLayout(line); n += 1
        self.title.setText('Sonuçlar (%d)' % n if n else 'Sonuçlar'); self.body.adjustSize(); self.adjustSize()
        return n
    def place(self):
        vp = self.main.scroll.viewport().geometry(); self.adjustSize()
        if self.offset is None: x, y = vp.right() - self.width() - 12, vp.y() + 74
        else: x, y = vp.x() + self.offset.x(), vp.y() + self.offset.y()
        x = max(vp.x() + 4, min(x, vp.right() - self.width() - 4)); y = max(vp.y() + 4, min(y, vp.bottom() - min(self.height(), 60)))
        self.move(x, y); self.raise_()
    def resizeEvent(self, e):
        if self.isVisible(): QTimer.singleShot(0, self.place)
    def mousePressEvent(self, e): self.drag = e.globalPos() - self.pos()
    def mouseMoveEvent(self, e):
        if self.drag is not None:
            vp = self.main.scroll.viewport().geometry(); np_ = e.globalPos() - self.drag; self.offset = np_ - vp.topLeft(); self.place()
    def mouseReleaseEvent(self, e): self.drag = None

class GeoBar(QWidget):
    """Koordinat düzlemi araç çubuğu: yalnızca koordinat şablonunda görünür."""
    BTN = [('nokta', 'Nokta koy'), ('gir', 'Koordinat gir'), None, ('dist', 'Mesafe'), ('line', 'Doğru'), ('slope', 'Eğim'), ('mid', 'Orta nokta'),
           ('par', 'Paralel'), ('perp', 'Dik'), ('cut', 'Kesişim'), None, ('gizle', 'Cevabı gizle'), ('sil', 'Sil'), ('temizle', 'Temizle')]
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.setObjectName('geobar'); self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet('#geobar{background:rgba(15,26,46,236);border:1px solid #2b3b5a;border-radius:16px;}'
                           '#geobar QPushButton{background:#22314d;color:#e8eefc;border:1px solid #33456a;border-radius:11px;padding:8px 13px;font-size:15px;min-height:26px;}'
                           '#geobar QPushButton:checked{background:#2f7cf6;border-color:#2f7cf6;color:white;}'
                           '#geobar QPushButton[pasif="true"]{color:#6b7c99;background:#1a2640;border-color:#24324d;}'
                           '#geobar QFrame{background:#33456a;}')
        row = QHBoxLayout(self); row.setContentsMargins(8, 7, 8, 7); row.setSpacing(6); self.b = {}
        for it in self.BTN:
            if it is None:
                sep = QFrame(); sep.setFixedSize(1, 30); row.addWidget(sep); continue
            k, t = it; b = QPushButton(t); b.setFocusPolicy(Qt.NoFocus); b.setCheckable(k in ('nokta', 'gizle'))
            b.clicked.connect(lambda checked=False, k_=k: self.main.geo_action(k_)); row.addWidget(b); self.b[k] = b
        self.hide()
    def sync(self):
        o = self.main; sel = getattr(o.board, 'geo_sel', []); np_ = sum(1 for t, _ in sel if t == 'p'); nl = len(sel) - np_
        self.b['nokta'].setChecked(o.tool == 'geo'); self.b['gizle'].setChecked(getattr(o, 'geo_hide', False))
        ok = {'dist': np_ == 2, 'line': np_ == 2, 'slope': np_ == 2, 'mid': np_ == 2, 'par': np_ == 1 and nl == 1, 'perp': np_ == 1 and nl == 1, 'cut': nl == 2, 'sil': bool(sel)}
        for k, v in ok.items():
            b = self.b[k]
            if b.property('pasif') != (not v): b.setProperty('pasif', not v); b.style().unpolish(b); b.style().polish(b)
    def place(self):
        vp = self.main.scroll.viewport().geometry(); self.adjustSize()
        self.move(vp.x() + max(10, (vp.width() - self.width())//2), vp.y() + 10); self.raise_()

class GeoInput(QDialog):
    """Koordinat gir: x ve y, tahtanın kendi tuş takımıyla."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Koordinat gir'); self.setModal(True)
        from PyQt5.QtWidgets import QLineEdit
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(10)
        t = QLabel('Nokta koordinatı'); t.setStyleSheet('font-size:21px;font-weight:600;'); box.addWidget(t)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row); self.fields = []
        for i, name in enumerate(('x', 'y')):
            l = QLabel(('( ' if i == 0 else ' ;  ') + name + ' ='); l.setStyleSheet('font-size:20px;'); row.addWidget(l)
            e = QLineEdit(); e.setMinimumHeight(52); e.setFixedWidth(130); e.setAlignment(Qt.AlignCenter); e.setStyleSheet('font-size:22px;'); e.installEventFilter(self); row.addWidget(e); self.fields.append(e)
        r_ = QLabel(' )'); r_.setStyleSheet('font-size:20px;'); row.addWidget(r_); row.addStretch(1)
        self.cur = self.fields[0]; self.err = QLabel(''); self.err.setStyleSheet('color:#ff8a95;font-size:15px;'); box.addWidget(self.err)
        pad = QHBoxLayout(); box.addLayout(pad); pad.addWidget(NumPad(self, self.key), 1)
        sign = QPushButton('±'); sign.setFocusPolicy(Qt.NoFocus); sign.setMinimumSize(70, 52); sign.setStyleSheet('font-size:24px;'); sign.clicked.connect(lambda: self.key('±')); pad.addWidget(sign, 0, Qt.AlignTop)
        bt = QHBoxLayout(); box.addLayout(bt)
        c = QPushButton('Vazgeç'); c.setMinimumHeight(48); c.clicked.connect(self.reject); bt.addWidget(c)
        ok = QPushButton('Noktayı koy'); ok.setMinimumHeight(48); ok.setObjectName('primary'); ok.clicked.connect(self.put); bt.addWidget(ok)
        self.fields[0].setFocus()
    def eventFilter(self, o, e):
        if e.type() == QEvent.FocusIn and o in self.fields: self.cur = o
        return False
    def key(self, k):
        e = self.cur; t = e.text()
        if k == '⌫': e.setText(t[:-1])
        elif k == 'Temizle': e.setText('')
        elif k == '±': e.setText(t[1:] if t.startswith('−') else '−' + t)
        elif k == ',':
            if ',' not in t: e.setText((t or '0') + ',')
        else: e.setText(t + k)
        e.setFocus()
    def put(self):
        try:
            x, y = (gq(float(f.text().replace('−', '-').replace(',', '.'))) for f in self.fields)
        except ValueError:
            self.err.setText('İki sayıyı da girin (ör. 2,5 ve −3).'); return
        page = self.main.doc[self.main.page].rect
        if abs(float(x)) > page.width/2/GEO_U or abs(float(y)) > page.height/2/GEO_U:
            self.err.setText('Bu nokta düzlemin dışında kalıyor (x: ±%d, y: ±%d).' % (page.width/2/GEO_U, page.height/2/GEO_U)); return
        self.main.board.geo_point(x, y); self.accept()

class TriangleDialog(QDialog):
    """Ölçülü üçgen: ne bilindiğini seç, değerleri gir, tahtaya koy."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Ölçülü üçgen'); self.setModal(True)
        from PyQt5.QtWidgets import QLineEdit, QCheckBox
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(860, scr.width()-60), min(760, scr.height()-60))
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(10)
        t = QLabel('Ölçülü üçgen'); t.setStyleSheet('font-size:21px;font-weight:600;'); box.addWidget(t)
        box.addWidget(QLabel('Ne biliniyor?'))
        row = QHBoxLayout(); row.setSpacing(6); box.addLayout(row); self.mode_buttons = {}
        for key, name, _ in TRI_MODES:
            b = QPushButton(name); b.setCheckable(True); b.setMinimumHeight(46); b.clicked.connect(lambda checked=False, k=key: self.set_mode(k)); row.addWidget(b); self.mode_buttons[key] = b
        body = QHBoxLayout(); body.setSpacing(18); box.addLayout(body)
        left = QVBoxLayout(); left.setSpacing(8); body.addLayout(left, 3)
        self.grid = QGridLayout(); self.grid.setVerticalSpacing(8); self.grid.setHorizontalSpacing(12); left.addLayout(self.grid)
        self.labels = []; self.fields = []
        for i in range(3):
            l = QLabel(); e = QLineEdit(); e.setMinimumHeight(50); e.setStyleSheet('font-size:21px;'); e.installEventFilter(self); e.textChanged.connect(self.check)
            self.grid.addWidget(l, i, 0); self.grid.addWidget(e, i, 1); self.labels.append(l); self.fields.append(e)
        self.result = QLabel(); self.result.setWordWrap(True); self.result.setStyleSheet('font-size:16px;'); left.addWidget(self.result)
        cfg = main.tri_cfg if hasattr(main, 'tri_cfg') else {}
        self.opts = {}
        for key, name, on in (('names', 'Köşe adları (A, B, C)', True), ('sides', 'Verilen kenarlar', True), ('angles', 'Verilen açılar', True),
                              ('calc', 'Hesaplanan değerler', False), ('height', 'Yükseklik (C’den)', False), ('bisector', 'Açıortay (A’dan)', False), ('median', 'Kenarortay (A’dan)', False)):
            c = QCheckBox(name); c.setChecked(cfg.get(key, on)); left.addWidget(c); self.opts[key] = c
        left.addStretch(1)
        right = QVBoxLayout(); body.addLayout(right, 2)
        self.pad = NumPad(self, self.key); right.addWidget(self.pad); right.addStretch(1)
        btns = QHBoxLayout(); box.addLayout(btns)
        no = QPushButton('Vazgeç'); no.setMinimumHeight(50); no.clicked.connect(self.reject); btns.addWidget(no)
        self.ok = QPushButton('Tahtaya koy'); self.ok.setObjectName('primary'); self.ok.setMinimumHeight(50); self.ok.clicked.connect(self.place); btns.addWidget(self.ok)
        self.target = None; self.set_mode(cfg.get('mode', 'sas'))
    def eventFilter(self, o, e):
        if e.type() in (QEvent.FocusIn, QEvent.MouseButtonPress) and o in self.fields: self.target = o
        return False
    def key(self, k):
        t = self.target or next((f for f in self.fields if f.isVisible()), None)
        if t is None: return
        if k == '⌫': t.backspace()
        elif k == 'Temizle': t.clear()
        else: t.insert(k)
    def set_mode(self, key):
        self.mode = key
        for k, b in self.mode_buttons.items(): b.setChecked(k == key)
        names = dict((k, f) for k, _, f in TRI_MODES)[key]
        for i in range(3):
            vis = i < len(names); self.labels[i].setVisible(vis); self.fields[i].setVisible(vis)
            if vis: self.labels[i].setText(names[i] + ('  (derece)' if 'açı' in names[i] else '')); self.labels[i].setStyleSheet('font-size:18px;')
        self.target = self.fields[0]; self.fields[0].setFocus(); self.check()
    def values(self):
        n = len(dict((k, f) for k, _, f in TRI_MODES)[self.mode]); out = []
        for f in self.fields[:n]:
            t = f.text().strip().replace(',', '.').replace('°', '')
            try: out.append(float(t))
            except ValueError: return None
        return out
    def check(self):
        v = self.values()
        if v is None: self.result.setText('Değerleri girin.'); self.result.setStyleSheet('font-size:16px;color:#a9b9cf;'); self.ok.setEnabled(False); return None
        sol = triangle_solve(self.mode, v)
        if isinstance(sol, str): self.result.setText(sol); self.result.setStyleSheet('font-size:16px;color:#ff8a95;'); self.ok.setEnabled(False); return None
        a, b, c, A, B, C = sol
        txt = 'Geçerli üçgen · ' + ('|AB| ≈ %s · |BC| ≈ %s · |CA| ≈ %s · ' % (fmt_num(c), fmt_num(a), fmt_num(b)) if self.mode != 'aaa' else '') + 'A ≈ %s° · B ≈ %s° · C ≈ %s°' % (fmt_num(A, 1), fmt_num(B, 1), fmt_num(C, 1))
        self.result.setText('✓ ' + txt); self.result.setStyleSheet('font-size:16px;color:#4ade80;'); self.ok.setEnabled(True); return sol
    def place(self):
        sol = self.check()
        if sol is None: return
        opts = {k: c.isChecked() for k, c in self.opts.items()}; self.main.tri_cfg = dict(opts, mode=self.mode)
        b = self.main.board; vis = b.visibleRegion().boundingRect(); size = min(vis.width(), vis.height())/b.scale*.42
        self.main.pending_triangle = triangle_marks(sol, self.mode, opts, size, self.main.color if self.main.color != '#ffffff' or self.main.background in DARK_BACKGROUNDS else PEN_DEFAULT, max(2, self.main.width.value()))
        self.accept(); self.main.set_tool('place_tri')


# ---------------------------------------------------------------------------
# Şablonlar: koordinat düzlemi, sayı doğrusu, izometrik, milimetrik (yeni boş tahta)
TEMPLATES = [('koordinat', 'Koordinat düzlemi'), ('sayi', 'Sayı doğrusu'), ('izometrik', 'İzometrik'), ('milimetrik', 'Milimetrik')]

def make_template(key, width=960, height=540):
    doc = fitz.open(); page = doc.new_page(width=width, height=height); sh = page.new_shape()
    dark = (.2, .25, .33); light = (.84, .88, .94)
    def label(x, y, t, size=8):
        page.insert_text((x - fitz.get_text_length(t, fontsize=size)/2, y), t, fontsize=size, color=dark)
    if key == 'koordinat':
        u = 24; cx, cy = width/2, height/2
        for i in range(-int(cx//u), int(cx//u) + 1): sh.draw_line((cx + i*u, 0), (cx + i*u, height))
        for j in range(-int(cy//u), int(cy//u) + 1): sh.draw_line((0, cy + j*u), (width, cy + j*u))
        sh.finish(color=light, width=.6)
        sh.draw_line((8, cy), (width - 8, cy)); sh.draw_line((cx, height - 8), (cx, 8))
        sh.draw_polyline([(width - 18, cy - 5), (width - 8, cy), (width - 18, cy + 5)]); sh.draw_polyline([(cx - 5, 18), (cx, 8), (cx + 5, 18)])
        sh.finish(color=dark, width=1.4)
        for i in range(-int(cx//u) + 1, int(cx//u)):
            if i: sh.draw_line((cx + i*u, cy - 3), (cx + i*u, cy + 3)); label(cx + i*u, cy + 13, str(i))
        for j in range(-int(cy//u) + 1, int(cy//u)):
            if j: sh.draw_line((cx - 3, cy - j*u), (cx + 3, cy - j*u)); page.insert_text((cx - 6 - fitz.get_text_length(str(j), fontsize=8), cy - j*u + 3), str(j), fontsize=8, color=dark)
        sh.finish(color=dark, width=1); label(cx - 7, cy + 13, '0'); label(width - 14, cy - 8, 'x', 11); label(cx + 12, 16, 'y', 11)
    elif key == 'sayi':
        for yy, n in ((height*.25, 10), (height*.5, 10), (height*.75, 10)):
            x0, x1 = 40, width - 40; step = (x1 - x0)/(2*n + 2)
            sh.draw_line((x0 - 10, yy), (x1 + 10, yy)); sh.draw_polyline([(x1, yy - 5), (x1 + 10, yy), (x1, yy + 5)]); sh.draw_polyline([(x0, yy - 5), (x0 - 10, yy), (x0, yy + 5)])
            for i in range(-n, n + 1):
                x = width/2 + i*step; big = i == 0
                sh.draw_line((x, yy - (8 if big else 5)), (x, yy + (8 if big else 5))); label(x, yy + 20, str(i), 9)
        sh.finish(color=dark, width=1.3)
    elif key == 'izometrik':
        u = 24; hrow = u*math.sqrt(3)/2; j = 0; y = 0.0
        while y <= height + 1:
            off = (u/2) if j % 2 else 0; x = off
            while x <= width + 1: sh.draw_circle((x, y), 1.3); x += u
            y += hrow; j += 1
        sh.finish(color=None, fill=(.45, .53, .66))
    elif key == 'milimetrik':
        mm = 72/25.4
        for i in range(int(width/mm) + 1):
            x = i*mm; w_ = .9 if i % 10 == 0 else .55 if i % 5 == 0 else .25
            sh.draw_line((x, 0), (x, height)); sh.finish(color=(.93, .55, .45) if i % 10 == 0 else (.96, .78, .72), width=w_)
        for i in range(int(height/mm) + 1):
            y = i*mm; w_ = .9 if i % 10 == 0 else .55 if i % 5 == 0 else .25
            sh.draw_line((0, y), (width, y)); sh.finish(color=(.93, .55, .45) if i % 10 == 0 else (.96, .78, .72), width=w_)
    sh.commit(); doc.set_metadata({'title': APP_NAME, 'keywords': 'UMAL-template:' + key}); return doc

class TemplateDialog(QDialog):
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Şablonlar'); self.setModal(True)
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(12)
        t = QLabel('Şablonlar · seçilen zeminle yeni boş tahta açılır'); t.setStyleSheet('font-size:19px;font-weight:600;'); box.addWidget(t)
        g = QGridLayout(); g.setSpacing(14); box.addLayout(g)
        for i, (key, name) in enumerate(TEMPLATES):
            d = make_template(key); pix = d[0].get_pixmap(matrix=fitz.Matrix(.36, .36), alpha=False); d.close()
            b = QPushButton(name); b.setIcon(QIcon(QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy())))
            b.setIconSize(QSize(pix.width, pix.height)); b.setStyleSheet('QPushButton{padding:10px;font-size:17px;}'); b.setMinimumHeight(pix.height + 24)
            b.clicked.connect(lambda checked=False, k=key, n=name: self.pick(k, n)); g.addWidget(b, i//2, i % 2)
        c = QPushButton('Vazgeç'); c.setMinimumHeight(48); c.clicked.connect(self.reject); box.addWidget(c)
    def pick(self, key, name):
        m = self.main; self.accept(); m.start_tab(name); m.replace(make_template(key)); m.tabs_changed(); m.set_tool('pen')

# ---------------------------------------------------------------------------
# Grafik çizici: y = f(x) (log, ln, üstel, sin/cos/tan, mutlak değer, kök…) → yeni tahta sekmesinde vektör grafik
import re as _re
_SUB = str.maketrans('₀₁₂₃₄₅₆₇₈₉', '0123456789')
def graph_compile(expr):
    """Öğretmenin yazdığını güvenli Python ifadesine çevirir. Döner: (işlev, hata)."""
    s0 = expr.strip()
    s = s0.lower().replace(' ', '').replace('−', '-').replace('·', '*').replace('×', '*').replace('÷', '/')
    s = _re.sub(r'^(y|f\(x\))=', '', s)
    if not s: return None, 'Fonksiyonu yazın.'
    s = _re.sub(r'(\d),(\d)', r'\1.\2', s)
    s = s.replace('²', '**2').replace('³', '**3').replace('π', 'pi').replace('^', '**')
    s = _re.sub(r'log([₀-₉]+)\(', lambda m: 'logb(%s,' % m.group(1).translate(_SUB), s)
    s = _re.sub(r'log_(\d+(?:\.\d+)?)\(', r'logb(\1,', s)
    s = _re.sub(r'(?<![a-z])log\(', 'lg(', s)
    s = s.replace('√(', 'sqrt(')
    s = _re.sub(r'√(\d+(?:\.\d+)?|x)', r'sqrt(\1)', s)
    for _ in range(3): s = _re.sub(r'\|([^|]+)\|', r'abs(\1)', s)
    s = _re.sub(r'(\d|\))(?=[a-z(])', r'\1*', s)
    s = _re.sub(r'(?<![a-z])x(?=[\d(a-z])', 'x*', s)
    s = _re.sub(r'(?<![a-z])pi(?=[\dx(a-z])', 'pi*', s)
    s = _re.sub(r'(?<![a-z])e(?=[\dx(])', 'e*', s)
    if _re.search(r'[^0-9a-z+\-*/().,]', s): return None, 'Anlaşılmayan işaret var.'
    names = set(_re.findall(r'[a-z]+', s)) - {'x', 'sin', 'cos', 'tan', 'sqrt', 'lg', 'ln', 'logb', 'abs', 'pi', 'e', 'cot'}
    if names: return None, 'Tanınmayan: ' + ', '.join(sorted(names))
    ns = dict(sin=math.sin, cos=math.cos, tan=math.tan, cot=lambda v: 1/math.tan(v), sqrt=math.sqrt, lg=math.log10, ln=math.log,
              logb=lambda b_, v: math.log(v, b_), abs=abs, pi=math.pi, e=math.e)
    try: code = compile(s, '<f>', 'eval')
    except SyntaxError: return None, 'Yazım hatası (parantezleri denetleyin).'
    def f(x):
        try:
            v = eval(code, {'__builtins__': {}}, dict(ns, x=x))
            if isinstance(v, complex) or v != v or abs(v) > 1e12: return None
            return float(v)
        except (ValueError, ZeroDivisionError, OverflowError, TypeError): return None
        except Exception: return None
    try: eval(code, {'__builtins__': {}}, dict(ns, x=1.37))
    except (NameError, SyntaxError, TypeError): return None, 'Yazım hatası.'
    except Exception: pass
    return f, None

def graph_build(funcs, opts, W=960, H=600):
    """funcs: [(yazı, işlev, renk)] · opts: roots, extrema, cross, yx. Döner: fitz belge."""
    xs_try = [i/25 for i in range(-250, 251)]
    pos_only = all(all(fn(x) is None for x in xs_try if x <= 0) and any(fn(x) is not None for x in xs_try if x > 0) for _, fn, _ in funcs)
    keys = []   # kökler, uç noktalar, kesişimler, tanım sınırları: görüntü bunlara göre seçilir
    for _, fn, _ in funcs:
        prev = None
        for x in xs_try:
            v = fn(x)
            if prev is not None:
                pv = prev[1]
                if (v is None) != (pv is None): keys.append(x)
                elif v is not None and pv is not None and abs(v - pv) < 5:
                    if pv*v <= 0: keys.append(x)
            prev = (x, v)
        vals = [(x, fn(x)) for x in xs_try]
        for (xa, a), (xb, b), (xc_, c) in zip(vals, vals[1:], vals[2:]):
            if None not in (a, b, c) and (b - a)*(c - b) < 0 and abs(c - a) < 5: keys.append(xb)
    if len(funcs) == 2:
        f_, g_ = funcs[0][1], funcs[1][1]; prev = None
        for x in xs_try:
            a, b = f_(x), g_(x); v = None if a is None or b is None else a - b
            if v is not None and prev is not None and prev*v <= 0 and abs(v - prev) < 5: keys.append(x)
            prev = v
    if keys and len(keys) <= 8:
        x0, x1 = min(keys) - 2.5, max(keys) + 2.5
        if x1 - x0 < 9: c_ = (x0 + x1)/2; x0, x1 = c_ - 4.5, c_ + 4.5
        if x1 - x0 > 22: x0, x1 = max(x0, -11), min(x1, 11)
    else: x0, x1 = (-2.0, 12.0) if pos_only else (-7.0, 7.0)
    if pos_only: x0 = max(x0, -1.5)
    ys = []
    for _, fn, _ in funcs:
        for i in range(401):
            v = fn(x0 + (x1 - x0)*i/400)
            if v is not None and abs(v) < 60: ys.append(v)
    ys.sort()
    lo, hi = (ys[int(len(ys)*.05)], ys[int(len(ys)*.95)]) if ys else (-5, 5)
    lo, hi = min(lo, 0), max(hi, 0); span = max(4.0, hi - lo); lo -= span*.15; hi += span*.15
    lo, hi = max(lo, -15), min(hi, 15)
    if opts.get('yx'):   # ters fonksiyonlar: iki eksende aynı aralık (simetri görünsün)
        a_, b_ = min(x0, -2.5), max(x1, 6.5); lo, hi = a_, b_; x0, x1 = a_, b_
    m = 46; pw, ph = W - 2*m, H - 2*m
    ux, uy = pw/(x1 - x0), ph/(hi - lo)
    if opts.get('yx') or .55 < ux/uy < 1.8:   # birimler yakınsa eşit al (y = x simetrisi doğru görünsün)
        unit = min(ux, uy); xc, yc = (x0 + x1)/2, (lo + hi)/2
        x0, x1 = xc - pw/unit/2, xc + pw/unit/2; lo, hi = yc - ph/unit/2, yc + ph/unit/2; ux = uy = unit
    unit = min(ux, uy)
    X = lambda x: m + (x - x0)*ux; Y = lambda y: m + (hi - y)*uy
    doc = fitz.open(); page = doc.new_page(width=W, height=H); sh = page.new_shape()
    fonts = pdf_fonts(); dark = (.2, .25, .33)
    dv = next((q for q in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans.ttf', os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'seguisym.ttf')) if os.path.isfile(q)), None)
    pop = fitz.Font(fontfile=fonts['m']) if fonts['m'] else None
    def text(x, y, t, size, color=dark, anchor='c'):
        f = fonts['m']
        if pop is not None and dv and any(not pop.has_glyph(ord(ch)) for ch in t): f = dv   # log₂, ˣ gibi işaretler
        wdt = fitz.Font(fontfile=f).text_length(t, fontsize=size) if f else fitz.get_text_length(t, fontsize=size)
        xx = x - wdt/2 if anchor == 'c' else x - wdt if anchor == 'r' else x
        if f: page.insert_text((xx, y), t, fontsize=size, fontname='umalm' if f == fonts['m'] else 'umaldv', fontfile=f, color=color)
        else: page.insert_text((xx, y), t, fontsize=size, color=color)
    step = next(k for k in (1, 2, 5, 10, 20) if k*ux >= 26); stepy = next(k for k in (1, 2, 5, 10, 20) if k*uy >= 22)
    for i in range(math.ceil(x0), math.floor(x1) + 1): sh.draw_line((X(i), m), (X(i), H - m))
    for j in range(math.ceil(lo), math.floor(hi) + 1): sh.draw_line((m, Y(j)), (W - m, Y(j)))
    sh.finish(color=(.87, .9, .95), width=.5)
    ax_y = Y(0) if lo < 0 < hi else (Y(lo) if lo >= 0 else Y(hi)); ax_x = X(0) if x0 < 0 < x1 else X(x0)
    sh.draw_line((m - 6, ax_y), (W - m + 10, ax_y)); sh.draw_line((ax_x, H - m + 6), (ax_x, m - 10))
    sh.draw_polyline([(W - m + 2, ax_y - 5), (W - m + 10, ax_y), (W - m + 2, ax_y + 5)]); sh.draw_polyline([(ax_x - 5, m - 2), (ax_x, m - 10), (ax_x + 5, m - 2)])
    sh.finish(color=dark, width=1.3)
    for i in range(math.ceil(x0/step)*step, math.floor(x1) + 1, step):
        if i: sh.draw_line((X(i), ax_y - 3), (X(i), ax_y + 3)); text(X(i), ax_y + 14, str(i).replace('-', '−') if fonts['m'] else str(i), 9)
    for j in range(math.ceil(lo/stepy)*stepy, math.floor(hi) + 1, stepy):
        if j: sh.draw_line((ax_x - 3, Y(j)), (ax_x + 3, Y(j))); text(ax_x - 7, Y(j) + 3, str(j).replace('-', '−') if fonts['m'] else str(j), 9, anchor='r')
    sh.finish(color=dark, width=1); text(W - m + 4, ax_y - 9, 'x', 12); text(ax_x + 11, m - 4, 'y', 12)
    if opts.get('yx'):
        a_, b_ = max(x0, lo), min(x1, hi); sh.draw_line((X(a_), Y(a_)), (X(b_), Y(b_))); sh.finish(color=(.6, .64, .7), width=1, dashes='[5 4] 0')
    N = 1600; marks = []
    def rgb(c): q = QColor(c); return (q.redF(), q.greenF(), q.blueF())
    sampled = []
    for label, fn, col in funcs:
        pts = [(x0 + (x1 - x0)*i/N, fn(x0 + (x1 - x0)*i/N)) for i in range(N + 1)]; sampled.append(pts)
        seg = []; asym = []
        def flush():
            if len(seg) > 1: sh.draw_polyline([(X(a), Y(b)) for a, b in seg]); sh.finish(color=rgb(col), width=2.4, closePath=False)
            seg.clear()
        yr = hi - lo
        for (xa, ya), (xb, yb) in zip(pts, pts[1:]):
            if ya is None or yb is None:
                if ya is not None and yb is None and abs(ya) > yr: asym.append(xb)   # tanım dışı sınırında sonsuza gidiyor
                if ya is None and yb is not None and abs(yb) > yr: asym.append(xa)
                flush(); continue
            if abs(yb - ya) > yr*1.5 and ya*yb < 0: asym.append((xa + xb)/2); flush(); continue   # tan gibi sıçrama
            ca, cb = min(max(ya, lo - yr), hi + yr), min(max(yb, lo - yr), hi + yr)
            inside_a, inside_b = lo <= ya <= hi, lo <= yb <= hi
            if inside_a and not seg: seg.append((xa, ya))
            if inside_a and inside_b: seg.append((xb, yb))
            elif inside_a and not inside_b:
                yy = hi if yb > hi else lo; xx = xa + (xb - xa)*(yy - ya)/(yb - ya); seg.append((xx, yy)); flush()
            elif not inside_a and inside_b:
                yy = hi if ya > hi else lo; xx = xa + (xb - xa)*(yy - ya)/(yb - ya); seg.extend([(xx, yy), (xb, yb)])
        flush()
        al = sorted(set(round(v, 2) for v in asym))
        for xa in al:
            xv = round(xa*2)/2 if abs(xa*2 - round(xa*2)) < .03 else xa
            sh.draw_line((X(xv), m), (X(xv), H - m)); sh.finish(color=rgb(col), width=1, dashes='[6 4] 0')
            if len(al) <= 3: text(X(xv) + 4, m + 12, 'x = ' + fmt_num(xv), 10, rgb(col), 'l')
    def refine(g, a, b):
        ga = g(a)
        for _ in range(48):
            c = (a + b)/2; gc = g(c)
            if gc is None: return None
            if (gc < 0) == (ga < 0): a, ga = c, gc
            else: b = c
        return (a + b)/2
    dots = []
    for (label, fn, col), pts in zip(funcs, sampled):
        yr = hi - lo
        if opts.get('roots', True):
            for (xa, ya), (xb, yb) in zip(pts, pts[1:]):
                if ya is None or yb is None or abs(yb - ya) > yr: continue
                if ya == 0 or ya*yb < 0:
                    r = xa if ya == 0 else refine(fn, xa, xb)
                    if r is not None and all(abs(r - d[0]) > (x1 - x0)/200 for d in dots if d[3] == 'kök'): dots.append((r, 0.0, col, 'kök'))
        if opts.get('extrema', True):
            for i in range(1, len(pts) - 1):
                (xa, ya), (xb, yb), (xc_, yc_) = pts[i-1], pts[i], pts[i+1]
                if None in (ya, yb, yc_) or abs(yc_ - ya) > yr*.5: continue
                if (yb - ya)*(yc_ - yb) < 0:
                    a_, b_ = xa, xc_   # altın oran araması
                    for _ in range(60):
                        c1 = b_ - (b_ - a_)*.618; c2 = a_ + (b_ - a_)*.618; f1, f2 = fn(c1), fn(c2)
                        if f1 is None or f2 is None: break
                        if (f1 < f2) == (yb < ya): b_ = c2
                        else: a_ = c1
                    xe = (a_ + b_)/2; ye = fn(xe)
                    if ye is not None and lo < ye < hi: dots.append((xe, ye, col, 'uç'))
    if opts.get('cross', True) and len(funcs) == 2:
        f, g = funcs[0][1], funcs[1][1]
        def d(x):
            a, b = f(x), g(x); return None if a is None or b is None else a - b
        prev = None
        for i in range(N + 1):
            x = x0 + (x1 - x0)*i/N; v = d(x)
            if v is not None and prev is not None and prev[1]*v < 0 and abs(v - prev[1]) < (hi - lo):
                r = refine(d, prev[0], x)
                if r is not None and f(r) is not None and lo < f(r) < hi: dots.append((r, f(r), '#111111', 'kesişim'))
            prev = (x, v) if v is not None else None
    n_ext = sum(1 for d in dots if d[3] == 'uç'); many = len(dots) > 8; placed = []
    def free(x, y, w, h):   # etiketler üst üste binmesin
        r = fitz.Rect(x - w/2, y - h, x + w/2, y + 2)
        return not any(r.intersects(q) for q in placed), r
    for x, y, col, kind in dots[:16]:
        page.draw_circle((X(x), Y(y)), 4.2, color=(1, 1, 1), fill=rgb('#e8132b' if kind == 'uç' else col), width=1)
        if many: continue
        if kind == 'kök': t = 'x = ' + fmt_num(x)
        elif kind == 'uç': t = ('T' if n_ext == 1 else '') + '(%s ; %s)' % (fmt_num(x), fmt_num(y))
        else: t = '(%s ; %s)' % (fmt_num(x), fmt_num(y))
        w_ = fitz.get_text_length(t, fontsize=10.5)*1.05 + 6
        lower = kind == 'kök' or (kind == 'uç' and y < (lo + hi)/2)
        for dy in (((30, 44, -12) if kind == 'kök' else (18, -10, 32, -24)) if lower else (-10, 18, -24, 32)):
            ok, r = free(X(x), Y(y) + dy, w_, 12)
            if ok: placed.append(r); text(X(x), Y(y) + dy, t, 10.5, rgb('#e8132b' if kind == 'uç' else col)); break
    yy = m + 8
    for label, fn, col in funcs:   # fonksiyon adları sol üstte
        page.draw_rect(fitz.Rect(m + 6, yy - 9, m + 16, yy + 1), color=None, fill=rgb(col)); text(m + 22, yy, 'y = ' + label, 13, rgb(col), 'l'); yy += 20
    sh.commit(); doc.set_metadata({'title': 'Grafik — ' + APP_NAME, 'keywords': 'UMAL-graph'}); return doc

class GraphDialog(QDialog):
    COLORS = ('#2f7cf6', '#e8132b')
    KEYS = [['x', '²', '³', '^', '√', '(', ')', '|x|'], ['sin', 'cos', 'tan', 'log', 'ln', 'log₂', 'π', 'e'],
            ['7', '8', '9', '/', '·', ',', '⌫', 'Temizle'], ['4', '5', '6', '+', '−', '1', '2', '3'], ['0', 'eˣ', '2ˣ', 'log₃', '√x']]
    INSERT = {'√': '√(', 'sin': 'sin(', 'cos': 'cos(', 'tan': 'tan(', 'log': 'log(', 'ln': 'ln(', 'log₂': 'log₂(', 'log₃': 'log₃(', 'eˣ': 'e^x', '2ˣ': '2^x', '√x': '√(x)'}
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Grafik çizici'); self.setModal(True)
        from PyQt5.QtWidgets import QLineEdit, QCheckBox
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(1500, scr.width()-40), min(860, scr.height()-40))
        box = QHBoxLayout(self); box.setContentsMargins(20, 16, 20, 16); box.setSpacing(18)
        left = QVBoxLayout(); left.setSpacing(8); box.addLayout(left, 5)
        t = QLabel('Grafik çizici'); t.setStyleSheet('font-size:21px;font-weight:600;'); left.addWidget(t)
        cfg = getattr(main, 'graph_cfg', {}); self.fields = []; self.errs = []
        for i, col in enumerate(self.COLORS):
            row = QHBoxLayout(); dot = QLabel('●'); dot.setStyleSheet('color:%s;font-size:22px;' % col); row.addWidget(dot)
            pre = QLabel('y ='); pre.setStyleSheet('font-size:20px;'); row.addWidget(pre)
            e = QLineEdit(cfg.get('f%d' % i, 'x² − 3x + 2' if i == 0 else '')); e.setMinimumHeight(52); e.setStyleSheet('font-size:22px;')
            e.setPlaceholderText('ikinci fonksiyon (isteğe bağlı)' if i else 'fonksiyon'); e.installEventFilter(self); e.textChanged.connect(self.later)
            row.addWidget(e, 1); left.addLayout(row); self.fields.append(e)
            er = QLabel(''); er.setStyleSheet('color:#ff8a95;font-size:14px;'); left.addWidget(er); self.errs.append(er)
        kb = QGridLayout(); kb.setSpacing(6); left.addLayout(kb)
        for r, keys in enumerate(self.KEYS):
            for c, k in enumerate(keys):
                b = QPushButton(k); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(48); b.setStyleSheet('font-size:19px;padding:0;')
                b.clicked.connect(lambda checked=False, k_=k: self.key(k_)); kb.addWidget(b, r, c)
        self.opts = {}
        orow = QHBoxLayout(); left.addLayout(orow)
        for key, name in (('roots', 'Kökler'), ('extrema', 'Tepe / uç noktalar'), ('cross', 'Kesişimler'), ('yx', 'y = x doğrusu')):
            c = QCheckBox(name); c.setChecked(cfg.get(key, key != 'yx')); c.toggled.connect(self.later); orow.addWidget(c); self.opts[key] = c
        left.addStretch(1)
        btns = QHBoxLayout(); left.addLayout(btns)
        no = QPushButton('Vazgeç'); no.setMinimumHeight(52); no.clicked.connect(self.reject); btns.addWidget(no)
        self.ok = QPushButton('Tahtaya aç'); self.ok.setObjectName('primary'); self.ok.setMinimumHeight(52); self.ok.clicked.connect(self.open_board); btns.addWidget(self.ok)
        self.preview = QLabel(); self.preview.setAlignment(Qt.AlignCenter); self.preview.setStyleSheet('background:white;border-radius:12px;'); box.addWidget(self.preview, 6)
        self.target = self.fields[0]; self.timer = QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(250); self.timer.timeout.connect(self.redraw)
        QTimer.singleShot(0, self.redraw)
    def eventFilter(self, o, e):
        if e.type() in (QEvent.FocusIn, QEvent.MouseButtonPress) and o in self.fields: self.target = o
        return False
    def key(self, k):
        t = self.target
        if k == '⌫': t.backspace()
        elif k == 'Temizle': t.clear()
        else: t.insert(self.INSERT.get(k, k))
        t.setFocus()
    def later(self, *a): self.timer.start()
    def funcs(self):
        out = []; ok = True
        for i, e in enumerate(self.fields):
            txt = e.text().strip(); self.errs[i].setText('')
            if not txt: continue
            fn, err = graph_compile(txt)
            if err: self.errs[i].setText(err); ok = False; continue
            if not any(fn(k/10) is not None for k in range(-100, 101)): self.errs[i].setText('Bu aralıkta tanımlı değil.'); ok = False; continue
            pretty = txt.replace('*', '·').replace('^2', '²').replace('^3', '³').replace('^x', 'ˣ')
            out.append((pretty, fn, self.COLORS[i]))
        return out, ok
    def redraw(self):
        fs, ok = self.funcs(); self.ok.setEnabled(bool(fs) and ok)
        if not fs: self.preview.setText('Fonksiyonu yazın'); return
        doc = graph_build(fs, {k: c.isChecked() for k, c in self.opts.items()})
        w = max(300, self.preview.width() - 16); z = w/doc[0].rect.width; pix = doc[0].get_pixmap(matrix=fitz.Matrix(z, z), alpha=False); doc.close()
        self.preview.setPixmap(QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()))
    def open_board(self):
        fs, ok = self.funcs()
        if not fs or not ok: return
        opts = {k: c.isChecked() for k, c in self.opts.items()}
        self.main.graph_cfg = dict(opts, f0=self.fields[0].text(), f1=self.fields[1].text())
        doc = graph_build(fs, opts); m = self.main; self.accept()
        name = 'y = ' + fs[0][0]; m.start_tab(name if len(name) < 28 else name[:26] + '…'); m.replace(doc); m.tabs_changed(); m.set_tool('pen')

class Ruler(QWidget):
    """Cetvel: sayfanın üstünde yarı saydam; gövdeden sürüklenir, sağ uçtaki tutamakla
    döndürülür (15°'lere yapışır), sol uçtaki × ile kalkar. Çizgiler sayfanın gerçek
    santimetresiyle; kenarına yakın çizilen kalem çizgisi kenara yapışır."""
    L, W, KNOB = 760, 86, 22
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.angle = 0.0; self.drag = None
        vp = main.scroll.viewport().geometry(); self.c = QPointF(vp.center().x(), vp.y() + vp.height()*.62)
        self.setCursor(Qt.SizeAllCursor); self.hide()
    def corners(self):
        a = math.radians(self.angle); ca, sa = math.cos(a), math.sin(a); L, W = self.L/2, self.W/2
        return [QPointF(self.c.x() + ca*x - sa*y, self.c.y() + sa*x + ca*y) for x, y in ((-L, -W), (L, -W), (L, W), (-L, W))]
    def local(self, x, y):
        a = math.radians(self.angle); return QPointF(self.c.x() + math.cos(a)*x - math.sin(a)*y, self.c.y() + math.sin(a)*x + math.cos(a)*y)
    def place(self):
        pts = self.corners(); xs = [q.x() for q in pts]; ys = [q.y() for q in pts]
        r = QRect(int(min(xs))-4, int(min(ys))-4, int(max(xs)-min(xs))+9, int(max(ys)-min(ys))+9)
        self.setGeometry(r)
        poly = QPolygonF([q - QPointF(r.topLeft()) for q in pts]); self.setMask(QRegion(poly.toPolygon())); self.update()
    def edge_for(self, vp, off):
        """Kalem başlangıcı kenara yakınsa o kenarın çizgisi: ((ox,oy),(dx,dy),(t0,t1)), görüntü koordinatında."""
        a = math.radians(self.angle); dx, dy = math.cos(a), math.sin(a); nx, ny = -dy, dx
        for side in (-1, 1):   # üst kenar, alt kenar (dışa doğru kalem kalınlığı kadar)
            o = self.local(0, side*(self.W/2 + off))
            dist = (vp.x() - o.x())*nx + (vp.y() - o.y())*ny; along = (vp.x() - o.x())*dx + (vp.y() - o.y())*dy
            if abs(dist) <= 36 and abs(along) <= self.L/2 + 10 and side*dist >= -14:
                return ((o.x(), o.y()), (dx, dy), (-self.L/2, self.L/2))
        return None
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.translate(-QPointF(self.geometry().topLeft()))
        p.translate(self.c); p.rotate(self.angle); L, W = self.L/2, self.W/2
        p.setPen(QPen(QColor('#b78a00'), 1.6)); p.setBrush(QColor(234, 179, 8, 92)); p.drawRoundedRect(QRectF(-L, -W, 2*L, 2*W), 10, 10)
        cm = 28.3465*self.main.board.scale; mm = cm/10; n = int((2*L - 40)/mm)
        f = p.font(); f.setPixelSize(13); f.setBold(True); p.setFont(f)
        for i in range(n + 1):   # üst kenar: santimetre ve milimetre çizgileri
            x = -L + 20 + i*mm; big = i % 10 == 0; mid = i % 5 == 0
            if mm < 3.5 and not (big or mid): continue
            p.setPen(QPen(QColor('#5c4400'), 1.4 if big else 1)); p.drawLine(QPointF(x, -W), QPointF(x, -W + (20 if big else 13 if mid else 8)))
            if big: p.drawText(QRectF(x - 20, -W + 20, 40, 18), Qt.AlignCenter, str(i//10))
        for i in range(n + 1):   # alt kenar da ölçülü
            x = -L + 20 + i*mm; big = i % 10 == 0
            if mm < 3.5 and i % 5: continue
            p.setPen(QPen(QColor('#5c4400'), 1.4 if big else 1)); p.drawLine(QPointF(x, W), QPointF(x, W - (14 if big else 8)))
        k = QPointF(L - 30, 4)   # döndürme tutamağı
        p.setPen(QPen(QColor('#b78a00'), 2)); p.setBrush(QColor(255, 255, 255, 230)); p.drawEllipse(k, self.KNOB, self.KNOB)
        p.setPen(QPen(QColor('#7a5b00'), 2.4)); p.drawArc(QRectF(k.x()-10, k.y()-10, 20, 20), 40*16, 280*16)
        p.drawLine(k + QPointF(7, -9), k + QPointF(10, -3)); p.drawLine(k + QPointF(10, -3), k + QPointF(4, -2))
        x_ = QPointF(-L + 28, 6)   # kaldır
        p.setPen(QPen(QColor('#b42318'), 2.6)); p.setBrush(QColor(255, 255, 255, 220)); p.drawEllipse(x_, 15, 15)
        p.drawLine(x_ + QPointF(-6, -6), x_ + QPointF(6, 6)); p.drawLine(x_ + QPointF(-6, 6), x_ + QPointF(6, -6))
        if self.drag and self.drag[0] == 'rotate':
            p.setPen(QColor('#3d2a00')); f.setPixelSize(18); p.setFont(f); p.drawText(QRectF(-60, -12, 120, 30), Qt.AlignCenter, '%d°' % round((-self.angle) % 360))
    def to_local(self, q):
        a = math.radians(-self.angle); d = q - self.c
        return QPointF(math.cos(a)*d.x() - math.sin(a)*d.y(), math.sin(a)*d.x() + math.cos(a)*d.y())
    def mousePressEvent(self, e):
        q = QPointF(e.pos()) + QPointF(self.geometry().topLeft()); l = self.to_local(q)
        if math.hypot(l.x() - (-self.L/2 + 28), l.y() - 6) < 22: self.main.toggle_ruler(False); return
        if math.hypot(l.x() - (self.L/2 - 30), l.y() - 4) < self.KNOB + 10:
            self.drag = ('rotate', math.degrees(math.atan2(q.y() - self.c.y(), q.x() - self.c.x())) - self.angle)
        else: self.drag = ('move', q - self.c)
    def mouseMoveEvent(self, e):
        if not self.drag: return
        q = QPointF(e.pos()) + QPointF(self.geometry().topLeft())
        if self.drag[0] == 'move': self.c = q - self.drag[1]
        else:
            a = math.degrees(math.atan2(q.y() - self.c.y(), q.x() - self.c.x())) - self.drag[1]
            near = round(a/15)*15; self.angle = near if abs(a - near) < 2.5 else a   # 0°, 15°, 30°, 45°, 90°…
        self.place()
    def mouseReleaseEvent(self, e): self.drag = None; self.update()

class FloatingBell(QWidget):
    """Tahtanın üstünde yüzen zil saati: ders, kalan süre, saat aralığı, ilerleme.
    Ders boyunca sade; son 5 dakikada sarı, son 1 dakikada kırmızı ve nabız gibi atar
    (teneffüste altın tonları). Dokun: küçük hap ↔ büyük kutu; sürükle: taşı."""
    BIG = (236, 124); SMALL = (196, 46)
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.small = False; self.offset = None
        self.press = None; self.moved = False; self.now = None; self.state = None
        self.setCursor(Qt.PointingHandCursor)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(500); self.tick()
    def phase(self, st):
        if st['left'] is None: return None
        if st['left'] <= 60 and st['kind'] in ('lesson', 'break'): return 'son1'
        if st['left'] <= 300 and st['kind'] in ('lesson', 'break'): return 'son5'
        return 'normal'
    def tick(self):
        import datetime
        st = bell_state(self.now or datetime.datetime.now()); self.state = st; ph = self.phase(st)
        show = ph is not None and not getattr(self.main, 'overlay_mode', False)
        big = ph in ('son5', 'son1') or not self.small
        w, h = self.BIG if big else self.SMALL
        if (self.width(), self.height()) != (w, h): self.setFixedSize(w, h); self.place()
        if show != self.isVisible(): self.setVisible(show); self.main.place_overlays()
        self.timer.setInterval(50 if ph == 'son1' else 500)
        if show: self.raise_(); self.update()
    def place(self):
        vp = self.main.scroll.viewport().geometry()
        if self.offset is None: x, y = vp.right() - self.width() - 14, vp.y() + 14
        else: x, y = vp.right() - self.offset[0] - self.width(), vp.y() + self.offset[1]
        self.move(max(vp.x(), min(x, vp.right() - self.width())), max(vp.y(), min(y, vp.bottom() - self.height())))
    def colors(self, st, ph):
        brk = st['kind'] == 'break'
        if ph == 'son1': return QColor('#ff6b7a'), QColor(255, 107, 122, 40), QColor('#bb1826')
        if ph == 'son5': return QColor('#ffc526'), QColor(255, 197, 38, 30), QColor('#8a6514')
        if brk: return QColor('#e7c46a'), QColor(201, 154, 46, 26), QColor('#8a6514')
        return QColor('#ffffff'), QColor(14, 28, 50, 205), QColor('#1d4f8f')
    def font(self, px, bold=False):
        from PyQt5.QtGui import QFont
        f = QFont(ui_fonts().get('Poppins-Regular') or 'DejaVu Sans'); f.setPixelSize(px); f.setBold(bold); return f
    def paintEvent(self, e):
        st = self.state
        if st is None or st['left'] is None: return
        ph = self.phase(st); fg, bg, tagc = self.colors(st, ph)
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); r = QRectF(1.5, 1.5, W-3, H-3)
        if ph == 'son1':   # nabız: çerçeve dışına yayılan hafif ışık
            k = (math.sin(time.monotonic()*5.2) + 1)/2
            for i in range(3): c = QColor(fg); c.setAlpha(int(70*k/(i+1))); p.setPen(QPen(c, 2)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r.adjusted(-i, -i, i, i).adjusted(2, 2, -2, -2), 16, 16)
        base = QColor(14, 28, 50, 215); p.setPen(Qt.NoPen); p.setBrush(base); p.drawRoundedRect(r, 16, 16)
        p.setBrush(bg); p.drawRoundedRect(r, 16, 16)
        border = QColor(fg) if ph in ('son5', 'son1') else QColor(255, 255, 255, 45)
        p.setPen(QPen(border, 2 if ph in ('son5', 'son1') else 1)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 16, 16)
        l = st['left']; cd = ('%d:%02d:%02d' % (l//3600, l%3600//60, l%60)) if l >= 3600 else ('%d:%02d' % (l//60, l%60))
        label = 'zile kalan' if st['kind'] in ('lesson', 'prep') else 'derse kalan' if st['kind'] == 'break' else 'okula kalan'
        p.setFont(self.font(12, True)); tw = p.fontMetrics().horizontalAdvance(st['tag']) + 16
        if H < 60:   # küçük hap: etiket + süre
            tr = QRectF(10, (H-22)/2, tw, 22); p.setPen(Qt.NoPen); p.setBrush(tagc); p.drawRoundedRect(tr, 11, 11)
            p.setPen(Qt.white); p.drawText(tr, Qt.AlignCenter, st['tag'])
            p.setPen(fg); p.setFont(self.font(20, True)); p.drawText(QRectF(tr.right()+8, 0, W-tr.right()-14, H), Qt.AlignVCenter|Qt.AlignLeft, cd); return
        tr = QRectF((W-tw)/2, 10, tw, 22); p.setPen(Qt.NoPen); p.setBrush(tagc); p.drawRoundedRect(tr, 11, 11)
        p.setPen(Qt.white); p.drawText(tr, Qt.AlignCenter, st['tag'])
        p.setPen(fg); p.setFont(self.font(40 if l < 3600 else 32, True)); p.drawText(QRectF(0, 32, W, 48), Qt.AlignCenter, cd)
        sub = QColor(fg) if ph else QColor('#9fb3cf'); sub.setAlpha(200 if ph in ('son5', 'son1') else 255)
        p.setPen(sub); p.setFont(self.font(12)); p.drawText(QRectF(0, 80, W, 18), Qt.AlignCenter, label + ('  ·  ' + st['span'].replace(' – ', '–') if st['span'] else ''))
        bar = QRectF(18, H-17, W-36, 5); p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 30)); p.drawRoundedRect(bar, 2.5, 2.5)
        fill = QColor('#ff6b7a') if ph == 'son1' else QColor('#ffc526') if ph == 'son5' or st['kind'] == 'break' else QColor('#3d8bff')
        if st['frac'] > 0: p.setBrush(fill); p.drawRoundedRect(QRectF(bar.x(), bar.y(), bar.width()*min(1, st['frac']), bar.height()), 2.5, 2.5)
    def mousePressEvent(self, e): self.press = (e.globalPos(), self.pos()); self.moved = False
    def mouseMoveEvent(self, e):
        if self.press is None: return
        d = e.globalPos() - self.press[0]
        if self.moved or abs(d.x()) + abs(d.y()) > 10:
            self.moved = True; vp = self.main.scroll.viewport().geometry(); q = self.press[1] + d
            self.offset = (vp.right() - q.x() - self.width(), q.y() - vp.y()); self.place(); self.main.place_overlays()
    def mouseReleaseEvent(self, e):
        if self.press is not None and not self.moved: self.small = not self.small; self.tick(); self.main.place_overlays()
        self.press = None

class BellClock(QWidget):
    """Saat ve zile kalan süre: üst şeritte, PDF sekmelerinin sağında, tek satır."""
    W, H = 700, 42
    def __init__(self, parent=None, show_time=True):
        super().__init__(parent); self.show_time = show_time
        if not show_time: self.W = 450   # saat/tarih sol paneldeki büyük saatte; "Sonra" satırı yok
        self.setFixedSize(self.W, self.H); self.setAttribute(Qt.WA_TranslucentBackground)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(500)
        self.now = None   # tests can pin a time
        self.chimed = None; self.sound_dir = None
        if not show_time: self.fit_width()
    WARN_S = 300   # dersin bitmesine 5 dk kala hoş bir ses
    def fit_width(self, st=None):
        """Kutu içeriği kadar: ders dışında yalnızca etiket (boş uzun kutu kalmaz)."""
        import datetime
        from PyQt5.QtGui import QFontMetrics
        st = st or bell_state(self.now or datetime.datetime.now())
        tw = QFontMetrics(self.font(12, True)).horizontalAdvance(st['tag']) + 14
        if st['left'] is None: w = int(tw + 28)
        else:
            l = st['left']; cd = ('%d:%02d:%02d' % (l//3600, l%3600//60, l%60)) if l >= 3600 else ('%d:%02d' % (l//60, l%60))
            label = 'zile kalan' if st['kind'] in ('lesson','prep') else 'derse kalan' if st['kind'] == 'break' else 'okula kalan'
            w = 12 + 190 + 12 + QFontMetrics(self.font(22, True)).horizontalAdvance('0:00:00' if l >= 3600 else '00:00') + 6 + QFontMetrics(self.font(12)).horizontalAdvance(label) + 14
        if w != self.width(): self.setFixedWidth(w)
    def tick(self):
        import datetime
        now = self.now or datetime.datetime.now(); st = bell_state(now)
        # Yalnızca 5. dakikaya girerken bir kez (uygulama ders sonuna yakın açılırsa çalmaz).
        if st['kind'] == 'lesson' and st['left'] is not None and self.WARN_S - 30 < st['left'] <= self.WARN_S:
            key = (now.date(), st['tag'])
            if key != self.chimed:
                self.chimed = key
                try: play_sound(warn_chime_file(self.sound_dir or tempfile.gettempdir()))
                except Exception: pass
        if not self.show_time: self.fit_width(st)
        self.update()
    @staticmethod
    def font(px, bold=False):
        from PyQt5.QtGui import QFont
        f = QFont(ui_fonts().get('Poppins-Regular') or 'DejaVu Sans'); f.setPixelSize(px); f.setBold(bold); return f
    def paintEvent(self, e):
        import datetime
        now = self.now or datetime.datetime.now(); st = bell_state(now)
        if not self.show_time and st['left'] is None:   # ders dışı: yalnızca etiket, ortada
            p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); W_ = self.width()
            p.setPen(QPen(QColor(255, 255, 255, 30), 1)); p.setBrush(QColor(255, 255, 255, 14)); p.drawRoundedRect(QRectF(.5, .5, W_-1, self.H-1), 14, 14)
            p.setFont(self.font(12, True)); tw = p.fontMetrics().horizontalAdvance(st['tag'])+14
            p.setPen(Qt.NoPen); p.setBrush(QColor('#3a5577')); r_ = QRectF((W_-tw)/2, (self.H-22)/2, tw, 22); p.drawRoundedRect(r_, 11, 11)
            p.setPen(Qt.white); p.drawText(r_, Qt.AlignCenter, st['tag']); p.end(); return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        urgent = st['kind'] == 'lesson' and st['left'] is not None and st['left'] <= 120
        accent = QColor('#e23b4d') if urgent else QColor('#c99a2e') if st['kind'] == 'break' else QColor('#3a5577')
        p.setPen(QPen(accent, 1.5)); p.setBrush(QColor(255, 255, 255, 14)); p.drawRoundedRect(QRectF(.75, .75, self.width()-1.5, self.H-1.5), 14, 14)
        muted = QColor('#8fa3bd'); H = self.H; x = 12
        def text(s_, px, color, bold=False, top=0, h=H, align=Qt.AlignLeft|Qt.AlignVCenter, width=None):
            p.setPen(color); p.setFont(self.font(px, bold)); w = width or p.fontMetrics().horizontalAdvance(s_)
            p.drawText(QRectF(x, top, w, h), align, s_); return w
        # saat + saniye, altında tarih yok (yer kazanmak için tarih sağ uçta)
        if self.show_time:
            x += text(now.strftime('%H:%M'), 26, Qt.white, True); x += 2
            x += text(':%02d' % now.second, 13, muted, top=4) + 12
            p.setPen(QPen(QColor('#3a5577'), 1)); p.drawLine(QPointF(x, 8), QPointF(x, H-8)); x += 12
        # ders etiketi + saat aralığı (üstte), ilerleme çubuğu (altta)
        tagc = QColor('#8a6514') if st['kind'] == 'break' else QColor('#1d4f8f') if st['kind'] in ('lesson','prep','before') else QColor('#3a5577')
        p.setFont(self.font(12, True)); tw = p.fontMetrics().horizontalAdvance(st['tag'])+14
        p.setPen(Qt.NoPen); p.setBrush(tagc); p.drawRoundedRect(QRectF(x, 5, tw, 20), 10, 10)
        p.setPen(Qt.white); p.drawText(QRectF(x, 5, tw, 20), Qt.AlignCenter, st['tag'])
        block = 190
        p.setPen(muted); p.setFont(self.font(12)); p.drawText(QRectF(x+tw+6, 5, block-tw-6, 20), Qt.AlignLeft|Qt.AlignVCenter, st['span'])
        if st['left'] is not None:
            bar = QColor('#e23b4d') if urgent else QColor('#ffc526') if st['kind'] == 'break' else QColor('#3d8bff')
            p.setPen(Qt.NoPen); p.setBrush(QColor('#26405f')); p.drawRoundedRect(QRectF(x, 30, block, 5), 2.5, 2.5)
            if st['frac'] > 0: p.setBrush(bar); p.drawRoundedRect(QRectF(x, 30, block*min(1, st['frac']), 5), 2.5, 2.5)
        x += block + 12
        if st['left'] is not None:
            l = st['left']; cd = ('%d:%02d:%02d' % (l//3600, l%3600//60, l%60)) if l >= 3600 else ('%d:%02d' % (l//60, l%60))
            color = QColor('#ff6b7a') if urgent else QColor('#ffc526') if st['kind'] == 'break' else Qt.white
            x += text(cd, 22, color, True) + 6
            label = 'zile kalan' if st['kind'] in ('lesson','prep') else 'derse kalan' if st['kind'] == 'break' else 'okula kalan'
            x += text(label, 12, muted) + 12
        # sağda: tarih (üst) ve sıradaki ders (alt)
        rest = self.width() - x - 10
        p.setPen(muted); p.setFont(self.font(12))
        if self.show_time:
            date = '%s · %d %s' % (TR_DAYS[now.weekday()], now.day, TR_MONTHS[now.month-1])
            p.drawText(QRectF(x, 3, rest, 18), Qt.AlignRight|Qt.AlignVCenter, date)
            p.drawText(QRectF(x, 21, rest, 18), Qt.AlignRight|Qt.AlignVCenter, p.fontMetrics().elidedText(st['next'], Qt.ElideRight, int(rest)))

        p.end()

def warn_chime_file(folder):
    """Dersin bitmesine 5 dk kala: yumuşak, yükselen üç notalı çan (bir kez üretilir)."""
    import wave, struct
    path = os.path.join(folder, 'ders-uyari.wav')
    if os.path.isfile(path): return path
    os.makedirs(folder, exist_ok=True)
    rate = 44100; frames = []
    notes = [(0.0, 523.25), (0.32, 659.25), (0.64, 783.99)]   # C5 → E5 → G5
    for i in range(int(rate*2.8)):
        t = i/rate; v = 0.0
        for start, f in notes:
            dt = t-start
            if dt < 0: continue
            env = min(1, dt/.012)*math.exp(-dt*2.2)
            v += env*(math.sin(2*math.pi*f*dt) + .3*math.sin(2*math.pi*2*f*dt) + .1*math.sin(2*math.pi*3*f*dt))
        frames.append(struct.pack('<h', int(max(-1, min(1, v*.22))*32767)))
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b''.join(frames))
    return path

def rapt_sound_file(folder):
    """Short paper 'rapt' (slap + soft thump), generated once."""
    import wave, struct, random
    path = os.path.join(folder, 'rapt.wav')
    if os.path.isfile(path): return path
    os.makedirs(folder, exist_ok=True); rate = 44100; rng = random.Random(3); frames = []
    for i in range(int(rate*.16)):
        t = i/rate
        v = rng.uniform(-1, 1)*math.exp(-t*55)*.55 + math.sin(2*math.pi*140*t)*math.exp(-t*30)*.6
        frames.append(struct.pack('<h', int(max(-1, min(1, v*.5))*32767)))
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b''.join(frames))
    return path

def paint_postit(p, rect, pix, color, tilt=0, shadow=True):
    """A paper note: colour, tape strip, the captured picture inside."""
    p.save(); p.translate(rect.center()); p.rotate(tilt); r = QRectF(-rect.width()/2, -rect.height()/2, rect.width(), rect.height())
    if shadow: p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 70)); p.drawRect(r.translated(4, 5))
    p.setPen(Qt.NoPen); p.setBrush(QColor(color)); p.drawRect(r)
    m = max(6, r.width()*.05); top = max(10, r.height()*.1)
    inner = QRectF(r.left()+m, r.top()+top, r.width()-2*m, r.height()-top-m)
    if pix is not None and not pix.isNull():
        s = min(inner.width()/pix.width(), inner.height()/pix.height()); w, h = pix.width()*s, pix.height()*s
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawPixmap(QRectF(inner.center().x()-w/2, inner.center().y()-h/2, w, h), pix, QRectF(pix.rect()))
    p.setBrush(QColor(255, 255, 255, 140)); tw = r.width()*.32
    p.rotate(-2); p.drawRect(QRectF(-tw/2, r.top()-6, tw, 14)); p.restore()

class PostItCard(QWidget):
    W = 300   # wide enough that a question stays readable on the board
    def __init__(self, pano, pix, color, name, tilt):
        super().__init__(pano.holder); self.pano, self.pix, self.color, self.name, self.tilt = pano, pix, color, name, tilt
        # Height follows the picture, so the whole question shows (no tiny strip).
        paper = self.W-24; m = max(6, paper*.05); inner = paper-2*m
        ratio = pix.height()/max(1, pix.width()) if pix is not None and not pix.isNull() else .6
        self.H = int(max(140, min(420, inner*ratio + max(10, (inner*ratio+30)*.1) + m + 30)))
        self.pending = False; self.setFixedSize(self.W, self.H); self.setCursor(Qt.PointingHandCursor)
        self.setToolTip('Dokunun: büyür · sağ üstteki ×: kaldırır')
    def close_rect(self): return QRectF(self.W-36, 4, 30, 30)
    def paintEvent(self, e):
        if self.pending: return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        paint_postit(p, QRectF(10, 12, self.W-24, self.H-26), self.pix, self.color, self.tilt)
        c = self.close_rect(); p.setPen(Qt.NoPen); p.setBrush(QColor(18, 32, 52, 200)); p.drawEllipse(c)
        p.setPen(QPen(Qt.white, 2.4, Qt.SolidLine, Qt.RoundCap)); d = 7
        p.drawLine(QPointF(c.center().x()-d, c.center().y()-d), QPointF(c.center().x()+d, c.center().y()+d))
        p.drawLine(QPointF(c.center().x()+d, c.center().y()-d), QPointF(c.center().x()-d, c.center().y()+d)); p.end()
    def mouseReleaseEvent(self, e):
        if self.pending: return
        if self.close_rect().adjusted(-8, -8, 8, 8).contains(QPointF(e.pos())): self.pano.main.remove_postit(self)
        else: self.pano.main.show_postit(self)

class PostItPano(QScrollArea):
    """Post-it panosu: a narrow column right of the board."""
    TILTS = (-3, 2, -1.5, 3)
    def __init__(self, main):
        super().__init__(); self.main = main; self.cards = []
        self.setFixedWidth(PostItCard.W+18); self.setWidgetResizable(True); self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.holder = QWidget(); self.box = QVBoxLayout(self.holder); self.box.setContentsMargins(4, 6, 4, 6); self.box.setSpacing(4)
        head = QHBoxLayout(); head.setContentsMargins(4, 0, 0, 0)
        title = QLabel('Post-it panosu'); title.setStyleSheet('color:#8fa3bd;font-size:13px;'); head.addWidget(title, 1)
        hide = QPushButton('Gizle  ›'); hide.setToolTip('Panoyu gizle (post-it\'ler silinmez)'); hide.setFixedHeight(38)
        hide.setStyleSheet('QPushButton{padding:0 12px;min-height:38px;max-height:38px;font-size:14px;}')
        hide.clicked.connect(lambda: self.main.set_pano_hidden(True)); head.addWidget(hide)
        self.box.addLayout(head); self.box.addStretch(); self.setWidget(self.holder)
    def add(self, pix, color, name, pending=False):
        card = PostItCard(self, pix, color, name, self.TILTS[len(self.cards) % len(self.TILTS)]); card.pending = pending
        self.box.insertWidget(self.box.count()-1, card); self.cards.append(card); return card
    def remove(self, card):
        if card in self.cards: self.cards.remove(card)
        card.hide(); card.deleteLater()
    def clear(self):
        for c in list(self.cards): self.remove(c)

class PostItFlight(QWidget):
    """Peel off (lift and tilt), shrink, fly to the board, land."""
    def __init__(self, parent, pix, color, start, end, tilt, done):
        super().__init__(parent); self.pix, self.color, self.start, self.end, self.tilt, self.done = pix, color, QRectF(start), QRectF(end), tilt, done
        self.setAttribute(Qt.WA_TransparentForMouseEvents); self.setGeometry(parent.rect()); self.t = 0; self.show(); self.raise_()
        self.anim = QVariantAnimation(self); self.anim.setStartValue(0.0); self.anim.setEndValue(1.0); self.anim.setDuration(720)
        self.anim.valueChanged.connect(self.step); self.anim.finished.connect(self.finish); self.anim.start()
    def step(self, v): self.t = v; self.update()
    def finish(self): self.hide(); self.deleteLater(); self.done()
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); t = self.t
        if t < .3:   # peel: lift a little, tilt, paper colour comes in
            u = t/.3; r = self.start; c = r.center(); k = 1+.05*u
            rect = QRectF(c.x()-r.width()*k/2, c.y()-r.height()*k/2-10*u, r.width()*k, r.height()*k); rot = -6*u
            col = QColor(self.color); col.setAlpha(int(255*u))
            p.save(); p.translate(rect.center()); p.rotate(rot); p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, int(60*u)))
            p.drawRect(QRectF(-rect.width()/2+6, -rect.height()/2+8, rect.width(), rect.height())); p.setBrush(Qt.white)
            p.drawRect(QRectF(-rect.width()/2, -rect.height()/2, rect.width(), rect.height())); p.restore()
            paint_postit(p, rect, self.pix, col.name() if u > .5 else '#ffffff', rot, shadow=False)
        else:        # fly with a small overshoot, then land
            u = QEasingCurve(QEasingCurve.OutBack).valueForProgress((t-.3)/.7)
            s0 = self.start; s0 = QRectF(s0.center().x()-s0.width()*.525, s0.center().y()-s0.height()*.525-10, s0.width()*1.05, s0.height()*1.05)
            e = QRectF(self.end.x()+10, self.end.y()+12, self.end.width()-24, self.end.height()-26)
            lerp = lambda a, b: a+(b-a)*u
            rect = QRectF(lerp(s0.x(), e.x()), lerp(s0.y(), e.y()), max(10, lerp(s0.width(), e.width())), max(10, lerp(s0.height(), e.height())))
            paint_postit(p, rect, self.pix, self.color, lerp(-6, self.tilt))
        p.end()

class PostItBig(QWidget):
    """Tap a post-it: it opens large over the board; tap again to put it back."""
    def __init__(self, scroll, pix, color):
        super().__init__(scroll); self.pix, self.color = pix, color; vp = scroll.viewport().geometry()
        # Card sized to the picture: as large as fits, small paper margins.
        mw, mh = vp.width()*.82, vp.height()*.8
        sc = min((mw-60)/max(1, pix.width()), (mh-90)/max(1, pix.height()), 3.0)
        w = int(pix.width()*sc+60); h = int(pix.height()*sc+90)
        self.setGeometry(vp.x()+(vp.width()-w)//2, vp.y()+(vp.height()-h)//2, w, h); self.setCursor(Qt.PointingHandCursor)
        self.setToolTip('Dokunun: küçülür'); self.show(); self.raise_()
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        paint_postit(p, QRectF(14, 18, self.width()-30, self.height()-36), self.pix, self.color, 0); p.end()
    def mouseReleaseEvent(self, e): self.hide(); self.deleteLater()

class ThemePicker(QWidget):
    """Touch-sized theme chooser with live colour + pattern previews."""
    def __init__(self, main):
        super().__init__(main, Qt.Popup|Qt.FramelessWindowHint)
        self.main = main; self.setAttribute(Qt.WA_TranslucentBackground)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        panel = QWidget(); panel.setObjectName('picker'); outer.addWidget(panel)
        panel.setStyleSheet('QWidget#picker{background:#0b1426;border:1px solid #2a3b57;border-radius:18px;} QLabel{background:transparent;color:#e8eefc;}')
        layout = QVBoxLayout(panel); layout.setContentsMargins(18, 14, 18, 18); layout.setSpacing(12)
        title = QLabel('Tema seçin'); title.setStyleSheet('font-size:19px;font-weight:bold;color:#9fb3d1;'); layout.addWidget(title)
        grid = QGridLayout(); grid.setSpacing(12); layout.addLayout(grid)
        for i, key in enumerate(THEME_ORDER):
            t = THEMES[key]; tile = main.theme_tile(key)
            b = QPushButton(); b.setFixedSize(176, 118); b.setCursor(Qt.PointingHandCursor); b.setToolTip(t['name'])
            current = key == main.theme
            b.setStyleSheet('''QPushButton{border:%s;border-radius:14px;background-color:%s;background-image:url("%s");text-align:left;min-height:118px;max-height:118px;min-width:176px;max-width:176px;padding:0;}
                QPushButton:hover{border:2px solid %s;}''' % ('3px solid %s' % t['selb'] if current else '1px solid %s' % t['border'], t['view'], tile.replace('\\\\','/'), t['selb']))
            inner = QVBoxLayout(b); inner.setContentsMargins(10, 8, 10, 8); inner.addStretch()
            chip = QLabel(('✓  ' if current else '')+t['name']); chip.setWordWrap(True)
            chip.setStyleSheet('QLabel{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %s,stop:1 %s);color:white;font-size:%dpx;font-weight:bold;border-radius:10px;padding:6px 10px;}' % (t['sel2'], t['sel'], 14 if len(t['name']) > 14 else 17))
            inner.addWidget(chip)
            b.clicked.connect(lambda checked=False, k=key: (self.main.apply_theme(k), self.close()))
            grid.addWidget(b, i//4, i % 4)

class ScreenToolbar(QWidget):
    def __init__(self, session):
        # A normal independent window stays reachable from the taskbar when
        # the main window is hidden, unlike tool windows grouped by some WMs.
        super().__init__(None,Qt.Window|Qt.WindowStaysOnTopHint)
        self.session=session;self.drag_from=None
        self.setWindowTitle('Ekrana yaz • Ümraniye Merkez Anadolu Lisesi')
        self.setWindowIcon(QIcon(LOGO))
    # Frameless panel: drag from any empty area (buttons keep their clicks).
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton:self.drag_from=e.globalPos()-self.frameGeometry().topLeft()
    def mouseMoveEvent(self,e):
        if self.drag_from is not None:self.move(e.globalPos()-self.drag_from)
    def mouseReleaseEvent(self,e):self.drag_from=None
    def moveEvent(self,e):
        super().moveEvent(e)
        if self is self.session.toolbar:self.session.update_mask()
    def resizeEvent(self,e):
        super().resizeEvent(e)
        if self is self.session.toolbar:self.session.update_mask()
    def closeEvent(self,event):
        event.ignore(); self.session.leave()

class ScreenSession:
    """Independent screen-coordinate strokes and history, retained across mode switches."""
    overlay_mode=True
    @property
    def color(self): return self._color
    @color.setter
    def color(self, value):
        self._color = value
        if hasattr(self,'tools'): paint_tool_buttons(self.tools, self.tool_labels, self.tool, value)
    def __init__(self, main):
        self.main=main
        self.doc=fitz.open(); self.doc.new_page(width=1920,height=1080)
        self.page=0; self.tool='pen'; self.color='#e8132b'; self.backdrop=None
        self.marks={};self.undo_stack=[];self.redo_stack=[];self.dirty=False
        self.toolbar=ScreenToolbar(self)
        self.active=False
        self.floating=ScreenToolbar(self)
        self.floating.setWindowFlags(Qt.Window|Qt.WindowStaysOnTopHint|Qt.CustomizeWindowHint|Qt.WindowTitleHint)
        self.floating.setWindowTitle('Serbest kalem')
        self.floating.setWindowIcon(QIcon(LOGO))
        floating_layout=QHBoxLayout(self.floating)
        write=QPushButton('Kalem');write.setIcon(tool_icon('Kalem'));write.clicked.connect(self.resume)
        back=QPushButton('Tahta');back.clicked.connect(self.leave)
        floating_layout.addWidget(write);floating_layout.addWidget(back)
        self.board=Board(self)
        self.board.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.board.setAttribute(Qt.WA_TranslucentBackground)
        self.board.setAttribute(Qt.WA_QuitOnClose,False)
        self.board.setCursor(Qt.CrossCursor)
        self.toolbar.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.toolbar.setStyleSheet('''QWidget{background:#0a203e;color:white;font-family:"DejaVu Sans";font-size:13px;}
            QWidget#panel{border:1px solid #526780;border-radius:10px;}
            QPushButton#primary{background:#c61d2d;border:1px solid #e23b4d;font-weight:bold;font-size:14px;}
            QPushButton,QSpinBox{background:#203957;border:1px solid #526780;border-radius:8px;padding:0;}
            QPushButton:checked{background:#bc1b2b;border:2px solid #e23b4d;} QPushButton:hover{background:#365575;}''')
        self.floating.setStyleSheet('''QWidget{background:#0a203e;color:white;font-family:"DejaVu Sans";font-size:14px;}
            QPushButton{background:#203957;border:1px solid #526780;border-radius:7px;padding:9px;min-height:25px;}
            QPushButton:hover{background:#365575;}''')
        # Compact vertical panel on the left: icon-only buttons in two
        # columns; names are shown as tooltips. No full-width top band.
        outer=QHBoxLayout(self.toolbar);outer.setContentsMargins(0,0,0,0);outer.setSpacing(4);outer.setAlignment(Qt.AlignTop)
        panel=QWidget();panel.setObjectName('panel');outer.addWidget(panel)
        layout=QVBoxLayout(panel);layout.setContentsMargins(8,6,8,8);layout.setSpacing(6)
        grip=QLabel('⋮⋮');grip.setAlignment(Qt.AlignCenter);grip.setToolTip('Sürükleyerek taşıyın');grip.setStyleSheet('color:#8fa3bd;font-size:15px;')
        layout.addWidget(grip)
        grid=QGridLayout();grid.setSpacing(6);layout.addLayout(grid)
        def icon_button(label):
            b=QPushButton();b.setIcon(tool_icon(label));b.setIconSize(QSize(28,28));b.setFixedSize(54,54)
            b.setToolTip(label);b.setAccessibleName(label);return b
        # Only this panel stays on screen: "Masaüstünü kullan" keeps it
        # visible (no separate floating window); Kalem returns to writing.
        to_pdf=QPushButton("PDF'ye yaz");to_pdf.setIcon(tool_icon("PDF'ye yaz"));to_pdf.setIconSize(QSize(26,26))
        to_pdf.setObjectName('primary');to_pdf.setFixedHeight(54);to_pdf.setToolTip('Ekran modunu kapatıp PDF üzerine kalemle yazın')
        to_pdf.clicked.connect(self.write_on_pdf);grid.addWidget(to_pdf,0,0,1,2)
        self.tools={};self.tool_labels={}
        for i,(key,label) in enumerate([('pen','Kalem'),('highlight','Fosforlu'),('eraser','Silgi'),('smart','Akıllı seçim')]):
            b=icon_button(label);b.setCheckable(True);b.clicked.connect(lambda checked=False,k=key:self.set_tool(k))
            grid.addWidget(b,1+i//2,i%2);self.tools[key]=b;self.tool_labels[key]=label
        self.tools['pen'].setChecked(True)
        paint_tool_buttons(self.tools,self.tool_labels,self.tool,self.color)
        for i,(label,fn) in enumerate([('Geri al',self.undo),('İleri al',self.redo),('Tümünü sil',self.clear),('Notları PDF kaydet',self.save_notes)]):
            b=icon_button(label);b.clicked.connect(lambda checked=False,fn=fn:fn());grid.addWidget(b,3+i//2,i%2)
        self.mode=icon_button('Masaüstünü kullan');self.mode.setCheckable(True)
        self.mode.toggled.connect(self.set_passthrough)
        grid.addWidget(self.mode,5,0)
        dash=icon_button('Kesikli çizgi');dash.setCheckable(True);dash.clicked.connect(lambda checked=False:self.set_tool('dash'))
        grid.addWidget(dash,5,1);self.tools['dash']=dash;self.tool_labels['dash']='Kesikli çizgi'
        area=icon_button('Alan silgisi');area.setCheckable(True);area.clicked.connect(lambda checked=False:self.set_tool('area_eraser'))
        grid.addWidget(area,6,0);self.tools['area_eraser']=area;self.tool_labels['area_eraser']='Alan silgisi'
        # Kalem stili: the button shows the current style; tap opens the
        # five choices beside the panel (inside the same window, so the
        # input hole in the ink layer covers them too).
        self.pen_style='fluid'
        self.style_button=icon_button('Kalem stili');self.style_button.setIcon(tool_icon('Akıcı'));self.style_button.setToolTip('Kalem stili: Akıcı')
        self.style_button.clicked.connect(self.toggle_styles);grid.addWidget(self.style_button,6,1)
        self.style_panel=QWidget();self.style_panel.setObjectName('panel');outer.addWidget(self.style_panel,0,Qt.AlignTop)
        styles=QVBoxLayout(self.style_panel);styles.setContentsMargins(6,6,6,6);styles.setSpacing(6)
        self.style_buttons={}
        for key,label in PEN_STYLES:
            b=QPushButton(' '+label);b.setIcon(tool_icon({'fluid':'Akıcı','laser':'Neon'}.get(key)) if key in ('fluid','laser') else style_icon(key,28));b.setIconSize(QSize(28,28));b.setFixedSize(150,48);b.setCheckable(True)
            b.setAccessibleName('Kalem stili: '+label);b.setStyleSheet('QPushButton{text-align:left;padding-left:8px;font-size:14px;}')
            b.clicked.connect(lambda checked=False,k=key:self.set_pen_style(k));styles.addWidget(b);self.style_buttons[key]=b
        self.style_buttons['fluid'].setChecked(True);self.style_panel.hide()
        self.nib=QComboBox(self.toolbar);self.nib.addItem('Yuvarlak uç','round');self.nib.hide()
        self.colors=QComboBox(self.toolbar);self.colors.hide()
        palette=[('Kırmızı','#e8132b'),('Siyah','#111111'),('Mavi','#0057ff'),('Yeşil','#00a24a'),('Sarı','#ffe14d'),('Beyaz','#ffffff'),('Mor','#8a2be2'),('Pembe','#ff2d95')]   # 4 Sarı, 5 Beyaz: used below
        for label,c in palette:self.colors.addItem(label,c)
        dots=QGridLayout();dots.setSpacing(6);layout.addLayout(dots)
        self.color_buttons=[]
        for i,(label,c) in enumerate(palette):
            b=QPushButton();b.setFixedSize(54,54);b.setCheckable(True);b.setToolTip(label);b.setAccessibleName(label)
            b.setStyleSheet('QPushButton{background:'+c+';border:2px solid #8292a8;border-radius:27px;}QPushButton:checked{border:4px solid #ffffff;}')
            b.clicked.connect(lambda checked=False,n=i:self.colors.setCurrentIndex(n))
            dots.addWidget(b,i//2,i%2);self.color_buttons.append(b)
        self.color_buttons[0].setChecked(True)
        self.colors.currentIndexChanged.connect(lambda:self.set_color(self.colors.currentData()))
        self.colors.currentIndexChanged.connect(lambda n:[b.setChecked(k==n) for k,b in enumerate(self.color_buttons)])
        # Screen backdrop: transparent (desktop visible) or a full board.
        backdrops=QHBoxLayout();backdrops.setSpacing(6);layout.addLayout(backdrops)
        self.backdrop_buttons={}
        for label,c in [('Saydam (masaüstü görünür)',None),('Beyaz tahta','#ffffff'),('Yeşil tahta','#214d38'),('Kara tahta','#121214')]:
            b=QPushButton('∅' if c is None else '');b.setFixedSize(26,26);b.setCheckable(True);b.setToolTip(label);b.setAccessibleName(label)
            b.setStyleSheet('QPushButton{background:%s;border:2px solid #8292a8;border-radius:5px;color:#b9c6d8;font-size:14px;}QPushButton:checked{border:3px solid #ffffff;}' % (c or '#0a203e'))
            b.clicked.connect(lambda checked=False,c=c:self.set_backdrop(c));backdrops.addWidget(b);self.backdrop_buttons[c]=b
        self.backdrop_buttons[None].setChecked(True)
        size=QHBoxLayout();size.setSpacing(4);layout.addLayout(size)
        self.width=QSpinBox();self.width.setRange(1,16);self.width.setValue(3);self.width.setSuffix(' pt')
        self.width.setButtonSymbols(QSpinBox.NoButtons);self.width.setAlignment(Qt.AlignCenter);self.width.setReadOnly(True);self.width.setFixedSize(46,36)
        minus=QPushButton('−');minus.setFixedSize(34,36);minus.setAccessibleName('Kalemi incelt');minus.setToolTip('Kalemi incelt');minus.clicked.connect(self.width.stepDown);size.addWidget(minus)
        size.addWidget(self.width)
        plus=QPushButton('+');plus.setFixedSize(34,36);plus.setAccessibleName('Kalemi kalınlaştır');plus.setToolTip('Kalemi kalınlaştır');plus.clicked.connect(self.width.stepUp);size.addWidget(plus)
        self.hint=QLabel('Esc: tahtaya dön');self.hint.setWordWrap(True);self.hint.setAlignment(Qt.AlignCenter)
        self.hint.setStyleSheet('color:#b9c6d8;font-size:11px;');self.hint.setFixedWidth(114);layout.addWidget(self.hint)
        for parent in (self.board,self.toolbar):
            QShortcut(QKeySequence('Escape'),parent,activated=self.leave)
            QShortcut(QKeySequence('Ctrl+Z'),parent,activated=self.undo)
            QShortcut(QKeySequence('Ctrl+Shift+Z'),parent,activated=self.redo)

    def enter(self):
        self.board.finish()
        screen=self.main.windowHandle().screen() if self.main.windowHandle() else QApplication.primaryScreen()
        geometry=screen.geometry()
        old=self.doc;self.doc=fitz.open();self.doc.new_page(width=geometry.width(),height=geometry.height());old.close()
        self.board.setGeometry(geometry);self.board.scale=1
        self.mode.setChecked(False)
        self.toolbar.adjustSize()
        self.toolbar.move(geometry.x()+12,geometry.y()+max(0,(geometry.height()-self.toolbar.height())//2))
        if not self.floating.isVisible():self.floating.move(geometry.x()+20,geometry.y()+100)
        self.floating.hide()
        self.active=True
        self.main.hide()
        # Allow the window manager to process main-window hiding BEFORE
        # displaying the independent overlay and its control window.
        QTimer.singleShot(150,self.show_windows)
    def update_mask(self):
        # Cut the panel's rectangle out of the full-screen ink layer so taps
        # there always reach the panel buttons, even if the window manager
        # raises the ink layer above the panel after a touch.
        if not hasattr(self,'board'):return
        hole=self.toolbar.frameGeometry().adjusted(-4,-4,4,4)
        hole.translate(-self.board.geometry().topLeft())
        self.board.setMask(QRegion(self.board.rect())-QRegion(hole))
    def show_windows(self):
        if not self.active:return
        self.update_mask()
        self.board.show();self.board.raise_()
        self.toolbar.showNormal();self.toolbar.raise_();self.toolbar.activateWindow()
    def write_on_pdf(self):
        self.leave();self.main.set_tool('pen')
    def leave(self):
        self.active=False
        self.board.finish()
        if self.main.tabs is None: self.main.init_tabs()   # never return to an empty board without tabs
        self.main.show();self.main.raise_();self.main.activateWindow()
        self.board.hide();self.toolbar.hide();self.floating.hide()
    def park(self):
        if not self.active:return
        self.board.finish();self.mode.setChecked(True)
        self.toolbar.hide()
        self.floating.show();self.floating.raise_()
    def resume(self):
        if not self.active:return
        self.floating.hide()
        self.set_tool('pen')
        self.board.show();self.board.raise_()
        self.toolbar.showNormal();self.toolbar.raise_();self.toolbar.activateWindow()
    def set_backdrop(self,color):
        self.backdrop=color
        for c,b in self.backdrop_buttons.items():b.setChecked(c==color)
        if color in ('#214d38','#121214') and self.color in ('#172b4d','#000000',PEN_DEFAULT):self.colors.setCurrentIndex(5)
        elif color=='#ffffff' and self.color=='#ffffff':self.colors.setCurrentIndex(1)
        self.board.update()
    def set_passthrough(self,enabled):
        if enabled and self.backdrop:self.set_backdrop(None)
        self.board.finish()
        visible=self.board.isVisible()
        self.board.setWindowFlag(Qt.WindowTransparentForInput,enabled)
        if visible:self.board.show()
        self.mode.setToolTip('Yazmaya dön' if enabled else 'Masaüstünü kullan')
        self.hint.setText('Masaüstü açık' if enabled else 'Esc: tahtaya dön')
        if visible:self.toolbar.raise_()
    def set_tool(self,tool):
        self.board.finish();self.tool=tool;self.mode.setChecked(False)
        if tool!='smart':self.board.clear_selection()
        if tool=='highlight':self.colors.setCurrentIndex(4)
        for k,b in self.tools.items():b.setChecked(k==tool)
        paint_tool_buttons(self.tools,self.tool_labels,self.tool,self.color)
    def set_color(self,color):
        self.color=color
        if self.tool not in ('pen','highlight','dash','laser'):self.set_tool('pen')
    def toggle_styles(self):
        self.style_panel.setVisible(not self.style_panel.isVisible());self.toolbar.adjustSize()
    def set_pen_style(self,key):
        name=dict(PEN_STYLES)[key]
        for k,b in self.style_buttons.items():b.setChecked(k==key)
        self.style_button.setIcon(tool_icon({'fluid':'Akıcı','laser':'Neon'}.get(key)) if key in ('fluid','laser') else style_icon(key,28));self.style_button.setToolTip('Kalem ucu: '+name)
        self.style_panel.hide();self.toolbar.adjustSize()
        if key=='laser':self.set_tool('laser');self.hint.setText('Neon kalem: birkaç saniye sonra söner');return
        self.pen_style=key
        if self.tool!='pen':self.set_tool('pen')
        self.hint.setText('Kalem ucu: '+name)
    def checkpoint(self):
        self.undo_stack.append(copy.deepcopy(self.marks));self.undo_stack=self.undo_stack[-80:];self.redo_stack.clear()
        self.main.undo_log.append(('screen',));self.main.redo_log.clear()
    def changed(self):self.dirty=True
    def move_log(self,source,target):
        for i in range(len(source)-1,-1,-1):
            if source[i]==('screen',):del source[i];break
        target.append(('screen',))
    def undo(self,record=True):
        self.board.finish()
        self.board.clear_selection()
        if self.undo_stack:
            if record:self.move_log(self.main.undo_log,self.main.redo_log)
            self.redo_stack.append(copy.deepcopy(self.marks));self.marks=self.undo_stack.pop();self.changed();self.board.update()
    def redo(self,record=True):
        self.board.finish()
        self.board.clear_selection()
        if self.redo_stack:
            if record:self.move_log(self.main.redo_log,self.main.undo_log)
            self.undo_stack.append(copy.deepcopy(self.marks));self.marks=self.redo_stack.pop();self.changed();self.board.update()
    def clear(self):
        if self.marks.get(0) and QMessageBox.question(self.toolbar,'Ekran notları','Ekran üzerindeki yazılar temizlensin mi?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)==QMessageBox.Yes:
            self.checkpoint();self.marks={};self.changed();self.board.update()
    def save_notes(self):
        self.board.finish()
        path,_=QFileDialog.getSaveFileName(self.toolbar,'Yalnızca ekran notlarını PDF kaydet','Ekran-notlari.pdf','PDF (*.pdf)')
        if not path:return False
        if not path.lower().endswith('.pdf'):path+='.pdf'
        try:
            export_document(self.doc,self.marks,path);self.dirty=False;self.hint.setText('Ekran notları kaydedildi');return True
        except Exception as e:QMessageBox.warning(self.toolbar,'Kaydedilemedi',str(e));return False
    def confirm_close(self):
        if not self.dirty:return True
        answer=QMessageBox.question(self.main,'Ekran notları','Ekran üzerine yazdığınız notlar kaydedilsin mi? Masaüstü görüntüsü kayda dahil değildir.',QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
        if answer==QMessageBox.Save:return self.save_notes()
        return answer==QMessageBox.Discard

def install_turkish(app):
    """Turkish dialog buttons (Evet/Hayır/Kaydet/İptal/Tamam) and file dialogs."""
    from PyQt5.QtCore import QTranslator, QLibraryInfo
    class Overrides(QTranslator):
        WORDS = {'Discard': 'Kaydetme', '&Yes': '&Evet', '&No': '&Hayır', 'Yes': 'Evet', 'No': 'Hayır'}
        def translate(self, context, source, disambiguation=None, n=-1):
            return self.WORDS.get(source) if context == 'QPlatformTheme' else None   # None = use qtbase_tr
    base = QTranslator(app)
    for folder in (os.path.dirname(os.path.abspath(__file__)), QLibraryInfo.location(QLibraryInfo.TranslationsPath)):
        if base.load('qtbase_tr', folder): app.installTranslator(base); break
    app._tr_override = Overrides(app); app.installTranslator(app._tr_override)

def main():
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    # Keep every pen/touch sample (Qt merges fast moves by default, which
    # turns curves into visible corners on interactive boards).
    QApplication.setAttribute(Qt.AA_CompressHighFrequencyEvents, False)
    if hasattr(Qt,'AA_CompressTabletEvents'): QApplication.setAttribute(Qt.AA_CompressTabletEvents, False)
    app = QApplication(sys.argv); app.setApplicationName(APP_NAME)
    install_turkish(app)
    data_dir=os.path.join(QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation),'umal-tahta')
    os.makedirs(data_dir,mode=0o700,exist_ok=True)
    lock=QLockFile(os.path.join(data_dir,'uygulama.lock'));lock.setStaleLockTime(0)
    if not lock.tryLock(100):
        QMessageBox.information(None,APP_NAME,'Uygulama zaten açık. Görev çubuğundaki pencereye dönün; serbest kalem için Ekrana yaz düğmesini kullanın.');return
    window = Window(); window.show()
    handling_error=[False]
    def report_error(kind,value,tb):
        if handling_error[0]:return
        handling_error[0]=True
        try:
            import traceback
            with open(os.path.join(data_dir,'hata-kaydi.txt'),'a',encoding='utf-8') as f:traceback.print_exception(kind,value,tb,file=f)
            if window.screen_session:window.screen_session.leave()
            window.show();window.raise_()
            QMessageBox.warning(window,'İşlem tamamlanamadı','Bir hata oluştu. Çalışmanızı PDF kaydet ile kaydedebilirsiniz. Hata kaydı cihazda tutuldu.\n'+str(value))
        finally:handling_error[0]=False
    sys.excepthook=report_error
    # Açılış kaydı: who started the app and how (to find unwanted start-ups).
    try:
        with open('/proc/uptime') as f: uptime = float(f.read().split()[0])
    except (OSError, ValueError): uptime = 9999
    try:
        with open('/proc/%d/comm' % os.getppid()) as f: parent = f.read().strip()
    except OSError: parent = '?'
    try:
        import datetime
        with open(os.path.join(data_dir,'acilis-kaydi.txt'),'a',encoding='utf-8') as f:
            f.write('%s  açılıştan %d sn sonra  başlatan=%s  ayar=%s\n' % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), uptime, parent, ' '.join(sys.argv[1:]) or '-'))
    except OSError: pass
    # Right after the board starts, always show the PDF screen: an old or extra
    # start-up entry must not open Ekrana yaz on its own.
    if '--serbest-kalem' in sys.argv and uptime > 180:
        # The PDF window behind Ekrana yaz must be ready too (tabs, + Yeni,
        # Havuz): without this the top bar stayed empty after "Tahtaya dön".
        QTimer.singleShot(0,window.init_tabs);QTimer.singleShot(0,window.screen_ink)
    elif '--serbest-kalem' in sys.argv: QTimer.singleShot(0,window.init_tabs)
    elif len(sys.argv) > 1 and not sys.argv[1].startswith('--'):
        try:
            doc = fitz.open(sys.argv[1])
            if doc.needs_pass or not doc.page_count: raise ValueError('Bu dosyayı PDF aç düğmesiyle açın.')
            window.init_tabs(restore=False)
            same=next((t for t in window.tabs if t.get('source') and os.path.realpath(t['source'])==os.path.realpath(sys.argv[1])),None)
            if same: doc.close(); window.switch_tab(same['id'])
            else:
                window.start_tab(os.path.splitext(os.path.basename(sys.argv[1]))[0],sys.argv[1])
                window.replace(doc,sys.argv[1]);window.tabs_changed()
        except Exception as e: QMessageBox.warning(window,'PDF açılamadı',str(e))
    else:QTimer.singleShot(0,window.init_tabs)
    sys.exit(app.exec_())

if __name__ == '__main__': main()
