#!/usr/bin/python3
"""Ümraniye Merkez Anadolu Lisesi 2.4.0 — offline board. GPL-3.0-or-later."""
import sys, os, json, math, copy, tempfile, uuid, shutil, time
import fitz
from PyQt5.QtCore import QProcess, Qt, QPoint, QPointF, QRect, QRectF, QSize, QTimer, QEvent, QStandardPaths, QLockFile, QVariantAnimation, QEasingCurve
from PyQt5.QtGui import QColor, QImage, QPainter, QPen, QKeySequence, QPolygonF, QPixmap, QIcon, QRegion
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QPushButton, QLabel, QScrollArea, QFileDialog, QMessageBox,
    QSpinBox, QSlider, QShortcut, QInputDialog, QComboBox, QGridLayout, QSizePolicy, QDialog, QCheckBox, QFrame, QLineEdit)
from PyQt5.QtGui import QFontMetrics

TAG = 'TahtaKalem/1'
TAG_FX = 'TahtaKalem/1-fx'   # extra look-only annotations (neon glow); rebuilt on every save
APP_NAME = 'Ümraniye Merkez Anadolu Lisesi'
PRODUCT = 'UMAL Atlas'   # uygulamanın adı (pencere, açılış, karşılama); PDF'lerde okulun adı kalır
BACKGROUNDS = [('Beyaz','white'),('Kareli','grid'),('Noktalı','dots'),('Koyu','dark'),('Yeşil tahta','green'),('Kara tahta','black')]
# Dark boards start with white ink.
DARK_BACKGROUNDS = ('dark','green','black')
LOGO = os.path.join(os.path.dirname(__file__),'okul-logo-resmi.png')   # okulun resmi logosu (ÜA, 1965)

def svg_path(d):
    """Tiny SVG path reader (M/m, c, l, z) for the drawn icons."""
    import re
    from PyQt5.QtGui import QPainterPath
    path = QPainterPath(); x = y = 0.0; cmd = None
    toks = re.findall(r'[MmCcLlZz]|-?\d*\.?\d+', d); i = 0
    while i < len(toks):
        t = toks[i]
        if t in 'MmCcLlZz': cmd = t; i += 1
        if cmd in 'Zz': path.closeSubpath(); continue
        n = [float(v) for v in toks[i:i+(6 if cmd in 'Cc' else 2)]]; i += len(n)
        if cmd == 'M': x, y = n; path.moveTo(x, y); cmd = 'L'
        elif cmd == 'm': x, y = x+n[0], y+n[1]; path.moveTo(x, y); cmd = 'l'
        elif cmd == 'l': x, y = x+n[0], y+n[1]; path.lineTo(x, y)
        elif cmd == 'L': x, y = n; path.lineTo(x, y)
        elif cmd == 'c': path.cubicTo(x+n[0], y+n[1], x+n[2], y+n[3], x+n[4], y+n[5]); x, y = x+n[4], y+n[5]
        elif cmd == 'C': path.cubicTo(*n); x, y = n[4], n[5]
    return path

def havuz_icon(height=24):
    """PDF Havuzu: a flying pigeon carrying a PDF letter in its beak."""
    from PyQt5.QtGui import QFont
    k = 4; w, h = 120, 96
    pix = QPixmap(w*k, h*k); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing); p.scale(k, k); p.setPen(Qt.NoPen)
    p.setBrush(QColor('#edf4ff')); p.drawPath(svg_path('M14 54c10-2 20 0 28 6 6-14 18-22 32-22-6 6-10 12-12 20 10-2 18 0 24 6-14 4-30 6-44 4-10 6-22 6-28-2 0 0-4-8 0-12z'))
    p.setBrush(QColor('#b9d4f3')); p.drawPath(svg_path('M44 58c-8-14-6-28 4-40 6 12 8 26 4 38z'))
    p.setBrush(QColor('#dbe8f8')); p.drawPath(svg_path('M58 42c4-14 14-24 28-28-2 14-10 26-24 32z'))
    p.setBrush(QColor('#122034')); p.drawEllipse(QPointF(82, 58), 2.4, 2.4)
    p.setBrush(QColor('#ffb02e')); p.drawPolygon(QPolygonF([QPointF(88, 60), QPointF(95, 62), QPointF(88, 65)]))
    p.save(); p.translate(104, 70); p.rotate(10); p.translate(-104, -70)
    p.setBrush(QColor('#fff8e6')); p.setPen(QPen(QColor('#c9a96b'), 1.4)); p.drawRoundedRect(QRectF(92, 60, 24, 17), 2, 2)
    p.drawPolyline(QPolygonF([QPointF(92, 60), QPointF(104, 69), QPointF(116, 60)]))
    p.setPen(Qt.NoPen); p.setBrush(QColor('#e23b4d')); p.drawRoundedRect(QRectF(96, 70, 16, 6), 1, 1)
    f = QFont('DejaVu Sans'); f.setPixelSize(5); f.setBold(True); p.setFont(f); p.setPen(QColor('white'))
    p.drawText(QRectF(96, 70, 16, 6), Qt.AlignCenter, 'PDF'); p.restore(); p.end()
    pix = pix.copy(QRect(8*k, 12*k, 112*k, 72*k))   # trim empty margins so the bird fills the button
    return QIcon(pix.scaledToHeight(height*2, Qt.SmoothTransformation))

UI_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts')
_FONTS = {}
def ui_fonts():
    """Pakette gelen yazı tipleri (bir kez yüklenir): Poppins arayüz yazısı, Phosphor ikonları, Patrick Hand (Atlas cevapları, el yazısı; OFL)."""
    if not _FONTS and QApplication.instance() is not None:
        from PyQt5.QtGui import QFontDatabase
        for name in ('Poppins-Regular', 'Poppins-Medium', 'Poppins-Bold', 'Phosphor-Fill', 'PatrickHand-Regular'):
            path = os.path.join(UI_FONT_DIR, name + '.ttf'); fam = None
            if os.path.isfile(path):
                i = QFontDatabase.addApplicationFont(path)
                fams = QFontDatabase.applicationFontFamilies(i) if i >= 0 else []
                fam = fams[0] if fams else None
            _FONTS[name] = fam
    return _FONTS

# Premium ikonlar (C: cam efektli renkli daire, beyaz dolu Phosphor ikonu). Phosphor: MIT lisansı.
# Renk araç türünü söyler: yazı mavi, silme pembe, düzen mor, sunum turuncu, kayıt kırmızı.
PREMIUM_ICONS = {
    'Kalem': (0xe3b4, '#2f7cf6'), 'Taşı': (0xe298, '#64748b'), 'Çözüm alanı': (0xe296, '#0ea5a4'), 'Alan seç': (0xe69a, '#0ea5a4'),
    'Fosforlu': (0xe632, '#eab308'), 'Silgi': (0xe21e, '#ec4899'), 'Alan silgisi': (0xe69e, '#db2777'), 'Tümünü sil': (0xe4a6, '#ef4444'),
    'Seçimi kaldır': (0xe69e, '#94a3b8'), 'Akıllı seçim': (0xe69c, '#6366f1'), 'Şekiller': (0xec5e, '#8b5cf6'),
    'Çizgi': (0xe6d2, '#8b5cf6'), 'Ok': (0xe092, '#8b5cf6'), 'Dikdörtgen': (0xe3f0, '#8b5cf6'), 'Elips': (0xe18a, '#8b5cf6'), 'Kesikli çizgi': (0xe6d4, '#8b5cf6'),
    'Post-it': (0xe348, '#f59e0b'), 'Perde': (0xeb16, '#f97316'), 'Spot ışığı': (0xe246, '#fb923c'), 'Alkış': (0xe81a, '#d946ef'), 'Oyunlar': (0xe26e, '#22c55e'), 'Anket': (0xe196, '#06b6d4'), 'Okul araçları': (0xe62c, '#22e8ff'), 'Rehberlik': (0xe63c, '#f59e0b'), 'Proje seçimi': (0xe0e6, '#8b5cf6'),
    'Geri al': (0xe038, '#64748b'), 'İleri al': (0xe036, '#64748b'), 'Ekrana yaz': (0xe654, '#06b6d4'), 'PDF kaydet': (0xe248, '#ef4444'),
    'Günün soruları': (0xe2f6, '#22c55e'), 'Araçlar': (0xe464, '#6366f1'), 'Ayarlar': (0xe272, '#94a3b8'), 'Tam ekran': (0xe0a2, '#64748b'),
    'Sayaç': (0xe492, '#f97316'), 'Hesap makinesi': (0xe538, '#0ea5e9'), 'PDF aç': (0xe702, '#ef4444'), 'Yeni tahta': (0xe236, '#2f7cf6'),
    'Tema': (0xe6c8, '#d946ef'), 'Gizle': (0xe224, '#64748b'), 'Tahtaya dön': (0xe08a, '#2f7cf6'), "PDF'ye yaz": (0xe34c, '#2f7cf6'),
    'Akıcı': (0xe3ac, '#2f7cf6'), 'Neon': (0xe6a2, '#d946ef'),
    'Grafik çizici': (0xe154, '#2f7cf6'), 'Şablonlar': (0xec8c, '#0ea5a4'), 'Cetvel': (0xe6b8, '#eab308'), 'Pergel': (0xea0e, '#8b5cf6'),
    'Üçgen': (0xe4b0, '#8b5cf6'), 'Ölçülü üçgen': (0xe4b0, '#7c3aed'),
    'Notları PDF kaydet': (0xe248, '#ef4444'), 'Masaüstünü kullan': (0xe560, '#06b6d4'),
    'Sayfaya git': (0xe2a2, '#64748b'), 'Sığdır': (0xe626, '#64748b'), 'Önceki': (0xe138, '#64748b'), 'Sonraki': (0xe13a, '#64748b'),
}
_ICONS = {}
def _drop_icons():   # ikon önbelleği Qt kapanmadan boşaltılır (kapanışta çökmesin)
    _ICONS.clear()
import atexit; atexit.register(_drop_icons)
def premium_icon(label, size=64):
    app = QApplication.instance()
    if app is not None and not getattr(app, '_umal_icons_hook', False):
        app.aboutToQuit.connect(_drop_icons); app._umal_icons_hook = True
    g = PREMIUM_ICONS.get(label)
    fam = ui_fonts().get('Phosphor-Fill') if g else None
    if not g or not fam: return None
    if label in _ICONS: return _ICONS[label]
    from PyQt5.QtGui import QFont, QLinearGradient, QRadialGradient
    code, color = g; pix = QPixmap(size, size); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
    r = QRectF(2, 2, size-4, size-4); base = QColor(color)
    grad = QLinearGradient(r.topLeft(), r.bottomLeft()); grad.setColorAt(0, base.lighter(128)); grad.setColorAt(1, base.darker(118))
    p.setPen(QPen(QColor(255, 255, 255, 95), size*.035)); p.setBrush(grad); p.drawEllipse(r)
    gloss = QRadialGradient(QPointF(size*.34, size*.24), size*.5); gloss.setColorAt(0, QColor(255, 255, 255, 150)); gloss.setColorAt(.55, QColor(255, 255, 255, 25)); gloss.setColorAt(1, QColor(255, 255, 255, 0))
    p.setPen(Qt.NoPen); p.setBrush(gloss); p.drawEllipse(r)
    f = QFont(fam); f.setPixelSize(int(size*.5)); p.setFont(f); p.setPen(QColor(0, 0, 0, 55)); p.drawText(r.translated(0, size*.025), Qt.AlignCenter, chr(code))
    p.setPen(QColor('#ffffff')); p.drawText(r, Qt.AlignCenter, chr(code)); p.end()
    _ICONS[label] = QIcon(pix); return _ICONS[label]

def glyph_style(code, px, extra=''):
    """Düğmede ikon fontundan tek işaret (ok, artı, eksi): yeni ikonlarla aynı aileden."""
    fam = ui_fonts().get('Phosphor-Fill')
    return (chr(code), ('font-family:"%s";font-size:%dpx;font-weight:normal;' % (fam, px) if fam else 'font-size:%dpx;' % px) + extra)

def tool_icon(label, ink='#edf4ff'):
    """Small high-contrast vector-style UI glyphs; no external icon dependency."""
    ic = premium_icon(label)
    if ic is not None: return ic
    pix=QPixmap(32,32);pix.fill(Qt.transparent)
    p=QPainter(pix);p.setRenderHint(QPainter.Antialiasing)
    p.setPen(QPen(QColor(ink),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
    def line(a,b):p.drawLine(QPointF(*a),QPointF(*b))
    def poly(pts):p.drawPolyline(QPolygonF([QPointF(*pt) for pt in pts]))
    if label=='Yazdır':
        p.drawRect(QRectF(9,4,14,8));p.drawRoundedRect(QRectF(4,12,24,11),3,3);p.drawRect(QRectF(9,19,14,9));line((12,23),(20,23))
    elif label=='Kalem':
        poly([(5,26),(8,17),(23,3),(29,9),(14,24),(5,26)])
        line((8,17),(14,24));line((21,6),(26,11))
    elif label=='Fosforlu':
        p.setPen(QPen(QColor('#ffdf56'),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        poly([(9,19),(20,5),(28,12),(17,25),(9,19)])
        p.setBrush(QColor('#ffdf56'));p.drawPolygon(QPolygonF([QPointF(9,19),QPointF(17,25),QPointF(11,28),QPointF(5,24)]))
        line((3,30),(27,30))
    elif label=='Silgi':
        poly([(4,20),(17,5),(29,16),(17,28),(12,28),(4,20)])
        line((10,13),(23,23));line((17,28),(29,28))
    elif label=='Post-it':
        p.setBrush(QColor('#ffe27a'));p.setPen(QPen(QColor('#ffe27a'),1.5));p.drawPolygon(QPolygonF([QPointF(5,6),QPointF(27,6),QPointF(27,20),QPointF(20,27),QPointF(5,27)]))
        p.setPen(QPen(QColor('#122034'),1.6));line((9,12),(23,12));line((9,17),(20,17));p.setBrush(QColor('#d9a400'));p.drawPolygon(QPolygonF([QPointF(20,27),QPointF(20,20),QPointF(27,20)]))
    elif label in ('Neon kalem','Neon'):
        glow=QColor(ink);glow.setAlpha(90);p.setPen(QPen(glow,6,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        pts=[(4,22),(10,10),(16,22),(22,10),(28,22)];poly(pts)
        p.setPen(QPen(QColor(ink),2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));poly(pts)
    elif label=='Alan silgisi':
        p.setPen(QPen(QColor(ink),1.8,Qt.DashLine));p.drawEllipse(QRectF(2,2,28,28))
        p.setPen(QPen(QColor(ink),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        poly([(8,19),(17,9),(25,17),(17,25),(13,25),(8,19)]);line((12,14),(20,22))
    elif label in ('Alan seç','Akıllı seçim','Çözüm alanı','Seçimi kaldır'):
        p.setPen(QPen(QColor('#edf4ff'),2,Qt.DashLine));p.drawRect(QRectF(5,5,22,22))
        if label=='Seçimi kaldır':line((10,10),(22,22));line((22,10),(10,22))
    elif label=='Taşı':   # open hand ✋
        from PyQt5.QtGui import QPainterPath, QTransform
        hand=QPainterPath();hand.setFillRule(Qt.WindingFill)
        for x,top in ((9,6),(13.5,3),(18,4),(22.5,7.5)):hand.addRoundedRect(QRectF(x-2,top,4,16),2,2)
        hand.addRoundedRect(QRectF(7,14,17.5,15),5,5)
        t=QPainterPath();t.addRoundedRect(QRectF(-2,-10,4,12),2,2);hand.addPath(QTransform().translate(8,21).rotate(-50).map(t))
        p.setBrush(QColor(ink));p.setPen(Qt.NoPen);p.drawPath(hand.simplified())
    elif label=='Dikdörtgen':p.drawRect(QRectF(4,7,24,18))
    elif label=='Elips':p.drawEllipse(QRectF(4,7,24,18))
    elif label=='Çizgi':line((5,27),(27,5))
    elif label=='Ok':line((5,27),(27,5));poly([(15,5),(27,5),(27,17)])
    elif label=='Şekiller':
        p.drawRect(QRectF(4,4,12,10));p.drawEllipse(QRectF(16,15,13,13));line((4,28),(14,18))
    elif label=='Kesikli çizgi':
        for a in range(4):line((3+a*7.5,27-a*7.5),(7.5+a*7.5,22.5-a*7.5))
    elif label in ('Geri al','Yinele','İleri al'):
        if label!='Geri al':p.translate(32,0);p.scale(-1,1)
        poly([(11,6),(4,13),(11,20)]);poly([(4,13),(20,13),(26,18),(26,24)])
    elif label in ('PDF kaydet','Notları PDF kaydet'):
        poly([(5,4),(23,4),(28,9),(28,28),(5,28),(5,4)])
        p.drawRect(QRectF(10,4,11,9));p.drawRect(QRectF(10,20,13,8))
    elif label in ('Ekrana yaz','Masaüstünü kullan','Yazmaya dön'):
        p.drawRoundedRect(QRectF(3,4,26,19),2,2);line((16,23),(16,28));line((10,28),(22,28))
        line((10,18),(23,8))
    elif label in ('Yeni tahta','PDF aç','Tahtaya dön',"PDF'ye yaz"):
        p.drawRoundedRect(QRectF(5,3,22,26),2,2)
        if label=='Yeni tahta':line((16,10),(16,23));line((10,16),(22,16))
        elif label=='PDF aç':line((10,11),(22,11));line((10,17),(22,17));line((10,23),(18,23))
        elif label=="PDF'ye yaz":line((10,11),(19,11));line((10,16),(16,16));poly([(13,25),(14,21),(24,11),(27,14),(17,24),(13,25)])
        else:poly([(15,10),(9,16),(15,22)]);line((9,16),(23,16))
    elif label in ('Temizle','Notları temizle','Tümünü sil'):
        poly([(8,10),(10,28),(23,28),(25,10)]);line((5,7),(28,7));line((12,3),(21,3))
    elif label=='Tema':
        p.drawEllipse(QRectF(4,4,24,24));p.setBrush(QColor('#edf4ff'))
        for x,y in ((11,11),(20,10),(23,18)):p.drawEllipse(QPointF(x,y),2.2,2.2)
        p.setBrush(Qt.NoBrush)
    elif label=='Hesap makinesi':
        p.drawRoundedRect(QRectF(6,3,20,26),3,3);p.drawRect(QRectF(10,7,12,5))
        for x in (11,16,21):
            for y in (17,23):p.drawPoint(QPointF(x,y))
    elif label=='Sayaç':
        p.drawEllipse(QRectF(5,7,22,22));line((16,18),(16,12));line((16,18),(20,21));line((13,3),(19,3));line((16,3),(16,7))
    elif label=='Gizle':   # eye, struck through
        path=QPolygonF([QPointF(3+i*1.0,16-9*math.sin(math.pi*i/26)) for i in range(27)]+[QPointF(29-i*1.0,16+9*math.sin(math.pi*i/26)) for i in range(27)])
        p.drawPolygon(path);p.drawEllipse(QPointF(16,16),4,4);line((6,27),(26,5))
    elif label=='Perde':   # curtain pulled half way, with its handle
        p.setBrush(QColor(ink));p.setPen(Qt.NoPen);p.drawRoundedRect(QRectF(4,15,24,13),2,2)
        p.setBrush(Qt.NoBrush);p.setPen(QPen(QColor(ink),2));p.drawRoundedRect(QRectF(4,4,24,24),3,3);line((12,12),(20,12))
    elif label=='Spot ışığı':   # dark field, one bright circle
        p.setBrush(QColor(ink));p.setPen(Qt.NoPen);p.drawRoundedRect(QRectF(3,3,26,26),4,4)
        p.setBrush(QColor('#ffe14d'));p.drawEllipse(QPointF(18,14),7,7)
    elif label=='Araçlar':   # 2×2 tiles
        for x,y in ((5,5),(18,5),(5,18),(18,18)):p.drawRoundedRect(QRectF(x,y,9,9),2,2)
    elif label=='PDF Havuzu':   # two stacked pages and a down arrow
        p.drawRoundedRect(QRectF(9,3,17,21),2,2);p.setBrush(QColor('#16253a'));p.drawRoundedRect(QRectF(5,8,17,21),2,2);p.setBrush(Qt.NoBrush)
        line((13.5,13),(13.5,24));poly([(9.5,20),(13.5,24),(17.5,20)])
    elif label=='Ayarlar':   # gear
        p.setBrush(Qt.NoBrush)
        for k in range(8):
            a=math.radians(k*45);line((16+9*math.cos(a),16+9*math.sin(a)),(16+13*math.cos(a),16+13*math.sin(a)))
        p.setPen(QPen(QColor(ink),2.6));p.drawEllipse(QPointF(16,16),9,9);p.setPen(QPen(QColor(ink),2.2));p.drawEllipse(QPointF(16,16),3.5,3.5)
    elif label=='Günün soruları':   # page with a numbered list
        p.drawRoundedRect(QRectF(6,3,20,26),3,3)
        for k,y in enumerate((10,16,22)):
            p.drawPoint(QPointF(11,y));line((15,y),(22 if k!=1 else 20,y))
    elif label=='Alkış':   # party popper: cone and bursts
        poly([(5,28),(11,12),(21,22),(5,28)])
        for a,b_ in (((15,9),(17,4)),((20,13),(26,9)),((23,18),(28,19))):line(a,b_)
        p.drawPoint(QPointF(24,5));p.drawPoint(QPointF(28,13));p.drawPoint(QPointF(19,4))
    elif label=='Tam ekran':
        for pts in [[(4,12),(4,4),(12,4)],[(20,4),(28,4),(28,12)],[(4,20),(4,28),(12,28)],[(20,28),(28,28),(28,20)]]:poly(pts)
    else:
        p.end();return QIcon()
    p.end();return QIcon(pix)

COLOR_TOOLS = ('pen','highlight','line','arrow','rect','circle','dash','laser')
SHAPE_TOOLS = ('line','arrow','rect','circle','triangle','dash')   # grouped under the Şekiller button
DASH_PATTERN = (2, 3)   # in pen widths; with round caps: dash 3w, gap 2w

def stroke_pen(s, offset=0):
    pen = QPen(QColor(s['color']), s['width'], Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    if s.get('dash'):
        pen.setDashPattern(list(DASH_PATTERN)); pen.setDashOffset(offset / max(s['width'], .1))
    return pen

PEN_STYLES = (('fluid','Akıcı'),('laser','Neon (söner)'))
# Only these two tips are offered; writing made earlier with Normal, Tebeşir,
# Keçeli, Kurşun kalem or Neon still draws exactly as before.
# 'laser' in the tips row is the Neon kalem tool (glows, then fades; not saved).
# Tebeşir was removed from the row; old chalk writing still draws as before.
STYLE_SPAN = {'fluid':1, 'felt':1.7, 'chalk':1.6, 'pencil':1, 'neon':5.5, 'laser':8}   # drawn width ÷ pen width
STYLED_TOOLS = ('pen','line','rect','circle','laser')   # snapped shapes keep the style

def fluid_outline(s):
    """Akıcı kalem: outline of a stroke whose width follows the stored
    per-point factors (speed + tapered ends), as one polygon."""
    pts, ws, half = s['points'], s['w'], s['width']/2
    if len(pts) < 2: return None
    left, right = [], []
    for i, (x, y) in enumerate(pts):
        a, b = pts[max(0, i-1)], pts[min(len(pts)-1, i+1)]
        dx, dy = b[0]-a[0], b[1]-a[1]; d = math.hypot(dx, dy)
        nx, ny = (-dy/d, dx/d) if d > 1e-6 else (0, 1)
        r = max(.25, half*ws[i]); left.append([x+nx*r, y+ny*r]); right.append([x-nx*r, y-ny*r])
    return left+right[::-1]

def mix_color(c, other, t):
    c, o = QColor(c), QColor(other)
    return QColor.fromRgbF(c.redF()+(o.redF()-c.redF())*t, c.greenF()+(o.greenF()-c.greenF())*t, c.blueF()+(o.blueF()-c.blueF())*t)

_masks = {}
def style_mask(kind):
    """Soft grain (alpha only) laid over a whole chalk / pencil stroke at once.
    Coarse blotches + fine speckle, so it reads as chalk dust or graphite
    on the board instead of hard pixel noise."""
    if kind not in _masks:
        import random
        rng = random.Random(7 if kind == 'chalk' else 23); N = 128
        def noise(n):
            img = QImage(n, n, QImage.Format_Grayscale8)
            for y in range(n):
                for x in range(n): img.setPixel(x, y, QColor.fromHsv(0, 0, rng.randrange(256)).rgb())
            return img
        def tile(img):   # 3×3 tiling before smoothing keeps the edges seamless
            big = QImage(img.width()*3, img.height()*3, QImage.Format_Grayscale8); p = QPainter(big)
            for i in range(3):
                for j in range(3): p.drawImage(i*img.width(), j*img.height(), img)
            p.end(); s = big.scaled(N*3, N*3, Qt.IgnoreAspectRatio, Qt.SmoothTransformation); return s.copy(N, N, N, N)
        coarse = tile(noise(N//8)); mid = tile(noise(N//3)); fine = noise(N)
        out = QImage(N, N, QImage.Format_ARGB32_Premultiplied)
        for y in range(N):
            for x in range(N):
                c, m, f = QColor(coarse.pixel(x, y)).red()/255, QColor(mid.pixel(x, y)).red()/255, QColor(fine.pixel(x, y)).red()/255
                if kind == 'chalk': a = .9*c + .6*m + .55*f - .28
                else: a = .62 + .18*m + .28*f
                a = max(0., min(1., a)); out.setPixel(x, y, QColor(255, 255, 255, int(a*255)).rgba())
        _masks[kind] = QPixmap.fromImage(out)
    return _masks[kind]

def style_passes(s):
    """How a styled stroke is painted: a list of (pen, opacity, mask) passes.
    Each pass is drawn solid on its own layer and only then made see-through
    or grainy, so overlapping pieces never darken or speckle."""
    st = s.get('style'); w = s['width']; c = QColor(s['color'])
    if s['tool'] not in STYLED_TOOLS or st not in STYLE_SPAN or st == 'fluid': return None
    pen = lambda col, k: QPen(QColor(col), max(.6, w*k), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    if st == 'felt': return [(pen(c, 1.7), 1, None)]
    if st == 'chalk': return [(pen(mix_color(c, '#ffffff', .12), 1.6), .95, 'chalk')]
    if st == 'pencil': return [(pen(mix_color(c, '#4a4f57', .35), .85), 1, 'pencil')]
    if st == 'laser':   # Neon kalem: geniş ışıma + beyaz-sıcak çekirdek
        return [(pen(c, 8), .07, None), (pen(c, 5.5), .12, None), (pen(c, 3.4), .28, None), (pen(c, 1.8), .9, None),
                (pen(mix_color(c, '#ffffff', .8), .65), 1, None)]
    return [(pen(c, 5.5), .16, None), (pen(c, 3), .42, None), (pen('#ffffff', .7), 1, None), (pen(c, .35), .95, None)]

def arrow_points(a, b, width):
    """Ok: the shaft and both head strokes as one polyline (a plain 'line'
    stroke, so drawing, erasing, saving and the PDF work unchanged)."""
    d = math.hypot(b[0]-a[0], b[1]-a[1])
    if d < 3: return [a, b]
    ux, uy = (b[0]-a[0])/d, (b[1]-a[1])/d; L = min(d*.45, max(12, width*4.5)); s, c = math.sin(math.radians(28)), math.cos(math.radians(28))
    h1 = [b[0]-L*(ux*c-uy*s), b[1]-L*(uy*c+ux*s)]; h2 = [b[0]-L*(ux*c+uy*s), b[1]-L*(uy*c-ux*s)]
    return [a, b, h1, b, h2]

def stroke_path(pts):
    from PyQt5.QtGui import QPainterPath
    path = QPainterPath(QPointF(*pts[0]))
    for pt in pts[1:]: path.lineTo(QPointF(*pt))
    if len(pts) == 1: path.lineTo(QPointF(pts[0][0]+.01, pts[0][1]))
    return path

def apply_mask(q, kind, r):
    """Cut the grain into a layer; q is set up in widget pixels (r = area)."""
    from PyQt5.QtGui import QBrush
    q.save(); q.resetTransform(); q.translate(-r.x(), -r.y())
    q.setCompositionMode(QPainter.CompositionMode_DestinationIn); q.fillRect(QRectF(r), QBrush(style_mask(kind))); q.restore()

def paint_passes(p, path, passes, clip, dpr=1):
    """Finished styled stroke: every pass on a small clear layer, then laid
    over the page — the same result as while it was being written."""
    t = p.transform()
    for pen, opacity, mask in passes:
        if opacity >= 1 and not mask:   # plain opaque pass: straight onto the page
            p.setPen(pen); p.drawPath(path); continue
        pad = pen.widthF()/2 + 2
        r = (t.mapRect(path.boundingRect().adjusted(-pad, -pad, pad, pad)) & clip).toAlignedRect()
        if r.isEmpty(): continue
        img = QImage(max(1, int(r.width()*dpr)), max(1, int(r.height()*dpr)), QImage.Format_ARGB32_Premultiplied)
        img.setDevicePixelRatio(dpr); img.fill(Qt.transparent)
        q = QPainter(img); q.setRenderHint(QPainter.Antialiasing)
        q.translate(-r.x(), -r.y()); q.setTransform(t, True); q.setPen(pen); q.drawPath(path)
        if mask: apply_mask(q, mask, r)
        q.end()
        p.save(); p.resetTransform(); p.setOpacity(p.opacity()*opacity); p.drawImage(QRectF(r), img); p.restore()

def style_icon(key, size=26, ink='#ffffff'):
    pix = QPixmap(size*2, size*2); pix.fill(Qt.transparent)
    p = QPainter(pix); p.setRenderHint(QPainter.Antialiasing); p.scale(2, 2)
    s = dict(tool='pen', color=ink, width=size/10 if key != 'neon' else size/14,
             points=[[size*.16+i*size*.68/20, size*.5+math.sin(i/20*2*math.pi)*size*.2] for i in range(21)])
    if key != 'normal': s['style'] = key
    if key == 'fluid': s['width'] = size/8
    passes = style_passes(s); path = stroke_path(s['points'])
    if passes: paint_passes(p, path, passes, QRectF(0, 0, size*2, size*2))
    elif s.get('w'):
        p.setPen(Qt.NoPen); p.setBrush(QColor(ink)); p.drawPolygon(QPolygonF([QPointF(*q) for q in fluid_outline(s)]), Qt.WindingFill)
    else: p.setPen(stroke_pen(s)); p.drawPath(path)
    p.end(); return QIcon(pix)

def paint_tool_buttons(buttons, labels, tool, color):
    """The selected drawing tool's button takes the current ink colour, so
    the chosen colour is always visible on the tool itself."""
    q = QColor(color); light = .299*q.redF()+.587*q.greenF()+.114*q.blueF() > .6
    ink = '#122034' if light else '#ffffff'
    for key, b in buttons.items():
        if key == tool and key in COLOR_TOOLS:
            b.setStyleSheet('QPushButton:checked{background:%s;color:%s;border:3px solid #ffffff;}' % (color, ink))
            b.setIcon(tool_icon(labels[key], ink))
        else:
            b.setStyleSheet(''); b.setIcon(tool_icon(labels[key]))

BOARD_FILLS = {'dark': (.025,.065,.13), 'green': (.13,.30,.22), 'black': (.07,.07,.08)}
BLANK_H = 1080   # yeni boş tahta: iki ekran boyu (sonsuz; yazdıkça uzar)
def make_board(background='white', width=960, height=540):
    doc = fitz.open(); page = doc.new_page(width=width,height=height)
    if background in BOARD_FILLS:
        page.draw_rect(page.rect,color=None,fill=BOARD_FILLS[background])
    elif background == 'grid':
        shape = page.new_shape()
        for x in range(0,int(width)+1,24): shape.draw_line((x,0),(x,height))
        for y in range(0,int(height)+1,24): shape.draw_line((0,y),(width,y))
        shape.finish(color=(.55,.64,.76),width=.9); shape.commit()
    elif background == 'dots':
        shape = page.new_shape()
        for x in range(24,int(width),24):
            for y in range(24,int(height),24): shape.draw_circle((x,y),1.6)
        shape.finish(color=None,fill=(.40,.50,.64)); shape.commit()
    doc.set_metadata({'title':APP_NAME,'keywords':'UMAL-board:'+background})
    return doc

def nib_outline(stroke):
    """Same directional nib geometry for the screen and vector PDF export."""
    if stroke.get('w') and len(stroke['w']) == len(stroke['points']): return fluid_outline(stroke)
    if stroke['tool'] != 'pen' or stroke.get('nib') not in ('fountain','marker'): return None
    pts = stroke['points']; width = stroke['width']; nib = stroke['nib']
    if len(pts) == 1 or all(math.dist(pts[0],p)<.01 for p in pts):
        x,y = pts[0]; radius = width*(1 if nib=='marker' else .55)
        return [[x+radius*math.cos(i*math.pi/12),y+radius*math.sin(i*math.pi/12)] for i in range(24)]
    left,right = [],[]
    distances = [0.0]
    for a,b in zip(pts,pts[1:]): distances.append(distances[-1]+math.dist(a,b))
    for i,(x,y) in enumerate(pts):
        a,b = pts[max(0,i-2)],pts[min(len(pts)-1,i+2)]
        dx,dy = b[0]-a[0],b[1]-a[1]; length = math.hypot(dx,dy)
        nx,ny = (-dy/length,dx/length) if length>.0001 else (0,1)
        angle = abs((nx+ny)*.70710678)
        if nib == 'fountain':
            taper = .35+.65*min(1,distances[i]/max(width*2,1),(distances[-1]-distances[i])/max(width*2,1))
            half = width*(.22+.65*angle)*taper
        else: half = width*(.65+.55*angle)
        left.append([x+nx*half,y+ny*half]); right.append([x-nx*half,y-ny*half])
    return left+right[::-1]

def catmull_rom(p0, p1, p2, p3, steps):
    """Centripetal Catmull–Rom from p1 to p2 (p1 excluded, p2 included).
    It passes through the pen samples themselves, so small loops and letter
    joins keep their size, and the centripetal form makes no cusps or loops
    at sharp turns."""
    def knot(t, a, b):
        return t + max(1e-6, math.hypot(b[0]-a[0], b[1]-a[1])) ** .5
    t0 = 0.0; t1 = knot(t0, p0, p1); t2 = knot(t1, p1, p2); t3 = knot(t2, p2, p3)
    out = []
    for k in range(1, steps+1):
        t = t1 + (t2-t1)*k/steps
        def lerp(a, b, ta, tb): u = (t-ta)/(tb-ta); return (a[0]+(b[0]-a[0])*u, a[1]+(b[1]-a[1])*u)
        a1 = lerp(p0, p1, t0, t1); a2 = lerp(p1, p2, t1, t2); a3 = lerp(p2, p3, t2, t3)
        b1 = lerp(a1, a2, t0, t2); b2 = lerp(a2, a3, t1, t3)
        c = lerp(b1, b2, t1, t2); out.append([c[0], c[1]])
    out[-1] = list(p2)
    return out

def cr_steps(a, b, scale):
    return max(2, min(24, int(math.hypot(b[0]-a[0], b[1]-a[1])*scale/1.5)+1))

def cr_points(raw, scale):
    """Whole-stroke reference of Board.smooth_append() for Akıcı (tests)."""
    if len(raw) < 3: return [list(p) for p in raw]
    pts = [list(raw[0])]
    for n in range(3, len(raw)+1):
        p0 = raw[n-4] if n >= 4 else raw[n-3]
        pts.extend(catmull_rom(p0, raw[n-3], raw[n-2], raw[n-1], cr_steps(raw[n-3], raw[n-2], scale)))
    pts.append(list(raw[-1])); return pts

def smooth_points(raw):
    """Quadratic midpoint interpolation suppresses jitter without sharp corners."""
    if len(raw) < 3: return list(raw)
    result = [raw[0]]
    start = raw[0]
    for i in range(1,len(raw)-1):
        control = raw[i]
        end = [(raw[i][j]+raw[i+1][j])/2 for j in (0,1)]
        steps = max(2,min(16,int(math.hypot(end[0]-start[0],end[1]-start[1])/1.2)+1))
        for k in range(1,steps+1):
            t = k/steps
            result.append([(1-t)**2*start[j]+2*(1-t)*t*control[j]+t*t*end[j] for j in (0,1)])
        start = end
    result.append(raw[-1])
    return result

def export_document(doc, marks, target, solutions=None):
    """Write atomically; keep original PDF and its existing annotations intact."""
    out = fitz.open(stream=doc.tobytes(), filetype='pdf')
    try:
        if solutions is not None:
            if SOLUTIONS_FILE in out.embfile_names(): out.embfile_del(SOLUTIONS_FILE)
            if solutions:
                data = {k: dict(v, marks={str(p): m for p, m in v['marks'].items()}) for k, v in solutions.items()}
                out.embfile_add(SOLUTIONS_FILE, json.dumps(data, ensure_ascii=False).encode('utf-8'),
                                desc='Ümraniye Merkez Anadolu Lisesi soru çözümleri')
        for n, strokes in marks.items():
            page = out[n]
            for s in strokes:
                if s['tool'] == 'geo':   # koordinat düzlemi: görünmez taşıyıcı + çizimin kendisi
                    a = page.add_ink_annot([[(1, 1), (1.01, 1.01)]]); a.set_opacity(0); a.set_info(title=TAG, content=json.dumps(s)); a.update()
                    try:
                        for sub_ in geo_strokes(s, page.rect.width, page.rect.height):
                            g = page.add_ink_annot([[tuple(q) for q in sub_['points']]]); c_ = QColor(sub_['color'])
                            g.set_colors(stroke=(c_.redF(), c_.greenF(), c_.blueF())); g.set_border(width=sub_['width']); g.set_info(title=TAG_FX); g.update()
                    except Exception: pass
                    continue
                outline = nib_outline(s)
                if outline:
                    points = [fitz.Point(*pt)*page.derotation_matrix for pt in outline]
                    a = page.add_polygon_annot([(pt.x,pt.y) for pt in points])
                    c = QColor(s['color']); rgb = (c.redF(),c.greenF(),c.blueF())
                    a.set_colors(stroke=rgb,fill=rgb); a.set_border(width=0)
                    a.set_info(title=TAG,content=json.dumps(s)); a.update()
                    continue
                if s['tool'] == 'whiteout':
                    rect = fitz.Rect(*s['points'][0], *s['points'][1]) * page.derotation_matrix
                    a = page.add_rect_annot(rect)
                    a.set_colors(stroke=(1,1,1), fill=(1,1,1))
                    a.set_border(width=0)
                    a.set_info(title=TAG, content=json.dumps(s))
                    a.update()
                    continue
                pts = [fitz.Point(*p) * page.derotation_matrix for p in s['points']]
                if len(pts) == 1:
                    pts.append(pts[0] + fitz.Point(.01, .01))
                ink = [[(p.x,p.y) for p in pts]]
                c = QColor(s['color']); width = s['width']; opacity = .3 if s['tool'] == 'highlight' else 1
                style = s.get('style') if s['tool'] in STYLED_TOOLS else None
                # Pen styles outside the app: plain ink that looks close to them.
                if style == 'felt': width *= 1.7
                elif style == 'chalk': width *= 1.6; c = mix_color(c, '#ffffff', .12); opacity = .85
                elif style == 'pencil': width = max(.6, width*.85); c = mix_color(c, '#4a4f57', .35); opacity = .85
                elif style == 'neon':
                    for k, alpha, col in ((5.5, .16, c), (3, .42, c), (.7, 1, QColor('#ffffff'))):
                        g = page.add_ink_annot(ink); g.set_colors(stroke=(col.redF(), col.greenF(), col.blueF()))
                        g.set_border(width=max(.6, width*k)); g.set_opacity(alpha); g.set_info(title=TAG_FX); g.update()
                    width = max(.6, width*.35)
                a = page.add_ink_annot(ink)
                a.set_colors(stroke=(c.redF(), c.greenF(), c.blueF()))
                if s.get('dash'): a.set_border(width=s['width'], dashes=[DASH_PATTERN[0]*s['width']+s['width'], DASH_PATTERN[1]*s['width']-s['width']])
                else: a.set_border(width=width)
                a.set_opacity(opacity)
                a.set_info(title=TAG, content=json.dumps(s))
                a.update()
        fd, tmp = tempfile.mkstemp(suffix='.pdf', dir=os.path.dirname(os.path.abspath(target)))
        os.close(fd)
        try:
            # garbage=3/deflate re-compress every image of large textbooks
            # (10+ s, UI freeze); garbage=1 keeps output valid and fast.
            out.save(tmp, garbage=1)
            os.replace(tmp, target)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
    finally:
        out.close()

SOLUTIONS_FILE = 'umal-cozumler.json'

def read_solutions(doc):
    """Saved question solutions travel inside the PDF as an embedded file."""
    try:
        if SOLUTIONS_FILE in doc.embfile_names():
            data = json.loads(doc.embfile_get(SOLUTIONS_FILE).decode('utf-8'))
            return {k: dict(v, marks=load_marks(v.get('marks'))) for k, v in data.items()
                    if len(v.get('rect', [])) == 4}
    except Exception: pass
    return {}

def solution_overlap(a, b):
    ra, rb = fitz.Rect(a), fitz.Rect(b); inter = ra & rb
    if inter.is_empty: return 0
    area = lambda r: max(0, r.width) * max(0, r.height)
    union = area(ra) + area(rb) - area(inter)
    return area(inter) / union if union else 0

def recover_marks(doc):
    marks = {}
    for page in doc:
        marks[page.number] = []
        for a in list(page.annots() or []):
            if a.info.get('title') == TAG_FX: page.delete_annot(a); continue
            if a.info.get('title') != TAG: continue
            try:
                s = json.loads(a.info['content'])
                assert s['tool'] in ('pen', 'highlight', 'line', 'rect', 'circle', 'whiteout', 'geo')
                assert 0 < float(s['width']) <= 100
                assert s['points'] and all(len(p) == 2 and all(math.isfinite(float(v)) for v in p) for p in s['points'])
                assert QColor(s['color']).isValid()
                if s['tool'] == 'whiteout':
                    assert len(s['points']) == 2
                    assert s['points'][1][0] > s['points'][0][0] and s['points'][1][1] > s['points'][0][1]
                marks[page.number].append(s)
                page.delete_annot(a)
            except (ValueError, KeyError, TypeError, AssertionError):
                pass
    return marks

def load_marks(data):
    """Validated marks from autosave JSON (same rules as recover_marks)."""
    marks = {}
    for key, strokes in (data or {}).items():
        page = int(key); marks[page] = []
        for s in strokes:
            try:
                assert s['tool'] in ('pen', 'highlight', 'line', 'rect', 'circle', 'whiteout', 'geo')
                assert 0 < float(s['width']) <= 100
                assert s['points'] and all(len(p) == 2 and all(math.isfinite(float(v)) for v in p) for p in s['points'])
                assert QColor(s['color']).isValid()
                marks[page].append(s)
            except (ValueError, KeyError, TypeError, AssertionError):
                pass
    return marks

def segment_distance(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    d = dx*dx+dy*dy
    t = max(0, min(1, ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/d)) if d else 0
    return math.hypot(p[0]-a[0]-t*dx, p[1]-a[1]-t*dy)

def stroke_bounds(stroke):
    pts=stroke['points']; pad=stroke['width']/2
    x0=min(p[0] for p in pts)-pad;y0=min(p[1] for p in pts)-pad
    return QRectF(x0,y0,max(p[0] for p in pts)+pad-x0,max(p[1] for p in pts)+pad-y0)

def is_scribble(points, scale=1):
    """Back-and-forth scratching (≥5 reversals, very long for its size)."""
    if len(points) < 10: return False
    xs = [p[0] for p in points]; ys = [p[1] for p in points]
    w, h = max(xs)-min(xs), max(ys)-min(ys)
    if max(w, h)*scale < 24: return False
    length = sum(math.dist(a, b) for a, b in zip(points, points[1:]))
    if length < 3*(w+h): return False
    def reversals(vals, extent):
        hyst = max(4/scale, .18*extent); count = 0; direction = 0; anchor = vals[0]
        for v in vals[1:]:
            if direction >= 0 and v < anchor-hyst:
                count += direction > 0; direction = -1; anchor = v
            elif direction <= 0 and v > anchor+hyst:
                count += direction < 0; direction = 1; anchor = v
            elif (direction > 0 and v > anchor) or (direction < 0 and v < anchor): anchor = v
        return count
    return max(reversals(xs, w), reversals(ys, h)) >= 5

def scribble_hits(strokes, scribble, scale=1):
    """Strokes lying mostly under the scribble."""
    xs = [p[0] for p in scribble['points']]; ys = [p[1] for p in scribble['points']]
    pad = max(4/scale, scribble.get('width', 3))
    x0, x1, y0, y1 = min(xs)-pad, max(xs)+pad, min(ys)-pad, max(ys)+pad
    hits = []
    for s in strokes:
        if s is scribble or s['tool'] == 'whiteout' or not s['points']: continue
        inside = sum(1 for q in s['points'] if x0 <= q[0] <= x1 and y0 <= q[1] <= y1)
        if inside >= .5*len(s['points']): hits.append(s)
    return hits

def recognize_triangle(points, diag, length):
    """Kapalı ve üç köşeli el çizimi → düzgün üçgen (köşeler el çiziminden)."""
    def far(pts, a, b):
        return max(range(len(pts)), key=lambda k: segment_distance(pts[k], a, b) if a != b else math.dist(pts[k], a))
    p0 = points[0]; i1 = max(range(len(points)), key=lambda k: math.dist(points[k], p0)); A = points[i1]
    i2 = max(range(len(points)), key=lambda k: math.dist(points[k], A)); B = points[i2]
    i3 = far(points, A, B); C = points[i3]
    corners = [A, B, C]
    sides = [math.dist(A, B), math.dist(B, C), math.dist(C, A)]
    if min(sides) < diag*.25: return None
    per = sum(sides)
    if not (.85*per < length < 1.18*per): return None
    edges = [(A, B), (B, C), (C, A)]
    err = [min(segment_distance(p, a, b) for a, b in edges) for p in points]
    if sum(e < diag*.06 for e in err)/len(err) < .9: return None
    # her köşenin yakınından geçilmiş olmalı (dörtgen/daire elensin)
    def ang(p, q, r):
        v1 = (q[0]-p[0], q[1]-p[1]); v2 = (r[0]-p[0], r[1]-p[1])
        c = (v1[0]*v2[0] + v1[1]*v2[1])/max(1e-9, math.hypot(*v1)*math.hypot(*v2)); return math.degrees(math.acos(max(-1, min(1, c))))
    if min(ang(A, B, C), ang(B, C, A), ang(C, A, B)) < 12: return None
    return [list(A), list(B), list(C), list(A)]

SHAPE_MIN_PX = 150   # şekil düzeltme yalnızca ekranda bu boydan büyük çizimlerde (harfler ~30–80 px)
def recognize_shape(points):
    """Conservative axis-aligned shapes; called only after an intentional hold."""
    if len(points)<3:return None
    xs=[p[0] for p in points];ys=[p[1] for p in points]
    x0,x1=min(xs),max(xs);y0,y1=min(ys),max(ys)
    w,h=x1-x0,y1-y0;diag=math.hypot(w,h)
    if diag<20:return None
    # Remove sampling jitter and resample uniformly. Touch screens often send
    # many points while stationary and only a few during a fast straight stroke.
    def simplify(pts):
        keep={0,len(pts)-1};stack=[(0,len(pts)-1)]
        while stack:
            a,b=stack.pop()
            if b-a<2:continue
            i=max(range(a+1,b),key=lambda k:segment_distance(pts[k],pts[a],pts[b]))
            if segment_distance(pts[i],pts[a],pts[b])>max(1.5,diag*.012):
                keep.add(i);stack.extend([(a,i),(i,b)])
        return [pts[i] for i in sorted(keep)]
    filtered=simplify(points)
    samples=[]
    for a,b in zip(filtered,filtered[1:]):
        steps=max(1,min(200,int(math.dist(a,b)/max(1,diag/80))))
        samples.extend([[a[0]+(b[0]-a[0])*i/steps,a[1]+(b[1]-a[1])*i/steps] for i in range(steps)])
    points=samples+[filtered[-1]]
    length=sum(math.dist(a,b) for a,b in zip(points,points[1:]))
    chord=math.dist(points[0],points[-1])
    if chord>.8*diag and length<chord*1.2 and max(segment_distance(p,points[0],points[-1]) for p in points)<max(2.5,diag*.04):
        return 'line',[points[0],points[-1]]
    if min(w,h)<12 or chord>diag*.2:return None
    tri=recognize_triangle(points,diag,length)
    if tri:return 'triangle',tri
    perimeter=2*(w+h)
    if .8*perimeter<length<1.2*perimeter:
        errors=[min(abs(x-x0),abs(x-x1),abs(y-y0),abs(y-y1)) for x,y in points]
        corners=[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]
        if sum(e<min(w,h)*.07 for e in errors)/len(errors)>.9 and all(min(math.dist(c,p) for p in points)<diag*.09 for c in corners):
            return 'rect',corners+[corners[0]]
    cx,cy=(x0+x1)/2,(y0+y1)/2;rx,ry=w/2,h/2
    error=sum(abs(math.hypot((x-cx)/rx,(y-cy)/ry)-1) for x,y in points)/len(points)
    angles=[math.atan2((y-cy)/ry,(x-cx)/rx) for x,y in points]
    sweep=sum((b-a+math.pi)%(2*math.pi)-math.pi for a,b in zip(angles,angles[1:]))
    if error<.09 and 5.4<abs(sweep)<7.1:
        return 'circle',[[cx+rx*math.cos(t*math.pi/32),cy+ry*math.sin(t*math.pi/32)] for t in range(65)]
    return None

# Çizgi yazısı: etiketler (A, B, C, 6, 60°) normal kalem çizgisi olarak yazılır;
# silinir, taşınır, PDF'e aynen geçer. Hershey Roman Simplex (kamu malı).
HERSHEY = {"!":[14,[[[5,-12],[5,2]],[[5,7],[4,8],[5,9],[6,8],[5,7]]]],"\"":[20,[[[4,-12],[4,-5]],[[12,-12],[12,-5]]]],"#":[25,[[[11,-16],[4,16]],[[17,-16],[10,16]],[[4,-3],[18,-3]],[[3,3],[17,3]]]],"$":[24,[[[8,-16],[8,13]],[[12,-16],[12,13]],[[17,-9],[15,-11],[12,-12],[8,-12],[5,-11],[3,-9],[3,-7],[4,-5],[5,-4],[7,-3],[13,-1],[15,0],[16,1],[17,3],[17,6],[15,8],[12,9],[8,9],[5,8],[3,6]]]],"%":[28,[[[21,-12],[3,9]],[[8,-12],[10,-10],[10,-8],[9,-6],[7,-5],[5,-5],[3,-7],[3,-9],[4,-11],[6,-12],[8,-12],[10,-11],[13,-10],[16,-10],[19,-11],[21,-12]],[[17,2],[15,3],[14,5],[14,7],[16,9],[18,9],[20,8],[21,6],[21,4],[19,2],[17,2]]]],"&":[30,[[[23,-3],[23,-4],[22,-5],[21,-5],[20,-4],[19,-2],[17,3],[15,6],[13,8],[11,9],[7,9],[5,8],[4,7],[3,5],[3,3],[4,1],[5,0],[12,-4],[13,-5],[14,-7],[14,-9],[13,-11],[11,-12],[9,-11],[8,-9],[8,-7],[9,-4],[11,-1],[16,6],[18,8],[20,9],[22,9],[23,8],[23,7]]]],"'":[14,[[[5,-10],[4,-11],[5,-12],[6,-11],[6,-9],[5,-7],[4,-6]]]],"(":[18,[[[11,-16],[9,-14],[7,-11],[5,-7],[4,-2],[4,2],[5,7],[7,11],[9,14],[11,16]]]],")":[18,[[[3,-16],[5,-14],[7,-11],[9,-7],[10,-2],[10,2],[9,7],[7,11],[5,14],[3,16]]]],"*":[20,[[[8,-6],[8,6]],[[3,-3],[13,3]],[[13,-3],[3,3]]]],"+":[30,[[[13,-9],[13,9]],[[4,0],[22,0]]]],",":[12,[[[5,5],[4,6],[3,5],[4,4],[5,5],[5,7],[3,9]]]],"-":[30,[[[4,0],[22,0]]]],".":[12,[[[4,4],[3,5],[4,6],[5,5],[4,4]]]],"/":[26,[[[20,-16],[2,16]]]],"0":[24,[[[9,-12],[6,-11],[4,-8],[3,-3],[3,0],[4,5],[6,8],[9,9],[11,9],[14,8],[16,5],[17,0],[17,-3],[16,-8],[14,-11],[11,-12],[9,-12]]]],"1":[24,[[[6,-8],[8,-9],[11,-12],[11,9]]]],"2":[24,[[[4,-7],[4,-8],[5,-10],[6,-11],[8,-12],[12,-12],[14,-11],[15,-10],[16,-8],[16,-6],[15,-4],[13,-1],[3,9],[17,9]]]],"3":[24,[[[5,-12],[16,-12],[10,-4],[13,-4],[15,-3],[16,-2],[17,1],[17,3],[16,6],[14,8],[11,9],[8,9],[5,8],[4,7],[3,5]]]],"4":[24,[[[13,-12],[3,2],[18,2]],[[13,-12],[13,9]]]],"5":[24,[[[15,-12],[5,-12],[4,-3],[5,-4],[8,-5],[11,-5],[14,-4],[16,-2],[17,1],[17,3],[16,6],[14,8],[11,9],[8,9],[5,8],[4,7],[3,5]]]],"6":[24,[[[16,-9],[15,-11],[12,-12],[10,-12],[7,-11],[5,-8],[4,-3],[4,2],[5,6],[7,8],[10,9],[11,9],[14,8],[16,6],[17,3],[17,2],[16,-1],[14,-3],[11,-4],[10,-4],[7,-3],[5,-1],[4,2]]]],"7":[24,[[[17,-12],[7,9]],[[3,-12],[17,-12]]]],"8":[24,[[[8,-12],[5,-11],[4,-9],[4,-7],[5,-5],[7,-4],[11,-3],[14,-2],[16,0],[17,2],[17,5],[16,7],[15,8],[12,9],[8,9],[5,8],[4,7],[3,5],[3,2],[4,0],[6,-2],[9,-3],[13,-4],[15,-5],[16,-7],[16,-9],[15,-11],[12,-12],[8,-12]]]],"9":[24,[[[16,-5],[15,-2],[13,0],[10,1],[9,1],[6,0],[4,-2],[3,-5],[3,-6],[4,-9],[6,-11],[9,-12],[10,-12],[13,-11],[15,-9],[16,-5],[16,0],[15,5],[13,8],[10,9],[8,9],[5,8],[4,6]]]],":":[12,[[[4,-3],[3,-2],[4,-1],[5,-2],[4,-3]],[[4,4],[3,5],[4,6],[5,5],[4,4]]]],";":[12,[[[4,-3],[3,-2],[4,-1],[5,-2],[4,-3]],[[5,5],[4,6],[3,5],[4,4],[5,5],[5,7],[3,9]]]],"<":[28,[[[20,-9],[4,0],[20,9]]]],"=":[30,[[[4,-3],[22,-3]],[[4,3],[22,3]]]],">":[28,[[[4,-9],[20,0],[4,9]]]],"?":[22,[[[3,-7],[3,-8],[4,-10],[5,-11],[7,-12],[11,-12],[13,-11],[14,-10],[15,-8],[15,-6],[14,-4],[13,-3],[9,-1],[9,2]],[[9,7],[8,8],[9,9],[10,8],[9,7]]]],"@":[31,[[[18,-4],[17,-6],[15,-7],[12,-7],[10,-6],[9,-5],[8,-2],[8,1],[9,3],[11,4],[14,4],[16,3],[17,1]],[[12,-7],[10,-5],[9,-2],[9,1],[10,3],[11,4]],[[18,-7],[17,1],[17,3],[19,4],[21,4],[23,2],[24,-1],[24,-3],[23,-6],[22,-8],[20,-10],[18,-11],[15,-12],[12,-12],[9,-11],[7,-10],[5,-8],[4,-6],[3,-3],[3,0],[4,3],[5,5],[7,7],[9,8],[12,9],[15,9],[18,8],[20,7],[21,6]],[[19,-7],[18,1],[18,3],[19,4]]]],"A":[22,[[[9,-12],[1,9]],[[9,-12],[17,9]],[[4,2],[14,2]]]],"B":[25,[[[4,-12],[4,9]],[[4,-12],[13,-12],[16,-11],[17,-10],[18,-8],[18,-6],[17,-4],[16,-3],[13,-2]],[[4,-2],[13,-2],[16,-1],[17,0],[18,2],[18,5],[17,7],[16,8],[13,9],[4,9]]]],"C":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4]]]],"D":[25,[[[4,-12],[4,9]],[[4,-12],[11,-12],[14,-11],[16,-9],[17,-7],[18,-4],[18,1],[17,4],[16,6],[14,8],[11,9],[4,9]]]],"E":[23,[[[4,-12],[4,9]],[[4,-12],[17,-12]],[[4,-2],[12,-2]],[[4,9],[17,9]]]],"F":[22,[[[4,-12],[4,9]],[[4,-12],[17,-12]],[[4,-2],[12,-2]]]],"G":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[18,1]],[[13,1],[18,1]]]],"H":[26,[[[4,-12],[4,9]],[[18,-12],[18,9]],[[4,-2],[18,-2]]]],"I":[12,[[[4,-12],[4,9]]]],"J":[20,[[[12,-12],[12,4],[11,7],[10,8],[8,9],[6,9],[4,8],[3,7],[2,4],[2,2]]]],"K":[25,[[[4,-12],[4,9]],[[18,-12],[4,2]],[[9,-3],[18,9]]]],"L":[21,[[[4,-12],[4,9]],[[4,9],[16,9]]]],"M":[28,[[[4,-12],[4,9]],[[4,-12],[12,9]],[[20,-12],[12,9]],[[20,-12],[20,9]]]],"N":[26,[[[4,-12],[4,9]],[[4,-12],[18,9]],[[18,-12],[18,9]]]],"O":[26,[[[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[19,1],[19,-4],[18,-7],[17,-9],[15,-11],[13,-12],[9,-12]]]],"P":[25,[[[4,-12],[4,9]],[[4,-12],[13,-12],[16,-11],[17,-10],[18,-8],[18,-5],[17,-3],[16,-2],[13,-1],[4,-1]]]],"Q":[26,[[[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[19,1],[19,-4],[18,-7],[17,-9],[15,-11],[13,-12],[9,-12]],[[12,5],[18,11]]]],"R":[25,[[[4,-12],[4,9]],[[4,-12],[13,-12],[16,-11],[17,-10],[18,-8],[18,-6],[17,-4],[16,-3],[13,-2],[4,-2]],[[11,-2],[18,9]]]],"S":[24,[[[17,-9],[15,-11],[12,-12],[8,-12],[5,-11],[3,-9],[3,-7],[4,-5],[5,-4],[7,-3],[13,-1],[15,0],[16,1],[17,3],[17,6],[15,8],[12,9],[8,9],[5,8],[3,6]]]],"T":[20,[[[8,-12],[8,9]],[[1,-12],[15,-12]]]],"U":[26,[[[4,-12],[4,3],[5,6],[7,8],[10,9],[12,9],[15,8],[17,6],[18,3],[18,-12]]]],"V":[22,[[[1,-12],[9,9]],[[17,-12],[9,9]]]],"W":[28,[[[2,-12],[7,9]],[[12,-12],[7,9]],[[12,-12],[17,9]],[[22,-12],[17,9]]]],"X":[24,[[[3,-12],[17,9]],[[17,-12],[3,9]]]],"Y":[22,[[[1,-12],[9,-2],[9,9]],[[17,-12],[9,-2]]]],"Z":[24,[[[17,-12],[3,9]],[[3,-12],[17,-12]],[[3,9],[17,9]]]],"[":[18,[[[4,-16],[4,16]],[[5,-16],[5,16]],[[4,-16],[11,-16]],[[4,16],[11,16]]]],"\\":[18,[[[0,-12],[14,12]]]],"]":[18,[[[9,-16],[9,16]],[[10,-16],[10,16]],[[3,-16],[10,-16]],[[3,16],[10,16]]]],"^":[20,[[[8,-14],[0,0]],[[8,-14],[16,0]]]],"_":[22,[[[0,16],[18,16]]]],"`":[12,[[[5,-7],[3,-5],[3,-3],[4,-2],[5,-3],[4,-4],[3,-3]]]],"a":[23,[[[15,-5],[15,9]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"b":[23,[[[4,-12],[4,9]],[[4,-2],[6,-4],[8,-5],[11,-5],[13,-4],[15,-2],[16,1],[16,3],[15,6],[13,8],[11,9],[8,9],[6,8],[4,6]]]],"c":[22,[[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"d":[23,[[[15,-12],[15,9]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"e":[22,[[[3,1],[15,1],[15,-1],[14,-3],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"f":[16,[[[10,-12],[8,-12],[6,-11],[5,-8],[5,9]],[[2,-5],[9,-5]]]],"g":[23,[[[15,-5],[15,11],[14,14],[13,15],[11,16],[8,16],[6,15]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"h":[23,[[[4,-12],[4,9]],[[4,-1],[7,-4],[9,-5],[12,-5],[14,-4],[15,-1],[15,9]]]],"i":[12,[[[3,-12],[4,-11],[5,-12],[4,-13],[3,-12]],[[4,-5],[4,9]]]],"j":[14,[[[5,-12],[6,-11],[7,-12],[6,-13],[5,-12]],[[6,-5],[6,12],[5,15],[3,16],[1,16]]]],"k":[21,[[[4,-12],[4,9]],[[14,-5],[4,5]],[[8,1],[15,9]]]],"l":[12,[[[4,-12],[4,9]]]],"m":[34,[[[4,-5],[4,9]],[[4,-1],[7,-4],[9,-5],[12,-5],[14,-4],[15,-1],[15,9]],[[15,-1],[18,-4],[20,-5],[23,-5],[25,-4],[26,-1],[26,9]]]],"n":[23,[[[4,-5],[4,9]],[[4,-1],[7,-4],[9,-5],[12,-5],[14,-4],[15,-1],[15,9]]]],"o":[23,[[[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6],[16,3],[16,1],[15,-2],[13,-4],[11,-5],[8,-5]]]],"p":[23,[[[4,-5],[4,16]],[[4,-2],[6,-4],[8,-5],[11,-5],[13,-4],[15,-2],[16,1],[16,3],[15,6],[13,8],[11,9],[8,9],[6,8],[4,6]]]],"q":[23,[[[15,-5],[15,16]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]]]],"r":[17,[[[4,-5],[4,9]],[[4,1],[5,-2],[7,-4],[9,-5],[12,-5]]]],"s":[21,[[[14,-2],[13,-4],[10,-5],[7,-5],[4,-4],[3,-2],[4,0],[6,1],[11,2],[13,3],[14,5],[14,6],[13,8],[10,9],[7,9],[4,8],[3,6]]]],"t":[16,[[[5,-12],[5,5],[6,8],[8,9],[10,9]],[[2,-5],[9,-5]]]],"u":[23,[[[4,-5],[4,5],[5,8],[7,9],[10,9],[12,8],[15,5]],[[15,-5],[15,9]]]],"v":[20,[[[2,-5],[8,9]],[[14,-5],[8,9]]]],"w":[26,[[[3,-5],[7,9]],[[11,-5],[7,9]],[[11,-5],[15,9]],[[19,-5],[15,9]]]],"x":[21,[[[3,-5],[14,9]],[[14,-5],[3,9]]]],"y":[20,[[[2,-5],[8,9]],[[14,-5],[8,9],[6,13],[4,15],[2,16],[1,16]]]],"z":[21,[[[14,-5],[3,9]],[[3,-5],[14,-5]],[[3,9],[14,9]]]],"{":[18,[[[9,-16],[7,-15],[6,-14],[5,-12],[5,-10],[6,-8],[7,-7],[8,-5],[8,-3],[6,-1]],[[7,-15],[6,-13],[6,-11],[7,-9],[8,-8],[9,-6],[9,-4],[8,-2],[4,0],[8,2],[9,4],[9,6],[8,8],[7,9],[6,11],[6,13],[7,15]],[[6,1],[8,3],[8,5],[7,7],[6,8],[5,10],[5,12],[6,14],[7,15],[9,16]]]],"|":[12,[[[4,-16],[4,16]]]],"}":[18,[[[5,-16],[7,-15],[8,-14],[9,-12],[9,-10],[8,-8],[7,-7],[6,-5],[6,-3],[8,-1]],[[7,-15],[8,-13],[8,-11],[7,-9],[6,-8],[5,-6],[5,-4],[6,-2],[10,0],[6,2],[5,4],[5,6],[6,8],[7,9],[8,11],[8,13],[7,15]],[[8,1],[6,3],[6,5],[7,7],[8,8],[9,10],[9,12],[8,14],[7,15],[5,16]]]],"~":[28,[[[3,3],[3,1],[4,-2],[6,-3],[8,-3],[10,-2],[14,1],[16,2],[18,2],[20,1],[21,-1]],[[3,1],[4,-1],[6,-2],[8,-2],[10,-1],[14,2],[16,3],[18,3],[20,2],[21,-1],[21,-3]]]]," ":[16,[]],"\u0131":[12,[[[4,-5],[4,9]]]],"\u0130":[12,[[[4,-12],[4,9]],[[4.0,-16],[4.0,-15]]]],"\u015f":[21,[[[14,-2],[13,-4],[10,-5],[7,-5],[4,-4],[3,-2],[4,0],[6,1],[11,2],[13,3],[14,5],[14,6],[13,8],[10,9],[7,9],[4,8],[3,6]],[[8.5,9],[10.5,11],[8.5,13],[6.5,13]]]],"\u015e":[24,[[[17,-9],[15,-11],[12,-12],[8,-12],[5,-11],[3,-9],[3,-7],[4,-5],[5,-4],[7,-3],[13,-1],[15,0],[16,1],[17,3],[17,6],[15,8],[12,9],[8,9],[5,8],[3,6]],[[10.0,9],[12.0,11],[10.0,13],[8.0,13]]]],"\u00e7":[22,[[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]],[[9.0,9],[11.0,11],[9.0,13],[7.0,13]]]],"\u00c7":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4]],[[10.5,9],[12.5,11],[10.5,13],[8.5,13]]]],"\u011f":[23,[[[15,-5],[15,11],[14,14],[13,15],[11,16],[8,16],[6,15]],[[15,-2],[13,-4],[11,-5],[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6]],[[5.0,-12],[6.0,-10],[9.0,-9],[12.0,-10],[13.0,-12]]]],"\u011e":[25,[[[18,-7],[17,-9],[15,-11],[13,-12],[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[18,1]],[[13,1],[18,1]],[[6.5,-17],[7.5,-15],[10.5,-14],[13.5,-15],[14.5,-17]]]],"\u00f6":[23,[[[8,-5],[6,-4],[4,-2],[3,1],[3,3],[4,6],[6,8],[8,9],[11,9],[13,8],[15,6],[16,3],[16,1],[15,-2],[13,-4],[11,-5],[8,-5]],[[6.5,-10],[6.5,-9]],[[12.5,-10],[12.5,-9]]]],"\u00fc":[23,[[[4,-5],[4,5],[5,8],[7,9],[10,9],[12,8],[15,5]],[[15,-5],[15,9]],[[6.5,-10],[6.5,-9]],[[12.5,-10],[12.5,-9]]]],"\u00d6":[26,[[[9,-12],[7,-11],[5,-9],[4,-7],[3,-4],[3,1],[4,4],[5,6],[7,8],[9,9],[13,9],[15,8],[17,6],[18,4],[19,1],[19,-4],[18,-7],[17,-9],[15,-11],[13,-12],[9,-12]],[[8.0,-16],[8.0,-15]],[[14.0,-16],[14.0,-15]]]],"\u00dc":[26,[[[4,-12],[4,3],[5,6],[7,8],[10,9],[12,9],[15,8],[17,6],[18,3],[18,-12]],[[8.0,-16],[8.0,-15]],[[14.0,-16],[14.0,-15]]]],"\u2212":[22,[[[4,0],[18,0]]]],"\u2019":[14,[[[5,-10],[4,-11],[5,-12],[6,-11],[6,-9],[5,-7],[4,-6]]]],"\u00b7":[10,[[[5,-1],[5,0]]]],"\u221a":[22,[[[2,1],[5,0],[9,9],[15,-14],[22,-14]]]],"\u0394":[20,[[[3,9],[10,-12],[17,9],[3,9]]]],"\u2225":[14,[[[5,-12],[5,9]],[[10,-12],[10,9]]]],"\u22a5":[20,[[[10,-12],[10,9]],[[3,9],[17,9]]]],"\u2229":[20,[[[4,9],[4,-2],[6,-6],[10,-8],[14,-6],[16,-2],[16,9]]]],"\u2248":[22,[[[3,-2.0],[4,-2.8419035512031976],[5,-3.5556349186104046],[6,-4.03253497152483],[7,-4.2],[8,-4.03253497152483],[9,-3.555634918610405],[10,-2.841903551203198],[11,-2.0000000000000004],[12,-1.1580964487968026],[13,-0.4443650813895954],[14,0.032534971524830425],[15,0.20000000000000018],[16,0.03253497152483087],[17,-0.44436508138959496],[18,-1.158096448796801],[19,-1.9999999999999996]],[[3,4.0],[4,3.1580964487968024],[5,2.4443650813895954],[6,1.9674650284751691],[7,1.7999999999999998],[8,1.9674650284751691],[9,2.444365081389595],[10,3.158096448796802],[11,3.9999999999999996],[12,4.841903551203197],[13,5.555634918610405],[14,6.03253497152483],[15,6.2],[16,6.03253497152483],[17,5.555634918610405],[18,4.841903551203199],[19,4.000000000000001]]]],"\u2080":[14.879999999999999,[[[5.58,-0.4399999999999995],[3.7199999999999998,0.17999999999999972],[2.48,2.04],[1.8599999999999999,5.140000000000001],[1.8599999999999999,7.0],[2.48,10.1],[3.7199999999999998,11.96],[5.58,12.58],[6.82,12.58],[8.68,11.96],[9.92,10.1],[10.54,7.0],[10.54,5.140000000000001],[9.92,2.04],[8.68,0.17999999999999972],[6.82,-0.4399999999999995],[5.58,-0.4399999999999995]]]],"\u2081":[14.879999999999999,[[[3.7199999999999998,2.04],[4.96,1.42],[6.82,-0.4399999999999995],[6.82,12.58]]]],"\u2082":[14.879999999999999,[[[2.48,2.66],[2.48,2.04],[3.1,0.7999999999999998],[3.7199999999999998,0.17999999999999972],[4.96,-0.4399999999999995],[7.4399999999999995,-0.4399999999999995],[8.68,0.17999999999999972],[9.3,0.7999999999999998],[9.92,2.04],[9.92,3.2800000000000002],[9.3,4.52],[8.06,6.38],[1.8599999999999999,12.58],[10.54,12.58]]]],"\u2083":[14.879999999999999,[[[3.1,-0.4399999999999995],[9.92,-0.4399999999999995],[6.2,4.52],[8.06,4.52],[9.3,5.140000000000001],[9.92,5.76],[10.54,7.62],[10.54,8.86],[9.92,10.719999999999999],[8.68,11.96],[6.82,12.58],[4.96,12.58],[3.1,11.96],[2.48,11.34],[1.8599999999999999,10.1]]]],"\u2084":[14.879999999999999,[[[8.06,-0.4399999999999995],[1.8599999999999999,8.24],[11.16,8.24]],[[8.06,-0.4399999999999995],[8.06,12.58]]]],"\u2085":[14.879999999999999,[[[9.3,-0.4399999999999995],[3.1,-0.4399999999999995],[2.48,5.140000000000001],[3.1,4.52],[4.96,3.9],[6.82,3.9],[8.68,4.52],[9.92,5.76],[10.54,7.62],[10.54,8.86],[9.92,10.719999999999999],[8.68,11.96],[6.82,12.58],[4.96,12.58],[3.1,11.96],[2.48,11.34],[1.8599999999999999,10.1]]]],"\u2086":[14.879999999999999,[[[9.92,1.42],[9.3,0.17999999999999972],[7.4399999999999995,-0.4399999999999995],[6.2,-0.4399999999999995],[4.34,0.17999999999999972],[3.1,2.04],[2.48,5.140000000000001],[2.48,8.24],[3.1,10.719999999999999],[4.34,11.96],[6.2,12.58],[6.82,12.58],[8.68,11.96],[9.92,10.719999999999999],[10.54,8.86],[10.54,8.24],[9.92,6.38],[8.68,5.140000000000001],[6.82,4.52],[6.2,4.52],[4.34,5.140000000000001],[3.1,6.38],[2.48,8.24]]]],"\u2087":[14.879999999999999,[[[10.54,-0.4399999999999995],[4.34,12.58]],[[1.8599999999999999,-0.4399999999999995],[10.54,-0.4399999999999995]]]],"\u2088":[14.879999999999999,[[[4.96,-0.4399999999999995],[3.1,0.17999999999999972],[2.48,1.42],[2.48,2.66],[3.1,3.9],[4.34,4.52],[6.82,5.140000000000001],[8.68,5.76],[9.92,7.0],[10.54,8.24],[10.54,10.1],[9.92,11.34],[9.3,11.96],[7.4399999999999995,12.58],[4.96,12.58],[3.1,11.96],[2.48,11.34],[1.8599999999999999,10.1],[1.8599999999999999,8.24],[2.48,7.0],[3.7199999999999998,5.76],[5.58,5.140000000000001],[8.06,4.52],[9.3,3.9],[9.92,2.66],[9.92,1.42],[9.3,0.17999999999999972],[7.4399999999999995,-0.4399999999999995],[4.96,-0.4399999999999995]]]],"\u2089":[14.879999999999999,[[[9.92,3.9],[9.3,5.76],[8.06,7.0],[6.2,7.62],[5.58,7.62],[3.7199999999999998,7.0],[2.48,5.76],[1.8599999999999999,3.9],[1.8599999999999999,3.2800000000000002],[2.48,1.42],[3.7199999999999998,0.17999999999999972],[5.58,-0.4399999999999995],[6.2,-0.4399999999999995],[8.06,0.17999999999999972],[9.3,1.42],[9.92,3.9],[9.92,7.0],[9.3,10.1],[8.06,11.96],[6.2,12.58],[4.96,12.58],[3.1,11.96],[2.48,10.719999999999999]]]]}
HERSHEY['°'] = [12, [[[6 + 3*math.cos(t*math.pi/8), -9 + 3*math.sin(t*math.pi/8)] for t in range(17)]]]
def text_strokes(text, x, y, h, color, width, anchor='c'):
    """Yazıyı kalem çizgilerine çevirir (h: büyük harf yüksekliği, sayfa birimi).
    anchor: 'c' ortası (x, y), 'l' sol-orta, 'r' sağ-orta."""
    k = h/21.0; glyphs = [HERSHEY.get(ch, HERSHEY.get(ch.upper(), [12, []])) for ch in text]
    total = sum(g[0] for g in glyphs)*k
    cx = x - total/2 if anchor == 'c' else x - total if anchor == 'r' else x
    out = []
    for adv, polys in glyphs:
        for poly in polys:
            out.append(dict(tool='pen', color=color, width=width, points=[[cx + gx*k, y + (gy + 1.5)*k] for gx, gy in poly]))
        cx += adv*k
    return out

def fmt_num(v, nd=2):
    """Türkçe ondalık: 5,29 · tam sayıysa 6."""
    if abs(v - round(v)) < 1e-9: return str(int(round(v)))
    return ('{:.%df}' % nd).format(v).rstrip('0').rstrip('.').replace('.', ',')

def tri_points(a, b):
    """Sürükleyerek çizilen sıradan üçgen: tabanı alt kenar, tepesi biraz solda."""
    x0, x1 = min(a[0], b[0]), max(a[0], b[0]); y0, y1 = min(a[1], b[1]), max(a[1], b[1])
    apex = [x0 + .38*(x1 - x0), y0]
    return [[x0, y1], [x1, y1], apex, [x0, y1]]

PEN_DEFAULT = '#111111'   # canlı palet: siyah, kırmızı, mavi, yeşil, mor, pembe, sarı, beyaz
SIDE_ARROW_W, SIDE_ARROW_H = 56, 116
HAVUZ_DIR = os.path.join(os.path.expanduser('~'), 'PDF Havuzu')
HAVUZ_TOOL = '/usr/lib/umal-tahta/umal-havuz'
HAVUZ_RCLONE = '/usr/lib/umal-tahta/rclone'
HAVUZ_PYTHON = None
if sys.platform == 'win32':   # taşınabilir Windows paketi: app/umal-havuz.py + runtime/
    _app = os.path.dirname(os.path.abspath(__file__))
    HAVUZ_TOOL = os.path.join(_app, 'umal-havuz.py')
    HAVUZ_RCLONE = os.path.join(os.path.dirname(_app), 'runtime', 'rclone.exe')
    HAVUZ_PYTHON = os.path.join(os.path.dirname(_app), 'runtime', 'pythonw.exe')

def havuz_ready():
    if HAVUZ_PYTHON: return os.path.isfile(HAVUZ_TOOL) and os.path.isfile(HAVUZ_PYTHON)
    return os.access(HAVUZ_TOOL, os.X_OK)

def token_from_authorize(out):
    """The token rclone authorize prints between its paste markers."""
    if '--->' not in out or '<---End paste' not in out: return None
    blob = out.split('--->', 1)[1].split('<---End paste', 1)[0].strip()
    if not blob.startswith('{'):
        try:
            import base64; blob = base64.b64decode(blob + '=' * (-len(blob) % 4)).decode('utf-8')
        except Exception: return None
    try: data = json.loads(blob)
    except ValueError: return None
    if isinstance(data, dict) and 'token' in data and isinstance(data['token'], (str, dict)):
        data = data['token'] if isinstance(data['token'], dict) else json.loads(data['token'])
    return json.dumps(data, separators=(',', ':')) if isinstance(data, dict) and data.get('refresh_token') else None

def havuz_data():
    return os.path.join(QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation), 'umal-tahta', 'havuz')

# ---------------------------------------------------------------------------
# Günün soruları: derste çözülen sorular, tarih / konu / öğretmen adıyla iki
# sütunlu A4 sayfaya dizilir; PDF "Günün Soruları" klasörüne (Drive) gider.
GUNUN_DIR = os.environ.get('UMAL_GUNUN_KLASOR') or os.path.join(os.path.expanduser('~'), 'Günün Soruları')
GUNUN_CARD = 864   # soru kartı genişliği (çözüm alanıyla aynı)

FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts')

def pdf_fonts():
    """Mizanpaj yazı tipleri: pakette gelen Poppins; yoksa sistemdeki Türkçe karakterli yazı tipi.
    Döner: {'r': normal, 'm': orta, 'b': kalın} dosya yolları (None: PDF'in yerleşik yazısı)."""
    pop = {k: os.path.join(FONT_DIR, 'Poppins-%s.ttf' % n) for k, n in (('r', 'Regular'), ('m', 'Medium'), ('b', 'Bold'))}
    if all(os.path.isfile(v) for v in pop.values()): return pop
    pairs = [('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
             ('/usr/share/fonts/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf')]
    win = os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts')
    pairs += [(os.path.join(win, 'segoeui.ttf'), os.path.join(win, 'segoeuib.ttf')), (os.path.join(win, 'arial.ttf'), os.path.join(win, 'arialbd.ttf'))]
    for a, b in pairs:
        if os.path.isfile(a): b = b if os.path.isfile(b) else a; return {'r': a, 'm': b, 'b': b}
    return {'r': None, 'm': None, 'b': None}

def bake(doc):
    """Kalem izleri PDF'te not (annotation) olarak durur; başka sayfaya gömülürken
    görünmeleri için sayfa içeriğine işlenir."""
    if hasattr(doc, 'bake'): doc.bake(annots=True, widgets=False)
    else:   # eski PyMuPDF: sayfayı resim olarak yeniden çiz
        for i in range(len(doc)):
            pg = doc[i]; pix = pg.get_pixmap(matrix=fitz.Matrix(3, 3), alpha=False); r = pg.rect
            for a in list(pg.annots() or []): pg.delete_annot(a)
            pg.clean_contents(); pg.insert_image(r, pixmap=pix, overlay=True)

def find_questions(page):
    """Sayfadaki soruları bulur (yazısı seçilebilen PDF; test kitapları: tek başına duran "1." numaraları,
    bir ya da iki sütun). Her soru: numarasından aynı sütundaki bir sonraki numaraya (ya da sütun sonuna) kadar.
    Döner: [(numara, fitz.Rect)]. Taranmış (yazısız) sayfada boş liste."""
    import re
    W, H = page.rect.width, page.rect.height; top, bot = H*0.06, H*0.95   # üst başlık bandı ve alt bilgi dışarıda
    lines = []
    try: blocks = page.get_text('dict', flags=fitz.TEXT_PRESERVE_WHITESPACE | fitz.TEXT_MEDIABOX_CLIP)['blocks']   # resimler çözülmez: ~200 ms → ~6 ms
    except Exception: return []
    for b in blocks:
        for l in b.get('lines', []):
            t = ''.join(sp['text'] for sp in l['spans']).replace('\t', ' ')
            if t.strip(): lines.append((l['bbox'], t))
    starts = []
    for (x0, y0, x1, y1), t in lines:
        m = re.match(r'^\s*(\d{1,2})\s*\.\s*$', t)
        if m and top <= y0 <= bot and x0 < W*0.62 and x1 - x0 < 24 and 1 <= int(m.group(1)) <= 40: starts.append((int(m.group(1)), x0, y0))
    if not starts:   # numarası yazıyla aynı satırda olan sorular ("1. Table below ...")
        for (x0, y0, x1, y1), t in lines:
            m = re.match(r'^\s*(\d{1,2})\s*[\.\)]\s+\S', t)
            if m and top <= y0 <= bot and x0 < W*0.62 and 1 <= int(m.group(1)) <= 40: starts.append((int(m.group(1)), x0, y0))
    if not starts: return []
    cols = []
    for st in sorted(starts, key=lambda q: q[1]):
        for c in cols:
            if abs(c[0] - st[1]) < 25: c[1].append(st); break
        else: cols.append([st[1], [st]])
    cols.sort(key=lambda c: c[0]); out = []
    for ci, (cx, ss) in enumerate(cols):
        x0 = cx - 6; x1 = (cols[ci + 1][0] - 8) if ci + 1 < len(cols) else W - 22
        ys = [bb[3] for bb, t in lines if bb[0] >= x0 - 4 and bb[2] <= x1 + 30 and top < bb[1] < bot]
        cb = max(ys) if ys else bot
        ss = sorted(ss, key=lambda q: q[2])
        for i, (n, _, y) in enumerate(ss):
            y1 = (ss[i + 1][2] - 6) if i + 1 < len(ss) else cb + 8
            r = fitz.Rect(x0, y - 4, x1, min(y1, bot))
            if r.height >= 30 and r.width >= 60: out.append((n, r))
    return out

def content_box(page, clip, marks):
    """Çerçevenin içinde gözle görülen kısım: alan resim gibi çizilir ve beyaz olmayan
    noktaların kutusu alınır. (PDF'teki görünmez yazı katmanı, beyaz kutu, kırpma
    alanı gibi nesneler hesaba katılmaz; kenar boşlukları kesilir, soru büyük çıkar.)"""
    clip = fitz.Rect(clip)
    if clip.is_empty: return clip
    try:
        z = min(4.0, 1400/max(clip.width, clip.height))
        pix = page.get_pixmap(matrix=fitz.Matrix(z, z), clip=clip, colorspace=fitz.csGRAY, alpha=False)
        w, h, st, data = pix.width, pix.height, pix.stride, pix.samples
        ink = bytes(1 if v < 225 else 0 for v in range(256))   # açık gri kâğıt dokusu sayılmaz
        x0, x1, y0, y1 = w, -1, None, None
        for y in range(h):
            row = data[y*st:y*st+w].translate(ink)
            a = row.find(1)
            if a < 0: continue
            if y0 is None: y0 = y
            y1 = y; x0 = min(x0, a); x1 = max(x1, row.rfind(1))
        r = fitz.Rect() if y0 is None else fitz.Rect(clip.x0 + x0/z, clip.y0 + y0/z, clip.x0 + (x1+1)/z, clip.y0 + (y1+1)/z)
    except Exception: return clip
    for st_ in marks or []:
        if st_.get('tool') == 'whiteout' or not st_.get('points'): continue
        xs = [q[0] for q in st_['points']]; ys = [q[1] for q in st_['points']]; lw = st_.get('width', 3)
        b = fitz.Rect(min(xs)-lw, min(ys)-lw, max(xs)+lw, max(ys)+lw) & clip
        if not b.is_empty: r |= b
    return clip if r.is_empty or r.width < 8 or r.height < 8 else r

def legacy_card(clip):
    """Eski çözüm alanı yerleşimi (en çok 300 birim yükseklik): eski çözümler yerinde açılsın."""
    clip = fitz.Rect(clip); h = min(300, GUNUN_CARD*clip.height/max(clip.width, 1))
    s = min(GUNUN_CARD/max(clip.width, 1), h/max(clip.height, 1)); w = clip.width*s; x0 = 48 + (GUNUN_CARD - w)/2
    return [x0, 36, x0 + w, 36 + clip.height*s]
SOLUTION_CARD_SHARE = .62   # soru kartı ekranın en çok bu kadarını kaplar; kalanı çözüm için boş kalır
def fit_card(clip, vw, vh):
    """Çözüm alanı: tahta genişliğe sığar, soru olabildiğince büyük; kart ekran yüksekliğinin
    en çok SOLUTION_CARD_SHARE'i kadar. Döner: (soru görüntüsünün yeri, yakınlaştırma)."""
    clip = fitz.Rect(clip); zoom = max(.5, (vw - 8)/960); seen = (vh - 8)/zoom
    hmax = max(120, seen*SOLUTION_CARD_SHARE - 52)   # kart çerçevesi: üstte 36, altta 16 birim
    w = GUNUN_CARD; h = w*clip.height/max(clip.width, 1)
    if h > hmax: h = hmax; w = h*clip.width/max(clip.height, 1)
    x0 = 480 - w/2
    return [x0, 36, x0 + w, 36 + h], zoom
def question_card(src, page_no, page_marks, clip, ink=None, card=None):
    """Soru (+ çözüm mürekkebi) tek sayfalık PDF, çözüm alanıyla aynı yerleşimde
    (soru 864 birim genişlikte; mürekkep koordinatları birebir tutar).
    Döner: (pdf baytları, tüm kırpma, yalnız soru kırpması)."""
    clip = fitz.Rect(clip)
    box = content_box(src[page_no], clip, page_marks)
    with tempfile.TemporaryDirectory() as folder:
        single = fitz.open(); single.insert_pdf(src, from_page=page_no, to_page=page_no)
        path = os.path.join(folder, 'soru.pdf'); export_document(single, {0: page_marks or []}, path); single.close()
        qdoc = fitz.open(path); bake(qdoc)   # notlar sayfaya işlenir (gömülünce kaybolmasın)
        cr = fitz.Rect(card or legacy_card(clip)); s = cr.width/max(clip.width, 1); x0 = cr.x0
        q = fitz.Rect(x0 + (box.x0-clip.x0)*s, cr.y0 + (box.y0-clip.y0)*s, x0 + (box.x1-clip.x0)*s, cr.y0 + (box.y1-clip.y0)*s)
        full = fitz.Rect(q)
        for st in ink or []:
            if not st.get('points'): continue
            w = st.get('width', 3); xs = [p_[0] for p_ in st['points']]; ys = [p_[1] for p_ in st['points']]
            full |= fitz.Rect(min(xs)-w, min(ys)-w, max(xs)+w, max(ys)+w)
        height = max(800, full.y1 + 40)
        doc = fitz.open(); page = doc.new_page(width=960, height=height)
        page.show_pdf_page(cr, qdoc, 0, clip=clip)
        qdoc.close()
        out = os.path.join(folder, 'kart.pdf'); export_document(doc, {0: ink or []}, out); doc.close()
        kd = fitz.open(out); bake(kd); data = kd.tobytes(garbage=3, deflate=True); kd.close()
    pad = lambda r, k: [max(0, r.x0-k), max(0, r.y0-k), min(960, r.x1+k), min(height, r.y1+k)]
    return data, pad(full, 10), pad(q, 6)

def daily_grid(n, W, H, aspects, gap):
    """1 ya da 2 sütun: soruların en büyük çıktığı düzen (aspects: yükseklik/genişlik)."""
    best = None
    for cols in (1, 2):
        if cols > n: break
        rows = math.ceil(n/cols); cw = (W - gap*(cols-1))/cols; ch = (H - gap*(rows-1))/rows
        sc = min(min(cw, ch/a) for a in aspects)
        if best is None or sc > best[0] + .01: best = (sc, cols, rows, cw, ch)
    return best[1:]

def build_daily_pdf(items, folder, date_text, topic, teacher, target):
    """Kareli defter mizanpajı (A4). Önce soruların boş hâli (altı kareli çözüm alanı),
    sonra yeni sayfadan çözümler, aynı numaralarla. Sayfada en çok 4 soru; sorular
    sayfaya yayılır, kenar boşlukları kesilip olabildiğince büyük konur."""
    W, H, M = 595, 842, 30
    TEAL = (.04, .43, .4); LIGHT = (.9, .96, .95); DARK = (.1, .12, .15); GRID = (.8, .9, .89)
    fonts = pdf_fonts(); out = fitz.open()
    def width_of(t, size, f):
        return fitz.Font(fontfile=fonts[f]).text_length(t, fontsize=size) if fonts[f] else fitz.get_text_length(t, fontsize=size)
    def text(pg, x, y, t, size, f='r', color=DARK, right=False, center=False):
        if right: x -= width_of(t, size, f)
        if center: x -= width_of(t, size, f)/2
        if fonts[f]: pg.insert_text((x, y), t, fontsize=size, fontname='umal' + f, fontfile=fonts[f], color=color)
        else: pg.insert_text((x, y), t, fontsize=size, color=color)
    srcs = {}
    def src(name):
        if name not in srcs: srcs[name] = fitz.open(os.path.join(folder, name))
        return srcs[name]
    def place(pg, rect, name, clip):
        clip = fitz.Rect(clip); s = min(rect.width/clip.width, rect.height/clip.height)
        r = fitz.Rect(rect.x0, rect.y0, rect.x0 + clip.width*s, rect.y0 + clip.height*s)
        pg.show_pdf_page(r, src(name), 0, clip=clip); return r.height
    pages = []   # (bölüm başlığı, ilk sayfa mı, [(no, dosya, kırpma)], boş mu)
    blank = [(n+1, it.get('qsnap') or it['snap'], it.get('qcrop') or it['crop']) for n, it in enumerate(items)]
    solved = [(n+1, it['snap'], it['crop']) for n, it in enumerate(items) if it['done']]
    for title, cards, is_blank in (('Günün soruları', blank, True), ('Çözümler', solved, False)):
        for k in range(0, len(cards), 4): pages.append((title, k == 0, cards[k:k+4], is_blank))
    for pi, (title, first, cards, is_blank) in enumerate(pages):
        pg = out.new_page(width=W, height=H)
        if pi == 0:
            pg.draw_rect(fitz.Rect(M, 28, M+6, 80), color=None, fill=TEAL)
            text(pg, M+16, 52 if topic else 60, title, 22, 'b')
            if topic: text(pg, M+16, 72, topic, 11, 'm', TEAL)
            r = fitz.Rect(W-M-140, 34, W-M, 74); pg.draw_rect(r, color=None, fill=LIGHT, radius=.25)
            text(pg, r.x0+70, 50, 'TARİH', 7.5, 'm', TEAL, center=True); text(pg, r.x0+70, 66, date_text, 9.5, 'm', center=True)
            top = 100
        else:
            pg.draw_rect(fitz.Rect(M, 28, M+6, 56), color=None, fill=TEAL)
            text(pg, M+16, 48, title if first or title == 'Çözümler' else title, 16, 'b'); text(pg, W-M, 48, date_text, 9.5, 'r', (.4, .45, .45), right=True)
            top = 74
        area = fitz.Rect(M, top, W-M, H-50); gap = 14
        aspects = [(2.2 if is_blank else 1.0)*fitz.Rect(c).height/fitz.Rect(c).width + 44/max(fitz.Rect(c).width, 1) for _, _, c in cards]
        cols, rows, cw, ch = daily_grid(len(cards), area.width - 44*0, area.height, aspects, gap)
        for k, (no, name, clip) in enumerate(cards):
            row, col = divmod(k, cols)
            if cols == 2 and len(cards) % 2 and k == len(cards)-1: x = area.x0 + (area.width-cw)/2   # tek kalan: ortada
            else: x = area.x0 + col*(cw+gap)
            cell = fitz.Rect(x, area.y0 + row*(ch+gap), x+cw, area.y0 + row*(ch+gap) + ch)
            pg.draw_rect(cell, color=(.78, .86, .85), fill=(1, 1, 1), width=.7, radius=min(.03, 8/max(cell.height, 1)))
            tab = fitz.Rect(cell.x0-1, cell.y0+12, cell.x0+28, cell.y0+38); pg.draw_rect(tab, color=None, fill=TEAL)
            text(pg, tab.x0+14.5, tab.y0+18, str(no), 12, 'b', (1, 1, 1), center=True)
            inner = fitz.Rect(cell.x0+34, cell.y0+10, cell.x1-10, cell.y1-10)
            if is_blank:
                h = place(pg, fitz.Rect(inner.x0, inner.y0, inner.x1, inner.y0 + inner.height*.5), name, clip)
                a = fitz.Rect(cell.x0+10, inner.y0+h+10, cell.x1-10, cell.y1-10); step = 12
                if a.height > step:
                    x_ = a.x0
                    while x_ <= a.x1 + .1: pg.draw_line((x_, a.y0), (x_, a.y1), color=GRID, width=.4); x_ += step
                    y_ = a.y0
                    while y_ <= a.y1 + .1: pg.draw_line((a.x0, y_), (a.x1, y_), color=GRID, width=.4); y_ += step
            else: place(pg, inner, name, clip)
        text(pg, W/2, H-26, '%d / %d' % (pi+1, len(pages)), 8.5, 'r', (.45, .5, .5), center=True)
        if teacher and pi == len(pages)-1: text(pg, W-M, H-26, 'Öğretmen: ' + teacher, 9, 'm', TEAL, right=True)
    for d in srcs.values(): d.close()
    try: out.subset_fonts()
    except Exception: pass
    out.save(target, garbage=3, deflate=True); out.close()

class DailyStrip(QWidget):
    """Günün soruları listesi: yazı alanının sağ üstünde 1, 2, 3… ve +."""
    S, GAP = 46, 10
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.setCursor(Qt.PointingHandCursor); self.hide()
    def sync(self):
        n = len(self.main.daily['items'])
        self.setFixedSize(self.S + 12, (n + 1)*(self.S + self.GAP) + 4)
        self.setVisible(n > 0 or self.main.tool == 'pick'); self.update()
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); f = p.font(); f.setPixelSize(18); f.setBold(True); p.setFont(f)
        cur = self.main.daily_current()
        for i, it in enumerate(self.main.daily['items'] + [None]):
            r = QRectF(5, 5 + i*(self.S + self.GAP), self.S, self.S)
            if it is None:
                p.setPen(QPen(QColor('#8fa3bd'), 1.5, Qt.DashLine)); p.setBrush(QColor(11, 31, 58, 215)); p.drawRoundedRect(r, 10, 10)
                p.setPen(QPen(QColor('#dbe6f5'), 2.4)); c = r.center()
                p.drawLine(QPointF(c.x()-8, c.y()), QPointF(c.x()+8, c.y())); p.drawLine(QPointF(c.x(), c.y()-8), QPointF(c.x(), c.y()+8)); continue
            now = i == cur
            p.setPen(QPen(QColor('#ffe14d' if now else '#6fa8ff' if it['done'] else '#3a5577'), 2))
            p.setBrush(QColor('#1d4f8f') if it['done'] else QColor(11, 31, 58, 225)); p.drawRoundedRect(r, 10, 10)
            p.setPen(QColor('#ffe14d' if now else '#ffffff')); p.drawText(r, Qt.AlignCenter, str(i+1))
            if it['done']:
                b = QRectF(r.right()-12, r.top()-4, 16, 16); p.setPen(Qt.NoPen); p.setBrush(QColor('#00a24a')); p.drawEllipse(b)
                p.setPen(QPen(QColor('white'), 2)); p.drawPolyline(QPolygonF([QPointF(b.x()+4, b.y()+8.5), QPointF(b.x()+7, b.y()+11.5), QPointF(b.x()+12.5, b.y()+5)]))
    def mousePressEvent(self, e):
        i = int((e.pos().y() - 5)//(self.S + self.GAP)); n = len(self.main.daily['items'])
        if 0 <= i < n: self.main.daily_open(i)
        elif i == n: self.main.set_tool('pick')

class DailyDialog(QDialog):
    """Günün soruları: tarih, isteğe bağlı konu ve öğretmen adı; soruları seç, önizle, gönder."""
    def __init__(self, main):
        super().__init__(main); self.main = main
        from PyQt5.QtWidgets import QCheckBox, QLineEdit, QGridLayout
        self.setWindowTitle('Günün soruları'); self.setModal(True)
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(820, scr.width()-80), min(640, scr.height()-80))
        box = QVBoxLayout(self); box.setContentsMargins(20, 18, 20, 18); box.setSpacing(12)
        self.title = QLabel(); self.title.setStyleSheet('font-size:20px;font-weight:bold;'); box.addWidget(self.title)
        cfg = main.daily_cfg(); grid = QGridLayout(); grid.setHorizontalSpacing(14); grid.setVerticalSpacing(12); box.addLayout(grid)
        grid.addWidget(QLabel('Tarih'), 0, 0); grid.addWidget(QLabel(daily_date_text()), 0, 1)
        self.topic_on = QCheckBox('Konu'); self.topic_on.setChecked(cfg.get('konu_on', True)); grid.addWidget(self.topic_on, 1, 0)
        self.topic = QLineEdit(cfg.get('konu', '') if cfg.get('konu_gun') == daily_today() else ''); grid.addWidget(self.topic, 1, 1)
        self.teacher_on = QCheckBox('Öğretmen'); self.teacher_on.setChecked(cfg.get('ogretmen_on', False)); grid.addWidget(self.teacher_on, 2, 0)
        self.teacher = QLineEdit(cfg.get('ogretmen', '')); self.teacher.setPlaceholderText('Ad Soyad'); grid.addWidget(self.teacher, 2, 1)
        for c in (self.topic, self.teacher): c.setMinimumHeight(48); c.installEventFilter(self)
        self.keyboard = TouchKeyboard(self); self.keyboard.hide()
        self.note = QLabel(); self.note.setWordWrap(True); self.note.setStyleSheet('color:#a9b9cf;'); box.addWidget(self.note)
        self.chips = QWidget(); self.chip_row = QHBoxLayout(self.chips); self.chip_row.setContentsMargins(0, 0, 0, 0); self.chip_row.setSpacing(8)
        box.addWidget(self.chips); box.addStretch(1); box.addWidget(self.keyboard)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row)
        for text, fn, name in (('Soru seç', self.pick, ''), ('Listeyi temizle', self.clear, ''), ('Önizle', self.preview, ''), ('Gönder', self.send, 'primary'), ('Kapat', self.close_save, '')):
            b = QPushButton(text); b.setObjectName(name); b.setMinimumHeight(52); b.clicked.connect(fn); row.addWidget(b, 1)
        self.refresh()
    def eventFilter(self, obj, e):
        # Tahtanın kendi klavyesi her zaman açılmıyor: alana dokununca uygulamanın klavyesi çıkar.
        if e.type() in (QEvent.MouseButtonPress, QEvent.FocusIn) and obj in (self.topic, self.teacher):
            self.keyboard.attach(obj)
            if self.keyboard.isHidden():
                self.keyboard.show(); scr = QApplication.primaryScreen().availableGeometry()
                self.resize(self.width(), min(scr.height()-40, max(self.height(), self.sizeHint().height())))
                self.move(self.x(), max(scr.top()+10, min(self.y(), scr.bottom()-self.height()-10)))
        return False
    def refresh(self):
        items = self.main.daily['items']
        while self.chip_row.count():
            w = self.chip_row.takeAt(0).widget()
            if w: w.deleteLater()
        for i, it in enumerate(items):
            b = QPushButton(str(i+1) + ('' if it['done'] else ' · çözülmedi')); b.setCheckable(True); b.setChecked(it.get('include', it['done']))
            b.setMinimumHeight(44); b.setStyleSheet('QPushButton{padding:0 14px;} QPushButton:!checked{color:#7f8fa6;text-decoration:line-through;}')
            b.toggled.connect(lambda v, it_=it: (it_.__setitem__('include', v), self.main.save_daily(), self.refresh_title())); self.chip_row.addWidget(b)
        self.chip_row.addStretch(1); self.refresh_title()
        self.note.setText('Numaraya dokunarak soruyu sayfaya alın ya da çıkarın. Seçilenler 1’den yeniden sıralanır.' if items else
                          'Henüz soru yok. Dersin başında “Soru seç” ile soruları çerçeveleyin; seçmezseniz derste açtığınız çözüm alanları buraya kendiliğinden gelir.')
    def refresh_title(self):
        k = len(self.main.daily_selected()); self.title.setText('Günün soruları · %d soru' % k)
    def values(self):
        topic = self.topic.text().strip() if self.topic_on.isChecked() else ''
        teacher = self.teacher.text().strip() if self.teacher_on.isChecked() else ''
        self.main.save_daily_cfg(dict(konu_on=self.topic_on.isChecked(), konu=self.topic.text().strip(), konu_gun=daily_today(),
                                      ogretmen_on=self.teacher_on.isChecked(), ogretmen=self.teacher.text().strip()))
        return topic, teacher
    def close_save(self): self.values(); self.accept()
    def pick(self): self.values(); self.accept(); self.main.set_tool('pick')
    def clear(self):
        if QMessageBox.question(self, 'Listeyi temizle', 'Günün soruları listesi boşaltılsın mı? (Çözümler kitapta kalır.)', QMessageBox.Yes|QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
        self.main.clear_daily(); self.refresh()
    def preview(self):
        if not self.main.daily_selected(): self.note.setText('Sayfaya alınacak soru yok.'); return
        topic, teacher = self.values(); path = os.path.join(tempfile.gettempdir(), 'umal-gunun-onizleme.pdf')
        try: self.main.write_daily(path, topic, teacher)
        except Exception as e: QMessageBox.warning(self, 'Önizleme yapılamadı', str(e)); return
        d = QDialog(self); d.setWindowTitle('Önizleme'); scr = QApplication.primaryScreen().availableGeometry(); d.resize(min(900, scr.width()-60), scr.height()-80)
        lay = QVBoxLayout(d); sc = QScrollArea(); sc.setWidgetResizable(True); lay.addWidget(sc, 1); holder = QWidget(); v = QVBoxLayout(holder); v.setSpacing(16)
        doc = fitz.open(path); width = min(820, scr.width()-120)
        for pg in doc:
            z = width/pg.rect.width; pix = pg.get_pixmap(matrix=fitz.Matrix(z, z), alpha=False)
            lab = QLabel(); lab.setPixmap(QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy())); lab.setAlignment(Qt.AlignCenter); v.addWidget(lab)
        doc.close(); sc.setWidget(holder)
        b = QPushButton('Kapat'); b.setMinimumHeight(48); b.clicked.connect(d.accept); lay.addWidget(b); d.exec_()
    def send(self):
        if not self.main.daily_selected(): self.note.setText('Sayfaya alınacak soru yok.'); return
        topic, teacher = self.values()
        try: name = self.main.send_daily(topic, teacher)
        except Exception as e: QMessageBox.warning(self, 'Gönderilemedi', str(e)); return
        self.accept(); self.main.show_toast('Günün soruları hazır: %s\nDrive’daki “Günün Soruları” klasörüne yükleniyor.' % name)

class TouchKeyboard(QWidget):
    """Uygulamanın kendi Türkçe Q klavyesi (dokunmatik tahtada sistem klavyesi açılmayabiliyor)."""
    ROWS = [list('1234567890') + ['⌫'], list('qwertyuıopğü'), list('asdfghjklşi'), ['⇧'] + list('zxcvbnmöç.'), [',', '-', ' ', 'Tamam']]
    def __init__(self, parent):
        super().__init__(parent); self.target = None; self.shift = False; self.keys = []
        from PyQt5.QtWidgets import QGridLayout
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 6, 0, 0); lay.setSpacing(6)
        for row in self.ROWS:
            r = QHBoxLayout(); r.setSpacing(6); lay.addLayout(r)
            for k in row:
                b = QPushButton('boşluk' if k == ' ' else k); b.setFocusPolicy(Qt.NoFocus); b.setFixedHeight(56)
                b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed); b.setStyleSheet('QPushButton{font-size:22px;padding:0;min-height:56px;max-height:56px;}')
                if k == 'Tamam': b.setObjectName('primary')
                b.clicked.connect(lambda checked=False, k_=k: self.press(k_)); r.addWidget(b, 5 if k == ' ' else 2 if k in ('Tamam', '⌫', '⇧') else 1)
                self.keys.append((k, b))
    def attach(self, edit):
        self.target = edit; self.set_shift(not edit.text())   # boş alanda büyük harfle başla
    def set_shift(self, on):
        self.shift = on
        for k, b in self.keys:
            if len(k) == 1 and k.isalpha(): b.setText(self.upper(k) if on else k)
            if k == '⇧': b.setStyleSheet('QPushButton{font-size:22px;padding:0;min-height:56px;max-height:56px;%s}' % ('background:#2f6fd6;color:white;' if on else ''))
    @staticmethod
    def upper(k): return {'i': 'İ', 'ı': 'I'}.get(k, k.upper())
    def press(self, k):
        t = self.target
        if k == 'Tamam': self.hide(); return
        if k == '⇧': self.set_shift(not self.shift); return
        if t is None: return
        if k == '⌫': t.backspace(); return
        t.insert(self.upper(k) if self.shift and k.isalpha() else k)
        if self.shift: self.set_shift(False)

def attach_touch_keyboard(dlg, edit, layout):
    """Diyalogdaki yazı alanına dokununca uygulamanın klavyesi çıkar (tahtada sistem klavyesi açılmayabiliyor)."""
    from PyQt5.QtCore import QObject
    kb = TouchKeyboard(dlg); kb.hide(); layout.addWidget(kb); dlg._kb = kb; dlg._kb_edit = edit
    class _F(QObject):
        def eventFilter(self_, o, e):
            if e.type() == QEvent.MouseButtonPress and o is edit:
                kb.attach(edit)
                if kb.isHidden():
                    kb.show(); dlg.adjustSize(); scr = QApplication.primaryScreen().availableGeometry()
                    dlg.resize(dlg.width(), min(scr.height() - 40, max(dlg.height(), dlg.sizeHint().height())))
                    dlg.move(dlg.x(), max(scr.top() + 10, min(dlg.y(), scr.bottom() - dlg.height() - 10)))
            return False
    f = _F(dlg); edit.installEventFilter(f); dlg._kb_filter = f
    return kb

NEON_ARA_TEXT = 'Nerede sınava gireceğim?'
def neon_button(parent, on_click, font_px=22):
    """Neon tabela gibi parlayan düğme (camgöbeği kenar ve yazı, nefes alan ışıma): öğrenci araması için."""
    from PyQt5.QtWidgets import QGraphicsDropShadowEffect
    b = QPushButton(NEON_ARA_TEXT, parent); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(58); b.clicked.connect(on_click)
    b.setStyleSheet('QPushButton{background:rgba(8,14,30,0.92);color:#7ff6ff;border:3px solid #22e8ff;border-radius:18px;padding:0 30px;font-size:%dpx;font-weight:800;}'
                    'QPushButton:pressed{background:#0d2a3a;}' % font_px)
    fx = QGraphicsDropShadowEffect(b); fx.setColor(QColor(34, 232, 255)); fx.setOffset(0, 0); fx.setBlurRadius(30); b.setGraphicsEffect(fx)
    a = QVariantAnimation(b); a.setStartValue(16.0); a.setKeyValueAt(0.5, 44.0); a.setEndValue(16.0); a.setDuration(2200); a.setLoopCount(-1)
    a.valueChanged.connect(lambda v: fx.setBlurRadius(float(v))); a.start(); b._neon = a
    return b

OFFICE_EXTS = ('.pptx', '.ppt', '.ppsx', '.pps', '.odp', '.docx', '.doc', '.odt', '.rtf')
def office_binary():
    """Tahtadaki LibreOffice (PowerPoint/Word dosyalarını PDF'e çevirmek için); yoksa None."""
    for n in ('libreoffice', 'soffice', '/usr/lib/libreoffice/program/soffice', '/opt/libreoffice/program/soffice'):
        p = shutil.which(n) if not n.startswith('/') else (n if os.access(n, os.X_OK) else None)
        if p: return p
    return None
def office_to_pdf(main, path):
    """PowerPoint/Word belgesini PDF'e çevirir (LibreOffice, ekransız); çevrilmiş kopya saklanır, ikinci açılış anında olur.
    Döner: (pdf yolu, sekme adı). Fotoğraf ve yazılar olduğu gibi; animasyon yok (sayfa sayfa)."""
    import hashlib, subprocess, threading
    st = os.stat(path); key = hashlib.sha1(('%s|%d|%d' % (os.path.realpath(path), st.st_size, int(st.st_mtime))).encode('utf-8')).hexdigest()[:16]
    name = os.path.splitext(os.path.basename(path))[0]
    folder = os.path.join(main.data_dir, 'ofis'); os.makedirs(folder, exist_ok=True)
    out = os.path.join(folder, '%s-%s.pdf' % (''.join(c for c in name if c not in '/\\:*?"<>|')[:60] or 'belge', key))
    if os.path.isfile(out) and os.path.getsize(out) > 0: return out, name
    exe = office_binary()
    if not exe: raise ValueError('Bu tahtada LibreOffice bulunamadı; PowerPoint/Word dosyası çevrilemiyor.\nDosyayı PDF olarak kaydedip açabilirsiniz.')
    tmp = tempfile.mkdtemp(prefix='umal-ofis-'); prof = os.path.join(tempfile.gettempdir(), 'umal-lo-profil')
    res = {}
    def work():
        try: res['r'] = subprocess.run([exe, '-env:UserInstallation=file://' + prof, '--headless', '--norestore', '--convert-to', 'pdf', '--outdir', tmp, path],
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
        except Exception as e: res['e'] = e
    th = threading.Thread(target=work, daemon=True); th.start()
    main.statusBar().showMessage('“%s” hazırlanıyor… (PowerPoint/Word sayfaları PDF’e çevriliyor, birkaç saniye sürer)' % name)
    QApplication.setOverrideCursor(Qt.WaitCursor)
    try:
        while th.is_alive(): QApplication.processEvents(); th.join(0.05)
    finally: QApplication.restoreOverrideCursor()
    if 'e' in res: raise ValueError('Belge çevrilemedi: %s' % res['e'])
    made = [f for f in os.listdir(tmp) if f.lower().endswith('.pdf')]
    if not made:
        err = (res.get('r').stderr or b'').decode('utf-8', 'replace')[-300:] if res.get('r') else ''
        raise ValueError('Belge PDF’e çevrilemedi.' + ('\n' + err if err.strip() else ''))
    shutil.move(os.path.join(tmp, made[0]), out); shutil.rmtree(tmp, ignore_errors=True)
    main.statusBar().showMessage('“%s” açıldı · sayfalar resim gibi; üstüne yazabilirsiniz' % name)
    return out, name

def daily_today():
    import datetime; return datetime.date.today().isoformat()
def daily_date_text():
    import datetime; d = datetime.date.today()
    return '%d %s %d %s' % (d.day, TR_MONTHS[d.month-1], d.year, TR_DAYS[d.weekday()])

class HavuzDialog(QDialog):
    """PDF Havuzu: every board's shared PDFs. Tap to open, remove from this
    board only, add a PDF for all boards, bring back removed ones."""
    def __init__(self, main):
        super().__init__(main); self.main = main
        self.setWindowTitle('PDF Havuzu'); self.setModal(True)
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(900, scr.width()-80), min(760, scr.height()-80))
        box = QVBoxLayout(self); box.setContentsMargins(18, 16, 18, 16); box.setSpacing(10)
        title = QLabel('PDF Havuzu'); title.setStyleSheet('font-size:20px;font-weight:bold;'); box.addWidget(title)
        self.note = QLabel(); self.note.setWordWrap(True); self.note.setStyleSheet('color:#a9b9cf;'); box.addWidget(self.note)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); box.addWidget(self.scroll, 1)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row)
        # One-time: link the pool to the school's Google account (opens the board's browser).
        self.link_button = QPushButton('Havuzu Google hesabına bağla (bir kez)'); self.link_button.setMinimumHeight(48)
        self.link_button.clicked.connect(self.link); self.link_button.hide(); box.insertWidget(2, self.link_button)
        for text, fn, name in (('Havuza PDF ekle', self.add_pdf, 'primary'), ('Şimdi eşitle', self.sync_now, ''), ('Kapat', self.accept, '')):
            b = QPushButton(text); b.setObjectName(name); b.setMinimumHeight(48); b.clicked.connect(fn); row.addWidget(b, 1)
        self.auth = None
        self.shown = None; self.show_removed = False
        self.timer = QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(2000); self.refresh()
    def state(self):
        try:
            with open(os.path.join(havuz_data(), 'durum.json'), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {'known': {}, 'removed': []}
    def status(self):
        try:
            with open(os.path.join(havuz_data(), 'son.json'), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {}
    def refresh(self):
        os.makedirs(HAVUZ_DIR, exist_ok=True)
        files = sorted((n for n in os.listdir(HAVUZ_DIR) if n.lower().endswith('.pdf') and not n.startswith('.')), key=str.lower)
        busy = [n[len('.indiriliyor-'):] for n in os.listdir(HAVUZ_DIR) if n.startswith('.indiriliyor-')]
        removed = self.state().get('removed', []); st = self.status()
        self.link_button.setVisible(st.get('durum') == 'bagli-degil' and os.path.isfile(HAVUZ_RCLONE) and self.auth is None)
        if not havuz_ready(): note = 'Bu cihazda havuz eşitleyicisi kurulu değil; yalnızca bu tahtadaki PDF\'ler görünür.'
        elif st.get('durum') == 'bagli-degil': note = 'Havuz henüz okul hesabına bağlanmadı.'
        elif st.get('durum') == 'hata': note = 'Son eşitleme yapılamadı: ' + st.get('mesaj', '')
        elif st.get('zaman'): note = '%s · son eşitleme %s' % (st.get('mesaj', ''), time.strftime('%H:%M', time.localtime(st['zaman'])))
        else: note = 'İlk eşitleme bekleniyor…'
        if busy: note += '\nİndiriliyor: ' + ', '.join(busy)
        self.note.setText(note)
        key = (tuple(files), tuple(removed), self.show_removed)
        if key == self.shown: return
        self.shown = key
        holder = QWidget(); lay = QVBoxLayout(holder); lay.setContentsMargins(0, 0, 8, 0); lay.setSpacing(6)
        if not files:
            empty = QLabel('Havuzda henüz PDF yok. "Havuza PDF ekle" ile ilk dosyayı ekleyin; birkaç dakika içinde bütün tahtalarda görünür.')
            empty.setWordWrap(True); lay.addWidget(empty)
        for name in files:
            line = QHBoxLayout(); line.setSpacing(6)
            size = os.path.getsize(os.path.join(HAVUZ_DIR, name)) / 1048576
            b = QPushButton('%s   ·   %s MB' % (os.path.splitext(name)[0], ('%.1f' % size).replace('.', ','))); b.setIcon(tool_icon('PDF aç'))
            b.setStyleSheet('QPushButton{text-align:left;padding:8px 14px;font-size:16px;}'); b.setMinimumHeight(52)
            b.clicked.connect(lambda checked=False, n=name: self.open(n)); line.addWidget(b, 1)
            r = QPushButton('Bu tahtadan kaldır'); r.setMinimumHeight(52); r.clicked.connect(lambda checked=False, n=name: self.remove(n)); line.addWidget(r)
            lay.addLayout(line)
        if removed:
            t = QPushButton(('▾ ' if self.show_removed else '▸ ') + 'Bu tahtadan kaldırılanlar (%d)' % len(removed)); t.setMinimumHeight(44)
            t.setStyleSheet('QPushButton{text-align:left;padding:6px 14px;}'); t.clicked.connect(self.toggle_removed); lay.addWidget(t)
            if self.show_removed:
                for name in removed:
                    line = QHBoxLayout(); lab = QLabel('   ' + os.path.splitext(name)[0]); line.addWidget(lab, 1)
                    g = QPushButton('Geri al'); g.setMinimumHeight(44); g.clicked.connect(lambda checked=False, n=name: self.restore(n)); line.addWidget(g)
                    lay.addLayout(line)
        lay.addStretch(); self.scroll.setWidget(holder)
    def toggle_removed(self):
        self.show_removed = not self.show_removed; self.shown = None; self.refresh()
    def open(self, name):
        self.accept(); self.main.open_pdf_path(os.path.join(HAVUZ_DIR, name))
    def remove(self, name):
        if QMessageBox.question(self, 'Bu tahtadan kaldır', '“%s” bu tahtadan kaldırılsın mı?\n\nHavuzda ve diğer tahtalarda kalır. İsterseniz “Bu tahtadan kaldırılanlar” listesinden geri alabilirsiniz.' % os.path.splitext(name)[0],
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
        try: os.remove(os.path.join(HAVUZ_DIR, name))
        except OSError as e: QMessageBox.warning(self, 'Kaldırılamadı', str(e)); return
        self.main.run_havuz('--hemen'); self.shown = None; self.refresh()
    def restore(self, name):
        self.main.run_havuz('--geri-al', name); self.note.setText('“%s” yeniden indiriliyor…' % os.path.splitext(name)[0])
    def add_pdf(self):
        paths, _ = QFileDialog.getOpenFileNames(self, 'Havuza PDF ekle', os.path.expanduser('~'), 'PDF dosyaları (*.pdf)')
        added = 0
        for path in paths:
            if os.path.realpath(os.path.dirname(path)) == os.path.realpath(HAVUZ_DIR): continue
            name = os.path.basename(path); target = os.path.join(HAVUZ_DIR, name); k = 2
            while os.path.exists(target): target = os.path.join(HAVUZ_DIR, '%s (%d).pdf' % (os.path.splitext(name)[0], k)); k += 1
            try: shutil.copy2(path, target); added += 1
            except OSError as e: QMessageBox.warning(self, 'Eklenemedi', str(e))
        if added:
            self.shown = None; self.refresh()
            self.note.setText('%d PDF eklendi, havuza gönderiliyor…' % added); self.main.run_havuz('--hemen')
    def sync_now(self):
        self.main.run_havuz('--hemen'); self.note.setText('Eşitleniyor…')
    def link(self):
        self.auth = QProcess(self); self.auth.setProcessChannelMode(QProcess.MergedChannels)
        self.auth.finished.connect(self.linked); self.link_button.hide()
        self.auth.start(HAVUZ_RCLONE, ['authorize', 'drive', '--drive-scope', 'drive.file'])
        self.note.setText('Tarayıcı açılıyor: okul hesabıyla giriş yapıp izin verin, sonra buraya dönün…')
    def linked(self, *args):
        out = bytes(self.auth.readAll()).decode('utf-8', 'replace'); self.auth = None
        token = token_from_authorize(out)
        if not token:
            self.note.setText('Bağlantı tamamlanamadı. Yeniden deneyin.'); self.shown = None; self.refresh(); return
        conf = '[havuz]\ntype = drive\nscope = drive.file\ntoken = %s\n' % token
        folder = havuz_data(); os.makedirs(folder, exist_ok=True); path = os.path.join(folder, 'rclone.conf')
        with open(path, 'w', encoding='utf-8') as f: f.write(conf)
        os.chmod(path, 0o600); self.main.run_havuz('--hemen')
        # Other boards get the link through the update: show it once to send to Claude.
        box = QDialog(self); box.setWindowTitle('Havuz bağlandı'); lay = QVBoxLayout(box)
        lab = QLabel('Bu tahta havuza bağlandı. Diğer tahtaların da bağlanması için aşağıdaki metni kopyalayıp Claude\'a gönderin; güncelleme ile bütün tahtalara dağıtılır.')
        lab.setWordWrap(True); lay.addWidget(lab)
        from PyQt5.QtWidgets import QPlainTextEdit
        text = QPlainTextEdit(conf); text.setReadOnly(True); text.setMinimumSize(700, 180); lay.addWidget(text)
        copy = QPushButton('Kopyala'); copy.setMinimumHeight(48); copy.clicked.connect(lambda: (QApplication.clipboard().setText(conf), copy.setText('Kopyalandı')))
        lay.addWidget(copy); box.exec_()
UPDATE_REQUEST = '/var/lib/umal-tahta/denetle'
APP_LAUNCHER = '/usr/bin/umal-tahta'   # Pardus paketi; yoksa (Windows) aynı Python ile bu dosya
UPDATE_LOG = '/var/log/umal-guncelle.log'
UPDATE_RESULTS = ('Güncel:', 'Kuruldu:', 'Bağlantı yok', 'TUTMADI', 'başarısız', 'yapılamadı', 'uyuşmuyor', 'geçersiz', 'okunamadı')

def installed_version():
    try:
        import subprocess
        v = subprocess.run(['dpkg-query', '-W', '-f=${Version}', 'umal-tahta'], capture_output=True, text=True, timeout=5).stdout.strip()
        return v or 'bilinmiyor'
    except Exception:
        return 'bilinmiyor'

def version_label(v=None):
    """Görünen sürüm adı: paket sürümü 3-proN → "Pro N" (eski 2.4.0-x olduğu gibi)."""
    import re
    v = installed_version() if v is None else v
    m = re.fullmatch(r'\d+-pro(\d+)', v or '')
    return 'Pro ' + m.group(1) if m else v

def snapshot_marks(marks, prev=None):
    """Geri al kopyası. Her çizgiden sonra bütün yazıları baştan kopyalamak (deepcopy)
    çizgi sayısıyla uzuyor, kalabalık sayfada ve Çözüm alanında kalemi takıldırıyordu.
    Değişmeyen sayfa ve çizgiler bir önceki kopyadan paylaşılır: kopyalar hiç değiştirilmez,
    geri alınırken canlı yazılara ayrıca kopyalanarak döner (live_marks)."""
    out = {}
    for p, lst in marks.items():
        old = prev.get(p) if isinstance(prev, dict) else None
        if old is not None and old == lst: out[p] = old; continue
        olds = old if isinstance(old, list) else []
        out[p] = [olds[i] if i < len(olds) and olds[i] == m else copy.deepcopy(m) for i, m in enumerate(lst)] if isinstance(lst, list) else copy.deepcopy(lst)
    return out
def live_marks(snapshot):   # paylaşılan kopyadan canlı (değiştirilebilir) yazılar
    return copy.deepcopy(snapshot)

# ---- Yazdır: okul bilgisayarlarına bağlı yazıcılara (yönetim sunucusu üzerinden) ----
YONETIM_URL = 'https://ceqdghykweubeaokwadt.supabase.co'
YONETIM_KEY = 'sb_publishable_YCctPAToPYgrvfeieRumPw_4SNsfaEZ'
YONETIM_ANAHTAR = 'umal-tahta-2026'
def yonetim_istek(path, data, ctype='application/json', timeout=60):
    """Supabase'e POST; hata olursa sunucunun kendi iletisiyle RuntimeError."""
    import urllib.request, urllib.error
    body = json.dumps(data, ensure_ascii=False).encode('utf-8') if ctype == 'application/json' else data
    req = urllib.request.Request(YONETIM_URL + path, data=body, method='POST',
                                 headers={'apikey': YONETIM_KEY, 'Authorization': 'Bearer ' + YONETIM_KEY, 'Content-Type': ctype, 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r: raw = r.read()
    except urllib.error.HTTPError as e:
        try: d = json.loads(e.read().decode('utf-8', 'replace')); msg = d.get('message') or d.get('error') or d.get('msg') or str(d)
        except Exception: msg = 'sunucu hatası %d' % e.code
        raise RuntimeError(msg)
    except urllib.error.URLError as e: raise RuntimeError('Sunucuya bağlanılamadı (%s)' % getattr(e, 'reason', e))
    return json.loads(raw.decode('utf-8')) if raw else None
def printer_list(resp):
    """umal_yazicilar_al yanıtı → [(etiket, cihaz, yazıcı)]. Liste ya da {"yazicilar": [...]} gelebilir."""
    items = resp.get('yazicilar', resp.get('liste', [])) if isinstance(resp, dict) else (resp or [])
    out = []
    for it in items if isinstance(items, list) else []:
        if not isinstance(it, dict): continue
        cihaz = it.get('cihaz') or it.get('cihaz_id') or it.get('hedef_cihaz') or ''
        yaz = it.get('yazici') or it.get('yazici_ad') or it.get('ad') or it.get('name') or ''
        pc = it.get('bilgisayar') or it.get('cihaz_ad') or it.get('konum') or ''
        if not (cihaz and yaz): continue
        etiket = yaz + (' · ' + pc if pc else '') + ('' if it.get('hazir', it.get('cevrimici', True)) else ' (kapalı)')
        out.append((etiket, cihaz, yaz))
    return out

def page_spec_error(text, n):
    """Özel sayfa aralığı: hata iletisi ya da None (geçerli)."""
    import re
    if not text: return 'Sayfaları yazın (ör. 1-3,5).'
    if not re.fullmatch(r'[0-9]+(-[0-9]+)?(,[0-9]+(-[0-9]+)?)*', text): return 'Biçim: 1-3,5 gibi; yalnız rakam, virgül ve tire.'
    for part in text.split(','):
        a, _, b = part.partition('-'); a = int(a); b = int(b) if b else a
        if a < 1 or b < 1: return 'Sayfa numarası 0 olamaz.'
        if a > n or b > n: return 'Belgede %d sayfa var.' % n
        if a > b: return 'Aralıkta baş sayfa son sayfadan büyük olamaz (%d-%d).' % (a, b)
    return None

class PrintDialog(QDialog):
    """Yazdır: şifre → yazıcı → belge (açık sekmeler, PDF Havuzu) → sayfalar → kopya / çift yüz."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Yazdır'); self.setModal(True)
        self.job = None; self.printers = []; self.choice = None; self.pages_mode = 'all'
        self.setStyleSheet('QPushButton#primary:disabled{background:#3a4658;color:#8d99aa;border:1px solid #3a4658;}')   # pasif Yazdır belli olsun
        from PyQt5.QtWidgets import QLineEdit, QComboBox, QListView
        self.docs = self.collect_docs()
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(10)
        t = QLabel('Yazdır'); t.setStyleSheet('font-size:21px;font-weight:600;'); box.addWidget(t)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row)
        self.pw = QLineEdit(); self.pw.setEchoMode(QLineEdit.Password); self.pw.setPlaceholderText('Yazdırma şifresi'); self.pw.setMinimumHeight(50)
        self.pw.setStyleSheet('font-size:20px;'); self.pw.installEventFilter(self); row.addWidget(self.pw, 1)
        self.get = QPushButton('Yazıcıları getir'); self.get.setMinimumHeight(50); self.get.clicked.connect(self.load_printers); row.addWidget(self.get)
        self.keyboard = TouchKeyboard(self); self.keyboard.hide(); box.addWidget(self.keyboard)
        self.list_box = QVBoxLayout(); self.list_box.setSpacing(6); box.addLayout(self.list_box)
        # Belge
        drow = QHBoxLayout(); drow.setSpacing(8); box.addLayout(drow)
        dl = QLabel('Belge'); dl.setMinimumWidth(80); drow.addWidget(dl)
        self.doc_box = QComboBox(); self.doc_box.setView(QListView()); self.doc_box.setMinimumHeight(50)
        self.doc_box.setStyleSheet('QComboBox{font-size:18px;padding:0 10px;} QComboBox QAbstractItemView::item{min-height:48px;font-size:18px;}')
        for d in self.docs: self.doc_box.addItem(d['label'])
        self.doc_box.currentIndexChanged.connect(self.doc_changed); drow.addWidget(self.doc_box, 1)
        # Sayfalar
        prow = QHBoxLayout(); prow.setSpacing(8); box.addLayout(prow)
        pl = QLabel('Sayfalar'); pl.setMinimumWidth(80); prow.addWidget(pl)
        self.page_buttons = {}
        for key, text in (('all', 'Tümü'), ('current', 'Şu anki sayfa'), ('custom', 'Özel')):
            b = QPushButton(text); b.setCheckable(True); b.setMinimumHeight(48); b.clicked.connect(lambda checked=False, k_=key: self.set_pages(k_))
            prow.addWidget(b, 1); self.page_buttons[key] = b
        self.custom = QLineEdit(); self.custom.setPlaceholderText('ör. 1-3,5'); self.custom.setMinimumHeight(50); self.custom.setStyleSheet('font-size:20px;')
        self.custom.textChanged.connect(self.custom_changed); self.custom.installEventFilter(self); self.custom.hide(); box.addWidget(self.custom)
        self.page_note = QLabel(''); self.page_note.setStyleSheet('color:#e07a5f;font-size:15px;'); self.page_note.hide(); box.addWidget(self.page_note)
        # Çift yüz, kopya
        opt = QHBoxLayout(); opt.setSpacing(8); box.addLayout(opt)
        self.duplex = QPushButton('Çift yüz'); self.duplex.setCheckable(True); self.duplex.setMinimumHeight(48); opt.addWidget(self.duplex)
        opt.addStretch(1); opt.addWidget(QLabel('Kopya'))
        self.copies = 1; minus = QPushButton('−'); plus = QPushButton('+'); self.count = QLabel('1'); self.count.setAlignment(Qt.AlignCenter); self.count.setMinimumWidth(36)
        for b, d in ((minus, -1), (plus, 1)):
            b.setFixedSize(48, 48); b.clicked.connect(lambda checked=False, d_=d: self.set_copies(self.copies + d_))
        opt.addWidget(minus); opt.addWidget(self.count); opt.addWidget(plus)
        self.summary = QLabel(''); self.summary.setWordWrap(True); self.summary.setStyleSheet('font-size:17px;font-weight:600;'); box.addWidget(self.summary)
        self.status = QLabel(''); self.status.setWordWrap(True); self.status.setStyleSheet('font-size:16px;'); box.addWidget(self.status)
        bt = QHBoxLayout(); box.addLayout(bt)
        close = QPushButton('Kapat'); close.setMinimumHeight(50); close.clicked.connect(self.reject); bt.addWidget(close)
        self.go = QPushButton('Yazdır'); self.go.setObjectName('primary'); self.go.setMinimumHeight(50); self.go.setEnabled(False); self.go.clicked.connect(self.send); bt.addWidget(self.go)
        self.poll = QTimer(self); self.poll.timeout.connect(self.check_job); self.poll.start(150)
        self.doc_changed(0)
        self.resize(720, self.sizeHint().height())
    # ---- belgeler ----
    def collect_docs(self):
        """Ekrandaki belge ilk sırada; sonra öbür sekmeler, sonra PDF Havuzu."""
        m = self.main; out = []
        name = os.path.splitext(os.path.basename(m.source))[0] if m.source else 'Tahta'
        out.append(dict(kind='cur', name=name, label='Ekrandaki: ' + name, pages=len(m.doc)))
        cur = m.current_tab()
        for t in (m.tabs or []):
            if t.get('id') == cur: continue
            folder = os.path.join(m.data_dir, t['id'])
            try:
                with open(os.path.join(folder, 'durum.json'), encoding='utf-8') as f: meta = json.load(f)
                pdf = os.path.join(folder, os.path.basename(meta.get('pdf', 'belge.pdf')))
                if not os.path.isfile(pdf): continue
            except (OSError, ValueError): continue
            nm = t.get('name') or 'Sekme'
            out.append(dict(kind='tab', name=nm, label='Sekme: ' + nm, folder=folder, meta=meta, pdf=pdf, pages=None))
        try: files = sorted((n for n in os.listdir(HAVUZ_DIR) if n.lower().endswith('.pdf') and not n.startswith('.')), key=str.lower)
        except OSError: files = []
        for n in files:
            nm = os.path.splitext(n)[0]
            out.append(dict(kind='havuz', name=nm, label='PDF Havuzu: ' + nm, pdf=os.path.join(HAVUZ_DIR, n), pages=None))
        return out
    def doc_pages(self, d):
        if d['pages'] is None:
            try:
                x = fitz.open(d['pdf']); d['pages'] = x.page_count; x.close()
            except Exception: d['pages'] = 0
        return d['pages']
    def cur_doc(self): return self.docs[max(0, self.doc_box.currentIndex())]
    def doc_changed(self, i):
        d = self.cur_doc(); self.doc_pages(d)
        on_screen = d['kind'] == 'cur'
        self.page_buttons['current'].setEnabled(on_screen)
        self.page_buttons['current'].setText('Şu anki sayfa (%d)' % (self.main.page + 1) if on_screen else 'Şu anki sayfa')
        if self.pages_mode == 'current' and not on_screen: self.pages_mode = 'all'
        self.set_pages(self.pages_mode)
    # ---- sayfalar ----
    def set_pages(self, key):
        self.pages_mode = key
        for k, b in self.page_buttons.items(): b.setChecked(k == key)
        self.custom.setVisible(key == 'custom')
        if key == 'custom':
            self.custom.setFocus(); self.keyboard.attach(self.custom); self.keyboard.set_shift(False); self.keyboard.show()
        elif self.keyboard.target is self.custom: self.keyboard.hide()
        self.update_state(); self.adjustSize()
    def custom_changed(self, text):
        clean = ''.join(c for c in text if c in '0123456789,-')
        if clean != text:
            pos = self.custom.cursorPosition() - (len(text) - len(clean)); self.custom.blockSignals(True); self.custom.setText(clean)
            self.custom.setCursorPosition(max(0, pos)); self.custom.blockSignals(False)
        self.update_state()
    def page_spec(self):
        """(p_sayfalar, özet metni, hata)."""
        if self.pages_mode == 'current': n = self.main.page + 1; return str(n), 'Sayfa %d' % n, None
        if self.pages_mode == 'custom':
            text = self.custom.text(); err = page_spec_error(text, self.doc_pages(self.cur_doc()))
            return text, 'Sayfa ' + (text or '…'), err
        return None, 'Tümü', None
    def update_state(self):
        d = self.cur_doc(); spec, shown, err = self.page_spec()
        self.page_note.setText(err or ''); self.page_note.setVisible(bool(err))
        self.summary.setText('%s · %s · %d kopya' % (d['name'], shown, self.copies))
        busy = bool(self.job and not self.job['done'] and self.job['kind'] == 'send')
        self.go.setEnabled(self.choice is not None and not err and not busy and d['pages'] != 0)
    def eventFilter(self, o, e):
        if o in (self.pw, getattr(self, 'custom', None)) and e.type() in (QEvent.MouseButtonPress, QEvent.FocusIn):
            self.keyboard.attach(o); self.keyboard.set_shift(False); self.keyboard.show(); self.adjustSize()
        return False
    def set_copies(self, n): self.copies = max(1, min(50, n)); self.count.setText(str(self.copies)); self.update_state()
    def run(self, kind, fn):   # ağ işi arka planda; sonuç check_job ile ana iş parçacığında işlenir
        import threading
        self.job = dict(kind=kind, done=False)
        def work():
            try: self.job.update(result=fn(), error=None)
            except Exception as ex: self.job.update(result=None, error=str(ex))
            self.job['done'] = True
        threading.Thread(target=work, daemon=True).start()
    def load_printers(self):
        sifre = self.pw.text().strip()
        if not sifre: self.status.setText('Yazdırma şifresini girin.'); return
        self.keyboard.hide(); self.get.setEnabled(False); self.status.setText('Yazıcılar getiriliyor…')
        self.run('list', lambda: yonetim_istek('/rest/v1/rpc/umal_yazicilar_al', {'p_anahtar': YONETIM_ANAHTAR, 'p_sifre': sifre}, timeout=30))
    def show_printers(self, resp):
        while self.list_box.count():
            w_ = self.list_box.takeAt(0).widget()
            if w_ is not None: w_.deleteLater()
        self.printers = printer_list(resp); self.choice = None; self.update_state()
        if not self.printers: self.status.setText('Açık bir bilgisayara bağlı yazıcı bulunamadı.'); return
        for i, (etiket, cihaz, yaz) in enumerate(self.printers):
            b = QPushButton(etiket); b.setCheckable(True); b.setMinimumHeight(48); b.clicked.connect(lambda checked=False, i_=i: self.pick(i_)); self.list_box.addWidget(b)
        self.status.setText('Yazıcıyı seçin.')
        if len(self.printers) == 1: self.pick(0)
        self.adjustSize()
    def pick(self, i):
        self.choice = i
        for k in range(self.list_box.count()):
            w_ = self.list_box.itemAt(k).widget()
            if w_ is not None: w_.setChecked(k == i)
        self.status.setText('Hazır: ' + self.printers[i][0]); self.update_state()
    def document_bytes(self, d):
        """Seçilen belgenin yazdırılacak PDF'i (notlarıyla)."""
        if d['kind'] == 'havuz':
            with open(d['pdf'], 'rb') as f: return f.read()
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix='.pdf'); os.close(fd)
        try:
            if d['kind'] == 'cur':
                m = self.main; export_document(m.doc, m.marks, tmp, None if m.solution_origin else m.solutions)
            else:
                meta = d['meta']; doc = fitz.open(d['pdf'])
                try:
                    marks = {p: v for p, v in load_marks(meta.get('marks')).items() if p < len(doc)}
                    sols = None if doc.metadata.get('keywords') == 'UMAL-solution' else \
                        {k: dict(v, marks=load_marks(v.get('marks'))) for k, v in (meta.get('solutions') or {}).items()}
                    export_document(doc, marks, tmp, sols)
                finally: doc.close()
            with open(tmp, 'rb') as f: return f.read()
        finally:
            try: os.remove(tmp)
            except OSError: pass
    def send(self):
        if self.choice is None or (self.job and not self.job['done']): return
        d = self.cur_doc(); spec, shown, err = self.page_spec()
        if err: self.update_state(); return
        m = self.main; m.board.finish(); sifre = self.pw.text().strip(); _, cihaz, yaz = self.printers[self.choice]
        import hashlib, uuid as uuid_
        try: data = self.document_bytes(d)
        except Exception as ex: self.status.setText('PDF hazırlanamadı: %s' % ex); return
        ad = d['name'] + '.pdf'
        sinif = m.board_info().get('sinif') or 'sınıfsız'; yol = 'yazdir/%s.pdf' % uuid_.uuid4()
        sha = hashlib.sha256(data).hexdigest(); kopya = self.copies; cift = self.duplex.isChecked()
        def job():
            yonetim_istek('/storage/v1/object/umal-pdf/' + yol, data, ctype='application/pdf', timeout=120)
            return yonetim_istek('/rest/v1/rpc/umal_yazdirma_iste', dict(p_anahtar=YONETIM_ANAHTAR, p_sifre=sifre, p_kaynak='tahta:' + sinif,
                                 p_hedef_cihaz=cihaz, p_yazici=yaz, p_pdf_yol=yol, p_pdf_ad=ad, p_sha256=sha, p_boyut=len(data), p_kopya=kopya, p_cift_yuz=cift,
                                 p_sayfalar=spec), timeout=30)
        self.keyboard.hide(); self.status.setText('Gönderiliyor… (%d KB)' % max(1, len(data)//1024)); self.run('send', job); self.update_state()
    def check_job(self):
        j = self.job
        if not j or not j['done'] or j.get('seen'): return
        j['seen'] = True
        if j['kind'] == 'list':
            self.get.setEnabled(True)
            if j['error']: self.status.setText('Yazıcılar alınamadı: ' + j['error'])
            else: self.show_printers(j['result'])
        else:
            if j['error']: self.status.setText('Yazdırılamadı: ' + j['error'])
            else: self.status.setText('Yazdırmaya gönderildi: %s · %s' % (self.printers[self.choice][0], self.summary.text()) + (' · çift yüz' if self.duplex.isChecked() else ''))
            self.update_state()

class PanelOrder(QDialog):
    """Düğmelerin yeri: bir düğmeye dokunun, oklarla taşıyın. Soldaki panel aynı anda değişir."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.key = None
        self.setWindowTitle('Düğmelerin yeri'); self.setModal(True)
        box = QHBoxLayout(self); box.setContentsMargins(18, 16, 18, 16); box.setSpacing(18)
        left = QVBoxLayout(); left.setSpacing(6); box.addLayout(left)
        t = QLabel('Düğmelerin yeri'); t.setStyleSheet('font-size:18px;font-weight:bold;'); left.addWidget(t)
        n = QLabel('Taşımak istediğiniz düğmeye dokunun, sonra oklarla yerini değiştirin. Soldaki panel hemen değişir.'); n.setWordWrap(True); n.setMaximumWidth(300); left.addWidget(n)
        self.grid = QVBoxLayout(); self.grid.setSpacing(4); left.addLayout(self.grid); left.addStretch(1)
        right = QVBoxLayout(); right.setSpacing(8); box.addLayout(right)
        pad = QGridLayout(); pad.setSpacing(8); right.addLayout(pad)
        self.arrows = {}
        for way, sym, r, c in (('up', '↑', 0, 1), ('left', '←', 1, 0), ('right', '→', 1, 2), ('down', '↓', 2, 1)):
            b = QPushButton(sym); b.setFixedSize(72, 72); b.setStyleSheet('font-size:30px;padding:0;')
            b.setAccessibleName({'up': 'Yukarı', 'down': 'Aşağı', 'left': 'Sola', 'right': 'Sağa'}[way])
            b.clicked.connect(lambda checked=False, w_=way: self.shift(w_)); pad.addWidget(b, r, c); self.arrows[way] = b
        self.shown = QLabel(); self.shown.setAlignment(Qt.AlignCenter); right.addWidget(self.shown); right.addStretch(1)
        reset = QPushButton('Varsayılan sıra'); reset.setMinimumHeight(46); reset.clicked.connect(self.reset); right.addWidget(reset)
        ok = QPushButton('Tamam'); ok.setObjectName('primary'); ok.setMinimumHeight(46); ok.clicked.connect(self.accept); right.addWidget(ok)
        self.refresh()
        scr = QApplication.primaryScreen().availableGeometry(); self.adjustSize()
        self.move(scr.left() + 280, max(scr.top() + 20, scr.top() + (scr.height() - self.height())//2))   # panelin yanında: değişiklik görünsün
    def refresh(self):
        while self.grid.count():
            it = self.grid.takeAt(0); lay = it.layout()
            if lay is not None:
                while lay.count():
                    w_ = lay.takeAt(0).widget()
                    if w_ is not None: w_.deleteLater()
        for keys in self.main.panel_layout_rows():
            h = QHBoxLayout(); h.setSpacing(4); self.grid.addLayout(h)
            for k in keys:
                b = QPushButton(self.main.PANEL_NAMES.get(k, k)); b.setCheckable(True); b.setChecked(k == self.key); b.setFixedHeight(38); b.setMinimumWidth(120)
                b.setStyleSheet('QPushButton{font-size:15px;padding:0 8px;min-height:36px;max-height:36px;} QPushButton:checked{background:#2f7cf6;border-color:#2f7cf6;color:white;}')
                b.clicked.connect(lambda checked=False, k_=k: self.pick(k_)); h.addWidget(b, 1)
        rows = self.main.panel_layout_rows(); pos = next(((r, j) for r, ks in enumerate(rows) for j, k in enumerate(ks) if k == self.key), None)
        en = {'up': False, 'down': False, 'left': False, 'right': False}
        if pos:
            r, j = pos; en['up'] = r > 0; en['down'] = r < len(rows) - 1; en['left'] = len(rows[r]) == 2 and j == 1; en['right'] = len(rows[r]) == 2 and j == 0
        for w_, b in self.arrows.items(): b.setEnabled(en[w_])
        self.shown.setText(('Seçili: <b>%s</b>' % self.main.PANEL_NAMES.get(self.key, self.key)) if self.key else 'Bir düğme seçin')
    def pick(self, k): self.key = k; self.refresh()
    def shift(self, way):
        if self.key and self.main.move_panel_unit(self.key, way): self.refresh()
    def reset(self):
        self.main.panel_order = list(self.main.panel_default); self.main.layout_panel(); self.main.save_panel(); self.refresh()

class PanelSettings(QDialog):
    """Ayarlar: tick the buttons the left panel should show."""
    def __init__(self, main):
        super().__init__(main); self.main = main
        self.setWindowTitle('Ayarlar'); self.setModal(True)
        box = QVBoxLayout(self); box.setContentsMargins(18, 16, 18, 16); box.setSpacing(10)
        head = QLabel('Tahta görünümü'); head.setStyleSheet('font-size:18px;font-weight:bold;'); box.addWidget(head)
        look = QHBoxLayout(); look.setSpacing(8); box.addLayout(look)
        for text, fn, enabled in (('Tahta arka planı', main.open_backgrounds, main.background is not None), ('Tema', main.open_theme_picker, True)):
            b = QPushButton(text); b.setMinimumHeight(46); b.setEnabled(enabled); look.addWidget(b, 1)
            b.clicked.connect(lambda checked=False, f_=fn: (self.accept(), f_()))
            if not enabled: b.setToolTip('Arka plan boş tahtada seçilir; PDF\'de kullanılmaz')
        title = QLabel('Paneldeki düğmeler'); title.setStyleSheet('font-size:18px;font-weight:bold;margin-top:8px;'); box.addWidget(title)
        note = QLabel('İşaretli olanlar sol panelde görünür. Kaldırılanlar silinmez, istediğiniz an geri açılır.'); note.setWordWrap(True); box.addWidget(note)
        grid = QGridLayout(); grid.setHorizontalSpacing(8); grid.setVerticalSpacing(8); box.addLayout(grid)
        self.checks = {}
        for i, (key, label, widgets) in enumerate(main.panel_items):
            c = QCheckBox(label); c.setChecked(key not in main.panel_hidden); c.setMinimumHeight(46)
            c.setStyleSheet('QCheckBox{font-size:16px;padding:4px 10px;border:1px solid #526780;border-radius:8px;}QCheckBox::indicator{width:26px;height:26px;}')
            c.toggled.connect(self.changed); grid.addWidget(c, i//3, i%3); self.checks[key] = c
        # Güncelleme: the button writes to a request file; a systemd path unit
        # starts the signed-package updater (no password needed).
        upd = QHBoxLayout(); upd.setSpacing(10); box.addLayout(upd)
        self.update_button = QPushButton('Güncellemeyi denetle'); self.update_button.setIcon(tool_icon('İleri al'))
        self.update_button.setMinimumHeight(46); self.update_button.clicked.connect(self.check_update); upd.addWidget(self.update_button)
        self.update_note = QLabel('Kurulu sürüm: ' + version_label()); self.update_note.setWordWrap(True); upd.addWidget(self.update_note, 1)
        self.update_timer = QTimer(self); self.update_timer.setInterval(1000); self.update_timer.timeout.connect(self.poll_update)
        row = QHBoxLayout(); box.addLayout(row)
        reset = QPushButton('Varsayılana dön'); reset.clicked.connect(self.reset); row.addWidget(reset)
        meter = QPushButton('Kalem ölçümü'); meter.setIcon(tool_icon('Kalem')); meter.setToolTip('10 saniye yazın: tahtanın kalem hızını ölçer')
        meter.clicked.connect(lambda: (self.accept(), QTimer.singleShot(0, self.main.start_pen_meter))); row.addWidget(meter)
        order = QPushButton('Düğmelerin yeri'); order.setToolTip('Paneldeki düğmeleri yukarı, aşağı, sağa, sola taşıyın')
        order.clicked.connect(lambda: (self.accept(), QTimer.singleShot(0, lambda: PanelOrder(self.main).exec_()))); row.addWidget(order)
        cls = QPushButton('Tahtanın sınıfı: ' + (main.board_info().get('sinif') or 'seçilmedi')); cls.setToolTip('Okul yönetimi tahtayı bu adla görür')
        cls.clicked.connect(lambda: (self.accept(), QTimer.singleShot(0, lambda: self.main.ask_class(True)))); row.addWidget(cls); row.addStretch()
        ok = QPushButton('Tamam'); ok.setObjectName('primary'); ok.clicked.connect(self.accept); row.addWidget(ok)
        for b in (reset, meter, order, cls, ok): b.setMinimumHeight(46); b.setMinimumWidth(150)
    def check_update(self):
        try:
            self.log_start = os.path.getsize(UPDATE_LOG) if os.path.exists(UPDATE_LOG) else 0
            with open(UPDATE_REQUEST, 'w') as f: f.write(str(time.time()))
        except OSError:
            self.update_note.setText('Güncelleyici bu cihazda kurulu değil.'); return
        self.update_button.setEnabled(False); self.update_note.setText('Denetleniyor…')
        self.update_waited = 0; self.update_timer.start()
    def poll_update(self):
        self.update_waited += 1
        try:
            with open(UPDATE_LOG, encoding='utf-8', errors='replace') as f: f.seek(self.log_start); lines = [l.strip() for l in f if l.strip()]
        except OSError: lines = []
        text = lines[-1].split('  ', 1)[-1] if lines else ''   # drop the time stamp
        done = [k for k in UPDATE_RESULTS if k in text]
        if text and not done: self.update_note.setText(text)   # e.g. "Yeni sürüm bulundu … İndiriliyor…"
        if done or self.update_waited >= 300:
            self.update_timer.stop(); self.update_button.setEnabled(True)
            if not done: self.update_note.setText('Yanıt alınamadı. Biraz sonra yeniden deneyin.')
            elif 'Kuruldu' in text: self.update_note.setText('Kuruldu: %s. Uygulamayı kapatıp açınca yeni sürüm başlar.' % text.split(':', 1)[1].strip().split(' ')[0].rstrip('.'))
            elif 'Güncel' in text: self.update_note.setText('Uygulama güncel · ' + version_label())
            elif 'Bağlantı yok' in text: self.update_note.setText('İnternete ulaşılamadı. Bağlantı gelince tahta kendisi de denetler.')
            else: self.update_note.setText(text)
    def changed(self):
        self.main.apply_panel({k for k, c in self.checks.items() if not c.isChecked()})
    def reset(self):
        for c in self.checks.values(): c.blockSignals(True); c.setChecked(True); c.blockSignals(False)
        self.main.apply_panel(set())

AUTO_PEN_MS = 4000
AUTO_PEN_TOOLS = ('eraser', 'area_eraser')

class Board(QWidget):
    def __init__(self, owner):
        super().__init__()
        self.owner = owner
        self.image = QImage()
        self.scale = 1
        self.active = None
        self.erasing = False
        self.pointer = None
        self.pan = None
        self.raw = []
        # Fast ink (screen mode): committed strokes are cached once per stroke;
        # only the new segment is drawn and only its small area is repainted.
        self.snapshot = None; self.drawn = 0; self.cum = []
        self.last_erase = None
        self.layers = None; self.tip = None; self.fl = None
        self.fading = []   # Neon kalem strokes: [stroke, page, (fade end)]
        self.fade_timer = QTimer(self); self.fade_timer.timeout.connect(self.fade_tick)
        self.selected=[];self.selection_page=None;self.transform=None
        self.snapped=False;self.hold_anchor=None
        self.hold_timer=QTimer(self);self.hold_timer.setSingleShot(True)
        self.hold_timer.timeout.connect(self.snap_shape)
        self.pending_snap=None
        # 4 s after the last erase with no new erase, the pen comes back by itself.
        self.auto_pen=QTimer(self);self.auto_pen.setSingleShot(True);self.auto_pen.setInterval(AUTO_PEN_MS)
        self.auto_pen.timeout.connect(lambda:self.owner.tool in AUTO_PEN_TOOLS and self.owner.set_tool('pen'))
        self.erasing=False
        self.release_timer=QTimer(self);self.release_timer.setSingleShot(True)
        self.release_timer.timeout.connect(self.snap_released_shape)
        self.setAttribute(Qt.WA_AcceptTouchEvents)
        self.setMouseTracking(True)

    def paintEvent(self, event):
        p = QPainter(self)
        if self.snapshot is not None and self.active and not self.snapped and self.snap_rect.contains(event.rect()):
            r = event.rect(); dpr = self.snapshot.devicePixelRatio(); o = self.snap_rect.topLeft()
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.drawPixmap(QRectF(r), self.snapshot, QRectF((r.x()-o.x())*dpr, (r.y()-o.y())*dpr, r.width()*dpr, r.height()*dpr))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
            first = max(0, self.drawn-1)
            if self.layers:
                # Styled pen: each pass = committed layer + the moving tail,
                # made grainy / see-through as a whole, then laid on the page.
                src = QRectF((r.x()-o.x())*dpr, (r.y()-o.y())*dpr, r.width()*dpr, r.height()*dpr).toAlignedRect()
                for layer, (pen, opacity, mask) in zip(self.layers, style_passes(self.active)):
                    tmp = layer.copy(src); tmp.setDevicePixelRatio(dpr)
                    q = QPainter(tmp); q.setRenderHint(QPainter.Antialiasing); q.translate(-r.x(), -r.y()); q.scale(self.scale, self.scale)
                    self.draw_segment(q, self.active, first, len(self.active['points']), pens=[pen])
                    if mask: apply_mask(q, mask, r)
                    q.end(); p.setOpacity(opacity); p.drawPixmap(QRectF(r), tmp, QRectF(tmp.rect())); p.setOpacity(1)
            else:
                p.scale(self.scale, self.scale); p.setRenderHint(QPainter.Antialiasing)
                self.draw_segment(p, self.active, first, len(self.active['points']), self.cum[first] if first < len(self.cum) else 0, self.direct_pens())
                pr = getattr(self, 'pred', None)
                if pr:   # uç tahmini (geçici, kaydedilmez)
                    pen = QPen(stroke_pen(self.active, 0)); pen.setWidthF(pr[2]); pen.setCapStyle(Qt.RoundCap)
                    p.setPen(pen); p.drawLine(QPointF(*pr[0]), QPointF(*pr[1]))
            self.paint_tip(p)
            return
        if self.cacheable(True) and self.base_valid(event.rect()):
            r = event.rect(); dpr = self.base.devicePixelRatio(); o = self.base_rect.topLeft()
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.drawPixmap(QRectF(r), self.base, QRectF((r.x()-o.x())*dpr, (r.y()-o.y())*dpr, r.width()*dpr, r.height()*dpr))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
            if self.active:   # çizilmekte olan şekil/pergel: hazır sayfanın üstüne
                p.save(); p.scale(self.scale, self.scale); p.setRenderHint(QPainter.Antialiasing); self.draw_mark(p, self.active, QRectF(r)); p.restore()
            if self.owner.tool == 'solution': p.save(); p.scale(self.scale, self.scale); p.setRenderHint(QPainter.Antialiasing); self.paint_questions(p); p.restore()
            self.paint_tip(p); return
        if getattr(self.owner,'overlay_mode',False):
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.fillRect(self.rect(),QColor(getattr(self.owner,'backdrop',None) or QColor(0,0,0,1)))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
        else:
            p.fillRect(self.rect(), Qt.white)
            p.setRenderHint(QPainter.SmoothPixmapTransform)
            page_rect = self.owner.doc[self.owner.page].rect
            top = getattr(self, 'image_height', None) or page_rect.height
            pattern = getattr(self, 'pattern', None); r = event.rect(); k = self.scale
            if pattern in BOARD_FILLS:   # same colours as make_board()
                p.fillRect(QRectF(r.left(), max(r.top(), top*k), r.width()+1, r.bottom()+1-max(r.top(), top*k)), QColor.fromRgbF(*BOARD_FILLS[pattern]))
            if pattern == 'grid':   # same lines as make_board('grid')
                p.setPen(QPen(QColor.fromRgbF(.55,.64,.76), .9*k)); p.setRenderHint(QPainter.Antialiasing)
                for x in range(int(r.left()/k/24)*24, int(r.right()/k)+25, 24): p.drawLine(QPointF(x*k, max(r.top(), top*k)), QPointF(x*k, r.bottom()+1))
                for y in range(max(int(r.top()/k/24)*24, math.ceil(top/24)*24), int(r.bottom()/k)+25, 24): p.drawLine(QPointF(r.left(), y*k), QPointF(r.right()+1, y*k))
            elif pattern == 'dots':   # same dots as make_board('dots')
                p.setPen(Qt.NoPen); p.setBrush(QColor.fromRgbF(.40,.50,.64)); p.setRenderHint(QPainter.Antialiasing)
                for x in range(max(24, int(r.left()/k/24)*24), min(int(self.width()/k), int(r.right()/k)+25), 24):
                    for y in range(max(int(r.top()/k/24)*24, math.ceil(top/24)*24, 24), int(r.bottom()/k)+25, 24): p.drawEllipse(QPointF(x*k, y*k), 1.6*k, 1.6*k)
                p.setBrush(Qt.NoBrush)
            p.drawImage(QRectF(0,0,page_rect.width*self.scale,top*self.scale),self.image)
        p.scale(self.scale, self.scale)
        p.setRenderHint(QPainter.Antialiasing)
        er = event.rect(); k = self.scale or 1
        vis = QRectF(er.x()/k, er.y()/k, er.width()/k, er.height()/k)
        for s in self.owner.marks.get(self.owner.page, []) + ([self.active] if self.active else []):
            if s is not self.active and not self.mark_visible(s, vis): continue   # ekran dışındaki çizgi çizilmez
            self.draw_mark(p, s, QRectF(event.rect()))
        self.paint_daily(p)
        self.paint_questions(p)
        self.paint_fading(p, QRectF(event.rect()))
        r=self.selection_rect()
        if r is not None and self.owner.tool=='smart' and not getattr(self,'_temiz_cek',False):
            p.setOpacity(1);p.setBrush(Qt.NoBrush)
            p.setPen(QPen(QColor('#2394ff'),2/self.scale,Qt.DashLine));p.drawRect(r)
            p.setPen(QPen(QColor('#2394ff'),1/self.scale));p.setBrush(Qt.white)
            for corner in (r.topLeft(),r.topRight(),r.bottomLeft(),r.bottomRight()):
                p.drawRect(QRectF(corner.x()-6/self.scale,corner.y()-6/self.scale,12/self.scale,12/self.scale))
            # delete badge (trash) beside the selection
            c=self.delete_badge(r);rad=20/self.scale
            p.setPen(QPen(QColor('#ffffff'),2/self.scale));p.setBrush(QColor('#e23b4d'));p.drawEllipse(c,rad,rad)
            k=1/self.scale;p.setPen(QPen(QColor('#ffffff'),2.2*k,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
            p.drawPolyline(QPolygonF([QPointF(c.x()-7*k,c.y()-5*k),QPointF(c.x()-5.5*k,c.y()+9*k),QPointF(c.x()+5.5*k,c.y()+9*k),QPointF(c.x()+7*k,c.y()-5*k)]))
            p.drawLine(QPointF(c.x()-10*k,c.y()-7*k),QPointF(c.x()+10*k,c.y()-7*k));p.drawLine(QPointF(c.x()-3*k,c.y()-10*k),QPointF(c.x()+3*k,c.y()-10*k))
        self.paint_tip(p)

    def mark_visible(self, s, vis):
        """Kalem/fosforlu çizgisi görünen alana değiyor mu? Kalabalık sayfada (Çözüm alanı) ekranı yeniden
        çizmek bütün çizgileri baştan çizdiği için yazı arttıkça uzuyordu; ekran dışındakiler atlanır."""
        if s.get('tool') not in ('pen', 'highlight'): return True
        pts = s.get('points')
        if not pts: return True
        key = (len(pts), tuple(pts[0]), tuple(pts[-1]), s.get('width'))
        cache = self.__dict__.setdefault('bounds_cache', {})
        hit = cache.get(id(s))
        if hit is None or hit[0] != key:
            pad = (s.get('width') or 4)*1.5 + 6
            xs = [q[0] for q in pts]; ys = [q[1] for q in pts]
            hit = (key, QRectF(min(xs)-pad, min(ys)-pad, max(xs)-min(xs)+2*pad, max(ys)-min(ys)+2*pad))
            if len(cache) > 20000: cache.clear()
            cache[id(s)] = hit
        return hit[1].intersects(vis)
    def draw_mark(self, p, s, rect):
        """Tek bir işareti çizer (tam çizimde ve hazır sayfa görüntüsüne eklerken aynı yol)."""
        if s['tool'] == 'geo':
            r_ = self.owner.doc[self.owner.page].rect
            try: draw_geo(p, s, r_.width, r_.height, getattr(self, 'geo_sel', ()))
            except Exception as ex: print('geo çizim:', ex)
            sig = (id(s), s.get('rev'))
            if sig != getattr(self, 'geo_sig', None): self.geo_sig = sig; QTimer.singleShot(0, self.owner.geo_panel_sync)
            return
        if s['tool'] == 'compass':   # pergel önizlemesi: kılavuz daire, merkez, açıklık, yay
            c = QPointF(*s['center']); r = s['r']; k = 1/self.scale; p.setOpacity(1)
            if r > 0:
                p.setPen(QPen(QColor(139, 92, 246, 150), 1.6*k, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, r, r)
                q = QPointF(*s.get('pen', s['center'])); p.setPen(QPen(QColor('#8b5cf6'), 2.2*k)); p.drawLine(c, q)
                p.save(); p.translate((c.x()+q.x())/2, (c.y()+q.y())/2); p.scale(k, k)   # ekranda sabit, okunaklı etiket
                f = p.font(); f.setPixelSize(24); f.setBold(True); p.setFont(f); txt = 'r = %s cm' % fmt_num(r/28.3465, 1)
                bw = p.fontMetrics().horizontalAdvance(txt) + 24; box = QRectF(14, -50, bw, 38)
                p.setPen(QPen(QColor('#8b5cf6'), 2)); p.setBrush(QColor(255, 255, 255, 235)); p.drawRoundedRect(box, 19, 19)
                p.setPen(QColor('#5b21b6')); p.drawText(box, Qt.AlignCenter, txt); p.restore(); p.setBrush(Qt.NoBrush)
            p.setPen(Qt.NoPen); p.setBrush(QColor('#8b5cf6')); p.drawEllipse(c, 5*k, 5*k); p.setBrush(Qt.NoBrush)
            if len(s['points']) > 1: p.setPen(stroke_pen(dict(s, tool='pen'))); p.drawPath(stroke_path(s['points']))
            return
        if s['tool'] in ('select', 'smart', 'solution', 'whiteout', 'erase_frame', 'postit_frame', 'pick_frame', 'atlas_frame'):
            if len(s['points']) < 2: return
            r = QRectF(QPointF(*s['points'][0]),QPointF(*s['points'][1])).normalized()
            p.setOpacity(1)
            if s['tool'] == 'whiteout':
                p.setRenderHint(QPainter.Antialiasing,False)
                p.fillRect(r,Qt.white)
                p.setRenderHint(QPainter.Antialiasing,True)
            elif s['tool'] == 'pick_frame':
                p.setPen(QPen(QColor('#ffb400'),3/self.scale,Qt.DashLine)); p.setBrush(QColor(255,180,0,30)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            elif s['tool'] == 'postit_frame':
                p.setPen(QPen(QColor('#d9a400'),2.5/self.scale,Qt.DashLine)); p.setBrush(QColor(255,226,122,40)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            elif s['tool'] == 'atlas_frame':   # K-350: Atlas'a sorulacak bölüm
                p.setPen(QPen(QColor('#14b8d4'),3/self.scale,Qt.DashLine)); p.setBrush(QColor(34,232,255,30)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            elif s['tool'] == 'erase_frame':
                p.setPen(QPen(QColor('#e23b4d'),2/self.scale,Qt.DashLine)); p.setBrush(QColor(226,59,77,28)); p.drawRect(r); p.setBrush(Qt.NoBrush)
            else:
                p.setPen(QPen(QColor('#109c70'),2/self.scale,Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(r)
            return
        p.setOpacity(.3 if s['tool'] == 'highlight' else 1)
        outline = nib_outline(s)
        if outline:
            p.setPen(Qt.NoPen); p.setBrush(QColor(s['color']))
            p.drawPolygon(QPolygonF([QPointF(*pt) for pt in outline]),Qt.WindingFill)
            if s.get('w'):   # Akıcı: round, tapered ends
                for i in (0, -1):
                    r = max(.25, s['width']/2*s['w'][i]); p.drawEllipse(QPointF(*s['points'][i]), r, r)
            p.setBrush(Qt.NoBrush)
            return
        pts = s['points']; passes = style_passes(s)
        if passes: paint_passes(p, stroke_path(pts), passes, rect, self.devicePixelRatioF()); return
        p.setPen(stroke_pen(s))
        if len(pts) == 1: p.drawPoint(QPointF(*pts[0]))
        else: p.drawPath(stroke_path(pts))
    # --- Hazır sayfa görüntüsü: her yeni çizgide eski çizgiler yeniden çizilmez -------
    def mark_key(self):
        o = self.owner; ms = o.marks.get(o.page, [])
        fp = tuple((id(m), len(m['points']), tuple(m['points'][0]) if m['points'] else (), tuple(m['points'][-1]) if m['points'] else (), m.get('color'), m.get('width'), m.get('rev')) for m in ms)
        return (id(o.doc), o.page, round(self.scale, 6), self.width(), self.height(), self.image.cacheKey(),
                getattr(self, 'pattern', None), getattr(self, 'image_height', None), tuple(getattr(self, 'geo_sel', ()))), fp
    def cacheable(self, active_ok=False):
        o = self.owner
        if getattr(o, 'overlay_mode', False) or self.fading or self.transform or (self.active and not active_ok): return False
        if o.tool == 'smart' and self.selection_rect() is not None: return False
        d = getattr(o, 'daily', None)
        if d and o.solution_origin is None and any(it['tab'] == o.current_tab() and it['page'] == o.page for it in d['items']): return False
        return True
    def ensure_base(self):
        """Önizleme için görünen sayfanın hazır görüntüsü (yoksa bir kez çizilir)."""
        r = self.visibleRegion().boundingRect()
        if r.isEmpty() or not self.cacheable(): return
        if not (self.base_valid(r) and self.base_rect == r):
            self.base = self.grab(r); self.base_rect = QRect(r); self.base_key = self.mark_key()
    def base_valid(self, rect):
        return getattr(self, 'base', None) is not None and self.base_rect.contains(rect) and self.base_key == self.mark_key()
    def refresh_base(self, added):
        """Biten çizgiyi hazır görüntüye ekler (çizim sırası aynı: sonuç tam çizimle aynı)."""
        if getattr(self, 'base', None) is None: return
        if not self.cacheable(): self.base = None; return
        page, fp = self.mark_key()
        if not fp or fp[-1][0] != id(added) or self.base_key != (page, fp[:-1]): self.base = None; return
        q = QPainter(self.base); o = self.base_rect.topLeft(); q.translate(-o.x(), -o.y()); q.scale(self.scale, self.scale)
        q.setRenderHint(QPainter.Antialiasing); self.draw_mark(q, added, QRectF(0, 0, self.base_rect.width(), self.base_rect.height())); q.end()
        self.base_key = (page, fp)
    def paint_questions(self, p):
        """Çözüm alanı açıkken Atlas'ın bulduğu sorular ince kesikli çerçeveyle görünür (dokununca kart açılır)."""
        o = self.owner
        if getattr(o, 'tool', None) != 'solution' or getattr(o, 'solution_origin', None) is not None or not hasattr(o, 'page_questions'): return
        qs = o.page_questions()
        if not qs: return
        k = 1/(self.scale or 1); p.setOpacity(1)
        done = [fitz.Rect(v['rect']) for v in getattr(o, 'solutions', {}).values() if v.get('page') == o.page]
        f = p.font(); f.setPixelSize(max(6, int(13*k))); f.setBold(True); p.setFont(f)
        for n, r in qs:
            ok = any(solution_overlap(list(d), r) >= .5 for d in done)
            c = QColor('#16a34a' if ok else '#0ea5a4'); qr = QRectF(r.x0, r.y0, r.width, r.height)
            fill = QColor(c); fill.setAlpha(14); p.setBrush(fill); pen = QPen(QColor(c.red(), c.green(), c.blue(), 150), 1.6*k, Qt.DashLine); p.setPen(pen)
            p.drawRoundedRect(qr, 6*k, 6*k)
            lbl = '%d%s' % (n, ' · çözüldü' if ok else ''); w = p.fontMetrics().horizontalAdvance(lbl) + 14*k
            tag = QRectF(qr.right() - w - 6*k, qr.y() + 4*k, w, 20*k)
            p.setPen(Qt.NoPen); p.setBrush(c); p.drawRoundedRect(tag, 10*k, 10*k); p.setPen(QColor('#ffffff')); p.drawText(tag, Qt.AlignCenter, lbl)
        p.setBrush(Qt.NoBrush)
    def paint_daily(self, p):
        o = self.owner
        if getattr(o, 'daily', None) is None or o.solution_origin is not None or getattr(o, 'overlay_mode', False): return
        tab = o.current_tab(); k = 1/self.scale; f = p.font(); f.setPixelSize(max(1, int(14*k))); f.setBold(True); p.setFont(f); p.setOpacity(1)
        for i, it in enumerate(o.daily['items']):
            if it['tab'] != tab or it['page'] != o.page: continue
            r = QRectF(QPointF(it['rect'][0], it['rect'][1]), QPointF(it['rect'][2], it['rect'][3]))
            p.setPen(QPen(QColor('#ffb400'), 2.5*k, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawRect(r)
            b = QRectF(r.left()-12*k, r.top()-12*k, 24*k, 24*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#00a24a') if it['done'] else QColor('#ffb400')); p.drawEllipse(b)
            p.setPen(QColor('white') if it['done'] else QColor('#3d2a00')); p.drawText(b, Qt.AlignCenter, str(i+1))
        p.setBrush(Qt.NoBrush)
    @staticmethod
    def draw_segment(p, s, a, b, offset=0, pens=None):
        pts = s['points'][a:b]
        if not pts: return
        ws = s.get('w')
        if ws and len(ws) == len(s['points']):   # Akıcı kalem: width per point
            half = s['width']/2; p.setPen(Qt.NoPen); p.setBrush(QColor(s['color']))
            for i in range(a, min(b, len(ws))):
                x, y = s['points'][i]; r = max(.25, half*ws[i]); p.drawEllipse(QPointF(x, y), r, r)
                if i > a:
                    (x0, y0), r0 = s['points'][i-1], max(.25, half*ws[i-1]); d = math.hypot(x-x0, y-y0)
                    if d > 1e-6:
                        nx, ny = -(y-y0)/d, (x-x0)/d
                        p.drawPolygon(QPolygonF([QPointF(x0+nx*r0, y0+ny*r0), QPointF(x+nx*r, y+ny*r), QPointF(x-nx*r, y-ny*r), QPointF(x0-nx*r0, y0-ny*r0)]))
            p.setBrush(Qt.NoBrush); return
        for pen in (pens if pens is not None else [stroke_pen(s, offset)]):
            p.setPen(pen)
            if len(pts) == 1: p.drawPoint(QPointF(*pts[0]))
            else: p.drawPath(stroke_path(pts))
    # Kalem ucu göstergesi: a ring at the pen tip showing the ink size (or the
    # eraser size), drawn in dark and light so it shows on any background.
    TIP_TOOLS = ('pen', 'dash', 'highlight', 'eraser')
    ERASER_TOOLS = ('eraser',)   # ring stays while rubbing; pens show it only when hovering
    def tip_radius(self):
        tool = self.owner.tool
        if tool == 'eraser': return 12
        w = self.owner.width.value()*(4 if tool == 'highlight' else 1)
        style = getattr(self.owner, 'pen_style', 'normal') if tool == 'pen' else None
        w *= {'neon': .9}.get(style, STYLE_SPAN.get(style, 1))
        return max(5, w*self.scale/2 + 2)
    def tip_rect(self):
        if self.tip is None: return None
        r = self.tip_radius() + 3
        return QRectF(self.tip.x()-r, self.tip.y()-r, 2*r, 2*r).toAlignedRect()
    def set_tip(self, pos):
        new = QPointF(pos) if pos is not None and self.owner.tool in self.TIP_TOOLS and not self.pan else None
        old = self.tip_rect(); self.tip = new; now = self.tip_rect()
        for r in (old, now):
            if r is not None: self.update(r)
    def paint_tip(self, p):
        if self.tip is None or self.snapped: return
        p.save(); p.resetTransform(); p.setOpacity(1); p.setRenderHint(QPainter.Antialiasing); p.setBrush(Qt.NoBrush)
        r = self.tip_radius()
        p.setPen(QPen(QColor(10, 20, 35, 215), 3.4)); p.drawEllipse(self.tip, r, r)
        p.setPen(QPen(QColor(255, 255, 255, 235), 1.4)); p.drawEllipse(self.tip, r, r)
        p.restore()
    def cr_steps(self, a, b): return cr_steps(a, b, self.scale)
    def ruler_point(self, vp):
        """Görüntü noktasını cetvel kenarına izdüşürüp sayfa koordinatına çevirir."""
        (ox, oy), (dx, dy), (t0, t1) = self.ruler_edge
        t = max(t0, min(t1, (vp.x() - ox)*dx + (vp.y() - oy)*dy))
        q = self.mapFrom(self.owner.ruler.parentWidget(), QPoint(0, 0))   # cetvel katmanından tahtaya kayma
        x, y = ox + dx*t + q.x(), oy + dy*t + q.y()
        return [x/self.scale, y/self.scale]
    # ---- Canlı koordinat düzlemi ----
    def geo_model(self, create=False):
        ms = self.owner.marks.setdefault(self.owner.page, []); m = geo_find(ms)
        if m is None and create:
            m = dict(tool='geo', points=[[-1000.0, -1000.0]], color='#000000', width=1, rev=0, P=[], O=[]); ms.insert(0, m)
        return m
    def geo_math(self, pt):
        r = self.owner.doc[self.owner.page].rect
        return (pt[0] - r.width/2)/GEO_U, (r.height/2 - pt[1])/GEO_U
    def geo_touch(self, m):
        m['rev'] = m.get('rev', 0) + 1; self.owner.changed(); self.update()
        gb = getattr(self.owner, 'geo_bar', None)
        if gb is not None: gb.sync()
        self.owner.geo_panel_sync()
    def geo_valid_sel(self, m):
        n = len(m['P']) if m else 0; k = len(m['O']) if m else 0
        self.geo_sel = [t for t in getattr(self, 'geo_sel', []) if (t[0] == 'p' and t[1] < n) or (t[0] == 'o' and t[1] < k and m['O'][t[1]]['t'] in GEO_LINES)]
    def geo_select(self, item):
        sel = list(getattr(self, 'geo_sel', []))
        if item in sel: sel.remove(item)
        else: sel = (sel + [item])[-2:]
        self.geo_sel = sel
    def geo_point(self, x, y):
        """(x, y) noktasını koyar; orada nokta varsa onu seçer."""
        m = self.geo_model(True); self.geo_valid_sel(m)
        for i, (px, py, _) in enumerate(m['P']):
            if gq(px) == x and gq(py) == y: self.geo_select(('p', i)); self.geo_touch(m); return
        self.owner.checkpoint(); used = {n for _, _, n in m['P']}
        name = next((c for c in GEO_LETTERS if c not in used), None) or next(c + str(i) for i in range(1, 99) for c in GEO_LETTERS if c + str(i) not in used)
        m['P'].append([float(x), float(y), name]); self.geo_select(('p', len(m['P']) - 1)); self.geo_touch(m)
    def geo_begin(self, pt):
        self.clear_selection(); m = self.geo_model(); tol = 18/self.scale
        if m is not None:
            self.geo_valid_sel(m); P, vals = geo_eval(m); r = self.owner.doc[self.owner.page].rect
            cx, cy = r.width/2, r.height/2
            best = None
            for i, (x, y) in enumerate(P):
                d = math.hypot(cx + float(x)*GEO_U - pt[0], cy - float(y)*GEO_U - pt[1])
                if d <= tol and (best is None or d < best[0]): best = (d, i)
            if best is not None:
                self.geo_drag = dict(i=best[1], moved=False); return
            mx, my = self.geo_math(pt)
            for k, v in enumerate(vals):
                L = v.get('L')
                if L is None: continue
                A, B, C = (float(t) for t in L)
                if abs(A*mx + B*my - C)/math.hypot(A, B)*GEO_U <= tol*.7:
                    self.geo_select(('o', k)); self.geo_touch(m); return
        mx, my = self.geo_math(pt); self.geo_point(_Fr(round(mx)), _Fr(round(my)))
    def geo_move(self, pt):
        d = self.geo_drag; m = self.geo_model()
        if m is None or d['i'] >= len(m['P']): return
        x, y = (round(v) for v in self.geo_math(pt)); P = m['P'][d['i']]
        if (gq(P[0]), gq(P[1])) == (x, y): return
        if any(gq(a) == x and gq(b) == y for j, (a, b, _) in enumerate(m['P']) if j != d['i']): return
        if not d['moved']: self.owner.checkpoint(); d['moved'] = True
        P[0], P[1] = float(x), float(y); self.geo_touch(m)
    def geo_end(self):
        d = self.geo_drag; self.geo_drag = None; m = self.geo_model()
        if m is not None and not d['moved']: self.geo_select(('p', d['i'])); self.geo_touch(m)

    def compass_move(self, pt):
        s = self.active; c = s['center']; st = self.compass
        r = math.dist(pt, c); ang = math.atan2(pt[1]-c[1], pt[0]-c[0]); s['pen'] = list(pt)
        prev = st['prev']; st['prev'] = (r, ang)
        if prev is None: s['r'] = r; return
        da = (ang - prev[1] + math.pi) % (2*math.pi) - math.pi
        if st['phase'] == 'radius':
            s['r'] = r
            if r > 14/self.scale and r*abs(da) > 1.5*abs(r - prev[0]):
                st['sweep'] += da
                if abs(st['sweep']) > math.radians(8):   # çevirmeye başladı: açıklık sabit
                    st['phase'] = 'arc'; st['a0'] = ang - st['sweep']; st['a'] = ang
            else: st['sweep'] = 0.0
        else:
            st['a'] = max(st['a0'] - 2*math.pi, min(st['a0'] + 2*math.pi, st['a'] + da))
        if st['phase'] == 'arc':
            R = s['r']; a0, a1 = st['a0'], st['a']; n = max(2, int(abs(a1 - a0)/math.radians(2)) + 1)
            s['points'] = [[c[0] + R*math.cos(a0 + (a1 - a0)*i/(n-1)), c[1] + R*math.sin(a0 + (a1 - a0)*i/(n-1))] for i in range(n)]
    def smooth_append(self):
        """Incremental smooth_points(): identical result, but only the newest
        curve piece is computed (no full recompute on every pen movement)."""
        raw, pts = self.raw, self.active['points']
        if self.fl is not None:
            # Akıcı: Catmull–Rom through the samples. The piece up to the
            # second-last sample is final (drawn once into the cache); the
            # last piece stays a provisional straight tail until the next
            # sample (or the lift) settles its curve.
            if len(raw) < 3: self.active['points'] = [list(p) for p in raw]; return
            pts.pop(); n = len(raw)
            p0 = raw[n-4] if n >= 4 else raw[n-3]
            pts.extend(catmull_rom(p0, raw[n-3], raw[n-2], raw[n-1], self.cr_steps(raw[n-3], raw[n-2])))
            pts.append(list(raw[-1])); return
        if len(raw) < 3: self.active['points'] = list(raw); return
        pts.pop()
        start = pts[-1] if len(raw) > 3 else raw[0]
        if len(raw) == 3: del pts[1:]
        i = len(raw)-2; control = raw[i]
        end = [(raw[i][j]+raw[i+1][j])/2 for j in (0,1)]
        steps = max(2,min(16,int(math.hypot(end[0]-start[0],end[1]-start[1])/1.2)+1))
        for k in range(1,steps+1):
            t = k/steps
            pts.append([(1-t)**2*start[j]+2*(1-t)*t*control[j]+t*t*end[j] for j in (0,1)])
        pts.append(raw[-1])
    def fast_ink(self):
        """Draw newly stable segments into the cached layer; repaint only the
        small rectangle around the pen tip."""
        s = self.active; pts = s['points']; stable = len(pts)-1
        first = max(0, self.drawn-1)
        while len(self.cum) < stable:   # path length to each stable point (dash continuity)
            i = len(self.cum); self.cum.append(self.cum[-1]+math.dist(pts[i-1],pts[i]) if i else 0)
        if stable > self.drawn:
            o = self.snap_rect.topLeft()
            if self.layers: targets = [(layer, [pen]) for layer, (pen, _, _) in zip(self.layers, style_passes(s))]
            else: targets = [(self.snapshot, self.direct_pens(self.cum[first]))]
            for target, pens in targets:
                painter = QPainter(target); painter.translate(-o.x(), -o.y()); painter.scale(self.scale, self.scale)
                painter.setRenderHint(QPainter.Antialiasing)
                self.draw_segment(painter, s, first, stable, pens=pens); painter.end()
        self.pred = self.predict_tip(s)
        area = pts[first:] + self.raw[-2:] + ([self.pred[1]] if self.pred else [])
        xs = [q[0] for q in area]; ys = [q[1] for q in area]
        pad = s['width']*(STYLE_SPAN.get(s.get('style'), 1) if s['tool'] in STYLED_TOOLS else 1)*self.scale/2 + 3
        self.drawn = max(self.drawn, stable)
        self.update(QRectF(min(xs)*self.scale-pad, min(ys)*self.scale-pad,
                           (max(xs)-min(xs))*self.scale+2*pad, (max(ys)-min(ys))*self.scale+2*pad).toAlignedRect())
    PRED_MAX_PX = 16   # uç tahmini: ekranda en çok bu kadar ileri
    PRED_ON = False    # kapalı: öğretmenler yazarken çizginin ucunun öne taşmasını ("uzama") rahatsız edici buldu
    def predict_tip(self, s):
        """Uç tahmini: tahta saniyede ~60 nokta gönderdiğinde kalem ucu çizginin önünde kalır.
        Son hıza göre en çok bir nokta aralığı ileri, yalnızca düz giderken, geçici bir uç
        çizilir (kaydedilmez; her yeni noktada yeniden hesaplanır, kalem durunca silinir)."""
        if not self.PRED_ON or s['tool'] != 'pen' or s.get('dash') or s.get('nib') in ('fountain', 'marker') or self.layers or s.get('style') not in (None, 'normal', 'fluid'): return None
        h = getattr(self, 'tip_hist', [])
        if len(h) < 3: return None
        (t0, p0), (t1, p1), (t2, p2) = h; dt = t2 - t1
        if not .006 <= dt <= .04: return None
        vx, vy = p2[0]-p1[0], p2[1]-p1[1]; ux, uy = p1[0]-p0[0], p1[1]-p0[1]
        n1, n2 = math.hypot(vx, vy), math.hypot(ux, uy)
        if n1*self.scale < 1.5 or n2 == 0: return None
        if (vx*ux + vy*uy)/(n1*n2) < .87: return None   # ~30°'den keskin dönüşte tahmin yok (köşede taşmasın)
        k = min(.8, self.PRED_MAX_PX/(n1*self.scale))
        tip = [p2[0] + vx*k, p2[1] + vy*k]
        w = s['width']*max(.25, s['w'][-1]) if s.get('w') else s['width']   # Akıcı: genişlik çarpanı
        t = getattr(self, 'pred_timer', None)
        if t is None:
            t = self.pred_timer = QTimer(self); t.setSingleShot(True); t.timeout.connect(self.drop_pred)
        t.start(40)
        return (list(p2), tip, w)
    def drop_pred(self):
        pr = getattr(self, 'pred', None); self.pred = None
        if pr and self.active is not None:
            pad = pr[2]*self.scale/2 + 3; (ax, ay), (bx, by) = pr[0], pr[1]
            self.update(QRectF(min(ax, bx)*self.scale - pad, min(ay, by)*self.scale - pad, abs(ax - bx)*self.scale + 2*pad, abs(ay - by)*self.scale + 2*pad).toAlignedRect())
    # --- Akıcı kalem ---------------------------------------------------
    FLUID_START = .35   # tapered start/end (share of full width)
    def fluid_input(self, pt):
        """Steady the pen: slow, shaky movement is smoothed more, fast strokes
        almost not at all. The smoothing is set per unit of time, not per
        sample, so a board that reports 60 times a second does not lag twice
        as much as one at 120 (measured with kalem_olcum.py)."""
        fl = self.fl; fl['true'] = pt; last = self.raw[-1]
        now = time.monotonic(); dt = max(.001, min(.1, now-fl.get('tin', fl['t']))); fl['tin'] = now
        v = math.hypot(pt[0]-last[0], pt[1]-last[1])*self.scale/(dt*1000)   # screen px per ms
        fl['v'] = v
        a = max(.45, min(1.0, .45+v*.35))       # share of the move taken at 120 Hz
        a = 1-(1-a)**(dt/.008)                  # same steadiness per second at any sample rate
        return [last[0]+(pt[0]-last[0])*a, last[1]+(pt[1]-last[1])*a]
    def fluid_widths(self):
        """Width factor per drawn point: slow = fuller, fast = thinner,
        growing in from a fine tip at the start (kept in step with
        smooth_append, which only rewrites the tail of the stroke)."""
        fl = self.fl; s = self.active; pts = s['points']
        fl['t'] = time.monotonic()
        target = .5 + .8*math.exp(-fl.get('v', 0)/.9)
        fl['f'] += .3*(target-fl['f'])
        fw, arc, ws = fl['fw'], fl['arc'], s['w']
        keep = 0 if len(self.raw) < 3 else 1 if len(self.raw) == 3 else max(0, len(fw)-1)
        del fw[keep:]; del arc[keep:]; del ws[keep:]
        f0 = fw[-1] if fw else fl['f']; n = max(1, len(pts)-keep); grow = s['width']*3
        for k in range(keep, len(pts)):
            arc.append(arc[-1]+math.dist(pts[k-1], pts[k]) if k else 0.0)
            fw.append(f0+(fl['f']-f0)*(k-keep+1)/n)
            ws.append(fw[k]*self._taper(arc[k], grow))
    def _taper(self, arc, grow):
        return self.FLUID_START+(1-self.FLUID_START)*min(1, arc/grow) if grow else 1
    def fluid_finish(self):
        """Reach the real lift point, then let the stroke end in a fine tip."""
        s, fl = self.active, self.fl
        if s['tool'] != 'pen': return   # snapped into a shape
        true = fl['true']; last = self.raw[-1]
        if math.hypot(true[0]-last[0], true[1]-last[1])*self.scale >= .5:
            self.raw.append(true); self.smooth_append()
            if 'w' in s: self.fluid_widths()
        raw = self.raw
        if 'w' not in s and len(raw) >= 3:   # last piece: from the straight tail to its curve, ending on the lift point
            n = len(raw); pts = s['points']; pts.pop()
            pts.extend(catmull_rom(raw[n-3], raw[n-2], raw[n-1], raw[n-1], self.cr_steps(raw[n-2], raw[n-1])))
        if 'w' not in s: return   # even-width Akıcı: done
        pts, ws = s['points'], s['w']
        if len(ws) != len(pts): ws[:] = [1.0]*len(pts)
        total = fl['arc'][-1] if fl['arc'] else 0; grow = s['width']*3
        if total < s['width']*2:   # a dot or a tiny tick: keep it full
            ws[:] = [max(1.0, w) for w in ws]; return
        for k in range(len(pts)):
            rest = total-fl['arc'][k] if k < len(fl['arc']) else 0
            ws[k] *= self._taper(rest, grow)
    # --- Neon kalem: strokes glow for a while, then fade away ------------
    NEON_HOLD, NEON_FADE = 3.0, .8
    def hold_fading(self):
        for item in self.fading: item[1:] = item[1:2]   # writing again: keep them all lit
    def release_fading(self):
        end = time.monotonic()+self.NEON_HOLD
        for item in self.fading: item[1:] = [item[1], end]
        if self.fading and not self.fade_timer.isActive(): self.fade_timer.start(40)
    def fade_tick(self):
        now = time.monotonic(); before = self.fading_rect()
        self.fading = [it for it in self.fading if len(it) < 3 or now < it[2]]
        if not self.fading: self.fade_timer.stop()
        if before is not None: self.update(before)
    def fading_rect(self):
        rect = None
        for it in self.fading:
            if it[1] != self.owner.page: continue
            b = stroke_bounds(it[0]); pad = it[0]['width']*STYLE_SPAN['laser']/2+2
            b = QRectF((b.x()-pad)*self.scale, (b.y()-pad)*self.scale, (b.width()+2*pad)*self.scale, (b.height()+2*pad)*self.scale)
            rect = b if rect is None else rect.united(b)
        return rect.toAlignedRect() if rect is not None else None
    def paint_fading(self, p, clip):
        if not self.fading: return
        now = time.monotonic()
        for it in self.fading:
            if it[1] != self.owner.page: continue
            alpha = 1 if len(it) < 3 else max(0.0, min(1.0, (it[2]-now)/self.NEON_FADE))
            if alpha <= 0: continue
            p.save(); p.setOpacity(alpha); paint_passes(p, stroke_path(it[0]['points']), style_passes(it[0]), clip, self.devicePixelRatioF()); p.restore()
    def direct_pens(self, offset=0):
        """Pens for strokes drawn straight onto the page (normal, dashed, felt)."""
        passes = style_passes(self.active)
        return [passes[0][0]] if passes else [stroke_pen(self.active, offset)]
    def clear_selection(self):
        self.release_timer.stop();self.pending_snap=None
        self.selected=[];self.selection_page=None;self.update()
    def selection_rect(self):
        if self.selection_page!=self.owner.page:return None
        marks=self.owner.marks.get(self.owner.page,[])
        rect=None
        for i in self.selected:
            if i>=len(marks):return None
            b=stroke_bounds(marks[i]);rect=b if rect is None else rect.united(b)
        return rect
    def snap_shape(self):
        if not self.active or self.active['tool']!='pen' or self.snapped:return
        if is_scribble(self.raw,self.scale) and scribble_hits(self.owner.marks.get(self.owner.page,[]),self.active,self.scale):
            self.erase_on_finish=True;self.snapped=True;self.snapshot=None;self.update()
            self.shape_feedback('Karalama: kalemi kaldırınca altındaki yazılar silinecek');return
        xs=[q[0] for q in self.raw];ys=[q[1] for q in self.raw]
        if math.hypot(max(xs)-min(xs),max(ys)-min(ys))*self.scale<SHAPE_MIN_PX:return   # harf boyutu: el yazısı olduğu gibi kalır
        result=recognize_shape(self.raw)
        if result:
            self.active['tool'],self.active['points']=result
            self.active.pop('nib',None);self.active.pop('w',None);self.snapped=True;self.snapshot=None;self.update()
            self.shape_feedback('Şekil düzeltildi')

    def shape_feedback(self,text):
        if hasattr(self.owner,'statusBar'):self.owner.statusBar().showMessage(text,4000)
        elif hasattr(self.owner,'hint'):self.owner.hint.setText(text)

    def erase_scribble(self,stroke,page):
        marks=self.owner.marks.get(page,[])
        if page!=self.owner.page or not any(s is stroke for s in marks):return
        hits=scribble_hits(marks,stroke,self.scale)
        if not hits:return
        gone={id(s) for s in hits}|{id(stroke)}
        # No new checkpoint: one Geri al returns to the state before the scribble.
        self.owner.marks[page]=[s for s in marks if id(s) not in gone]
        self.owner.changed();self.update();self.shape_feedback('Karalanan yazılar silindi · Geri al ile geri getirebilirsiniz')
    def snap_released_shape(self):
        erase=getattr(self,'pending_erase',None);self.pending_erase=None
        if erase and not self.active and not self.transform:self.erase_scribble(*erase);return
        pending=self.pending_snap;self.pending_snap=None
        if not pending or self.active or self.transform:return
        stroke,page,result=pending
        marks=self.owner.marks.get(page,[])
        if page!=self.owner.page or not any(s is stroke for s in marks):return
        self.owner.checkpoint()
        stroke['tool'],stroke['points']=result;stroke.pop('nib',None);stroke.pop('w',None)
        self.owner.changed();self.update();self.shape_feedback('Şekil düzeltildi · Geri al ile el çizimine dönebilirsiniz')

    def delete_badge(self,r):
        page=self.owner.doc[self.owner.page].rect;m=24/self.scale
        return QPointF(min(max(r.right()+28/self.scale,m),page.width-m),min(max(r.top()-28/self.scale,m),page.height-m))
    def delete_selection(self):
        marks=self.owner.marks.get(self.owner.page,[])
        if self.selection_page!=self.owner.page or not self.selected:return
        self.owner.checkpoint()
        gone=set(self.selected);self.owner.marks[self.owner.page]=[s for i,s in enumerate(marks) if i not in gone]
        self.clear_selection();self.owner.changed();self.update()
        self.shape_feedback('Seçilenler silindi · Geri al ile geri getirebilirsiniz')
    def start_smart(self,pt):
        r=self.selection_rect();corner=None
        if r is not None:
            c=self.delete_badge(r)
            if math.hypot(pt[0]-c.x(),pt[1]-c.y())<=24/self.scale:self.delete_selection();return
            corners=[r.topLeft(),r.topRight(),r.bottomLeft(),r.bottomRight()]
            for i,c in enumerate(corners):
                if math.hypot(pt[0]-c.x(),pt[1]-c.y())<=16/self.scale:corner=i;break
            if corner is not None or r.contains(QPointF(*pt)):
                self.transform=dict(before=copy.deepcopy(self.owner.marks),rect=r,point=pt,corner=corner)
                return
        self.clear_selection()
        self.active=dict(tool='smart',points=[pt],color='#2394ff',width=1)

    def move_selection(self,pt):
        t=self.transform;r=t['rect'];page=self.owner.doc[self.owner.page].rect
        scale=1;dx=dy=0;anchor=QPointF(0,0)
        if t['corner'] is None:
            dx=max(-r.left(),min(page.width-r.right(),pt[0]-t['point'][0]))
            dy=max(-r.top(),min(page.height-r.bottom(),pt[1]-t['point'][1]))
        else:
            corners=[r.topLeft(),r.topRight(),r.bottomLeft(),r.bottomRight()]
            anchor=corners[3-t['corner']];drag=corners[t['corner']]
            vx,vy=drag.x()-anchor.x(),drag.y()-anchor.y()
            scale=max(.1,min(8,((pt[0]-anchor.x())*vx+(pt[1]-anchor.y())*vy)/max(vx*vx+vy*vy,.01)))
            maxx=(page.width-anchor.x())/vx if vx>0 else -anchor.x()/vx
            maxy=(page.height-anchor.y())/vy if vy>0 else -anchor.y()/vy
            scale=max(.01,min(scale,maxx,maxy))
        for i in self.selected:
            s=copy.deepcopy(t['before'][self.owner.page][i])
            s['points']=[[anchor.x()+(x-anchor.x())*scale+dx,anchor.y()+(y-anchor.y())*scale+dy] for x,y in s['points']]
            s['width']=max(.05,min(100,s['width']*scale));s.pop('origin',None)
            self.owner.marks[self.owner.page][i]=s
        self.update()

    def point(self, pos):
        r = self.owner.doc[self.owner.page].rect
        return [max(0, min(r.width, pos.x()/self.scale)), max(0, min(r.height, pos.y()/self.scale))]

    def begin(self, pos):
        o_ = self.owner; o_ = o_ if hasattr(o_, 'send_state') else getattr(o_, 'main', o_)
        o_.last_touch = time.time()   # yönetici paneli: "kullanımda" (Ekrana yaz katmanında da ana pencereye)
        self.release_timer.stop();self.pending_snap=None;self.pending_erase=None;self.erase_on_finish=False
        self.snapped=False;self.hold_timer.stop()
        self.auto_pen.stop();self.erasing=self.owner.tool in AUTO_PEN_TOOLS
        # The ring must be gone before the fast-ink snapshot is taken.
        self.set_tip(pos if self.owner.tool in self.ERASER_TOOLS else None)
        if self.owner.tool == 'hand':
            self.pan = (pos, self.owner.scroll.horizontalScrollBar().value(), self.owner.scroll.verticalScrollBar().value())
            return
        pt = self.point(pos)
        self.ruler_edge = None
        if self.owner.tool=='smart':self.start_smart(pt);self.update();return
        if self.owner.tool == 'place_tri' and getattr(self.owner, 'pending_triangle', None):   # Ölçülü üçgen: dokunulan yere
            self.owner.checkpoint(); ms = self.owner.marks.setdefault(self.owner.page, [])
            for m in self.owner.pending_triangle: ms.append(dict(m, points=[[x + pt[0], y + pt[1]] for x, y in m['points']]))
            self.owner.pending_triangle = None; self.owner.changed(); self.update(); self.owner.set_tool('pen')
            self.shape_feedback(getattr(self.owner, 'pending_label', None) or 'Üçgen kondu · Akıllı seçimle taşıyabilir, Geri al ile kaldırabilirsiniz'); self.owner.pending_label = None; return
        if self.owner.tool == 'geo': self.geo_begin(pt); return
        if self.owner.tool == 'compass':   # Pergel: merkez burada; sürükle = açıklık, çevir = yay
            self.clear_selection(); self.ensure_base(); self.raw = []; self.compass = dict(r=0.0, prev=None, sweep=0.0, phase='radius', a0=0.0, a=0.0)
            self.active = dict(tool='compass', center=list(pt), r=0.0, points=[], color=self.owner.color, width=self.owner.width.value())
            self.update(); return
        ruler = getattr(self.owner, 'ruler', None)
        if self.owner.tool in ('pen', 'dash', 'highlight') and ruler is not None and ruler.isVisible():
            vp = QPointF(pos) + QPointF(self.mapTo(ruler.parentWidget(), QPoint(0, 0)))
            edge = ruler.edge_for(vp, self.owner.width.value()*self.scale/2 + 2)
            if edge is not None:   # cetvelin kenarına yakın: çizgi kenara yapışır, dümdüz
                self.ensure_base(); self.ruler_edge = edge; a = self.ruler_point(vp)
                self.active = dict(tool='line', color=self.owner.color, width=self.owner.width.value()*(4 if self.owner.tool == 'highlight' else 1), points=[a, a])
                if self.owner.tool == 'dash': self.active['dash'] = True
                if self.owner.tool == 'highlight': self.active['tool'] = 'highlight'
                self.raw = [a]; self.update(); return
        if self.owner.tool == 'pick':   # Günün soruları: soru seç
            self.clear_selection(); self.active = dict(tool='pick_frame', points=[pt], color='#ffb400', width=1)
            self.update(); return
        if self.owner.tool == 'atlas':   # K-350: Atlas — soruyu çerçeveye al, Atlas çözsün
            self.clear_selection(); self.active = dict(tool='atlas_frame', points=[pt], color='#22e8ff', width=1)
            self.update(); return
        if self.owner.tool == 'postit':   # Post-it: frame what to pin to the side board
            self.clear_selection(); self.active = dict(tool='postit_frame', points=[pt], color='#ffe27a', width=1)
            self.update(); return
        if self.owner.tool == 'area_eraser':   # Alan silgisi: frame like Akıllı seçim, deleted on release
            self.clear_selection(); self.active = dict(tool='erase_frame', points=[pt], color='#e23b4d', width=1)
            self.update(); return
        if self.owner.tool == 'eraser':
            self.owner.checkpoint()
            self.erasing = True; self.last_erase = None
            self.erase(pt)
        else:
            self.raw = [pt]; self.tip_hist = [(time.monotonic(), pt)]; self.pred = None
            self.snapshot = None; self.drawn = 0; self.cum = []
            # "Kesikli çizgi" is its own tool: a pen stroke drawn dashed.
            tool = 'pen' if self.owner.tool == 'dash' else 'line' if self.owner.tool == 'arrow' else self.owner.tool
            if tool == 'laser': self.hold_fading()
            if tool in ('line', 'rect', 'circle', 'triangle'): self.ensure_base()   # şekil önizlemesi hazır sayfanın üstünde
            if tool in ('pen', 'laser') and self.owner.nib.currentData() not in ('fountain','marker'):
                # Cache only what is on screen (a 333% page can be huge).
                self.snap_rect = self.visibleRegion().boundingRect()
                if not self.snap_rect.isEmpty():
                    ok = self.cacheable()
                    if ok and self.base_valid(self.snap_rect) and self.base_rect == self.snap_rect: self.snapshot = self.base.copy()
                    else:
                        self.snapshot = self.grab(self.snap_rect)
                        if ok: self.base = self.snapshot.copy(); self.base_rect = QRect(self.snap_rect); self.base_key = self.mark_key()
                        else: self.base = None
            self.active = dict(tool=tool, color=self.owner.color,
                width=self.owner.width.value() * (4 if tool == 'highlight' else 1), points=[pt])
            if self.owner.tool == 'dash': self.active['dash'] = True
            if self.owner.tool == 'arrow': self.active['arrow'] = True
            style = getattr(self.owner, 'pen_style', 'normal')
            if tool == 'pen' and self.owner.tool == 'pen' and style in STYLE_SPAN: self.active['style'] = style
            if tool == 'laser': self.active['style'] = 'laser'
            self.fl = None
            if self.active.get('style') == 'fluid':
                # Akıcı: even width with round ends (no pointed tips); only the
                # hand tremor is smoothed away.
                self.fl = dict(t=time.monotonic(), f=1.0, true=pt, arc=[0.0], fw=[1.0])
            self.layers = None
            passes = style_passes(self.active)
            if self.snapshot is not None and passes and any(o < 1 or m for _, o, m in passes):
                self.layers = []
                for _ in passes:
                    layer = QPixmap(self.snapshot.size()); layer.setDevicePixelRatio(self.snapshot.devicePixelRatio())
                    layer.fill(Qt.transparent); self.layers.append(layer)
            if tool == 'pen':
                self.active['nib'] = self.owner.nib.currentData()
                if self.active['nib'] == 'fine': self.active['width'] *= .45
                self.hold_anchor=pt;self.hold_timer.start(900)
        self.update()

    def move(self, pos):
        if self.pan:
            start, x, y = self.pan
            # Global pointer coordinates avoid feedback as the widget scrolls.
            self.owner.scroll.horizontalScrollBar().setValue(x+int(start.x()-pos.x()))
            self.owner.scroll.verticalScrollBar().setValue(y+int(start.y()-pos.y()))
            return
        if self.erasing: self.set_tip(pos)
        pt = self.point(pos)
        if getattr(self, 'geo_drag', None) is not None: self.geo_move(pt); return
        if self.transform:self.move_selection(pt);return
        if self.snapped:return
        if self.erasing: self.erase(pt)
        if self.active and self.active['tool'] == 'compass': self.compass_move(pt); self.update(); return
        if self.active and getattr(self, 'ruler_edge', None) is not None:
            self.active['points'][1] = self.ruler_point(QPointF(pos) + QPointF(self.mapTo(self.owner.ruler.parentWidget(), QPoint(0, 0)))); self.update(); return
        if self.active:
            s = self.active
            a = s['points'][0]
            if s['tool'] in ('pen', 'highlight', 'laser'):
                last = self.raw[-1]
                if self.fl is not None: pt = self.fluid_input(pt)
                # Samples closer than 0.8 screen px are skipped: measured, keeping
                # them only adds quantisation jitter to slow writing.
                if pt is not None and math.hypot(pt[0]-last[0],pt[1]-last[1])*self.scale >= .8:
                    self.raw.append(pt); self.tip_hist = (getattr(self, 'tip_hist', [])+[(time.monotonic(), pt)])[-3:]
                    self.smooth_append()
                    if self.fl is not None and 'w' in s: self.fluid_widths()
                    if s['tool']=='pen' and math.dist(pt,self.hold_anchor)*self.scale>12:
                        self.hold_anchor=pt;self.hold_timer.start(900)
                    if self.snapshot is not None and not self.snapped:
                        self.fast_ink();return
                elif self.snapshot is not None and not self.snapped:return
            elif s['tool'] == 'line' and s.get('arrow'): s['points'] = arrow_points(a, pt, s['width'])
            elif s['tool'] in ('line','select','smart','solution','erase_frame','postit_frame','pick_frame','atlas_frame'): s['points'] = [a, pt]
            elif s['tool'] == 'rect': s['points'] = [a, [pt[0],a[1]], pt, [a[0],pt[1]], a]
            elif s['tool'] == 'triangle': s.setdefault('origin', a); s['points'] = tri_points(s['origin'], pt)
            elif s['tool'] == 'circle':
                # Keep the press position separately because ellipse starts at its right edge.
                a = s.setdefault('origin', a)
                cx, cy = (a[0]+pt[0])/2, (a[1]+pt[1])/2
                rx, ry = abs(pt[0]-a[0])/2, abs(pt[1]-a[1])/2
                s['points'] = [[cx+rx*math.cos(t*math.pi/32),cy+ry*math.sin(t*math.pi/32)] for t in range(65)]
        self.update()

    LIVE_MOVES = (QEvent.TouchUpdate, QEvent.MouseMove, QEvent.TabletMove)
    def event(self, e):
        """Gerçek kullanım ölçümü (canlı): yazarken her noktanın işlenme süresi ve sırada bekleme.
        Yalnızca süreler tutulur; yazının kendisi hiçbir yere gitmez."""
        if e.type() in self.LIVE_MOVES and self.active is not None:
            st = time.perf_counter(); r = self.event_impl(e)
            lm = getattr(self.owner, 'live_meter', None)
            if lm is not None and self.active is not None:
                try: ts = e.timestamp()
                except Exception: ts = 0
                lm.point((time.perf_counter() - st)*1000, ts, self)
            return r
        return self.event_impl(e)
    def finish(self, cancel=False):
        lm = getattr(self.owner, 'live_meter', None)
        if lm is None or self.active is None: return self.finish_impl(cancel)
        st = time.perf_counter(); r = self.finish_impl(cancel); lm.stroke_end((time.perf_counter() - st)*1000, self); return r
    def finish_impl(self, cancel=False):
        self.hold_timer.stop();self.snapped=False;self.pred=None
        if getattr(self, 'geo_drag', None) is not None: self.geo_end(); return
        if self.erasing:
            self.erasing=False
            if self.owner.tool in AUTO_PEN_TOOLS:self.auto_pen.start()
        if self.active and self.active['tool'] == 'laser':   # Neon kalem: not saved, fades out
            if not cancel and self.active['points']:
                self.fading.append([self.active, self.owner.page])
            self.active = None; self.snapshot = None; self.layers = None; self.release_fading(); self.update(); return
        if self.active and self.fl is not None and not cancel and not self.snapped: self.fluid_finish()
        if self.active and self.active['tool']=='solution':
            pts=self.active['points'];self.active=None
            if not cancel and pts:
                a,b=pts[0],pts[-1]
                if len(pts)==2 and min(abs(a[0]-b[0]),abs(a[1]-b[1]))*self.scale>=12:self.owner.make_solution(pts)
                elif hasattr(self.owner,'solution_tap'):self.owner.solution_tap(pts[0])   # tek dokunuş: Atlas'ın bulduğu soru açılır
        if self.transform:
            after=copy.deepcopy(self.owner.marks);before=self.transform['before'];self.transform=None
            self.owner.marks=before
            if not cancel and after!=before:
                self.owner.checkpoint();self.owner.marks=after;self.owner.changed()
        if self.active and self.active['tool']=='smart':
            pts=self.active['points'];self.active=None
            if not cancel:
                self.selection_page=self.owner.page;self.selected=self.framed(pts)
        if self.active and self.active['tool']=='pick_frame':
            pts=self.active['points'];self.active=None;self.update()
            if not cancel and len(pts)==2 and hasattr(self.owner,'add_planned'):self.owner.add_planned(pts)
        if self.active and self.active['tool']=='atlas_frame':
            pts=self.active['points'];self.active=None;self.update()
            if not cancel and hasattr(self.owner,'atlas_cerceve'):QTimer.singleShot(0,lambda p_=list(pts):self.owner.atlas_cerceve(p_))
        if self.active and self.active['tool']=='postit_frame':
            pts=self.active['points'];self.active=None;self.update()
            if not cancel and len(pts)==2 and hasattr(self.owner,'make_postit'):self.owner.make_postit(pts)
        if self.active and self.active['tool']=='erase_frame':
            pts=self.active['points'];self.active=None
            gone=set(self.framed(pts)) if not cancel else set()
            if gone:
                marks=self.owner.marks.get(self.owner.page,[])
                self.owner.checkpoint();self.owner.marks[self.owner.page]=[s for i,s in enumerate(marks) if i not in gone]
                self.owner.changed();self.shape_feedback('Seçilen yazılar silindi · Geri al ile geri getirebilirsiniz')
        if self.active and self.active['tool'] == 'select':
            pts = self.active['points']
            self.active = None
            if not cancel and len(pts) == 2:
                getattr(self.owner,'select_area',self.owner.apply_selection)(pts)
        if self.active and self.active['tool'] == 'compass':   # yalnızca çizilen yay kalır
            s_ = self.active
            self.active = dict(tool='pen', color=s_['color'], width=s_['width'], points=s_['points']) if len(s_['points']) > 1 and not cancel else None
            if self.active is None: self.update()
        self.ruler_edge = None
        added = None
        if self.active and not cancel:
            self.owner.checkpoint()
            self.owner.marks.setdefault(self.owner.page, []).append(self.active); added = self.active
            self.owner.changed()
            if hasattr(self.owner, 'maybe_extend'): self.owner.maybe_extend(self.active)
            if self.active['tool']=='pen':
                if getattr(self,'erase_on_finish',False):
                    self.erase_on_finish=False;self.erase_scribble(self.active,self.owner.page)
                elif is_scribble(self.raw,self.scale) and scribble_hits(self.owner.marks.get(self.owner.page,[]),self.active,self.scale):
                    # Scratch over writing and wait ~1 s: the writing is erased.
                    self.pending_erase=(self.active,self.owner.page);self.release_timer.start(1000)
                # Kalem kaldırılınca şekle çevirme yok: el yazısındaki o, 0, 1, - gibi harfler
                # kendiliğinden elips ya da cetvel çizgisine dönüşüyordu. Şekil yalnızca kalemi
                # büyük bir çizimin sonunda bilerek bekletince düzeltilir (snap_shape).
        self.active = None; self.snapshot = None; self.layers = None
        self.erasing = False; self.last_erase = None
        if added is not None: self.refresh_base(added)
        self.pan = None; self.set_tip(None)
        self.update()

    def framed(self, pts):
        """Strokes inside a dragged frame, or the stroke under a single tap
        (same rule for Akıllı seçim and Alan silgisi)."""
        r=QRectF(QPointF(*pts[0]),QPointF(*pts[-1])).normalized();found=[]
        for i,s in enumerate(self.owner.marks.get(self.owner.page,[])):
            if s['tool']=='whiteout':continue
            if r.width()+r.height()<8/self.scale:
                hit=any(segment_distance(pts[0],a,b)<12/self.scale+s['width']/2 for a,b in zip(s['points'],s['points'][1:] or s['points']))
            else:hit=r.contains(stroke_bounds(s))
            if hit:found.append(i)
        return found
    def erase(self, pt):
        strokes = self.owner.marks.get(self.owner.page, [])
        def hit(s):
            if s['tool'] == 'whiteout': return False
            pts = s['points']
            return any(segment_distance(pt,a,b) <= 12/self.scale+s['width']/2 for a,b in zip(pts,pts[1:] or pts))
        left = [s for s in strokes if not hit(s)]
        if len(left) != len(strokes):
            self.owner.marks[self.owner.page] = left
            self.owner.changed()

    PALM_PX = 45   # contact wider than this (screen px) is treated as a palm
    TAP_S = .35        # two-finger tap (Geri al): shorter than this…
    TAP_MOVE_PX = 20   # …and no finger moving further than this
    @staticmethod
    def contact_size(p):
        try: d = p.ellipseDiameters(); return max(d.width(), d.height())
        except AttributeError: r = p.rect(); return max(r.width(), r.height())
    def erase_area(self, pt, radius):
        strokes = self.owner.marks.get(self.owner.page, [])
        def hit(s):
            if s['tool'] == 'whiteout': return False
            pts = s['points']
            return any(segment_distance(pt,a,b) <= radius+s['width']/2 for a,b in zip(pts,pts[1:] or pts))
        left = [s for s in strokes if not hit(s)]
        if len(left) != len(strokes):
            if getattr(self, 'palm', False) and not getattr(self, 'palm_saved', False):
                self.owner.checkpoint(); self.palm_saved = True   # one undo step per palm gesture
            self.owner.marks[self.owner.page] = left; self.owner.changed(); self.update()
    GESTURE_S = .18     # ikinci parmak bu süre içinde ve ilk parmak yazmaya başlamadan gelirse iki parmak hareketi
    GESTURE_MOVE_PX = 14
    def writing_started(self):
        """İlk parmak gerçekten yazıyor mu (süre ya da yol): o zaman ek temaslar hareket sayılmaz."""
        if time.monotonic() - getattr(self, 'touch_t0', 0) > self.GESTURE_S: return True
        raw = getattr(self, 'raw', None) or []
        return len(raw) > 1 and math.dist(raw[0], raw[-1])*self.scale > self.GESTURE_MOVE_PX
    def multi_touch(self, e, pts):
        """Avuç reddi ve iki parmak hareketi. Avuç / geniş temas ve 3+ temas hiçbir şey yapmaz
        (silmez, çizmez); iki parmak sıkıştırınca yakınlaştırır, kısa dokunuşta Geri al.
        Returns True when the event was handled (yok sayıldı ya da hareket)."""
        active = [p for p in pts if p.state() != Qt.TouchPointReleased]
        pal = getattr(self, 'palm_ids', None)
        if pal is None: pal = self.palm_ids = set()
        pal |= {p.id() for p in active if self.contact_size(p) >= self.PALM_PX}
        if self.active is not None and not getattr(self, 'gesture', None) and self.writing_started() and self.pointer not in pal:
            return False   # yazarken gelen ek temas (avuç, bilek, parmak) yok sayılır: çizgi ilk parmakla sürer
        if self.active is not None and self.pointer in pal:   # çizgiyi avuç başlatmış: iptal (iz bırakmaz)
            self.finish(cancel=True); self.pointer = None
        fingers = [p for p in active if p.id() not in pal]
        if len(active) >= 3 or getattr(self, 'palm', False):   # yumruk / çok temas: hepsi kalkana dek yok sayılır
            if not getattr(self, 'palm', False):
                if self.active or self.transform: self.finish(cancel=True)
                self.gesture = None; self.palm = True; self.pointer = None
            return True
        if pal and not fingers: return True   # yalnız avuç: yok say
        active = fingers
        # Screen mode has no page to zoom: two fingers are only a Geri al tap there.
        tap_only = getattr(self.owner, 'overlay_mode', False) or not hasattr(self.owner, 'scroll')
        if len(active) == 2 or getattr(self, 'gesture', None):
            if len(active) < 2: return True       # wait until all fingers lift
            a, b = active[0].screenPos(), active[1].screenPos()
            center = QPointF((a.x()+b.x())/2, (a.y()+b.y())/2); dist = max(1.0, math.hypot(a.x()-b.x(), a.y()-b.y()))
            if not getattr(self, 'gesture', None):
                if self.active or self.transform: self.finish(cancel=True)
                local = self.mapFromGlobal(center.toPoint())
                self.gesture = dict(d0=dist, z0=getattr(self.owner, 'zoom', 1), anchor=(local.x()/self.scale, local.y()/self.scale), last=0, c0=QPointF(center),
                                    t0=time.monotonic(), start={p.id(): QPointF(p.screenPos()) for p in active}, moved=False, tap_only=tap_only)
                return True
            g = self.gesture
            # Two-finger tap = Geri al: only if the fingers stay put.
            for p in active:
                q = g['start'].get(p.id())
                if q is None or math.hypot(p.screenPos().x()-q.x(), p.screenPos().y()-q.y()) > self.TAP_MOVE_PX: g['moved'] = True
            if g['tap_only']: return True
            zoom = max(.15, min(8, g['z0']*dist/g['d0']))
            if abs(zoom-self.owner.zoom)/self.owner.zoom > .03 and time.monotonic()-g['last'] > .06:
                self.owner.set_zoom(zoom); g['last'] = time.monotonic(); g['moved'] = True
            # İki parmak sayfayı kaydırmaz: yakınlaştırma, parmakların ilk değdiği nokta etrafında
            local = self.mapFromGlobal(g['c0'].toPoint()); ax, ay = g['anchor']
            h, v = self.owner.scroll.horizontalScrollBar(), self.owner.scroll.verticalScrollBar()
            h.setValue(int(h.value()+ax*self.scale-local.x())); v.setValue(int(v.value()+ay*self.scale-local.y()))
            return True
        return False
    def event_impl(self, e):
        if e.type() in (QEvent.TouchBegin, QEvent.TouchUpdate, QEvent.TouchEnd, QEvent.TouchCancel):
            pts = e.touchPoints()
            if e.type() in (QEvent.TouchEnd, QEvent.TouchCancel):
                self.palm_ids = set()
                if getattr(self, 'palm', False) or getattr(self, 'gesture', None):
                    g = self.gesture
                    tap = (g is not None and not getattr(self, 'palm', False) and not g['moved']
                           and time.monotonic()-g['t0'] <= self.TAP_S and e.type() == QEvent.TouchEnd)
                    self.palm = False; self.gesture = None; self.pointer = None
                    if tap:
                        self.owner.undo(); self.shape_feedback('İki parmak: Geri al')
                    if hasattr(self.owner, 'render'): self.owner.render()
                    e.accept(); return True
            elif self.multi_touch(e, pts):
                e.accept(); return True
            pal = getattr(self, 'palm_ids', set())
            if e.type() == QEvent.TouchBegin and pts:
                first = next((p for p in pts if p.id() not in pal), None)
                if first is not None:
                    self.pointer = first.id(); self.touch_t0 = time.monotonic()
                    self.begin(first.screenPos() if self.owner.tool == 'hand' else first.pos())
            elif e.type() == QEvent.TouchUpdate:
                if self.pointer is None and self.active is None:   # avuç dayalıyken sonradan gelen parmak yazar
                    new_ = next((p for p in pts if p.state() == Qt.TouchPointPressed and p.id() not in pal), None)
                    if new_ is not None:
                        self.pointer = new_.id(); self.touch_t0 = time.monotonic()
                        self.begin(new_.screenPos() if self.owner.tool == 'hand' else new_.pos())
                for p in pts:
                    if p.id() == self.pointer and p.state() != Qt.TouchPointPressed: self.move(p.screenPos() if self.pan else p.pos())
            else:
                self.finish(e.type() == QEvent.TouchCancel)
                self.pointer = None
            e.accept()
            return True
        return super().event(e)

    def mousePressEvent(self, e):
        if e.source()!=Qt.MouseEventNotSynthesized:return
        if e.button() == Qt.LeftButton: self.begin(e.globalPos() if self.owner.tool == 'hand' else e.localPos())
    def mouseMoveEvent(self, e):
        if e.source()!=Qt.MouseEventNotSynthesized:return
        if e.buttons() & Qt.LeftButton: self.move(e.globalPos() if self.pan else e.localPos())
        elif not self.active: self.set_tip(e.localPos())   # mouse hover shows the ring too
    def leaveEvent(self, e):
        self.set_tip(None); super().leaveEvent(e)
    def mouseReleaseEvent(self, e):
        if e.source()!=Qt.MouseEventNotSynthesized:return
        if e.button() == Qt.LeftButton:
            if self.active or self.transform: self.move(e.localPos())
            self.finish()
    def tabletEvent(self, e):
        if e.type() == QEvent.TabletPress: self.begin(e.globalPosF() if self.owner.tool == 'hand' else e.posF())
        elif e.type() == QEvent.TabletMove: self.move(e.globalPosF() if self.pan else e.posF())
        elif e.type() == QEvent.TabletRelease:
            if self.active or self.transform:self.move(e.posF())
            self.finish()
        e.accept()
    def closeEvent(self,e):
        if getattr(self.owner,'overlay_mode',False):e.ignore();self.owner.leave()
        else:super().closeEvent(e)

def x11_compositing_running():
    """EWMH check: a compositor owns the _NET_WM_CM_S<screen> selection.
    Pardus/Debian PyQt5 builds lack QX11Info.isCompositingManagerRunning,
    so libX11 is queried directly. Returns True when it cannot be determined
    so the overlay is never blocked by a detection failure."""
    from PyQt5.QtX11Extras import QX11Info
    if hasattr(QX11Info,'isCompositingManagerRunning'):
        return QX11Info.isCompositingManagerRunning()
    import ctypes, ctypes.util
    try:
        x11=ctypes.CDLL(ctypes.util.find_library('X11') or 'libX11.so.6')
        x11.XOpenDisplay.restype=ctypes.c_void_p; x11.XOpenDisplay.argtypes=[ctypes.c_char_p]
        x11.XDefaultScreen.restype=ctypes.c_int; x11.XDefaultScreen.argtypes=[ctypes.c_void_p]
        x11.XInternAtom.restype=ctypes.c_ulong; x11.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int]
        x11.XGetSelectionOwner.restype=ctypes.c_ulong; x11.XGetSelectionOwner.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
        x11.XCloseDisplay.argtypes=[ctypes.c_void_p]
        display=x11.XOpenDisplay(None)
        if not display: return True
        try:
            atom=x11.XInternAtom(display,('_NET_WM_CM_S%d' % x11.XDefaultScreen(display)).encode(),0)
            return x11.XGetSelectionOwner(display,atom)!=0
        finally: x11.XCloseDisplay(display)
    except (OSError, AttributeError): return True

def page_number_dialog(parent, count, current):
    """Touch-friendly number pad: no on-screen keyboard needed."""
    from PyQt5.QtWidgets import QDialog
    dialog=QDialog(parent);dialog.setWindowTitle('Sayfaya git');dialog.setModal(True)
    dialog.setStyleSheet('''QDialog,QWidget{background:#122034;color:#edf4ff;font-family:"DejaVu Sans";font-size:22px;}
        QPushButton{background:#22344c;border:1px solid #364a63;border-radius:10px;min-width:84px;min-height:64px;}
        QPushButton:hover{background:#304b68;} QPushButton#primary{background:#c61d2d;font-weight:bold;}''')
    layout=QVBoxLayout(dialog)
    info=QLabel('Sayfa numarası (1 – %d)' % count);info.setStyleSheet('font-size:16px;color:#b9c6d8;');layout.addWidget(info)
    shown=QLabel('');shown.setAlignment(Qt.AlignCenter);shown.setMinimumHeight(64)
    shown.setStyleSheet('font-size:36px;font-weight:bold;background:#091423;border:1px solid #364a63;border-radius:10px;');layout.addWidget(shown)
    grid=QGridLayout();grid.setSpacing(8);layout.addLayout(grid)
    value=['']
    def update():
        shown.setText(value[0] or str(current))
        go.setEnabled(bool(value[0]) and 1<=int(value[0])<=count)
    def press(d):
        if len(value[0])<5 and not (d=='0' and not value[0]):value[0]+=d;update()
    def back():value[0]=value[0][:-1];update()
    for i,d in enumerate('123456789'):
        b=QPushButton(d);b.clicked.connect(lambda checked=False,d=d:press(d));grid.addWidget(b,i//3,i%3)
    erase=QPushButton('Sil');erase.clicked.connect(back);grid.addWidget(erase,3,0)
    zero=QPushButton('0');zero.clicked.connect(lambda:press('0'));grid.addWidget(zero,3,1)
    go=QPushButton('Git');go.setObjectName('primary');go.clicked.connect(dialog.accept);grid.addWidget(go,3,2)
    cancel=QPushButton('Vazgeç');cancel.clicked.connect(dialog.reject);layout.addWidget(cancel)
    update()
    return int(value[0]) if dialog.exec_()==QDialog.Accepted and value[0] else None

class Window(QMainWindow):
    @property
    def color(self): return self._color
    @color.setter
    def color(self, value):
        self._color = value; self.refresh_colors()
    def refresh_colors(self):
        if not hasattr(self,'color_buttons') or not hasattr(self,'tool_buttons'): return
        for c,b in self.color_buttons: b.setChecked(c == self._color)
        paint_tool_buttons(self.tool_buttons, self.tool_labels, self.tool, self._color)
        if hasattr(self,'shape_button'):   # Şekiller shows the chosen shape, in the ink colour
            b=self.shape_button;chosen=self.tool in SHAPE_TOOLS;b.setChecked(chosen)
            if chosen:
                q=QColor(self._color);ink='#122034' if .299*q.redF()+.587*q.greenF()+.114*q.blueF()>.6 else '#ffffff'
                b.setStyleSheet('QPushButton:checked{background:%s;color:%s;border:3px solid #ffffff;}'%(self._color,ink))
                b.setIcon(tool_icon(self.tool_labels[self.tool],ink));b.setText('Şekiller')
            else:b.setStyleSheet('');b.setIcon(tool_icon('Şekiller'));b.setText('Şekiller')
        if hasattr(self,'solution_button'):   # folder buttons stay lit while one of their tools is on
            self.solution_button.setChecked(self.tool in ('solution','select'))
            self.tool_buttons['eraser'].setChecked(self.tool in ('eraser','area_eraser'))
    # ---- Post-it panosu --------------------------------------------------
    POSTIT_COLORS = ('#ffe27a', '#ffb3c7', '#b8f0c8', '#b9dcff')
    def postit_file(self): return os.path.join(self.data_dir, 'postit', 'postit.json')
    def load_postits(self):
        """One Post-it panosu for every screen (boş tahta and every PDF tab)."""
        self.pano_dir = 'ortak'; self.pano.clear()
        self.merge_tab_postits()
        try:
            with open(self.postit_file(), encoding='utf-8') as f: items = json.load(f)
        except (OSError, ValueError): items = []
        for it in items:
            pix = QPixmap(os.path.join(os.path.dirname(self.postit_file()), os.path.basename(str(it.get('file','')))))
            if not pix.isNull(): self.pano.add(pix, it.get('color', self.POSTIT_COLORS[0]), it['file'])
        try:
            with open(os.path.join(os.path.dirname(self.postit_file()), 'pano.json'), encoding='utf-8') as f: self.pano_hidden = bool(json.load(f).get('gizli'))
        except (OSError, ValueError, AttributeError): self.pano_hidden = False
        self.show_pano()
    def merge_tab_postits(self):
        """Earlier versions kept post-its per tab: move them onto the shared board once."""
        folder = os.path.dirname(self.postit_file())
        try: tabs = [d for d in os.listdir(self.data_dir) if d != 'postit' and os.path.isfile(os.path.join(self.data_dir, d, 'postit', 'postit.json'))]
        except OSError: return
        if not tabs: return
        try:
            with open(self.postit_file(), encoding='utf-8') as f: items = json.load(f)
        except (OSError, ValueError): items = []
        os.makedirs(folder, exist_ok=True)
        for d in tabs:
            old = os.path.join(self.data_dir, d, 'postit')
            try:
                with open(os.path.join(old, 'postit.json'), encoding='utf-8') as f: olds = json.load(f)
                for it in olds:
                    name = os.path.basename(str(it.get('file', '')))
                    if name and os.path.isfile(os.path.join(old, name)) and not os.path.exists(os.path.join(folder, name)):
                        shutil.copy2(os.path.join(old, name), os.path.join(folder, name)); items.append(dict(file=name, color=it.get('color', self.POSTIT_COLORS[0])))
                os.replace(os.path.join(old, 'postit.json'), os.path.join(old, 'postit.json.tasindi'))
            except (OSError, ValueError, TypeError): pass
        try:
            with open(self.postit_file(), 'w', encoding='utf-8') as f: json.dump(items, f)
        except OSError: pass
    def show_pano(self):
        """Pano or, when the teacher hid it, a slim tab to bring it back."""
        has = bool(self.pano.cards)
        self.pano.setVisible(has and not self.pano_hidden)
        self.pano_tab.setVisible(has and self.pano_hidden)
        self.pano_tab.setText(str(len(self.pano.cards)))
    def set_pano_hidden(self, hidden):
        self.pano_hidden = hidden; self.show_pano()
        try:
            os.makedirs(os.path.dirname(self.postit_file()), exist_ok=True)
            with open(os.path.join(os.path.dirname(self.postit_file()), 'pano.json'), 'w', encoding='utf-8') as f: json.dump(dict(gizli=hidden), f)
        except OSError: pass
    def save_postits(self):
        try:
            os.makedirs(os.path.dirname(self.postit_file()), exist_ok=True)
            with open(self.postit_file(), 'w', encoding='utf-8') as f:
                json.dump([dict(file=c.name, color=c.color) for c in self.pano.cards], f)
        except OSError: pass
    def make_postit(self, pts):
        """Peel the framed part off the board and stick it to the side board."""
        a, b = pts; k = self.board.scale
        r = QRectF(QPointF(a[0]*k, a[1]*k), QPointF(b[0]*k, b[1]*k)).normalized().toAlignedRect() & self.board.rect()
        if r.width() < 24 or r.height() < 24: return
        pix = self.board.grab(r)
        if pix.width() > 900: pix = pix.scaledToWidth(900, Qt.SmoothTransformation)
        folder = os.path.dirname(self.postit_file()); os.makedirs(folder, exist_ok=True)
        name = 'postit-%s.png' % uuid.uuid4().hex[:10]; pix.save(os.path.join(folder, name))
        color = self.POSTIT_COLORS[len(self.pano.cards) % len(self.POSTIT_COLORS)]
        start = QRect(self.board.mapTo(self.centralWidget(), r.topLeft()), r.size())
        card = self.pano.add(pix, color, name, pending=True)
        if self.pano_hidden: self.set_pano_hidden(False)   # a new post-it must land somewhere visible
        self.show_pano()
        self.centralWidget().layout().activate(); self.pano.box.activate(); QApplication.processEvents(); self.pano.ensureWidgetVisible(card)
        end = QRect(card.mapTo(self.centralWidget(), QPoint(0, 0)), card.size())
        self.save_postits(); self.set_tool('pen')
        PostItFlight(self.centralWidget(), pix, color, start, end, card.tilt, lambda: self.postit_landed(card))
    def postit_landed(self, card):
        card.pending = False; card.update()
        play_sound(rapt_sound_file(self.data_dir))
        self.statusBar().showMessage('Post-it panoya yapıştı · dokununca büyür, × ile kaldırılır')
    def remove_postit(self, card):
        self.pano.remove(card); self.save_postits(); self.show_pano()
        try: os.remove(os.path.join(os.path.dirname(self.postit_file()), card.name))
        except OSError: pass
    def show_postit(self, card):
        PostItBig(self.scroll, card.pix, card.color)
    def open_backgrounds(self, anchor=None):
        self.open_folder(self.bg_popup, anchor or self.gear)
    # ---- Çizimleri gizle / iki çözüm: the page keeps a second solution.
    # Tap: the drawings go away (kept) and the page is clean; tap again: back
    # to the first solution; the second one is kept too, so the teacher can
    # switch between the two solutions as often as wanted.
    def saved_marks(self):
        alt, showing = getattr(self, 'alt_ink', {}), getattr(self, 'alt_showing', set())
        if not showing: return self.marks
        out = dict(self.marks)
        for p in showing: out[p] = alt.get(p, [])   # the first solution is always the page's own drawings
        return out
    def second_solutions(self):
        alt, showing = getattr(self, 'alt_ink', {}), getattr(self, 'alt_showing', set())
        out = {}
        for p in alt:
            second = self.marks.get(p, []) if p in showing else alt[p]
            if second: out[str(p)] = second
        return out
    def toggle_hidden_ink(self):
        self.board.finish(); self.board.clear_selection(); p = self.page
        if p not in self.alt_ink and not self.marks.get(p):
            self.statusBar().showMessage('Bu sayfada gizlenecek çizim yok.'); self.sync_hide_button(); return
        cur = self.marks.get(p, []); self.marks[p] = self.alt_ink.get(p, []); self.alt_ink[p] = cur
        self.alt_showing ^= {p}
        if p not in self.alt_showing and not self.alt_ink[p]: del self.alt_ink[p]   # no second solution left: plain page again
        # Geri al works inside one solution; it does not mix the two.
        self.sync_history(); self.undo_stack.clear(); self.redo_stack.clear()
        if p in self.alt_showing:
            self.statusBar().showMessage('İkinci çözüm · temiz sayfada yeniden çözün · tekrar basınca ilk çözüme dönersiniz (bu çözüm de saklanır)')
        else: self.statusBar().showMessage('İlk çözüm' + (' · ikinci çözüm saklandı, düğmeyle geçebilirsiniz' if p in self.alt_ink else ''))
        self.changed(); self.board.update(); self.sync_hide_button()
    def sync_hide_button(self):
        b = getattr(self, 'hide_button', None)
        if b is None: return
        p = self.page; second = p in self.alt_showing
        b.setText('  1. çözümü göster' if second else '  2. çözümü göster' if self.alt_ink.get(p) else '  Çizimleri gizle')
        b.setChecked(second); b.adjustSize(); self.place_overlays()
    def toggle_curtain(self, on=None):
        on = (self.curtain is None) if on is None else on
        if self.curtain is not None: self.curtain.hide(); self.curtain.deleteLater(); self.curtain = None
        if on: self.curtain = Curtain(self); self.place_overlays(); self.curtain.show()
        self.curtain_button.setChecked(on)
        if on: self.statusBar().showMessage('Perde: tutamağı aşağı çektikçe çözüm açılır · ⇅ perdeyi üste alır · × kaldırır')
    def toggle_spot(self, on=None):
        on = (self.spot is None) if on is None else on
        if self.spot is not None: self.spot.hide(); self.spot.deleteLater(); self.spot = None
        if on: self.spot = Spotlight(self); self.place_overlays(); self.spot.show()
        self.spot_button.setChecked(on)
        if on: self.statusBar().showMessage('Spot ışığı: aydınlık kalacak yeri kalemle çerçeveleyin · köşelerden büyütün, “Taşı” ile kaydırın · × kapatır')
    def place_overlays(self):
        sc=self.scroll;vp=sc.viewport().geometry()
        ap=getattr(self,'atlas_panel',None)
        if ap is not None and ap.isVisible(): ap.yerlestir(); ap.raise_()
        for o in (getattr(self,'spot',None),getattr(self,'curtain',None),getattr(self,'exam_screen',None)):
            if o is not None: o.fit(vp); o.raise_()
        self.nav.adjustSize();self.nav.move(vp.x()+10,vp.bottom()-self.nav.height()-10);self.nav.raise_()   # lower left
        fb=getattr(self,'float_bell',None)
        if fb is not None:fb.place();fb.raise_()
        ds=getattr(self,'daily_strip',None)
        if ds is not None:   # Günün soruları: sağ üst; yüzen saat oradaysa onun altında
            top_=vp.y()+12
            if fb is not None and fb.isVisible() and fb.offset is None:top_=fb.geometry().bottom()+10
            ds.move(vp.right()-ds.width()-12,top_);ds.raise_()
        gb=getattr(self,'geo_bar',None)
        if gb is not None and gb.isVisible(): gb.place()
        gp=getattr(self,'geo_panel',None)
        if gp is not None and gp.isVisible(): gp.place()
        hb=getattr(self,'hide_button',None)
        if hb is not None:   # Çizimleri gizle: bottom centre of the board
            hb.adjustSize();hb.move(vp.x()+(vp.width()-hb.width())//2,vp.bottom()-hb.height()-10);hb.raise_()
        if getattr(self,'side_arrows',None):
            show=getattr(self,"doc",None) is not None and len(self.doc)>1 and not self.in_solution()
            # Both on the left edge, one above the other: Sonraki on top, Önceki below.
            left,right=self.side_arrows;y=vp.y()+(vp.height()-2*SIDE_ARROW_H-12)//2
            right.move(vp.x()+8,y);left.move(vp.x()+8,y+SIDE_ARROW_H+12)
            left.setEnabled(self.page>0);right.setEnabled(self.page<len(self.doc)-1)
            for a in self.side_arrows:a.setVisible(show);a.raise_()
        if self.toast.isVisible():
            # bottom right, beside the page controls: the top of the page stays readable
            room=max(240,min(760,vp.width()-self.nav.width()-40))
            self.toast.setFixedWidth(min(room,self.toast.fontMetrics().horizontalAdvance(self.toast.text())+48));self.toast.adjustSize()
            lift=0
            if hb is not None and self.toast.width()+20>vp.right()-hb.geometry().right():lift=hb.height()+10   # keep clear of Çizimleri gizle
            pb_=getattr(self,'preview_btn',None)
            if pb_ is not None and pb_.isVisible():lift=max(lift,pb_.height()+10)   # Sınav yerleri sağ altta
            self.toast.move(vp.right()-self.toast.width()-10,vp.bottom()-self.toast.height()-10-lift);self.toast.raise_()
        pb=getattr(self,'preview_btn',None)
        if pb is not None and pb.isVisible():   # Sınav yerleri: sağ alt köşede (ders sırasında sade)
            pb.adjustSize();pb.move(vp.right()-pb.width()-10,vp.bottom()-pb.height()-10);pb.raise_()
        af=getattr(self,'ara_float',None)
        if af is not None and af.isVisible():   # Nerede sınava gireceğim: en üstte, ortada
            af.adjustSize();af.move(int(vp.center().x()-af.width()/2),vp.y()+12);af.raise_()
        es=getattr(self,'exam_screen',None)
        if es is not None: es.raise_()   # sınav ekranı köşe saatinin de üstünde
        wc=getattr(self,'welcome',None)
        if wc is not None and wc.isVisible(): wc.setGeometry(self.rect()); wc.raise_()
        it=getattr(self,'intro',None)
        if it is not None and not it.done: it.raise_()
    # ---- Ayarlar: which buttons the left panel shows --------------------
    def apply_panel(self,hidden,save=True):
        self.panel_hidden=set(hidden)
        for key,label,widgets in self.panel_items:
            for w_ in widgets:w_.setVisible(key not in self.panel_hidden)
        self.layout_panel()
        if save: self.save_panel()
    # ---- Paneldeki düğmelerin yeri ----
    PANEL_HALF = ('perde', 'spot', 'geri_al', 'ileri_al', 'app:PDF kaydet', 'app:Araçlar', 'ayarlar')   # yan yana sığanlar ('Ekrana yaz' yarım genişlikte kesiliyordu: hep tam satır)
    PANEL_NAMES = {'renkler': 'Renkler', 'kalinlik': 'Kalınlık', 'kalem': 'Kalem uçları', 'tasi': 'Taşı', 'solution': 'Çözüm alanı', 'highlight': 'Fosforlu',
                   'eraser': 'Silgi', 'smart': 'Akıllı seçim', 'sekiller': 'Şekiller', 'postit': 'Post-it', 'perde': 'Perde', 'spot': 'Spot', 'alkis': 'Alkış', 'okul': 'Okul araçları', 'atlas': "Atlas'a sor",
                   'geri_al': 'Geri al', 'ileri_al': 'İleri al', 'app:Ekrana yaz': 'Ekrana yaz', 'app:PDF kaydet': 'Kaydet', 'app:Yazdır': 'Yazdır', 'app:Günün soruları': 'Günün soruları',
                   'app:Araçlar': 'Araçlar', 'ayarlar': 'Ayarlar'}
    def merge_order(self, order):
        known = [k for k in order if k in self.panel_units]
        for i, k in enumerate(self.panel_default):   # sonradan eklenen düğme: varsayılan komşusunun yanına
            if k not in known:
                prev = next((x for x in reversed(self.panel_default[:i]) if x in known), None)
                known.insert(known.index(prev) + 1 if prev else 0, k)
        return known
    def unit_visible(self, k):
        if k == 'ayarlar': return True   # Ayarlar hep görünür
        if k == 'kalem': return 'uclar' not in self.panel_hidden
        return k not in self.panel_hidden
    def panel_layout_rows(self):
        vis = [k for k in self.panel_order if self.unit_visible(k)]; rows = []; i = 0
        while i < len(vis):
            if vis[i] in self.PANEL_HALF and i + 1 < len(vis) and vis[i+1] in self.PANEL_HALF: rows.append(vis[i:i+2]); i += 2
            else: rows.append([vis[i]]); i += 1
        return rows
    def layout_panel(self):
        tools = self.panel_tools
        for row in self.panel_rows:
            lay = row.layout()
            while lay.count():
                w_ = lay.takeAt(0).widget()
                if w_ is not None: w_.setParent(self.panel_host)
            tools.removeWidget(row); row.deleteLater()
        self.panel_rows = []
        for k, w_ in self.panel_units.items():
            if not self.unit_visible(k): w_.setParent(self.panel_host)
        for n, keys in enumerate(self.panel_layout_rows()):
            row = QWidget(); h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(4)
            for k in keys:
                w_ = self.panel_units[k]; h.addWidget(w_, 1); w_.show()
            tools.insertWidget(1 + n, row); self.panel_rows.append(row)
    def move_panel_unit(self, key, way):
        """Seçili düğmeyi panelde yukarı / aşağı / sola / sağa taşır."""
        rows = self.panel_layout_rows(); pos = next(((r, j) for r, ks in enumerate(rows) for j, k in enumerate(ks) if k == key), None)
        if pos is None: return False
        r, j = pos; order = self.panel_order
        if way in ('left', 'right'):
            if len(rows[r]) < 2 or (way == 'left') != (j == 1): return False
            a, b = order.index(rows[r][0]), order.index(rows[r][1]); order[a], order[b] = order[b], order[a]
        elif way == 'up':
            if r == 0: return False
            order.remove(key); order.insert(order.index(rows[r-1][0]), key)
        else:
            if r == len(rows) - 1: return False
            order.remove(key); order.insert(order.index(rows[r+1][-1]) + 1, key)
        self.layout_panel(); self.save_panel(); return True
    def save_panel(self):
        try:
            with open(os.path.join(self.data_dir,'panel.json'),'w',encoding='utf-8') as f:
                json.dump(dict(hidden=sorted(self.panel_hidden), order=self.panel_order, v27=True), f, ensure_ascii=False)
        except OSError as e: self.statusBar().showMessage('Ayarlar kaydedilemedi: '+str(e))
    def open_panel_settings(self):
        PanelSettings(self).exec_()
    def show_toast(self,text):
        if not text:return
        self.toast.setText(text);self.toast.show();self.place_overlays();self.toast_timer.start(4000)
    def eventFilter(self,obj,e):
        if obj is getattr(self,'scroll',None) and e.type() in (QEvent.Resize,QEvent.Show):self.place_overlays()
        return super().eventFilter(obj,e)
    def open_shapes(self):
        self.refresh_colors()   # a tap must not change the button's own state
        self.shape_popup.adjustSize()
        self.shape_popup.move(self.shape_button.mapToGlobal(QPoint(self.shape_button.width()+6,0)))
        self.shape_popup.show()
    def open_folder(self,popup,anchor):
        """Open a button's folder beside the panel, kept on screen."""
        self.refresh_colors();popup.adjustSize()
        screen=(self.windowHandle().screen() if self.windowHandle() else QApplication.primaryScreen()).availableGeometry()
        g=anchor.mapToGlobal(QPoint(anchor.width()+6,0))
        popup.move(max(screen.left(),min(g.x(),screen.right()-popup.width()-8)),max(screen.top()+8,min(g.y(),screen.bottom()-popup.height()-8)))
        if popup is self.erase_popup:self.unselect_button.setVisible(any(m['tool']=='whiteout' for m in self.marks.get(self.page,[])));popup.adjustSize()
        popup.show()
    def pick_shape(self,key):
        self.shape_popup.hide();self.set_tool(key)
    def __init__(self):
        super().__init__()
        self.doc = make_board()
        self.background = 'white'
        self.screen_session = None
        self.solution_origin=None;self.solutions={};self.view_by_undo=False
        self.data_dir=os.path.join(QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation),'umal-tahta')
        self.session_dir=os.path.join(self.data_dir,'son-pdf')
        self.tabs=None   # PDF tabs: [{'id','name','source'}], newest first; each tab has its own autosave folder
        self.session_pdf_pending=False
        self.session_pdf_name=None
        self.alt_ink={};self.alt_showing=set();self.alt_store={}   # Çizimleri gizle: second solution per page
        # PDF Havuzu: eşitleyici her dakika arka planda çalışır.
        self.havuz_timer=QTimer(self);self.havuz_timer.setInterval(60*1000);self.havuz_timer.timeout.connect(self.run_havuz);self.havuz_timer.start()
        QTimer.singleShot(20000,self.run_havuz)
        self.session_timer=QTimer(self);self.session_timer.setSingleShot(True)
        self.session_timer.timeout.connect(self.save_session)
        self.marks, self.undo_stack, self.redo_stack = {}, [], []
        # One ordered history across PDF pages, solution areas, tabs and screen ink:
        # each entry names where the edit happened, so Geri al can go there.
        self.histories = {}; self.history_ctx = None; self.undo_log = []; self.redo_log = []
        self.page, self.zoom, self.tool, self.color = 0, 1, 'pen', PEN_DEFAULT
        self.dirty, self.source = False, ''
        self.resize(1360, 850)
        self.setWindowTitle(PRODUCT)
        self.setWindowIcon(QIcon(LOGO))
        root = QWidget(); self.setCentralWidget(root)
        # Wide writing area: ONE slim top bar (logo, PDF tabs, icon buttons),
        # pen settings in the left panel, page controls floating on the board.
        layout = QVBoxLayout(root); layout.setContentsMargins(4,2,4,4); layout.setSpacing(4)
        top = QHBoxLayout(); top.setSpacing(6); layout.addLayout(top)
        logo = QLabel(); logo.setPixmap(QPixmap(LOGO).scaled(40,40,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        logo.setToolTip(APP_NAME); top.addWidget(logo)
        self.return_pdf=QPushButton('Asıl PDF’ye dön');self.return_pdf.clicked.connect(self.return_to_pdf)
        self.return_pdf.setObjectName('primary');self.return_pdf.setIcon(tool_icon('Tahtaya dön'));self.return_pdf.setIconSize(QSize(22,22))
        self.return_pdf.setFixedHeight(40);top.addWidget(self.return_pdf);self.return_pdf.hide()
        # PDF tabs (kept across restarts): tap to switch, × to remove, + to open.
        self.tab_scroll=QScrollArea();self.tab_scroll.setWidgetResizable(True);self.tab_scroll.setFixedHeight(44)
        self.tab_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.tab_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.tab_scroll.setObjectName('tabs')
        self.tab_holder=QWidget();self.tab_row=QHBoxLayout(self.tab_holder);self.tab_row.setContentsMargins(0,0,0,0);self.tab_row.setSpacing(6)
        self.tab_scroll.setWidget(self.tab_holder);top.addWidget(self.tab_scroll,1)
        self.bell=BellClock(show_time=False);self.bell.sound_dir=self.data_dir;top.addWidget(self.bell);self.bell.hide()   # zil uyarısı (5 dk) burada çalışır; görünen saat tahtanın üstünde yüzer   # saat ve zile kalan süre: üst şeritte, yazma alanında yer kaplamaz
        self.filename = QLabel('Boş tahta · Kalemle yazmaya başlayın',self);self.filename.hide()   # name is on the tab
        body = QHBoxLayout(); body.setSpacing(4); layout.addLayout(body,1)
        tool_panel = QWidget()
        # Panel düğmeleri: ikon solda, adı yanında (iOS ayarlar düzeni)
        tool_panel.setStyleSheet('QPushButton{text-align:left;padding:8px 4px 8px 8px;font-size:15px;} QPushButton[ortala="true"]{text-align:center;padding-left:0;}')
        tools = QVBoxLayout(tool_panel); tools.setContentsMargins(0,0,6,0); tools.setSpacing(5)
        tool_scroll = QScrollArea(); tool_scroll.setWidgetResizable(True)
        tool_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        tool_scroll.setWidget(tool_panel); tool_scroll.setFixedWidth(256)   # room for big colours and a scroll bar
        body.addWidget(tool_scroll); self.tool_scroll = tool_scroll; self.top_logo = logo
        top_row=QHBoxLayout();top_row.setSpacing(4);tools.addLayout(top_row)
        self.button(top_row,'Tam ekran',self.fullscreen)   # first, at the very top
        gear=self.gear=QPushButton('Ayarlar');gear.setIcon(tool_icon('Ayarlar'));gear.setIconSize(QSize(28,28));gear.clicked.connect(self.open_panel_settings)
        gear.setToolTip('Ayarlar: tahta görünümü, paneldeki düğmeler, güncelleme');gear.setAccessibleName('Ayarlar')
        gear.setFixedHeight(42)
        # Renk (7 dots in one row) and Kalınlık at the top of the panel.
        dots=QGridLayout();dots.setSpacing(4);dots.setContentsMargins(0,0,0,0);tools.addLayout(dots)
        self.color_buttons = []
        for color,label in [('#111111','Siyah'),('#e8132b','Kırmızı'),('#0057ff','Mavi'),('#00a24a','Yeşil'),('#8a2be2','Mor'),('#ff2d95','Pembe'),('#ffe14d','Sarı'),('#ffffff','Beyaz')]:
            b = QPushButton(); b.clicked.connect(lambda checked=False,c=color:self.set_color(c)); dots.addWidget(b, len(self.color_buttons)//4, len(self.color_buttons)%4, Qt.AlignCenter)
            b.setToolTip(label); b.setAccessibleName(label); b.setFixedSize(50,50)   # big enough for a fingertip
            b.setStyleSheet('QPushButton{padding:0;min-height:50px;max-height:50px;min-width:50px;max-width:50px;background:'+color+';border:2px solid #8292a8;border-radius:25px;}QPushButton:checked{border:4px solid #ffffff;}')
            b.setCheckable(True); self.color_buttons.append((color,b))
        pen_settings=QHBoxLayout();pen_settings.setSpacing(4);tools.addLayout(pen_settings)
        self.width = QSpinBox(); self.width.setRange(1,16); self.width.setValue(3); self.width.setSuffix(' pt')
        self.width.setButtonSymbols(QSpinBox.NoButtons); self.width.setAlignment(Qt.AlignCenter)
        self.width.setReadOnly(True); self.width.setFixedHeight(42); self.width.setToolTip('Kalınlık')
        self.width.setStyleSheet('QSpinBox{padding:0;}')
        minus=self.button(pen_settings,'−',self.width.stepDown);minus.setFixedSize(48,42);minus.setAccessibleName('Kalemi incelt');minus.setToolTip('Kalemi incelt')
        pen_settings.addWidget(self.width,1)
        plus=self.button(pen_settings,'+',self.width.stepUp);plus.setFixedSize(48,42);plus.setAccessibleName('Kalemi kalınlaştır');plus.setToolTip('Kalemi kalınlaştır')
        for w_ in (minus,plus):w_.setStyleSheet('QPushButton{padding:0;min-height:0;}')
        tools.addSpacing(4)
        self.tool_buttons = {}; self.tool_labels = {}
        # Çizgi, Dikdörtgen, Elips, Kesikli çizgi live in one Şekiller folder:
        # tap it and the four open beside the panel.
        def folder():   # klasör menüleri: panel gibi ikon solda, adı yanında
            w_=QWidget(self,Qt.Popup);l_=QVBoxLayout(w_);l_.setContentsMargins(6,6,6,6);l_.setSpacing(6)
            w_.setStyleSheet('QPushButton{text-align:left;padding-left:12px;}');return w_,l_
        self.shape_popup,shapes=folder()
        # Çözüm alanı: one button, kareli or beyaz inside. Silgi: tap = rub
        # out, and Alan silgisi / Tümünü sil open beside it.
        self.sol_popup,sols=folder();self.erase_popup,ers=folder()
        for key,label in [('pen','Kalem'),('solution','Çözüm alanı'),('select','Alan seç'),('highlight','Fosforlu'),('eraser','Silgi'),('area_eraser','Alan silgisi'),('hand','Taşı'),('smart','Akıllı seçim'),('line','Çizgi'),('arrow','Ok'),('rect','Dikdörtgen'),('circle','Elips'),('triangle','Üçgen'),('dash','Kesikli çizgi')]:
            if key=='line':self.shape_button=self.button(tools,'Şekiller',self.open_shapes);self.shape_button.setCheckable(True)
            if key=='solution':self.solution_button=self.button(tools,'Çözüm alanı',lambda checked=False:self.set_tool('solution'));self.solution_button.setCheckable(True)   # tek dokunuş: kareli çözüm alanı
            if key in SHAPE_TOOLS:
                b=self.button(shapes,label,lambda checked=False,k=key:self.pick_shape(k));b.setMinimumWidth(240)
            elif key in ('solution','select'):
                b=self.button(sols,label,lambda checked=False,k=key:(self.sol_popup.hide(),self.set_tool(k)));b.setMinimumWidth(260)
                b.setText({'solution':'Kareli çözüm alanı','select':'Beyaz çözüm alanı'}[key])
            elif key=='area_eraser':
                b=self.button(ers,label,lambda checked=False:(self.erase_popup.hide(),self.set_tool('area_eraser')));b.setMinimumWidth(260)
            elif key=='eraser':
                b=self.button(tools,label,lambda checked=False:(self.set_tool('eraser'),self.open_folder(self.erase_popup,self.tool_buttons['eraser'])))
            else:b = self.button(tools,label,lambda checked=False,k=key:self.set_tool(k))
            b.setCheckable(True); self.tool_buttons[key] = b; self.tool_labels[key] = label
            if key == 'area_eraser':
                self.clear_button=self.button(ers,'Tümünü sil',lambda checked=False:(self.erase_popup.hide(),self.clear_page()));self.clear_button.setMinimumWidth(260)
                # old "Alan seç" pages may still carry the white cover: removable here
                self.unselect_button=self.button(ers,'Seçimi kaldır',lambda checked=False:(self.erase_popup.hide(),self.remove_selection()));self.unselect_button.setMinimumWidth(260)
        self.tool_buttons['pen'].setChecked(True)
        # Kalem stili: Normal, Tebeşir, Keçeli, Kurşun kalem, Neon.
        # The five pen tips sit on the Kalem row itself (keeps the tool list
        # short enough to fit the board screen without scrolling).
        self.pen_style='fluid';chips=QWidget();row=QHBoxLayout(chips);row.setContentsMargins(0,0,0,0);row.setSpacing(3)
        pen=self.tool_buttons['pen'];tools.removeWidget(pen);pen.setText('');pen.setToolTip('Kalem');pen.setAccessibleName('Kalem')
        pen.setFixedSize(42,42);pen.setIconSize(QSize(26,26));pen.setStyleSheet('padding:0;');pen.hide()   # ayrı Kalem düğmesi yok: uç düğmeleri (Akıcı, Neon…) kalemi de seçer
        self.style_buttons={}
        for key,label in PEN_STYLES:
            short={'fluid':'Akıcı','laser':'Neon'}.get(key,label)
            b=QPushButton('Kalem' if key=='fluid' else short);b.setIcon(tool_icon(short) if short in PREMIUM_ICONS else style_icon(key,18))   # panelde yalnız "Kalem" yazar;b.setIconSize(QSize(24,24));b.setMinimumWidth(21);b.setFixedHeight(42);b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed);b.setCheckable(True)
            b.setToolTip('Kalem' if key=='fluid' else 'Kalem ucu: '+label);b.setAccessibleName('Kalem' if key=='fluid' else 'Kalem ucu: '+label)
            if key=='laser':b.setToolTip('Neon kalem: yazdıklarınız birkaç saniye parlar, sonra kendiliğinden söner (kaydedilmez)')
            b.setStyleSheet('QPushButton{padding:0 0 0 8px;text-align:left;min-height:42px;max-height:42px;min-width:21px;}')
            b.clicked.connect(lambda checked=False,k=key:self.set_pen_style(k));row.addWidget(b);self.style_buttons[key]=b
        self.style_buttons['fluid'].setChecked(True)
        self.style_name=QLabel('Akıcı',self);self.style_name.hide()
        tools.insertWidget(4,chips)
        # Taşı: only the hand symbol, right under the pen row.
        hand=self.tool_buttons['hand'];tools.removeWidget(hand);hand.setText('Taşı');hand.setToolTip('Taşı (sayfayı kaydır)')
        hand.setAccessibleName('Taşı');hand.setIconSize(QSize(28,28));hand.setFixedHeight(42)
        tools.insertWidget(5,hand)
        self.nib = QComboBox(self);self.nib.addItem('Yuvarlak uç','round');self.nib.hide()
        b=self.button(tools,'Post-it',lambda checked=False:self.set_tool('postit'))
        self.tool_buttons['postit']=b;self.tool_labels['postit']='Post-it';b.setCheckable(True)
        b.setToolTip('Post-it: soruyu ve çözümünü çerçeveleyin; küçülüp sağdaki panoya yapışır')
        # Perde (reveal the solution step by step) and Spot ışığı (darken all but one part).
        show_row=QHBoxLayout();show_row.setSpacing(4);tools.addLayout(show_row)
        self.curtain_button=self.button(show_row,'Perde',lambda checked=False:self.toggle_curtain())
        self.spot_button=self.button(show_row,'Spot ışığı',lambda checked=False:self.toggle_spot());self.spot_button.setText('Spot')
        for b_ in (self.curtain_button,self.spot_button):
            b_.setCheckable(True);b_.setMinimumWidth(60);b_.setFixedHeight(42);b_.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        self.curtain_button.setToolTip('Perde: çözümü örter; tutamağı çektikçe adım adım açılır')
        self.spot_button.setToolTip('Spot ışığı: tahta kararır, çerçevelediğiniz yer aydınlık kalır')
        self.curtain=None;self.spot=None
        # Alkış: tahtaya kalkan öğrenciyi onurlandırmak için roketler, konfeti ve alkış sesi.
        self.cheer_button=self.button(tools,'Alkış',lambda checked=False:self.celebrate());self.cheer_button.setFixedHeight(42)
        self.games_button=self.button(tools,'Oyunlar',lambda checked=False:self.open_games());self.games_button.setFixedHeight(42)   # satranç · dama · XOX (iki kişi)
        self.games_button.setToolTip('Oyunlar: satranç, dama, XOX (iki kişi, tam ekran)')
        self.anket_button=self.button(tools,'Anket',lambda checked=False:self.open_anket());self.anket_button.hide()   # panelde yok: Okul araçları içinde
        self.games_button.hide()
        self.okul_button=self.button(tools,'Okul araçları',lambda checked=False:self.open_okul());self.okul_button.setFixedHeight(42)   # Anket · Oyunlar · Rehberlik · Proje seçimi
        # K-350: Atlas panelde tam satır: basınca soru çerçeveye alınır, Atlas çözer
        self.atlas_button=QPushButton("  Atlas'a sor");self.atlas_button.setIcon(QIcon(ATLAS_PNG));self.atlas_button.setIconSize(QSize(30,30))
        self.atlas_button.clicked.connect(lambda checked=False:self.atlas_dugme());self.atlas_button.setFixedHeight(42);tools.addWidget(self.atlas_button)
        self.atlas_button.setStyleSheet('QPushButton{border:1.5px solid #22e8ff;color:#7ff6ff;font-weight:700;}')
        self.atlas_button.setToolTip("Atlas: yazarak sorun ya da tahtadan soru seçin")
        self.cheer_button.setToolTip('Alkış: roketler, konfeti ve alkış sesi (yaklaşık 6 saniye)')
        # Tahta arka planı: a folder like Şekiller.
        # Arka plan and Tema live in Ayarlar now (set once, rarely changed).
        self.bg_button=QPushButton('Arka plan');self.theme_button=QPushButton('Tema')
        self.bg_popup=QWidget(self,Qt.Popup);bgs=QVBoxLayout(self.bg_popup);bgs.setContentsMargins(6,6,6,6);bgs.setSpacing(6)
        self.bg_buttons = {}
        for label,key in BACKGROUNDS:
            b = self.button(bgs,label,lambda checked=False,k=key:(self.bg_popup.hide(),self.set_background(k)))
            b.setCheckable(True); b.setMinimumWidth(240); self.bg_buttons[key]=b
        self.bg_buttons['white'].setChecked(True)
        history=QHBoxLayout();history.setSpacing(4);tools.addLayout(history)
        self.history_buttons=(self.button(history,'Geri al',self.undo),self.button(history,'İleri al',self.redo))
        for b in self.history_buttons:
            b.setMinimumWidth(60);b.setFixedHeight(42);b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        # App buttons right under İleri al: two columns of labelled buttons.
        self.app_buttons=[];apps=QGridLayout();apps.setHorizontalSpacing(4);apps.setVerticalSpacing(tools.spacing());apps.setContentsMargins(0,0,0,0);tools.addLayout(apps)
        self.tools_popup,tl=folder()
        for text,fn in (('Sayaç',self.open_timer),('Hesap makinesi',self.open_calc),('Grafik çizici',self.open_graph),('Şablonlar',self.open_templates),
                        ('Cetvel',lambda:self.toggle_ruler()),('Pergel',lambda:self.set_tool('compass')),('Yazdır',self.open_print)):
            b=self.button(tl,text,lambda checked=False,f_=fn:(self.tools_popup.hide(),f_()));b.setMinimumWidth(260)
        for i,(label,text,fn,name) in enumerate([('Ekrana yaz','Ekrana yaz',self.screen_ink,''),('PDF kaydet','Kaydet',self.save_pdf,'primary'),
                              ('Günün soruları','Günün soruları',self.open_daily,''),
                              ('Araçlar','Araçlar',lambda checked=False:self.open_folder(self.tools_popup,self.tools_button),'')]):
            b=QPushButton(text);b.setObjectName(name);b.setIcon(tool_icon(label));b.setIconSize(QSize(22,22));b.clicked.connect(fn)
            b.setToolTip(label);b.setAccessibleName(label);b.setMinimumWidth(60);b.setFixedHeight(42);b.setIconSize(QSize(26,26))
            b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
            apps.addWidget(b,i//2,i%2);self.app_buttons.append((label,b))
            if label=='Araçlar':self.tools_button=b
        self.apps_grid=apps;apps.setColumnStretch(0,1);apps.setColumnStretch(1,1)   # iki sütun eşit
        tri_b=self.button(shapes,'Ölçülü üçgen',lambda checked=False:(self.shape_popup.hide(),self.open_triangle()));tri_b.setMinimumWidth(240)
        for b_ in tool_panel.findChildren(QPushButton):   # yazısız / tek işaretli düğmeler (renkler, −, +, uçlar, el) ortada kalır
            if len(b_.text().strip()) <= 2: b_.setProperty('ortala', True)
            elif b_ is not self.tool_buttons.get('pen'): b_.setIconSize(QSize(26,26))   # bütün panelde aynı ikon boyu
        gear.setFixedHeight(42);gear.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed);apps.addWidget(gear,9,0,1,2)   # Ayarlar: Araçlar'ın yanına (yerleşim aşağıda)
        self.panel_clock=PanelClock();tools.addWidget(self.panel_clock,1)   # saat ve tarih: the empty space below
        self.panel_items=[('renkler','Renkler',[b for c,b in self.color_buttons]),('kalinlik','Kalınlık',[minus,self.width,plus]),
            ('uclar','Kalem uçları',list(self.style_buttons.values())),('tasi','Taşı (el)',[self.tool_buttons['hand']])]
        self.panel_items+=[('solution','Çözüm alanı',[self.solution_button]),('highlight','Fosforlu',[self.tool_buttons['highlight']]),('eraser','Silgi',[self.tool_buttons['eraser']]),
            ('smart','Akıllı seçim',[self.tool_buttons['smart']]),('sekiller','Şekiller',[self.shape_button]),('postit','Post-it',[self.tool_buttons['postit']]),
            ('perde','Perde',[self.curtain_button]),('spot','Spot ışığı',[self.spot_button]),('alkis','Alkış',[self.cheer_button]),('okul','Okul araçları',[self.okul_button]),
            ('atlas',"Atlas'a sor",[self.atlas_button]),('geri_al','Geri al',[self.history_buttons[0]]),('ileri_al','İleri al',[self.history_buttons[1]])]
        self.panel_items+=[('app:'+label,b.text(),[b]) for label,b in self.app_buttons]
        # Düğmelerin yeri öğretmence değiştirilebilir: panel "birimler"den kurulur (bkz. layout_panel).
        def drain(lay):   # eski yerleşimden çıkar (düğmeler silinmez)
            while lay.count():
                it=lay.takeAt(0)
                if it.layout() is not None: drain(it.layout())
        while tools.count()>2:
            it=tools.takeAt(1)
            if it.layout() is not None: drain(it.layout())
        def holder(lay):
            w=QWidget(); lay.setContentsMargins(0,0,0,0); w.setLayout(lay); return w
        g=QGridLayout(); g.setSpacing(4)
        for i,(c_,b_) in enumerate(self.color_buttons): g.addWidget(b_,i//4,i%4,Qt.AlignCenter)
        h=QHBoxLayout(); h.setSpacing(4); h.addWidget(minus); h.addWidget(self.width,1); h.addWidget(plus)
        self.panel_units={'renkler':holder(g),'kalinlik':holder(h),'kalem':chips,'tasi':self.tool_buttons['hand'],'solution':self.solution_button,
            'highlight':self.tool_buttons['highlight'],'eraser':self.tool_buttons['eraser'],'smart':self.tool_buttons['smart'],'sekiller':self.shape_button,
            'postit':self.tool_buttons['postit'],'perde':self.curtain_button,'spot':self.spot_button,'alkis':self.cheer_button,'okul':self.okul_button,
            'atlas':self.atlas_button,'geri_al':self.history_buttons[0],'ileri_al':self.history_buttons[1]}
        for label,b in self.app_buttons: self.panel_units['app:'+label]=b
        self.panel_units['ayarlar']=gear
        for k in ('tasi','solution','highlight','eraser','smart','sekiller','postit','alkis','okul','atlas'): self.panel_units[k].setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        self.panel_default=list(self.panel_units)   # bugünkü sıra
        self.panel_tools=tools; self.panel_rows=[]; self.panel_host=QWidget(tool_panel); self.panel_host.hide()
        try:
            with open(os.path.join(self.data_dir,'panel.json'),encoding='utf-8') as f:pj=json.load(f)
            hidden=pj.get('hidden',[]); order=pj.get('order',[])
        except (OSError,ValueError,AttributeError):hidden=[];order=[];pj={}
        self.panel_order=self.merge_order(order if isinstance(order,list) else [])
        hidden=set(hidden) if isinstance(hidden,list) else set(); first=not (isinstance(pj,dict) and pj.get('v27'))
        if first: hidden.add('app:PDF kaydet')   # Pro 27: Kaydet varsayılanda gizli; öğretmen Ayarlar'dan geri ekleyebilir (bir kez uygulanır)
        self.apply_panel(hidden,save=first)
        self.scroll = PageScroll(); self.scroll.setAlignment(Qt.AlignCenter); self.scroll.setObjectName('page')   # sayfanın arkası: desen, ışık, gölge
        self.board = Board(self); self.scroll.setWidget(self.board); body.addWidget(self.scroll,1)
        self.board.setAttribute(Qt.WA_OpaquePaintEvent)   # sayfa kendini tam boyar: arka planla birlikte yeniden çizilmez
        self.pano = PostItPano(self); body.addWidget(self.pano); self.pano.hide(); self.pano_dir = None; self.pano_hidden = False
        # Hidden pano leaves this slim tab at the right edge: tap to open again.
        self.pano_tab = QPushButton('0'); self.pano_tab.setIcon(tool_icon('Post-it')); self.pano_tab.setIconSize(QSize(26, 26))
        self.pano_tab.setToolTip('Post-it panosunu aç'); self.pano_tab.setAccessibleName('Post-it panosunu aç')
        self.pano_tab.setFixedSize(52, 120); self.pano_tab.setStyleSheet('QPushButton{padding:0;min-height:120px;max-height:120px;font-size:16px;font-weight:bold;}')
        self.pano_tab.clicked.connect(lambda: self.set_pano_hidden(False))
        tab_col = QVBoxLayout(); tab_col.setContentsMargins(0, 0, 0, 0); tab_col.addWidget(self.pano_tab); tab_col.addStretch(); body.addLayout(tab_col)
        self.pano_tab.hide()
        # Page and zoom controls float in the board's lower right corner.
        self.nav=QWidget(self.scroll);self.nav.setObjectName('nav')
        self.nav.setStyleSheet('QWidget#nav{background:rgba(14,28,50,215);border:1px solid rgba(255,255,255,0.14);border-radius:16px;}'
                               'QWidget#nav QPushButton{padding:0 8px;min-height:36px;max-height:36px;font-size:14px;} QWidget#nav QLabel{background:transparent;font-size:14px;}')
        bottom=QHBoxLayout(self.nav);bottom.setContentsMargins(6,4,6,4);bottom.setSpacing(4)
        prev=self.button(bottom,'Önceki',lambda:self.goto(-1));prev.setText('‹')
        self.page_label = QLabel(); bottom.addWidget(self.page_label)
        nxt=self.button(bottom,'Sonraki',lambda:self.goto(1));nxt.setText('›')
        prev.hide();nxt.hide()   # the big arrows on both sides of the screen turn pages
        self.side_arrows=[]
        for text,delta,name in (('‹',-1,'Önceki sayfa'),('›',1,'Sonraki sayfa')):
            a=QPushButton(text,self.scroll);a.setObjectName('side_arrow');a.setFixedSize(SIDE_ARROW_W,SIDE_ARROW_H);a.setToolTip(name);a.setAccessibleName(name)
            a.setFocusPolicy(Qt.NoFocus);a.clicked.connect(lambda checked=False,d=delta:self.goto(d))
            g_,css_=glyph_style(0xe13a if delta>0 else 0xe138, 40); a.setText(g_)
            a.setStyleSheet('QPushButton#side_arrow{background:rgba(14,28,50,200);color:white;border:1px solid rgba(255,255,255,0.16);border-radius:18px;padding:0;min-height:0;%s}'
                            'QPushButton#side_arrow:pressed{background:rgba(40,110,232,220);}QPushButton#side_arrow:disabled{background:rgba(14,28,50,80);color:rgba(255,255,255,70);border-color:rgba(255,255,255,0.06);}' % css_)
            self.side_arrows.append(a)
        self.button(bottom,'Sayfaya git',self.go_to_page)
        zo=self.button(bottom,'−',lambda:self.set_zoom(self.zoom/1.2))
        self.button(bottom,'Sığdır',self.fit_page)
        zi=self.button(bottom,'+',lambda:self.set_zoom(self.zoom*1.2))
        for b_,c_,n_ in ((zo,0xe32a,'Küçült'),(zi,0xe3d4,'Büyüt')):
            g_,css_=glyph_style(c_,18);b_.setText(g_);b_.setStyleSheet('QPushButton{%s}'%css_);b_.setToolTip(n_);b_.setAccessibleName(n_)
        for b in self.nav.findChildren(QPushButton):
            b.setToolTip(b.accessibleName() or b.text())
            if b.text() in ('−','+'):b.setMinimumWidth(48)
        # Messages appear briefly on the board instead of a status line.
        self.hide_button=QPushButton('  Çizimleri gizle',self.scroll);self.hide_button.setObjectName('hideink');self.hide_button.setCheckable(True)
        self.hide_button.setIcon(tool_icon('Gizle'));self.hide_button.setIconSize(QSize(24,24));self.hide_button.setFocusPolicy(Qt.NoFocus)
        self.hide_button.setToolTip('Bu sayfadaki bütün çizimleri gizler; tekrar basınca geri getirir')
        self.hide_button.setStyleSheet('QPushButton#hideink{background:rgba(14,28,50,215);color:white;border:1px solid rgba(255,255,255,0.14);border-radius:22px;padding:0 22px;min-height:44px;max-height:44px;font-size:16px;font-weight:bold;}'
                                       'QPushButton#hideink:checked{background:#ffc526;color:#122034;border:2px solid #ffffff;}')
        self.hide_button.clicked.connect(lambda checked=False:self.toggle_hidden_ink())
        self.hide_button.adjustSize()
        self.toast=QLabel(self.scroll);self.toast.setObjectName('toast');self.toast.setWordWrap(True);self.toast.setAlignment(Qt.AlignCenter)
        self.toast.setStyleSheet('QLabel#toast{background:rgba(10,32,62,235);color:white;border:1px solid #526780;border-radius:10px;padding:8px 14px;font-size:15px;}')
        self.toast.hide();self.toast_timer=QTimer(self);self.toast_timer.setSingleShot(True);self.toast_timer.timeout.connect(self.toast.hide)
        self.float_bell=None;self.daily_strip=None;self.load_daily();self.daily_strip=DailyStrip(self);self.daily_strip.sync()
        self.float_bell=FloatingBell(self)   # yüzen zil saati (sağ üst)   # Günün soruları: sağ üstte 1, 2, 3…
        self.statusBar().messageChanged.connect(self.show_toast);self.statusBar().hide()

        self.scroll.installEventFilter(self)
        self.scroll.verticalScrollBar().valueChanged.connect(self.scrolled)
        try:
            with open(os.path.join(self.data_dir,'tema.json'),encoding='utf-8') as f:saved=json.load(f).get('theme')
        except (OSError,ValueError,AttributeError):saved=None
        self.apply_theme(saved if saved in THEMES else 'default',save=False)
        for key,fn in [('Ctrl+O',self.open_pdf),('Ctrl+S',self.save_pdf),('Ctrl+Z',self.undo),('Ctrl+Shift+Z',self.redo),('F11',self.fullscreen),('Escape',self.showNormal),('PageDown',lambda:self.goto(1)),('PageUp',lambda:self.goto(-1))]:
            QShortcut(QKeySequence(key),self,activated=fn)
        QTimer.singleShot(0,self.fit_page)
        self.refresh_colors()

    def screen_ink(self):
        self.board.finish()
        if sys.platform!='win32' and QApplication.platformName() != 'xcb':
            QMessageBox.information(self,'Ekrana yaz','Masaüstüne yazma modu X11 oturumu gerektirir. Pardus giriş ekranında X11/Xorg oturumunu seçin. Tahta ve PDF özelliklerini bu oturumda kullanabilirsiniz.')
            return
        try:
            if sys.platform=='win32':compositing=True
            else:
                compositing=x11_compositing_running()
            if not compositing:
                QMessageBox.information(self,'Ekrana yaz','Saydam ekran için masaüstünün birleştirme (compositing) özelliği açık olmalı. Pardus Pencere Yöneticisi Ayarları içinden etkinleştirin.')
                return
        except ImportError:
            QMessageBox.warning(self,'Eksik bileşen','python3-pyqt5.qtx11extras paketini yüklemek için uygulama kurulumunu tamamlayın.')
            return
        if self.screen_session is None: self.screen_session = ScreenSession(self)
        self.screen_session.enter()

    def set_background(self, key):
        if self.background is None: return
        self.board.finish()
        old = self.doc; r=old[0].rect
        self.doc = make_board(key,r.width,r.height); old.close()
        self.background = key
        if key in DARK_BACKGROUNDS and self.color in ('#172b4d','#000000',PEN_DEFAULT): self.color='#ffffff'
        elif key not in DARK_BACKGROUNDS and self.color=='#ffffff': self.color=PEN_DEFAULT
        for k,b in self.bg_buttons.items(): b.setChecked(k==key)
        self.session_pdf_pending=True
        self.changed(); self.render()

    def select_area(self, points):
        """Alan seç: the chosen part opens like Çözüm alanı, on a white,
        endless writing area (inside a solution area it frames as before)."""
        if self.solution_origin is None: self.make_solution(points, 'white')
        else: self.apply_selection(points)
    def page_questions(self):
        """Bu sayfada bulunan sorular (belge ve sayfa başına bir kez hesaplanır)."""
        if getattr(self, 'solution_origin', None) is not None or self.doc is None: return []
        key = (id(self.doc), self.page); c = self.__dict__.setdefault('_q_cache', {})
        if key not in c:
            if len(c) > 400: c.clear()
            try: c[key] = find_questions(self.doc[self.page])
            except Exception as e: print('soru bulma:', e); c[key] = []
        return c[key]
    def solution_tap(self, pt):
        """Çözüm alanı: soruya tek dokunuş → o sorunun kartı açılır. Soru bulunamazsa çerçeve çizmek gerekir."""
        x, y = pt[0], pt[1]
        hit = [r for n, r in self.page_questions() if r.x0 <= x <= r.x1 and r.y0 <= y <= r.y1]
        if not hit:
            self.board.shape_feedback('Burada soru bulunamadı · Soruyu parmağınızla çerçeve içine alın'); return
        r = min(hit, key=lambda q: q.width*q.height)
        self.make_solution([[r.x0, r.y0], [r.x1, r.y1]])
    def make_solution(self, points, bg=None):
        a,b=points;clip=fitz.Rect(min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1]))
        if min(clip.width,clip.height)*self.board.scale<12:return
        if self.solution_origin is not None:
            self.statusBar().showMessage('Yeni bir soru seçmek için önce Asıl PDF’ye dön düğmesini kullanın.');return
        try:
            # The original stays in the autosaved base PDF (written once);
            # only its name and the notes are kept, never a full re-export.
            if not self.save_session():raise ValueError('Otomatik kayıt yapılamadı.')
            # Same question selected again (mostly overlapping frame on the
            # same page): reopen its saved solution instead of a blank one.
            previous=max(((solution_overlap(v['rect'],clip),k) for k,v in self.solutions.items() if v.get('page')==self.page),default=(0,None))
            key=previous[1] if previous[0]>=.5 else '%d:%.1f,%.1f,%.1f,%.1f'%(self.page,*clip)
            if previous[0]>=.5:clip=fitz.Rect(self.solutions[key]['rect'])
            origin=dict(pdf=self.session_pdf_name,marks=copy.deepcopy(self.marks),source=self.source,page=self.page,zoom=self.zoom,dirty=self.dirty,
                        solutions=copy.deepcopy(self.solutions),key=key,rect=list(clip))
            stored=self.solutions.get(key,{}) if previous[0]>=.5 else {}
            origin['bg']=stored.get('bg') or bg or 'grid'   # a reopened question keeps its own background
            # Yeni soru: ekrana göre en büyük kart. Önceki çözüm: kendi kartı (yazılar yerinde kalsın).
            # Çerçevedeki boş kenarlar kesilir (soru daha büyük çıkar); önceki çözüm kendi kırpmasıyla açılır.
            if stored:crop=fitz.Rect(stored.get('crop') or clip)
            else:
                box=content_box(self.doc[self.page],clip,self.marks.get(self.page,[]));pad=max(6,min(box.width,box.height)*.03)
                crop=fitz.Rect(box.x0-pad,box.y0-pad,box.x1+pad,box.y1+pad)&clip
                if crop.is_empty or min(crop.width,crop.height)<8:crop=fitz.Rect(clip)
            vp=self.scroll.viewport();card,fit_zoom=fit_card(crop,vp.width(),vp.height())
            if stored:card=stored.get('card') or legacy_card(clip)
            origin['card']=[float(v) for v in card];origin['crop']=list(crop);self.solution_fit=fit_zoom
            with open(os.path.join(self.session_dir,'soru-kaynagi.json'),'w',encoding='utf-8') as f:
                json.dump(dict({k:origin[k] for k in ('source','page','zoom','dirty','pdf','key','rect','bg','card','crop')},marks={str(k):v for k,v in origin['marks'].items()},
                               solutions={k:dict(v,marks={str(p):m for p,m in v['marks'].items()}) for k,v in origin['solutions'].items()}),f,ensure_ascii=False)
            with tempfile.TemporaryDirectory() as folder:
                single=fitz.open();single.insert_pdf(self.doc,from_page=self.page,to_page=self.page)
                path=os.path.join(folder,'soru.pdf');export_document(single,{0:self.marks.get(self.page,[])},path);single.close()
                rendered=fitz.open(path)
                need=(card[2]-card[0])*fit_zoom/crop.width*1.25   # ekrandaki büyüklükte keskin
                scale=min(max(3,need),6,math.sqrt(6000000/(crop.width*crop.height)))
                pix=rendered[0].get_pixmap(matrix=fitz.Matrix(scale,scale),clip=crop,alpha=False)
                png=pix.tobytes('png');rendered.close()
            cr=fitz.Rect(card);seen=(vp.height()-8)/fit_zoom
            doc=make_board(origin['bg'],960,max(800,cr.y1+16+seen,float(stored.get('height',800))));page=doc[0]
            frame=fitz.Rect(24,20,936,cr.y1+16) if stored and not stored.get('card') else fitz.Rect(cr.x0-24,20,cr.x1+24,cr.y1+16)   # eski çözüm: eski çerçeve
            page.draw_rect(frame,color=(.78,.82,.88),fill=(1,1,1),width=.8)
            page.insert_image(cr,stream=png,keep_proportion=True)
            doc.set_metadata({'title':'Soru ve çözüm — '+APP_NAME,'keywords':'UMAL-solution'})
            self.replace(doc,persist=False);self.solution_origin=origin
            self.return_pdf.show();self.filename.setText('Soru kartı · Altındaki alana çözümünüzü yazın')
            self.set_tool('pen');self.color=PEN_DEFAULT;self.dirty=True
            if key in origin['solutions']:
                self.marks={0:copy.deepcopy(origin['solutions'][key]['marks'].get(0,[]))}
                self.statusBar().showMessage('Bu sorunun önceki çözümü açıldı. Asıl PDF’ye dön ile kitaba dönebilirsiniz.')
            QTimer.singleShot(0,self.solution_zoom);self.session_pdf_pending=True;self.save_session()
        except Exception as e:QMessageBox.warning(self,'Çözüm alanı açılamadı',str(e))

    # ---- Günün soruları -------------------------------------------------
    def daily_dir(self): return os.path.join(self.data_dir, 'gunun-sorulari')
    def load_daily(self):
        try:
            with open(os.path.join(self.daily_dir(), 'liste.json'), encoding='utf-8') as f: d = json.load(f)
        except (OSError, ValueError): d = {}
        self.daily = dict(date=daily_today(), items=[])
        ok = lambda it: all(os.path.isfile(os.path.join(self.daily_dir(), it.get(k) or '')) for k in ('snap', 'qsnap'))
        if d.get('date') == daily_today(): self.daily['items'] = [it for it in d.get('items', []) if ok(it)]
        else: self.clear_daily(save=False)
        self.save_daily()
    def save_daily(self):
        os.makedirs(self.daily_dir(), exist_ok=True)
        try:
            with open(os.path.join(self.daily_dir(), 'liste.json'), 'w', encoding='utf-8') as f: json.dump(self.daily, f, ensure_ascii=False)
        except OSError: pass
        if getattr(self, 'daily_strip', None) is not None: self.daily_strip.sync(); self.place_overlays()
    def clear_daily(self, save=True):
        folder = self.daily_dir()
        if os.path.isdir(folder):
            for n in os.listdir(folder):
                if n.endswith('.pdf'):
                    try: os.remove(os.path.join(folder, n))
                    except OSError: pass
        self.daily = dict(date=daily_today(), items=[])
        if save: self.save_daily(); self.board.update()
    def daily_cfg(self):
        try:
            with open(os.path.join(self.daily_dir(), 'ayar.json'), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {}
    def save_daily_cfg(self, cfg):
        os.makedirs(self.daily_dir(), exist_ok=True)
        try:
            with open(os.path.join(self.daily_dir(), 'ayar.json'), 'w', encoding='utf-8') as f: json.dump(cfg, f, ensure_ascii=False)
        except OSError: pass
    def daily_selected(self): return [it for it in self.daily['items'] if it.get('include', it['done'])]
    def daily_store(self, item, data, crop, kind='snap'):
        os.makedirs(self.daily_dir(), exist_ok=True)
        old = item.get(kind); item[kind] = 'soru-%s.pdf' % uuid.uuid4().hex[:10]; item['qcrop' if kind == 'qsnap' else 'crop'] = crop
        with open(os.path.join(self.daily_dir(), item[kind]), 'wb') as f: f.write(data)
        if old:
            try: os.remove(os.path.join(self.daily_dir(), old))
            except OSError: pass
    def daily_match(self, tab, page, rect):
        best = max(((solution_overlap(it['rect'], list(rect)), i) for i, it in enumerate(self.daily['items']) if it['tab'] == tab and it['page'] == page), default=(0, None))
        return best[1] if best[0] >= .5 else None
    def daily_current(self):
        o = self.solution_origin
        return None if o is None else self.daily_match(self.current_tab(), o['page'], o['rect'])
    def add_planned(self, pts):
        """Soru seç: dersin başında seçilen soru listeye (sırayla) eklenir."""
        if self.solution_origin is not None: self.show_toast('Soru seçmek için önce Asıl PDF’ye dönün.'); return
        a, b = pts; clip = fitz.Rect(min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1]))
        if min(clip.width, clip.height)*self.board.scale < 12: return
        if self.daily_match(self.current_tab(), self.page, clip) is not None: self.show_toast('Bu soru zaten listede.'); return
        if self.daily.get('date') != daily_today(): self.clear_daily(save=False)
        try: data, crop, qcrop = question_card(self.doc, self.page, self.marks.get(self.page, []), clip)
        except Exception as e: QMessageBox.warning(self, 'Soru eklenemedi', str(e)); return
        it = dict(tab=self.current_tab(), source=self.source, page=self.page, rect=list(clip), done=False)
        self.daily_store(it, data, crop); self.daily_store(it, data, qcrop, 'qsnap'); self.daily['items'].append(it); self.save_daily(); self.board.update()
        self.show_toast('%d. soru listede. Sıradakini çerçeveleyin; bitince başka bir araç seçin.' % len(self.daily['items']))
    def daily_solved(self, origin, written):
        """Çözüm alanından çıkarken: soru listedeyse çözümü eklenir, değilse sona eklenir."""
        if self.daily.get('date') != daily_today(): self.clear_daily(save=False)
        tab = self.current_tab(); i = self.daily_match(tab, origin['page'], origin['rect'])
        if i is None and not written: return
        base = os.path.join(self.session_dir, origin['pdf']) if origin.get('pdf') else None
        src = fitz.open(base) if base and os.path.isfile(base) else fitz.open(stream=origin['data'], filetype='pdf')
        pm = origin['marks'].get(origin['page'], [])
        try:
            data, crop, _ = question_card(src, origin['page'], pm, origin.get('crop') or origin['rect'], written, origin.get('card'))
            blank = question_card(src, origin['page'], pm, origin['rect']) if i is None or not self.daily['items'][i].get('qsnap') else None
        finally: src.close()
        if i is None:
            it = dict(tab=tab, source=origin.get('source', ''), page=origin['page'], rect=list(origin['rect']), done=True)
            self.daily['items'].append(it)
        else:
            it = self.daily['items'][i]; it['done'] = bool(written)
            if written: it['include'] = True
        self.daily_store(it, data, crop)
        if blank: self.daily_store(it, blank[0], blank[2], 'qsnap')
        self.save_daily()
    def daily_open(self, i):
        it = self.daily['items'][i]
        if self.solution_origin is not None:
            if self.daily_current() == i: return
            self.return_to_pdf()
        if it['tab'] != self.current_tab():
            if any(t['id'] == it['tab'] for t in self.tabs or []): self.switch_tab(it['tab'])
            elif it.get('source') and os.path.isfile(it['source']): self.open_pdf_path(it['source']); it['tab'] = self.current_tab(); self.save_daily()
            else: self.show_toast('Bu sorunun PDF’si tahtada açık değil.'); return
        if it['page'] >= len(self.doc): return
        self.goto(it['page'] - self.page); r = it['rect']; self.make_solution([[r[0], r[1]], [r[2], r[3]]]); self.daily_strip.update()
    def write_daily(self, target, topic, teacher):
        build_daily_pdf(self.daily_selected(), self.daily_dir(), daily_date_text(), topic, teacher, target)
    def send_daily(self, topic, teacher):
        if self.solution_origin is not None: self.return_to_pdf()
        os.makedirs(GUNUN_DIR, exist_ok=True)
        safe = ''.join(c for c in topic if c not in '\\/:*?"<>|').strip()
        base = daily_today() + (' ' + safe if safe else ''); name = base + '.pdf'; k = 2
        while os.path.exists(os.path.join(GUNUN_DIR, name)): name = '%s (%d).pdf' % (base, k); k += 1
        tmp = os.path.join(GUNUN_DIR, '.' + name + '.yeni'); self.write_daily(tmp, topic, teacher); os.replace(tmp, os.path.join(GUNUN_DIR, name))
        self.clear_daily(); self.run_havuz('--simdi')
        return name
    def celebrate(self):
        self.board.finish()
        if getattr(self, 'celebration', None) is None: self.celebration = Celebration(self)
        self.celebration.start()
        try: play_sound(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sesler', 'alkis.wav'), 1.0)   # tam ses
        except Exception: pass
    def toggle_ruler(self, on=None):
        if getattr(self, 'ruler', None) is None: self.ruler = Ruler(self)
        on = not self.ruler.isVisible() if on is None else on
        if on: self.ruler.place(); self.ruler.show(); self.ruler.raise_(); self.statusBar().showMessage('Cetvel: gövdesinden sürükleyin, sağ uçtaki tutamakla döndürün; kenarına yakın çizdiğiniz çizgi dümdüz olur. Sol uçtaki × kaldırır.')
        else: self.ruler.hide()
        if on and self.tool not in ('pen', 'dash', 'highlight'): self.set_tool('pen')
    def geo_action(self, key):
        b = self.board; m = b.geo_model(); b.finish()
        if key == 'nokta': self.set_tool('pen' if self.tool == 'geo' else 'geo'); return
        if key == 'gir': self.set_tool('geo'); GeoInput(self).exec_(); return
        if key == 'gizle':
            self.geo_hide = not getattr(self, 'geo_hide', False); self.geo_bar.sync()
            self.statusBar().showMessage('Yeni sonuçlar “?” olarak gelir; açmak için sonuç kutusuna dokunun.' if self.geo_hide else 'Yeni sonuçlar açık gösterilir.'); return
        if key == 'temizle':
            if m is None: return
            self.checkpoint(); self.marks[self.page] = [s for s in self.marks.get(self.page, []) if s is not m]; b.geo_sel = []; self.changed(); b.update(); self.geo_bar.sync(); self.geo_panel_sync(); return
        if m is None: self.statusBar().showMessage('Önce “Nokta koy” ile ızgaraya dokunarak nokta koyun.'); return
        b.geo_valid_sel(m); sel = b.geo_sel; pts = [i for t, i in sel if t == 'p']; lns = [i for t, i in sel if t == 'o']
        if key == 'sil':
            if not sel: self.statusBar().showMessage('Silmek için bir nokta ya da doğru seçin.'); return
            self.checkpoint(); gone_p = set(pts); gone_o = set(lns)
            for k, o in enumerate(m['O']):   # silinenlere bağlı sonuçlar da gider
                refs_p = [o[x] for x in ('a', 'b', 'p') if x in o]; refs_o = [o[x] for x in ('l', 'm') if x in o]
                if any(r in gone_p for r in refs_p) or any(r in gone_o for r in refs_o): gone_o.add(k)
            pmap = {}; newP = []
            for i, q in enumerate(m['P']):
                if i not in gone_p: pmap[i] = len(newP); newP.append(q)
            omap = {}; newO = []
            for k, o in enumerate(m['O']):
                if k in gone_o: continue
                o = dict(o)
                for x in ('a', 'b', 'p'):
                    if x in o: o[x] = pmap[o[x]]
                for x in ('l', 'm'):
                    if x in o: o[x] = omap[o[x]]
                omap[k] = len(newO); newO.append(o)
            m['P'], m['O'] = newP, newO; b.geo_sel = []; b.geo_touch(m); return
        need = {'dist': 'iki nokta', 'line': 'iki nokta', 'slope': 'iki nokta', 'mid': 'iki nokta', 'par': 'bir doğru ve bir nokta', 'perp': 'bir doğru ve bir nokta', 'cut': 'iki doğru'}[key]
        if key in ('dist', 'line', 'slope', 'mid') and len(pts) == 2: o = dict(t=key, a=pts[0], b=pts[1])
        elif key in ('par', 'perp') and len(pts) == 1 and len(lns) == 1: o = dict(t=key, l=lns[0], p=pts[0])
        elif key == 'cut' and len(lns) == 2: o = dict(t=key, l=lns[0], m=lns[1])
        else: self.statusBar().showMessage('Bunun için %s seçin (dokunarak).' % need); return
        if any({k_: v for k_, v in q.items() if k_ != 'h'} == o for q in m['O']): self.statusBar().showMessage('Bu zaten tahtada.'); return
        if getattr(self, 'geo_hide', False): o['h'] = True
        self.checkpoint(); m['O'].append(o); b.geo_touch(m)
    def geo_after_history(self):
        if getattr(self, 'geo_bar', None) is not None and self.geo_bar.isVisible():
            self.board.geo_valid_sel(self.board.geo_model()); self.geo_bar.sync(); self.geo_panel_sync()
    def geo_reveal(self, k):
        m = self.board.geo_model()
        if m is not None and k < len(m['O']): m['O'][k]['h'] = False; self.board.geo_touch(m)
    def geo_panel_sync(self):
        gb = getattr(self, 'geo_bar', None); on = gb is not None and gb.isVisible()
        m = self.board.geo_model() if on else None
        if getattr(self, 'geo_panel', None) is None:
            if m is None or not m['O']: return
            self.geo_panel = GeoPanel(self)
        if m is None or not self.geo_panel.fill(m): self.geo_panel.hide(); return
        self.geo_panel.show(); self.geo_panel.place()
    def geo_sync_bar(self):
        """Araç çubuğu yalnızca koordinat düzlemi sekmesinde."""
        try: on = (self.doc.metadata.get('keywords') or '') == 'UMAL-template:koordinat'
        except Exception: on = False
        if getattr(self, 'geo_bar', None) is None:
            if not on: return
            self.geo_bar = GeoBar(self)
        if on:
            self.board.geo_valid_sel(self.board.geo_model()); self.geo_bar.sync(); self.geo_bar.show(); self.geo_bar.place()
        else:
            self.geo_bar.hide()
            if self.tool == 'geo': self.set_tool('pen')
        self.geo_panel_sync()
    def open_graph(self):
        self.board.finish(); GraphDialog(self).exec_()
    def open_templates(self):
        self.board.finish(); TemplateDialog(self).exec_()
    def open_triangle(self):
        self.board.finish(); TriangleDialog(self).exec_()
    def start_pen_meter(self):
        self.board.finish(); self.pen_meter = PenMeter(self); self.pen_meter.start()
    def open_daily(self):
        self.board.finish(); DailyDialog(self).exec_(); self.daily_strip.sync()

    def return_to_pdf(self):
        if self.solution_origin is None:return
        self.board.finish();self.view_by_undo=False
        # No save prompt: the solution is kept with the book automatically.
        origin=self.solution_origin
        solutions=origin.setdefault('solutions',{});key=origin.get('key')
        written=copy.deepcopy(self.marks.get(0,[]))
        changed=False
        if key:
            old=solutions.get(key,{}).get('marks',{}).get(0,[])
            changed=written!=old
            if written:solutions[key]=dict(page=origin['page'],rect=origin['rect'],marks={0:written},height=self.doc[0].rect.height,bg=origin.get('bg','grid'),
                                           **{k:origin[k] for k in ('card','crop') if origin.get(k)})
            else:solutions.pop(key,None)
        try:self.daily_solved(origin,written)   # Günün soruları
        except Exception as e:self.statusBar().showMessage('Günün sorularına eklenemedi: %s'%e)
        base=os.path.join(self.session_dir,origin['pdf']) if origin.get('pdf') else None
        if base:
            try:doc=fitz.open(base)
            except Exception as e:QMessageBox.warning(self,'Asıl PDF açılamadı',str(e));return
        else:doc=fitz.open(stream=origin['data'],filetype='pdf')
        self.replace(doc,origin['source'],persist=False)
        self.marks=origin['marks'];self.page=origin['page'];self.dirty=origin['dirty'] or changed
        self.solutions=solutions
        if changed:self.setWindowTitle(PRODUCT+' • Kaydedilmemiş değişiklikler')
        self.solution_origin=None;self.return_pdf.hide();self.set_tool('pen');self.set_zoom(origin['zoom'])
        if base:self.session_pdf_name=origin['pdf'];self.session_pdf_pending=False
        else:self.session_pdf_pending=True
        self.save_session()

    def button(self, layout, label, fn, name=''):
        b = QPushButton(label); b.setObjectName(name); b.setIcon(tool_icon(label)); b.setIconSize(QSize(28,28)); b.clicked.connect(fn); layout.addWidget(b); return b
    def tool_hint(self, text):
        """Araç ipucu yalnızca ilk birkaç seçimde çıkar (sonra sayfanın köşesini kapatmasın)."""
        path = os.path.join(self.data_dir, 'ipuclari.json')
        if not hasattr(self, 'hints_seen'):
            try:
                with open(path, encoding='utf-8') as f: self.hints_seen = json.load(f)
            except (OSError, ValueError): self.hints_seen = {}
        n = self.hints_seen.get(text[:40], 0)
        if n >= 3: return
        self.hints_seen[text[:40]] = n + 1
        try:
            with open(path, 'w', encoding='utf-8') as f: json.dump(self.hints_seen, f, ensure_ascii=False)
        except OSError: pass
        self.statusBar().showMessage(text)
    def set_tool(self, tool):
        self.board.finish()
        if tool!='smart':self.board.clear_selection()
        self.tool = tool
        if tool=='highlight':self.color='#ffc526'
        for k,b in self.tool_buttons.items(): b.setChecked(k == tool)
        self.refresh_colors(); self.sync_tips()
        self.board.setCursor(Qt.OpenHandCursor if tool == 'hand' else Qt.CrossCursor)
        if tool == 'select': self.tool_hint('Görünmesini istediğiniz alanı sürükleyerek seçin. Dışı beyaz olur; ardından kalemle yazabilirsiniz.')
        if tool == 'smart': self.tool_hint('Yazılarınızı çerçeve içine alın. İçinden sürükleyerek taşıyın; köşelerinden büyütün veya küçültün.')
        if tool == 'solution':
            self.tool_hint('Soruya dokunun ya da çerçeve içine alın: üstte soru kartı, altında geniş çözüm alanı açılacak.' if self.page_questions() else 'Soruyu çerçeve içine alın: üstte soru kartı, altında geniş çözüm alanı açılacak.')
            self.board.update()
        if getattr(self,'daily_strip',None) is not None: self.daily_strip.sync(); self.place_overlays()
        if getattr(self, 'geo_bar', None) is not None and self.geo_bar.isVisible(): self.geo_bar.sync()
        if tool == 'geo': self.tool_hint('Koordinat düzlemi: ızgaraya dokunun, nokta konur. Noktaya dokunmak seçer, sürüklemek taşır. İki nokta seçince Mesafe, Doğru, Eğim, Orta nokta; bir doğru ve bir nokta seçince Paralel, Dik.')
        if tool == 'compass': self.tool_hint('Pergel: merkeze dokunun, açıklığı sürükleyin, kalemi kaldırmadan çevirin; yay ya da daire çizilir.')
        if tool == 'triangle': self.tool_hint('Üçgen: köşeden köşeye sürükleyin. Ölçülü üçgen için Şekiller → Ölçülü üçgen.')
        if tool == 'place_tri': self.statusBar().showMessage(getattr(self, 'pending_hint', None) or 'Üçgeni koymak istediğiniz yere dokunun.'); self.pending_hint = None
        if tool == 'pick': self.tool_hint('Soru seç: günün sorularını sırayla çerçeveleyin. Bitince başka bir araç seçin.')
        if tool == 'postit': self.tool_hint('Post-it: soruyu ve çözümünü çerçeve içine alın; kalemi kaldırınca sağdaki panoya yapışır.')
        if tool == 'atlas': self.statusBar().showMessage("Atlas: soruyu çerçeve içine alın; kalemi kaldırınca Atlas çözer. Vazgeçmek için boş bir yere dokunun.")
        if tool == 'laser': self.tool_hint('Neon kalem: yazdıklarınız parlar; yazmayı bırakınca 3 saniye sonra kendiliğinden söner. Kaydedilmez.')
        if tool == 'area_eraser': self.tool_hint('Alan silgisi: silmek istediğiniz yazıları çerçeve içine alın (ya da yazıya dokunun); kalemi kaldırınca silinir. Geri al ile geri getirebilirsiniz.')
        if tool == 'arrow': self.tool_hint('Ok: başladığınız yerden kalemi kaldırdığınız yere doğru ok çizilir (kuvvet, yön, vektör).')
        if tool == 'dash': self.tool_hint('Kesikli çizgi: kalem gibi yazın. Düz çizgi, dikdörtgen veya elips çizip 1 saniye beklerseniz kesikli şekle dönüşür.')
        if tool == 'pen': self.tool_hint('Şekil çizin ve 1 saniye bekleyin; kalemi kaldırabilirsiniz. Çizgi, üçgen, dikdörtgen veya elips düzeltilir.')
    def apply_selection(self, points):
        a,b = points
        x0,x1 = sorted((a[0],b[0])); y0,y1 = sorted((a[1],b[1]))
        if min(x1-x0,y1-y0)*self.board.scale < 6: return
        page = self.doc[self.page].rect
        self.checkpoint()
        marks = [s for s in self.marks.get(self.page,[]) if s['tool'] != 'whiteout']
        for l,t,r,b in [(0,0,page.width,y0),(0,y1,page.width,page.height),(0,y0,x0,y1),(x1,y0,page.width,y1)]:
            if r>l and b>t:
                marks.append(dict(tool='whiteout',color='#ffffff',width=1,points=[[l,t],[r,b]]))
        self.marks[self.page] = marks
        self.changed()
        self.set_tool('pen')
        self.statusBar().showMessage('Seçilen alan kaldı. Beyaz alana da yazabilirsiniz. Geri al veya Seçimi kaldır ile tüm sayfayı gösterin.')
    def remove_selection(self):
        marks = self.marks.get(self.page,[])
        if any(s['tool']=='whiteout' for s in marks):
            self.checkpoint()
            self.marks[self.page] = [s for s in marks if s['tool'] != 'whiteout']
            self.changed(); self.board.update()
    def set_pen_style(self, key):
        if key == 'laser': self.set_tool('laser'); return   # Neon kalem is a tool of its own
        self.pen_style = key
        name = dict(PEN_STYLES)[key]; self.style_name.setText(name)
        if self.tool != 'pen': self.set_tool('pen')
        self.sync_tips(); self.statusBar().showMessage('Kalem stili: %s' % name)
    def sync_tips(self):
        """Tips row: Neon lit while the Neon kalem is in use, else the pen style."""
        if not hasattr(self, 'style_buttons'): return
        on = 'laser' if self.tool == 'laser' else (self.pen_style if self.tool == 'pen' else None)
        for k, b in self.style_buttons.items(): b.setChecked(k == on)
    def set_color(self, color):
        self.color = color
        if self.tool not in COLOR_TOOLS: self.set_tool('pen')
        self.statusBar().showMessage('Kalem rengi seçildi. Kalınlık: %s pt' % self.width.value())
    def current_ctx(self):
        tab = os.path.basename(self.session_dir)
        if self.solution_origin is not None and self.solution_origin.get('key'): return ('sol', tab, self.solution_origin['key'])
        return ('doc', tab)
    def sync_history(self):
        """Keep a separate undo/redo stack per place (document, solution area)."""
        ctx = self.current_ctx()
        if ctx == self.history_ctx: return
        if self.history_ctx is not None: self.histories[self.history_ctx] = (self.undo_stack, self.redo_stack)
        self.undo_stack, self.redo_stack = self.histories.get(ctx, ([], []))
        self.history_ctx = ctx
    def checkpoint(self):
        self.view_by_undo = False   # a new edit: Geri al may leave this view again
        self.sync_history()
        self.undo_stack.append(snapshot_marks(self.marks, self.undo_stack[-1] if self.undo_stack else None)); self.undo_stack = self.undo_stack[-80:]; self.redo_stack.clear()
        self.undo_log.append(self.current_ctx()); self.undo_log = self.undo_log[-400:]; self.redo_log.clear()
    def changed(self):
        # Notes are autosaved as JSON; the base PDF is rewritten only when
        # the document itself changes (new document or board background).
        self.dirty = True; self.setWindowTitle(PRODUCT+' • Kaydedilmemiş değişiklikler')
        self.session_timer.start(1200)

    def save_session(self):
        self.session_timer.stop()
        try:
            os.makedirs(self.session_dir,mode=0o700,exist_ok=True)
            pdf_path=os.path.join(self.session_dir,self.session_pdf_name or 'belge.pdf')
            if self.session_pdf_pending or not os.path.isfile(pdf_path):
                # The clean base PDF is written once per document; notes go
                # to the small JSON below, so large textbooks never re-save
                # on every stroke (that froze the UI for many seconds).
                name='belge-'+uuid.uuid4().hex+'.pdf';pdf_path=os.path.join(self.session_dir,name)
                fd,tmp_pdf=tempfile.mkstemp(dir=self.session_dir,suffix='.pdf');os.close(fd)
                try:
                    self.doc.save(tmp_pdf,garbage=1);os.replace(tmp_pdf,pdf_path)
                finally:
                    if os.path.exists(tmp_pdf):os.unlink(tmp_pdf)
            else:name=self.session_pdf_name or 'belge.pdf'
            meta=dict(source=self.source,page=self.page,zoom=self.zoom,dirty=self.dirty,pdf=name,
                      marks={str(k):v for k,v in self.saved_marks().items()},ikinci_cozum=self.second_solutions(),
                      solutions={k:dict(v,marks={str(p):m for p,m in v['marks'].items()}) for k,v in self.solutions.items()})
            def write_meta(path,data):
                fd,tmp=tempfile.mkstemp(dir=self.session_dir,suffix='.json')
                try:
                    with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
                    os.replace(tmp,path)
                finally:
                    if os.path.exists(tmp):os.unlink(tmp)
            meta_path=os.path.join(self.session_dir,'durum.json');old=None
            if os.path.isfile(meta_path):
                try:
                    with open(meta_path,encoding='utf-8') as f:old=json.load(f)
                    if old.get('pdf','belge.pdf')!=name:write_meta(os.path.join(self.session_dir,'yedek.json'),old)
                except (ValueError,OSError):pass
            fd,tmp=tempfile.mkstemp(dir=self.session_dir,suffix='.json')
            try:
                with os.fdopen(fd,'w',encoding='utf-8') as f:
                    json.dump(meta,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
                os.replace(tmp,os.path.join(self.session_dir,'durum.json'))
            finally:
                if os.path.exists(tmp):os.unlink(tmp)
            self.session_pdf_name=name;self.session_pdf_pending=False
            keep={name}
            if self.solution_origin and self.solution_origin.get('pdf'):keep.add(self.solution_origin['pdf'])
            try:
                with open(os.path.join(self.session_dir,'yedek.json'),encoding='utf-8') as f:keep.add(json.load(f).get('pdf','belge.pdf'))
            except (OSError,ValueError):pass
            for candidate in os.listdir(self.session_dir):
                if candidate.startswith('belge-') and candidate.endswith('.pdf') and candidate not in keep:
                    try:os.unlink(os.path.join(self.session_dir,candidate))
                    except OSError:pass
            return True
        except Exception as e:
            self.statusBar().showMessage('Otomatik kayıt yapılamadı. PDF kaydet düğmesini kullanın: '+str(e))
            return False

    def restore_session(self):
        meta_path=os.path.join(self.session_dir,'durum.json')
        if not os.path.isfile(meta_path):return False
        doc=None
        try:
            for candidate in ['durum.json','yedek.json']:
                try:
                    with open(os.path.join(self.session_dir,candidate),encoding='utf-8') as f:meta=json.load(f)
                    pdf_path=os.path.join(self.session_dir,os.path.basename(meta.get('pdf','belge.pdf')))
                    doc=fitz.open(pdf_path)
                    if doc.page_count and not doc.needs_pass:break
                    doc.close();doc=None
                except Exception:doc=None
            if doc is None:raise ValueError('Son kayıt ve yedek açılamadı.')
            if not doc.page_count or doc.needs_pass:raise ValueError('Kayıtlı belge okunamadı.')
            self.replace(doc,str(meta.get('source') or ''),persist=False)
            if 'marks' in meta:self.marks=load_marks(meta['marks'])
            self.alt_ink=load_marks(meta.get('ikinci_cozum'));self.alt_showing=set();self.sync_hide_button()
            if 'solutions' in meta:self.solutions={k:dict(v,marks=load_marks(v.get('marks'))) for k,v in meta['solutions'].items()}
            self.page=max(0,min(len(doc)-1,int(meta.get('page',0))))
            self.set_zoom(float(meta.get('zoom',1)))
            self.dirty=bool(meta.get('dirty',False));self.session_pdf_pending=False
            self.session_pdf_name=os.path.basename(meta.get('pdf','belge.pdf'))
            if self.doc.metadata.get('keywords')=='UMAL-solution':
                try:
                    with open(os.path.join(self.session_dir,'soru-kaynagi.json'),encoding='utf-8') as f:origin=json.load(f)
                    if origin.get('pdf'):
                        if not os.path.isfile(os.path.join(self.session_dir,os.path.basename(origin['pdf']))):raise ValueError
                        origin['pdf']=os.path.basename(origin['pdf']);origin['marks']=load_marks(origin.get('marks'))
                        origin['solutions']={k:dict(v,marks=load_marks(v.get('marks'))) for k,v in (origin.get('solutions') or {}).items()}
                    else:
                        original=fitz.open(os.path.join(self.session_dir,'soru-kaynagi.pdf'))
                        origin['marks']=recover_marks(original);origin['data']=original.tobytes();original.close()
                    self.solution_origin=origin;self.return_pdf.show()
                except Exception:pass
            self.statusBar().showMessage('Cihazdaki son PDF açıldı · Sayfa %s · Notlarınız korundu' % (self.page+1))
            return True
        except Exception as e:
            if doc is not None and doc is not self.doc:doc.close()
            self.statusBar().showMessage('Son çalışma açılamadı; PDF aç ile dosyanızı seçebilirsiniz. '+str(e))
            return False
    def undo(self):
        # Geri al always removes the last thing written (also in Çözüm alanı,
        # Alan seç and Akıllı seçim); Asıl PDF'ye dön leaves those views.
        r_ = self.step_history(self.undo_log, self.redo_log, True); QTimer.singleShot(0, self.geo_after_history); return r_
    def leave_view(self):
        """Geri al in a solution area, an Alan seç frame or an Akıllı seçim
        first returns to the plain PDF in one tap, without a question; what
        was written stays. The next taps undo as usual."""
        b = self.board; tab = os.path.basename(self.session_dir)
        if self.solution_origin is not None and not self.view_by_undo:
            o = self.solution_origin; self.redo_log.append(('view', tab, 'sol', (o['page'], list(o['rect']))))
            b.finish(); self.return_to_pdf()
            self.statusBar().showMessage('Asıl PDF’ye dönüldü · Çözüm alanındaki yazılar kayıtlı'); return True
        if b.selection_page == self.page and b.selected:
            self.redo_log.append(('view', tab, 'smart', (self.page, list(b.selected))))
            b.clear_selection(); self.statusBar().showMessage('Seçim kapatıldı · Yazılar yerinde'); return True
        if any(m['tool'] == 'whiteout' for m in self.marks.get(self.page, [])) and self.solution_origin is None:
            frame = [copy.deepcopy(m) for m in self.marks[self.page] if m['tool'] == 'whiteout']
            b.finish(); self.strip_frame(self.page); b.update()
            self.redo_log.append(('view', tab, 'frame', (self.page, frame)))
            self.statusBar().showMessage('Asıl PDF görünümüne dönüldü · Yazılar yerinde'); return True
        return False
    def strip_frame(self, page):
        """Remove the Alan seç frame of a page from the notes and from their
        history, so later Geri al taps never bring the frame back."""
        self.sync_history()
        strip = lambda m: {p: [x for x in v if not (p == page and x['tool'] == 'whiteout')] for p, v in m.items()}
        self.marks = strip(self.marks)
        for stack in (self.undo_stack, self.redo_stack):
            out = []
            for m in map(strip, stack):
                if not out or out[-1] != m: out.append(m)   # steps that only moved the frame vanish
            if stack is self.undo_stack and out and out[-1] == self.marks: out.pop()
            stack[:] = out
        self.changed()
    def redo(self):
        # İleri al right after a one-tap return: back to the screen that was left.
        if self.redo_log and self.redo_log[-1][0] == 'view': return self.back_to_view(self.redo_log.pop())
        r_ = self.step_history(self.redo_log, self.undo_log, False); QTimer.singleShot(0, self.geo_after_history); return r_
    def back_to_view(self, record):
        _, tab, kind, (page, data) = record
        self.board.finish()
        if tab != os.path.basename(self.session_dir):
            if not (self.tabs and any(t['id'] == tab for t in self.tabs)): return False
            self.switch_tab(tab)
        if self.solution_origin is not None: self.return_to_pdf()
        if page >= len(self.doc): return False
        self.page = page; self.render()
        if kind == 'sol':
            self.make_solution([[data[0], data[1]], [data[2], data[3]]]); self.view_by_undo = False
        elif kind == 'frame':
            self.marks[page] = [m for m in self.marks.get(page, []) if m['tool'] != 'whiteout'] + data
            self.changed(); self.set_tool('pen')
        elif kind == 'smart':
            n = len(self.marks.get(page, []))
            self.set_tool('smart'); self.board.selection_page = page; self.board.selected = [i for i in data if i < n]
        self.board.update(); self.statusBar().showMessage('Önceki ekrana dönüldü')
        return True
    def step_history(self, log, other, undo):
        """Undo/redo the most recent edit wherever it was made, and show it."""
        self.board.finish();self.board.clear_selection()
        while log:
            ctx = log.pop()
            if ctx[0] == 'view':
                if not undo and self.back_to_view(ctx): return True
                continue
            if ctx == ('screen',):
                s = self.screen_session
                stack = s.undo_stack if (s and undo) else (s.redo_stack if s else [])
                if not stack: continue
                self.screen_ink()
                (s.undo if undo else s.redo)(record=False); other.append(ctx); return True
            if not self.go_to_ctx(ctx): continue
            self.sync_history()
            stack, back = (self.undo_stack, self.redo_stack) if undo else (self.redo_stack, self.undo_stack)
            if not stack: continue
            before = self.marks; back.append(snapshot_marks(self.marks, back[-1] if back else None)); self.marks = live_marks(stack.pop())
            other.append(ctx); self.changed(); self.show_change(before, self.marks); return True
        self.statusBar().showMessage('Geri alınacak düzenleme yok.' if undo else 'İleri alınacak düzenleme yok.')
        return False
    def show_change(self, before, after):
        pages = sorted(p for p in set(before) | set(after) if before.get(p, []) != after.get(p, []))
        if pages and self.page not in pages and pages[0] < len(self.doc):
            self.page = pages[0]; self.render()
        self.board.update()
    def go_to_ctx(self, ctx):
        tab = ctx[1]
        known = tab == os.path.basename(self.session_dir) or (self.tabs is not None and any(t['id'] == tab for t in self.tabs))
        if not known: return False
        if ctx == self.current_ctx(): return True
        if self.solution_origin is not None and ctx[0] == 'doc' and tab == os.path.basename(self.session_dir):
            self.return_to_pdf(); return ctx == self.current_ctx()
        if tab != os.path.basename(self.session_dir): self.switch_tab(tab)
        if self.solution_origin is not None and ctx != self.current_ctx(): self.return_to_pdf()
        if ctx[0] == 'sol':
            sol = self.solutions.get(ctx[2])
            if not sol:   # emptied solution: its page and frame are in the key
                try:
                    page, rect = ctx[2].split(':'); sol = dict(page=int(page), rect=[float(v) for v in rect.split(',')])
                except ValueError: return False
            self.page = int(sol['page']); self.render(); r = sol['rect']
            self.make_solution([[r[0], r[1]], [r[2], r[3]]])
            self.view_by_undo = True   # opened by Geri al itself: keep undoing here
        return ctx == self.current_ctx()
    def confirm_leave(self):
        if not self.dirty: return True
        answer = QMessageBox.question(self,'Kaydedilmemiş notlar','Notlarınızı PDF olarak kaydetmek ister misiniz?',QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
        if answer == QMessageBox.Save: return self.save_pdf()
        return answer == QMessageBox.Discard
    def replace(self, doc, source='',persist=True):
        # Second solutions belong to this document: park them (first solutions shown).
        if self.alt_ink or self.alt_showing:
            for p in list(self.alt_showing):
                self.marks[p], self.alt_ink[p] = self.alt_ink.get(p, []), self.marks.get(p, [])
            self.alt_store[(self.session_dir, self.source)] = {p: m for p, m in self.alt_ink.items() if m}
        self.alt_ink, self.alt_showing = {}, set()
        self.sync_history()
        if self.history_ctx is not None: self.histories[self.history_ctx] = (self.undo_stack, self.redo_stack)
        self.history_ctx = None
        self.session_timer.stop()
        self.board.clear_selection()
        self.solution_origin=None;self.return_pdf.hide()
        old = self.doc
        marks = recover_marks(doc)
        self.solutions = read_solutions(doc)
        self.doc, self.marks, self.source = doc, marks, source
        keywords = doc.metadata.get('keywords') or ''
        key = keywords[len('UMAL-board:'):] if keywords.startswith('UMAL-board:') else ''
        self.background = key if key in dict((v,k) for k,v in BACKGROUNDS) and len(doc)==1 else None
        for k,b in self.bg_buttons.items(): b.setEnabled(self.background is not None); b.setChecked(k==self.background)
        self.bg_button.setEnabled(self.background is not None)   # backgrounds are for boards, not PDFs
        if self.background in DARK_BACKGROUNDS: self.color='#ffffff'
        elif self.color=='#ffffff': self.color=PEN_DEFAULT
        old.close()
        self.page = 0; self.undo_stack, self.redo_stack = [], []; self.dirty = False
        self.alt_ink = self.alt_store.pop((self.session_dir, source), {}); self.sync_hide_button()
        self.setWindowTitle(PRODUCT); self.filename.setText(os.path.basename(source) if source else 'Boş tahta · Kalemle yazmaya başlayın')
        self.fit_page()
        self.session_pdf_pending=True
        if persist:self.save_session()
    def open_pdf(self):
        # Work is autosaved per tab, so opening another PDF never asks to save.
        self.board.finish()
        path,_ = QFileDialog.getOpenFileName(self,'PDF aç','','Belgeler (*.pdf *.pptx *.ppt *.ppsx *.pps *.odp *.docx *.doc *.odt *.rtf);;PDF (*.pdf);;PowerPoint (*.pptx *.ppt *.ppsx *.pps *.odp);;Word (*.docx *.doc *.odt *.rtf)')
        if not path: return
        self.open_pdf_path(path)
    def open_pdf_path(self, path):
        self.board.finish()
        if os.path.splitext(path)[1].lower() in OFFICE_EXTS:   # PowerPoint / Word: önce PDF'e çevrilir, sonra her şey PDF gibi
            try: path, title = office_to_pdf(self, path)
            except Exception as e: QMessageBox.warning(self, 'Belge açılamadı', str(e)); return
        else: title = None
        if self.tabs is None: self.init_tabs(restore=False)
        same=next((t for t in self.tabs if t.get('source') and os.path.realpath(t['source'])==os.path.realpath(path)),None)
        if same:
            self.switch_tab(same['id']); self.statusBar().showMessage('Bu PDF zaten açık; sekmesine geçildi.'); return
        doc = None
        try:
            doc = fitz.open(path)
            if doc.needs_pass:
                pw,ok = QInputDialog.getText(self,'Şifreli PDF','PDF şifresi:',2)
                if not ok: doc.close(); return
                if not doc.authenticate(pw): raise ValueError('PDF şifresi doğru değil.')
            if not doc.page_count: raise ValueError('Bu PDF’de sayfa yok.')
            self.start_tab(title or os.path.splitext(os.path.basename(path))[0],path)
            self.replace(doc,path);self.tabs_changed()
        except Exception as e:
            if doc and doc is not self.doc: doc.close()
            QMessageBox.warning(self,'PDF açılamadı',str(e))
    def new_board(self):
        self.board.finish()
        self.start_tab('Boş tahta')
        self.replace(make_board(self.background or 'white', 960, BLANK_H));self.tabs_changed()   # iki ekran boyu: ilk uzatmada ekran yeniden çizilmez
        # A new blank board must not inherit Hand, Eraser, or Selection mode
        # from a PDF. Start with visible round ink, ready to write immediately.
        self.set_tool('pen');self.nib.setCurrentIndex(0)
        self.color='#ffffff' if self.background in DARK_BACKGROUNDS else PEN_DEFAULT
        self.width.setValue(3)
        self.statusBar().showMessage('Boş tahta hazır · PDF açmadan yazabilirsiniz · Yuvarlak kalem, 3 pt')
    # ---- PDF tabs -------------------------------------------------------
    def tabs_file(self): return os.path.join(self.data_dir,'sekmeler.json')
    def current_tab(self): return os.path.basename(self.session_dir)
    def load_tabs(self):
        try:
            with open(self.tabs_file(),encoding='utf-8') as f:data=json.load(f)
            tabs=[t for t in data.get('tabs',[]) if t.get('id') and os.sep not in t['id'] and os.path.isfile(os.path.join(self.data_dir,t['id'],'durum.json'))]
            active=data.get('active')
        except (OSError,ValueError,AttributeError):tabs,active=[],None
        if not tabs and os.path.isfile(os.path.join(self.data_dir,'son-pdf','durum.json')):
            # earlier versions kept only the last PDF here: it becomes the first tab
            try:
                with open(os.path.join(self.data_dir,'son-pdf','durum.json'),encoding='utf-8') as f:src=json.load(f).get('source') or ''
            except (OSError,ValueError):src=''
            tabs=[dict(id='son-pdf',name=os.path.splitext(os.path.basename(src))[0] if src else 'Boş tahta',source=src)];active='son-pdf'
        self.tabs=tabs
        return active
    def write_tabs(self):
        try:
            os.makedirs(self.data_dir,exist_ok=True)
            fd,tmp=tempfile.mkstemp(dir=self.data_dir,suffix='.json')
            with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(dict(tabs=self.tabs,active=self.current_tab()),f,ensure_ascii=False)
            os.replace(tmp,self.tabs_file())
        except OSError as e:self.statusBar().showMessage('Sekmeler kaydedilemedi: '+str(e))
    def init_tabs(self,restore=True):
        active=self.load_tabs()
        if restore and self.tabs:
            tab=next((t for t in self.tabs if t['id']==active),self.tabs[0])
            self.session_dir=os.path.join(self.data_dir,tab['id']);self.session_pdf_name=None
            if not self.restore_session():
                self.tabs=[t for t in self.tabs if t['id']!=tab['id']]
        if not self.tabs and (restore or self.source or any(self.marks.values())):
            # keep the current board/PDF as the first tab
            name=os.path.splitext(os.path.basename(self.source))[0] if self.source else 'Boş tahta'
            self.tabs=[dict(id=self.new_tab_folder(),name=name,source=self.source)]
            self.session_dir=os.path.join(self.data_dir,self.tabs[0]['id']);self.session_pdf_name=None;self.session_pdf_pending=True
            self.save_session()
        self.tabs_changed()
    def new_tab_folder(self):
        tid='sekme-'+uuid.uuid4().hex[:12];os.makedirs(os.path.join(self.data_dir,tid),mode=0o700,exist_ok=True);return tid
    def start_tab(self,name,source=''):
        """Save the current tab, then route autosave to a new tab placed first."""
        if self.tabs is None:self.init_tabs(restore=False)
        if self.tabs:self.save_session()
        tid=self.new_tab_folder()
        self.session_dir=os.path.join(self.data_dir,tid);self.session_pdf_name=None;self.session_pdf_pending=True
        self.tabs.insert(0,dict(id=tid,name=name,source=source))
    def switch_tab(self,tid):
        if tid==self.current_tab():self.tabs_changed();return
        self.board.finish();self.save_session()
        previous=self.session_dir
        self.session_dir=os.path.join(self.data_dir,tid);self.session_pdf_name=None
        if not self.restore_session():
            self.session_dir=previous
            QMessageBox.warning(self,'Sekme açılamadı','Bu sekmenin kaydı okunamadı. Sekmeyi kapatıp PDF’yi yeniden açabilirsiniz.')
        self.tabs_changed()
    def close_tab(self,tid):
        tab=next((t for t in self.tabs if t['id']==tid),None)
        if tab is None:return
        if QMessageBox.question(self,'Sekmeyi kapat','“%s” listeden kaldırılsın mı?\n\nBu PDF’nin tahtadaki kopyası ve üzerine yazdığınız notlar silinir. Bilgisayardaki asıl dosya silinmez.' % tab['name'],
                                QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        index=self.tabs.index(tab)
        if tid==self.current_tab():
            rest=[t for t in self.tabs if t['id']!=tid]
            if rest:self.switch_tab(rest[min(index,len(rest)-1)]['id'])
            else:
                self.start_tab('Boş tahta');self.replace(make_board(self.background or 'white', 960, BLANK_H))
        self.tabs=[t for t in self.tabs if t['id']!=tid]
        self.undo_log=[c for c in self.undo_log if c==('screen',) or c[1]!=tid]; self.redo_log=[c for c in self.redo_log if c==('screen',) or c[1]!=tid]
        self.histories={k:v for k,v in self.histories.items() if k[1]!=tid}
        folder=os.path.realpath(os.path.join(self.data_dir,tid))
        if os.path.dirname(folder)==os.path.realpath(self.data_dir) and folder!=os.path.realpath(self.session_dir):
            shutil.rmtree(folder,ignore_errors=True)
        self.tabs_changed()
    def open_new_menu(self, anchor):
        from PyQt5.QtWidgets import QMenu
        m=QMenu(self);m.setStyleSheet('QMenu{font-size:17px;padding:6px;} QMenu::item{padding:14px 36px 14px 18px;}')
        m.addAction(tool_icon('PDF aç'),'PDF aç',self.open_pdf);m.addAction(tool_icon('Yeni tahta'),'Boş tahta',self.new_board)
        m.exec_(anchor.mapToGlobal(QPoint(0,anchor.height()+4)))
    def tabs_changed(self):
        if self.tabs is not None: self.write_tabs()
        while self.tab_row.count():
            item=self.tab_row.takeAt(0)
            if item.widget():item.widget().deleteLater()
        current=self.current_tab()
        for t in (self.tabs or []):   # + Yeni and Havuz are always there, even before the tabs load
            name=t['name'] if len(t['name'])<=26 else t['name'][:24]+'…'
            b=QPushButton(name);b.setObjectName('tab');b.setCheckable(True);b.setChecked(t['id']==current);b.setToolTip(t.get('source') or t['name'])
            b.clicked.connect(lambda checked=False,tid=t['id']:self.switch_tab(tid))
            x=QPushButton('×');x.setObjectName('tabclose');x.setCheckable(True);x.setChecked(t['id']==current);x.setFixedSize(40,40);x.setToolTip('Sekmeyi kapat')
            x.clicked.connect(lambda checked=False,tid=t['id']:self.close_tab(tid))
            pair=QWidget();h=QHBoxLayout(pair);h.setContentsMargins(0,0,0,0);h.setSpacing(0);b.setFixedHeight(40);h.addWidget(b);h.addWidget(x)
            self.tab_row.addWidget(pair)
        plus=QPushButton('+ Yeni');plus.setObjectName('primary');plus.setFixedHeight(40);plus.setToolTip('PDF aç ya da boş tahta');plus.clicked.connect(lambda checked=False,b_=plus:self.open_new_menu(b_))
        self.tab_row.addWidget(plus)
        # PDF Havuzu sits with the PDFs in the top bar (not in the left panel).
        pool=QPushButton();pool.setObjectName('havuz_tab');pool.setAccessibleName('PDF Havuzu');pool.setIcon(havuz_icon(30));pool.setIconSize(QSize(47,30));pool.setFixedWidth(72)
        pool.setFixedHeight(40);pool.setToolTip('PDF Havuzu: bütün tahtalarda ortak PDF\'ler');pool.clicked.connect(self.open_havuz)
        self.tab_row.addWidget(pool);self.tab_row.addStretch()
    def save_pdf(self):
        self.board.finish()
        suggested = os.path.splitext(self.source)[0]+'-notlu.pdf' if self.source else 'Tahta-notlari.pdf'
        if self.source and os.path.realpath(os.path.dirname(self.source)) == os.path.realpath(HAVUZ_DIR):
            # Notlu kopya havuza düşerse bütün tahtalara giderdi: kişisel klasöre öner.
            suggested = os.path.join(os.path.expanduser('~'), os.path.basename(suggested))
        target,_ = QFileDialog.getSaveFileName(self,'Notlu PDF’yi kaydet',suggested,'PDF dosyaları (*.pdf)')
        if not target: return False
        if not target.lower().endswith('.pdf'): target += '.pdf'
        if self.source and os.path.realpath(target) == os.path.realpath(self.source):
            QMessageBox.information(self,'Farklı ad seçin','Orijinal PDF’yi korumak için farklı bir dosya adı seçin.'); return False
        try:
            export_document(self.doc,self.marks,target,None if self.solution_origin else self.solutions)
            self.dirty = False; self.setWindowTitle(PRODUCT); self.statusBar().showMessage('Kaydedildi: '+target)
            return True
        except Exception as e:
            QMessageBox.warning(self,'PDF kaydedilemedi',str(e)); return False
    def clear_page(self):
        if not self.marks.get(self.page): return
        if QMessageBox.question(self,'Tümünü sil','Bu sayfaya eklediğiniz bütün notlar silinsin mi?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No) == QMessageBox.Yes:
            self.checkpoint(); self.marks[self.page] = []; self.changed(); self.board.update()
    def goto(self, delta):
        self.board.finish();self.board.clear_selection()
        if delta and getattr(self,'curtain',None) is not None: self.toggle_curtain(False)   # a new page starts uncovered
        self.page = max(0,min(len(self.doc)-1,self.page+delta)); self.render(); self.sync_hide_button()
        self.save_session()
    def set_zoom(self, value):
        self.board.finish(); self.zoom = max(.15,min(8,value)); self.render()
    def theme_tile(self,key):
        folder=os.path.join(self.data_dir,'temalar');os.makedirs(folder,exist_ok=True)
        path=os.path.join(folder,key+'-v3.png')
        return path if os.path.isfile(path) else make_theme_tile(key,path)
    def apply_theme(self,key,save=True):
        self.theme=key
        try:tile=self.theme_tile(key)
        except Exception:tile=''
        self.setStyleSheet(theme_style(THEMES[key],tile))
        # pattern applied on the page backdrop itself (a global selector does not reach it)
        self.scroll.set_theme(THEMES[key]['view'],THEMES[key]['sel'],tile)
        if hasattr(self,'tool_buttons'):self.refresh_colors()
        if save:
            try:
                with open(os.path.join(self.data_dir,'tema.json'),'w',encoding='utf-8') as f:json.dump(dict(theme=key),f)
            except OSError:pass
            self.statusBar().showMessage('Tema: '+THEMES[key]['name'])
    def open_theme_picker(self, anchor=None):
        picker=ThemePicker(self);picker.adjustSize()
        # Open beside the panel (like Şekiller) and keep it fully on screen:
        # under the button it ran off the bottom of the board.
        screen=(self.windowHandle().screen() if self.windowHandle() else QApplication.primaryScreen()).availableGeometry()
        anchor=anchor or self.gear
        g=anchor.mapToGlobal(QPoint(anchor.width()+6,0))
        x=min(g.x(),screen.right()-picker.width()-8)
        y=max(screen.top()+8,min(g.y(),screen.bottom()-picker.height()-8))
        picker.move(max(screen.left(),x),y);picker.show()
    # ---- Yönetim ----
    def board_info_path(self): return os.path.join(self.data_dir, 'tahta.json')
    def board_info(self):
        try:
            with open(self.board_info_path(), encoding='utf-8') as f: d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError): return {}
    def save_board_info(self, d):
        try:
            with open(self.board_info_path(), 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)
        except OSError: pass
    def ask_class(self, force=False):
        info = self.board_info()
        if info.get('sinif') and not force: return
        if getattr(self, 'screen_session', None) and getattr(self.screen_session, 'active', False): QTimer.singleShot(60000, self.ask_class); return
        d = ClassDialog(self, info.get('sinif', ''))
        if d.exec_() and d.value:
            info['sinif'] = d.value; self.save_board_info(info); self.statusBar().showMessage('Bu tahta: ' + d.value)
            QTimer.singleShot(500, self.send_state)
    def start_state_reports(self):
        self.app_started = time.time(); self.version_cached = installed_version()
        try: self.live_meter = LiveMeter(self)
        except Exception as ex: print('canlı ölçüm:', ex); self.live_meter = None
        self.state_timer = QTimer(self); self.state_timer.timeout.connect(self.send_state); self.state_timer.start(120000)
        QTimer.singleShot(20000, self.send_state)
    def send_state(self):
        """İki dakikada bir: sınıf, sürüm, açık/kullanımda, bugünkü kullanım, son hata. Kişisel veri ve içerik yok."""
        now = time.time(); info = self.board_info(); today = time.strftime('%Y-%m-%d')
        touched = now - getattr(self, 'last_touch', 0) < 150
        use = info.get('kullanim', {})
        if use.get('gun') != today: use = {'gun': today, 'dk': 0}
        last = getattr(self, 'state_last', None)
        if touched and last: use['dk'] = use.get('dk', 0) + min(5, (now - last)/60)
        self.state_last = now; info['kullanim'] = use; self.save_board_info(info)
        err = {}
        try:
            with open(os.path.join(self.data_dir, 'hata-kaydi.txt'), encoding='utf-8', errors='replace') as f: lines = f.read().splitlines()
            stamps = [i for i, l in enumerate(lines) if l.startswith('### ')]
            day = [i for i in stamps if lines[i][4:14] == today]
            if stamps:
                i = stamps[-1]; tail = [l for l in lines[i+1:i+60] if l.strip()]
                err = dict(zaman=lines[i][4:23], ozet=hata_ozet(tail), bugun=len(day))
        except OSError: pass
        pen = {}
        try:
            pp_ = os.path.join(self.data_dir, 'kalem-olcum.json')
            with open(pp_, encoding='utf-8') as f: pm = json.load(f)
            pen = {k: pm.get(k) for k in ('hz', 'cizim_95', 'bekleme_max', 'surum')}
            pen['zaman'] = round(os.path.getmtime(pp_))   # testin yapıldığı an (DersMap eski testi bugünkü gibi göstermesin)
        except (OSError, ValueError): pass
        state = dict(ofis=bool(office_binary()), sinif=info.get('sinif', ''), surum=getattr(self, 'version_cached', '') or installed_version(), simdi=now, acilis=getattr(self, 'app_started', now),
                     son_dokunma=getattr(self, 'last_touch', 0), kullaniyor=touched, bugun_dk=round(use.get('dk', 0)), hata=err, kalem=pen, mesaj=info.get('mesaj', {}), kurulu=installed_version(),
                     kalem_canli=self.live_meter.summary() if getattr(self, 'live_meter', None) else {}, yazicilar=info.get('yazicilar', {}),
                     ders_simdi=self.lesson_state(info.get('sinif', '')),
                     ekran='%dx%d' % (self.screen().size().width(), self.screen().size().height()) if self.screen() else '')
        path = os.path.join(self.data_dir, 'yonetim-durum.json')
        try:
            with open(path, 'w', encoding='utf-8') as f: json.dump(state, f, ensure_ascii=False)
        except OSError: return
        if getattr(self, 'live_meter', None): self.live_meter.save()   # gün içinde kapanıp açılsa da birikir
        self.run_havuz('--durum', path)
    # ---- Yönetim mesajları (panelden, imzalı) ----
    def start_messages(self):
        self.msg_out = os.path.join(self.data_dir, 'yonetim-mesajlar.json'); self.msg_mtime = -1; self.msgs_all = []; self.msgs = []; self.msg_index = 0
        self.msg_bar = MessageBar(self); self.centralWidget().layout().insertWidget(1, self.msg_bar); self.msg_bar.hide()
        self.msg_timer = QTimer(self); self.msg_timer.timeout.connect(self.poll_messages); self.msg_timer.start(20000)   # K-341: acil mesaj en geç 20 sn
        self.msg_load_timer = QTimer(self); self.msg_load_timer.timeout.connect(self.load_messages); self.msg_load_timer.start(5000)
        self.update_ready = ''; self.update_snooze = 0
        QTimer.singleShot(15000, self.poll_messages); self.load_messages()
        self.version_timer = QTimer(self); self.version_timer.timeout.connect(self.check_installed); self.version_timer.start(60000)
        self.exam_screen = None; self.exam_hidden = None; self.kelebek = None; self.preview_open = False
        self.lesson_timer = QTimer(self); self.lesson_timer.timeout.connect(self.lesson_tick); self.lesson_timer.start(20000)
        self.preview_btn = QPushButton('  Sınav yerleri', self.scroll); self.preview_btn.setIcon(tool_icon('Sayaç')); self.preview_btn.setIconSize(QSize(26, 26))
        self.preview_btn.setFocusPolicy(Qt.NoFocus); self.preview_btn.setMinimumHeight(52); self.preview_btn.hide(); self.preview_btn.clicked.connect(self.open_preview)
        self.preview_btn.setStyleSheet('QPushButton{background:#13233a;color:white;border:1px solid #2f6fd6;border-radius:14px;padding:0 18px;font-size:18px;font-weight:600;}')
        self.ara_float = neon_button(self.scroll, self.open_ara, 21); self.ara_float.hide()
        self.kelebek_timer = QTimer(self); self.kelebek_timer.timeout.connect(self.kelebek_tick); self.kelebek_timer.start(120000); QTimer.singleShot(2000, self.kelebek_tick)
        self.exam_timer = QTimer(self); self.exam_timer.timeout.connect(self.exam_tick); self.exam_timer.start(1000); QTimer.singleShot(0, self.exam_tick)
        self.exam_timer.timeout.connect(self.acil_ust)   # K-341: sınav / anket ekranından sonra: acil mesaj hep en üstte
        self.watch_screens()
    # ---- Çözünürlük değişince (bazı tahtalarda kendiliğinden değişiyor) pencereler yeni ekrana oturur ----
    def watch_screens(self):
        self._refit_timer = QTimer(self); self._refit_timer.setSingleShot(True); self._refit_timer.timeout.connect(self.refit_screen)
        app = QApplication.instance()
        def hook(s):
            for sig in (s.geometryChanged, s.availableGeometryChanged): sig.connect(lambda *_: self._refit_timer.start(600))
        for s in app.screens(): hook(s)
        app.screenAdded.connect(lambda s: (hook(s), self._refit_timer.start(600)))
        app.screenRemoved.connect(lambda *_: self._refit_timer.start(600))
        app.primaryScreenChanged.connect(lambda *_: self._refit_timer.start(600))
        self._screen_check = QTimer(self); self._screen_check.timeout.connect(self.check_screen); self._screen_check.start(4000)   # sinyal gelmeyen sürücüler için
    def cur_screen(self):
        try: return (self.windowHandle().screen() if self.windowHandle() else None) or QApplication.primaryScreen()
        except Exception: return QApplication.primaryScreen()
    def check_screen(self):
        if self.isMinimized() or getattr(self.board, 'active', None) is not None: return   # yazarken hiç çalışmaz
        g = self.cur_screen().geometry()
        try: self.clamp_windows(g); self.fit_tools()
        except Exception as e: print('ekran:', e)
        if not self.isFullScreen(): return
        m = self.geometry()
        if m == g or self._refit_timer.isActive(): return
        key = (g.getRect(), m.getRect())   # aynı uyumsuzluk için bir kez dener (pencere yöneticisi izin vermiyorsa durmadan titremesin)
        if key == getattr(self, '_refit_key', None): return
        self._refit_key = key; self._refit_timer.start(0)
    def refit_screen(self):
        """Ana pencere ve açık tam ekran pencereler ekranın yeni boyunu bütünüyle kaplar; diğer pencereler ekranın içine çekilir."""
        scr = self.cur_screen(); g = scr.geometry()
        def full(w):
            if w.geometry() == g: return
            w.showNormal(); w.setGeometry(g); w.showFullScreen()
        if self.isFullScreen() and not self.isMinimized(): full(self)
        self.clamp_windows(g, full)
        QTimer.singleShot(0, self.place_overlays); QTimer.singleShot(200, self.place_overlays); QTimer.singleShot(300, self.fit_tools)
        try: QTimer.singleShot(250, self.fit_page)
        except Exception: pass
    def fit_tools(self):
        """Tam ekran araç ekranları (oyunlar, proje, rastgele, anket) ana pencereyle aynı boyda kalsın."""
        for n in ('games', 'proje_screen', 'rastgele_screen', 'anket_screen', 'anket_canli'):
            w = getattr(self, n, None)
            if w is not None and w.isVisible() and w.geometry() != self.rect(): w.fit(self.rect())
    def clamp_windows(self, g, full=None):
        """Açık pencereler ekrandan taşmasın (küçük çözünürlükte düğmeler dışarıda kalmasın)."""
        for w in QApplication.topLevelWidgets():
            if w is self or not w.isVisible() or w.isMinimized(): continue
            try:
                if getattr(w, '_fit_main', None) is not None:
                    if full is not None or w.geometry() != g: fit_screen(w, self)
                    continue
                if w.isFullScreen():
                    if full is not None: full(w)
                    continue
                if full is None and not isinstance(w, QDialog): continue   # düzenli denetimde yalnız pencereler (açılır menü/küçük sayaç kendi yerinde)
                if w.windowType() in (Qt.ToolTip, Qt.Popup): continue
                r = w.frameGeometry(); ww = min(r.width(), g.width()); hh = min(r.height(), g.height())
                if (ww, hh) != (r.width(), r.height()): w.resize(max(100, ww - (r.width() - w.width())), max(80, hh - (r.height() - w.height())))
                x = max(g.left(), min(r.x(), g.right() + 1 - ww)); y = max(g.top(), min(r.y(), g.bottom() + 1 - hh))
                if (x, y) != (r.x(), r.y()): w.move(x, y)
            except RuntimeError: pass
    # ---- Karşılama: açılışta ve her dersin başında --------------------
    def welcome_info(self):
        import datetime
        now = self.exam_clock(); sinif = self.board_info().get('sinif', ''); d = lesson_now(sinif, now)
        ust = '%d %s %s' % (now.day, TR_MONTHS[now.month-1], TR_DAYS[now.weekday()])
        if d.get('durum') == 'ders':
            ust = '%s  ·  %s – %s  ·  %s' % (d['saat'].upper(), d.get('bas', ''), d.get('bit', ''), TR_DAYS[now.weekday()])
            names = d.get('ogretmen') or []
            given = lambda n: ' '.join(w for w in n.split() if not (w.isupper() and len(w) > 1)) or n
            baslik = ('Hoş geldiniz, %s Hocam' % given(names[0])) if len(names) == 1 else 'Hoş geldiniz Hocam'
            return dict(ust=ust, baslik=baslik, alt='%s  ·  %s' % (sinif, d.get('ders', '')) if sinif else d.get('ders', ''))
        return dict(ust=ust, baslik='Hoş geldiniz', alt=sinif)
    def show_welcome(self):
        if getattr(self, 'karargah', None) is not None and self.karargah.isVisible(): return   # sınav sırasında Öğretmenler odası yoklama ekranında kalır
        es = getattr(self, 'exam_screen', None)
        if es is not None and es.st and es.st.get('phase') != 'preview': return   # sınavda sayaç öncelikli
        if es is not None:   # sınav yerleri önizlemesi açıksa kapanır (teneffüste yine kendiliğinden gelir)
            self.preview_open = False; self.exam_hidden = es.st['key']; self.exam_tick()
        if self.screen_session and getattr(self.screen_session, 'active', False): return
        if self.isMinimized() or not self.isVisible(): self.showFullScreen()
        self.raise_(); self.activateWindow(); self.board.finish()
        if getattr(self, 'welcome', None) is None: self.welcome = WelcomeCard(self)
        self.welcome.set_info(self.welcome_info()); self.welcome.setGeometry(self.rect()); self.welcome.show(); self.welcome.raise_()
        self.welcome_key = self.lesson_key()   # bu ders için soruldu
        QTimer.singleShot(300, lambda: self.welcome is not None and self.welcome.isVisible() and (self.welcome.setGeometry(self.rect()), self.welcome.raise_()))   # tam ekrana geçince boyut
    def hide_welcome(self):
        if getattr(self, 'welcome', None) is not None: self.welcome.hide()
    def welcome_go(self, fn):
        """Seçim yapılınca: seçilen ekran hazırlanır, okulun logosu açılır ve o ekrana açılır."""
        self.hide_welcome()
        try: fn()
        finally: QTimer.singleShot(60, self.play_intro)
    def welcome_blank(self): self.welcome_go(self.new_board)
    def welcome_pdf(self):
        def go():
            if self.source and self.source.lower().endswith('.pdf') and self.solution_origin is None: return   # zaten açık
            tab = next((t for t in (self.tabs or []) if (t.get('source') or '').lower().endswith('.pdf')), None)
            if tab: self.switch_tab(tab['id'])
            else: QTimer.singleShot(4000, lambda: self.show_toast('Bu tahtada açılmış bir PDF yok. Üstteki PDF düğmesiyle açabilirsiniz.'))
        self.welcome_go(go)
    def welcome_exam(self):
        def go():
            if getattr(self, 'exam_screen', None) is not None: return
            if not class_grade(self.board_info().get('sinif')) and self.upcoming_plans('*', started=True): self.open_salons()
            elif self.next_plan() is not None: self.open_preview()
            else: QTimer.singleShot(4000, lambda: self.show_toast('Şu an gösterilecek sınav ya da sınav yeri yok.'))
        self.welcome_go(go)
    def welcome_skip(self):
        self.hide_welcome(); self.board.finish(); self.showMinimized()   # kapanmaz: görev çubuğuna iner
    def lesson_key(self):
        now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        cur = next((n_ for n_, a_, b_, kind in bell_periods(now.weekday()) if kind == 'lesson' and a_ <= t < b_ and n_[0].isdigit()), None)
        return (now.date().isoformat(), cur) if cur else None
    def lesson_tick(self):
        """Her dersin başında (ilk 10 dk) karşılama: tahta görev çubuğundaysa öne gelir; biri yazıyorsa bölmez."""
        now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        cur = next(((n_, a_) for n_, a_, b_, kind in bell_periods(now.weekday()) if kind == 'lesson' and a_ <= t < b_ and n_[0].isdigit()), None)
        if not cur or t - cur[1] > 600: return
        key = (now.date().isoformat(), cur[0])
        if getattr(self, 'welcome_key', None) == key: return
        es = getattr(self, 'exam_screen', None)
        if es is not None and es.st and es.st.get('phase') != 'preview': self.welcome_key = key; return
        if not self.isMinimized() and time.time() - getattr(self, 'last_touch', 0) < 120: return   # ders sürüyor: 20 sn sonra yine bakılır
        self.welcome_key = key; self.show_welcome()
    def kelebek_tick(self):
        """Oturma planı: okul günü 07.00–15.00 arası 2 dakikada bir arka planda indirilir; gün geçince silinir."""
        import datetime, threading
        cache = os.path.join(self.data_dir, 'kelebek.bin'); today = datetime.date.today().isoformat()
        if self.kelebek is None:
            try:
                with open(cache, 'rb') as f: self.kelebek = kelebek_open(f.read())
            except Exception: self.kelebek = {}
        if self.kelebek and not any(pl.get('tarih', '') >= today for pl in self.kelebek.get('planlar', [])):
            self.kelebek = {}
            try: os.remove(cache)
            except OSError: pass
        now = datetime.datetime.now()
        fcache = os.path.join(self.data_dir, 'kelebek-foto.bin')
        if _PHOTOS['data'] is None:
            try:
                with open(fcache, 'rb') as f: fd = kelebek_open(f.read())
                if fd.get('bitis', '9999') >= today: _PHOTOS['data'] = fd.get('fotolar', {})
                else: os.remove(fcache); _PHOTOS['data'] = {}
            except Exception: _PHOTOS['data'] = _PHOTOS['data'] or {}
        if now.weekday() >= 5 or not (7 <= now.hour < 15) or getattr(self, 'kelebek_busy', False): return
        self.kelebek_busy = True
        def work():
            import urllib.request
            try:
                for url in KELEBEK_URLS:
                    try:
                        with urllib.request.urlopen(urllib.request.Request(url + '?t=%d' % int(time.time()//60), headers={'Cache-Control': 'no-cache'}), timeout=20) as r: blob = r.read()
                    except Exception as ex:
                        if getattr(ex, 'code', None) == 404: blob = b''   # plan yok (silindi)
                        else: continue
                    if not blob:
                        self.kelebek_new = {}; break
                    self.kelebek_new = kelebek_open(blob)
                    with open(cache + '.tmp', 'wb') as f: f.write(blob)
                    os.replace(cache + '.tmp', cache); break
                # fotoğraflar: yoksa, 6 saatten eskiyse ya da plan yeni bir fotoğraf paketi bildiriyorsa (foto_surum)
                import hashlib
                want = (self.kelebek_new or {}).get('foto_surum') if isinstance(getattr(self, 'kelebek_new', None), dict) else None
                try:
                    with open(fcache + '.surum', encoding='utf-8') as f: have = f.read().strip()
                except OSError: have = ''
                if not os.path.isfile(fcache) or time.time() - os.path.getmtime(fcache) > 6*3600 or (want and want != have):
                    for url in KELEBEK_FOTO_URLS:
                        try:
                            with urllib.request.urlopen(urllib.request.Request(url + '?t=%s' % (want or int(time.time()//3600)), headers={'Cache-Control': 'no-cache'}), timeout=60) as r: fb = r.read()
                        except Exception: continue
                        fd = kelebek_open(fb)
                        with open(fcache + '.tmp', 'wb') as f: f.write(fb)
                        os.replace(fcache + '.tmp', fcache); _PHOTOS['data'] = fd.get('fotolar', {}); _PHOTOS['pix'].clear()
                        try:
                            with open(fcache + '.surum', 'w', encoding='utf-8') as f: f.write(hashlib.sha256(fb).hexdigest()[:16])
                        except OSError: pass
                        break
            except Exception: pass
            finally: self.kelebek_busy = False
        threading.Thread(target=work, daemon=True).start()
    def take_kelebek(self):   # arka planda inen yeni plan ana iş parçacığında devreye girer
        new = getattr(self, 'kelebek_new', None)
        if new is not None:
            self.kelebek = new; self.kelebek_new = None; self.deneme_inject()
            try: self.sinav_plan_gonder()
            except Exception as e: print('sinav plani:', e)
            try: self.foto_gonder()
            except Exception as e: print('foto:', e)
    def foto_gonder(self):
        """Öğretmenler odası: kelebek fotoğraf paketi değişince öğrenci fotoğrafları DersMap'e (yalnız yeni/değişenler gider)."""
        if self.board_info().get('sinif') != 'Öğretmenler odası': return
        fd = _PHOTOS.get('data') or {}
        if not fd: return
        try: m = os.path.getmtime(os.path.join(self.data_dir, 'kelebek-foto.bin'))
        except OSError: return
        if m == getattr(self, '_foto_gitti', None) and time.monotonic() - getattr(self, '_foto_gitti_t', -1e9) < 6*3600: return
        path = os.path.join(self.data_dir, 'dersmap-foto.json')
        try:
            with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump({str(k): v for k, v in fd.items() if isinstance(v, str)}, f)
            os.replace(path + '.tmp', path)
        except OSError: return
        self._foto_gitti = m; self._foto_gitti_t = time.monotonic()
        self.run_havuz('--foto-yaz', path)
    def sinav_plan_gonder(self):
        """Öğretmenler odası: bugün ve sonraki sınav planları, okulun öğrenci listesi ve anket tanımları DersMap'e (değişince; aynıysa saatte bir)."""
        if self.board_info().get('sinif') != 'Öğretmenler odası': return
        import datetime, hashlib
        today = datetime.date.today().isoformat()
        pls = [dict(tarih=p_.get('tarih'), ders=p_.get('ders'), sinav=p_.get('sinav', ''), gozcu=p_.get('gozcu') or {}, salonlar=p_.get('salonlar') or {})
               for p_ in (self.kelebek or {}).get('planlar', []) if isinstance(p_, dict) and str(p_.get('tarih', '')) >= today and p_.get('salonlar')]
        kb = self.kelebek or {}
        ogr = [r for r in kb.get('ogrenciler', []) if isinstance(r, dict) and r.get('no') and r.get('ad')]   # okulun öğrenci listesi (DersMap Öğrenciler)
        try: ank = [a_ for a_ in self.anket_defs_kelebek() if isinstance(a_, dict) and a_.get('id')]   # DersMap'tekiler zaten orada
        except Exception: ank = []
        if not pls and not ogr and not ank: return
        blob = json.dumps(dict(planlar=pls, ogrenciler=ogr, anketler=ank), ensure_ascii=False, sort_keys=True)
        h = hashlib.sha256(blob.encode('utf-8')).hexdigest()
        if h == getattr(self, '_plan_gitti', None) and time.monotonic() - getattr(self, '_plan_gitti_t', -1e9) < 3600: return
        path = os.path.join(self.data_dir, 'sinav-plan.json')
        try:
            with open(path + '.tmp', 'w', encoding='utf-8') as f: f.write(blob)
            os.replace(path + '.tmp', path)
        except OSError: return
        self._plan_gitti = h; self._plan_gitti_t = time.monotonic()
        self.run_havuz('--sinav-plan-yaz', path)
    def deneme_inject(self):
        """Etkin deneme sınavını takvime ve kelebek planına ekler (seçilen salonlara, en son gerçek planın öğrenci listeleriyle); bitince çıkarır."""
        if not hasattr(self, 'exams'): self.exams = load_exams()
        self.exams = [x for x in (self.exams or []) if x[1] != DENEME_DERS]
        kb = self.kelebek if isinstance(self.kelebek, dict) else None
        if kb is not None: kb['planlar'] = [pl for pl in kb.get('planlar', []) if pl.get('ders') != DENEME_DERS]
        if not _DENEME: return
        self.exams.append((_DENEME['tarih'], DENEME_DERS, {g: 'Deneme sınavı' for g in ('9', '10', '11', '12')}))
        if kb is None: return
        real = sorted([pl for pl in kb.get('planlar', []) if pl.get('salonlar')], key=lambda pl: (pl.get('tarih', ''), pl.get('ders', '')), reverse=True)
        sal, goz = {}, {}
        for s_ in _DENEME.get('hedef', []):
            src = next((pl for pl in real if pl['salonlar'].get(s_)), None)
            if src: sal[s_] = [dict(r) for r in src['salonlar'][s_]]; goz[s_] = src.get('gozcu', {}).get(s_, '')
        if sal: kb.setdefault('planlar', []).append(dict(tarih=_DENEME['tarih'], ders=DENEME_DERS, sinav='Deneme sınavı', salonlar=sal, siniflar={}, gozcu={k: v for k, v in goz.items() if v}))
    def deneme_poll(self):
        """Deneme sınavı var mı: Öğretmenler odası kendi duyuru dosyasından, salonlar Drive'dan (hafta içi 07–17, dakikada bir) okur."""
        global _DENEME
        import datetime
        if time.monotonic() - getattr(self, 'deneme_chk', -1e9) < 5: return
        self.deneme_chk = time.monotonic(); now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        sinif = self.board_info().get('sinif', ''); grade = class_grade(sinif)
        if grade:
            if now.weekday() < 5 and 7*3600 <= t < 17*3600 and time.monotonic() - getattr(self, 'deneme_net', -1e9) > 60:
                self.deneme_net = time.monotonic(); self.run_havuz('--duyuru-oku', os.path.join(self.yok_dir(), 'duyuru-gelen.json'))
            fn = 'duyuru-gelen.json'
        else:
            fn = 'duyuru.json'
            if sinif == 'Öğretmenler odası' and now.weekday() < 5 and 7*3600 <= t < 17*3600 and time.monotonic() - getattr(self, 'deneme_net', -1e9) > 60:
                self.deneme_net = time.monotonic(); self.run_havuz('--duyuru-oku', os.path.join(self.yok_dir(), 'duyuru-gelen.json'))   # DersMap'in yazdıkları (send_duyuru birleştirir)
        try:
            with open(os.path.join(self.yok_dir(), fn), encoding='utf-8') as f: lst = json.load(f)
        except (OSError, ValueError): lst = []
        lst = [d for d in lst if isinstance(d, dict)] if isinstance(lst, list) else []
        ended = {d.get('ref') for d in lst if d.get('tur') == 'deneme_bitir'}
        act = [d for d in lst if d.get('tur') == 'deneme' and d.get('tarih') == now.date().isoformat() and d.get('id') not in ended
               and t < float(d.get('b', 0)) + EXAM_AFTER and (not grade or sinif in d.get('hedef', []))]
        new = max(act, key=lambda d: d.get('zaman', 0)) if act else {}
        new = dict(id=new['id'], tarih=new['tarih'], a=int(new['a']), b=int(new['b']), hedef=list(new.get('hedef', []))) if new else {}
        if new != _DENEME:
            _DENEME.clear(); _DENEME.update(new); self.deneme_inject()
            if not new and self.exam_screen is not None and self.exam_screen.st and self.exam_screen.st.get('lesson') == DENEME_DERS: self.exam_hidden = None
    def deneme_start(self, hedef, dk):
        now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second; a = t + 60; b = a + int(dk)*60
        ex_ = (None, now.date(), DENEME_DERS)
        if not self.send_duyuru('Deneme sınavı', list(hedef), ex_, dict(tur='deneme', a=a, b=b)): return False
        self.deneme_chk = -1e9; self.deneme_poll(); self.close_salons(); self.karargah_hidden_t = 0; self.exam_tick(); return True
    def deneme_stop(self):
        if not _DENEME: return
        now = self.exam_clock(); self.send_duyuru('', list(_DENEME.get('hedef', [])), (None, now.date(), DENEME_DERS), dict(tur='deneme_bitir', ref=_DENEME.get('id')))
        self.deneme_chk = -1e9; self.deneme_poll()
        kg = getattr(self, 'karargah', None)
        if kg is not None: kg.manual = False
        self.exam_tick()
    def ogrenci_ara(self, q):
        """Öğrenci adı (parçası) ya da okul numarasıyla bugünün ve sonraki sınavların salon/sıra bilgisi: [(kayıt, [(etiket, şimdi mi, salon, sıra, ders)])]."""
        import datetime
        self.take_kelebek(); now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second; today = now.date()
        low = lambda x: (x or '').replace('İ', 'i').replace('I', 'ı').lower()
        q = low(q).strip(); toks = q.split()
        if not toks or (not q.isdigit() and len(q) < 2): return []
        found = {}
        for pl in (self.kelebek or {}).get('planlar', []):
            if pl.get('ders') == DENEME_DERS: continue
            try: day = datetime.date.fromisoformat(pl.get('tarih', ''))
            except ValueError: continue
            span = exam_span(day.weekday(), pl.get('ders'), day)
            if day < today or not span or (day == today and t >= span[1]): continue
            for s_, lst in pl.get('salonlar', {}).items():
                for r in lst:
                    no = str(r.get('no', '')); ad = low(r.get('ad'))
                    if (q.isdigit() and no == q) or (not q.isdigit() and all(tk in ad for tk in toks)):
                        e = found.setdefault(no or r.get('ad'), [r, []])
                        lab = 'Bugün' if day == today else ('Yarın' if day == today + datetime.timedelta(days=1) else '%d %s' % (day.day, TR_MONTHS[day.month-1]))
                        e[1].append(((day, span[0]), lab, day == today and t >= span[0] - EXAM_BEFORE, pl.get('ders', ''), s_, r.get('sira'), tr_title(r.get('ders')) or ''))
        out = [(r, sorted(w)) for r, w in found.values()]
        out.sort(key=lambda x: (x[1][0][0] if x[1] else (datetime.date.max, 0), x[0].get('ad', '')))
        return out[:6]
    def open_ara(self):
        self.board.finish(); OgrenciAraDialog(self).exec_()
    def open_deneme(self):
        self.board.finish(); DenemeDialog(self).exec_()
    def seat_plan(self, st):
        self.take_kelebek()
        sinif = self.board_info().get('sinif', ''); day = (st.get('date') or __import__('datetime').date.today()).isoformat()
        for pl in (self.kelebek or {}).get('planlar', []):
            if pl.get('tarih') == day and pl.get('ders') == st['lesson']:
                if st.get('phase') == 'before' and pl.get('salonlar', {}).get(sinif):   # son 10 dakika: bu salonda oturacaklar (öğrenciler yerini bulsun)
                    return dict(tur='salon', sinif=sinif, liste=pl['salonlar'][sinif])
                if st.get('phase') in ('before', 'preview'):   # sınavdan önce: bu sınıfın öğrencileri hangi salonda, hangi sırada
                    lst = pl.get('siniflar', {}).get(sinif)
                    if lst: return dict(tur='sinif', sinif=sinif, liste=lst)
                elif st.get('phase') == 'during':   # sınavda: bu salonda oturması gerekenler, sıra numarasına göre
                    lst = pl.get('salonlar', {}).get(sinif)
                    if lst: return dict(tur='salon', sinif=sinif, liste=lst)
        return None
    def lesson_state(self, sinif):
        try:
            d = lesson_now(sinif, self.exam_clock())
            st = exam_now(self.exam_clock(), getattr(self, 'exams', None) or load_exams())
            if st and st['phase'] == 'during':   # sınav saatinde ders yerine sınav: bu salonda yazılan bütün dersler (kelebekten)
                d = dict(durum='sinav', saat=st['lesson'], ders=self.exam_courses(sinif, st) or st['exams'].get(class_grade(sinif)) or ', '.join(sorted(set(st['exams'].values()))))
            return d
        except Exception: return {}
    def exam_courses(self, sinif, st):
        """Kelebek planından: bu salonda oturanların dersleri (salon değilse sınavın bütün dersleri), 'Fizik, S. Fizik, …'."""
        day = (st.get('date') or __import__('datetime').date.today()).isoformat(); out = []
        for pl in (self.kelebek or {}).get('planlar', []):
            if pl.get('tarih') != day or pl.get('ders') != st['lesson']: continue
            sal = pl.get('salonlar', {}) or {}
            rows = sal.get(sinif) or [r for l in sal.values() for r in l]
            for r in rows:
                c = tr_title(r.get('ders', ''))
                if c and c not in out: out.append(c)
        return ', '.join(sorted(out, key=lambda c: (c.startswith('S. '), c)))
    def exam_clock(self):
        import datetime
        fake = os.environ.get('UMAL_SAAT')   # deneme: "2026-11-04 10:45:00"
        if fake:
            try:
                if not hasattr(self, '_fake_t0'): self._fake_t0 = (datetime.datetime.strptime(fake, '%Y-%m-%d %H:%M:%S'), time.monotonic())
                return self._fake_t0[0] + datetime.timedelta(seconds=time.monotonic() - self._fake_t0[1])
            except ValueError: pass
        return datetime.datetime.now()
    def exam_tick(self):
        """Sınav saatinde tahta alanı büyük saate döner; sınav bitince kendiliğinden kalkar."""
        sinif = self.board_info().get('sinif'); grade = class_grade(sinif)
        if not hasattr(self, 'exams'): self.exams = load_exams()
        try: self.anket_sync()
        except Exception as e: print('anket:', e)
        try: self.deneme_poll()
        except Exception as e: print('deneme:', e)
        if not grade:
            try: self.karargah_tick()
            except Exception as e: print('karargah:', e)
        st = exam_now(self.exam_clock(), self.exams) if grade else None   # Öğretmenler odası ve sınıfsız tahtada çıkmaz
        self._sinav_su_an = bool(st and st.get('phase') in ('before', 'during'))   # K-344: sınavda Atlas'a sor kapalı
        if self._sinav_su_an and getattr(self, 'atlas_panel', None) is not None and self.atlas_panel.isVisible(): self.atlas_panel.kapat()
        if st and self.exam_hidden == (st['key'], st['phase']): st = None
        if grade and not (st and st.get('phase') in ('before', 'during')):
            try: self.anket_kilit_tick()
            except Exception as e: print('anket kilit:', e)
        an_ = getattr(self, 'anket_screen', None)
        if an_ is not None and an_.isVisible():
            if st and st.get('phase') in ('before', 'during'): an_.hide()   # sınav başlıyor: anket kapanır
            else: st = None; an_.raise_()
        pj_ = getattr(self, 'proje_screen', None)
        rs_ = getattr(self, 'rastgele_screen', None)
        if rs_ is not None and rs_.isVisible():
            if st and st.get('phase') in ('before', 'during'): rs_.hide()
            else: st = None; rs_.raise_()
        if pj_ is not None and pj_.isVisible():
            if st and st.get('phase') in ('before', 'during'): pj_.hide()   # sınav başlıyor: proje seçimi kapanır
            else: st = None; pj_.raise_()
        gm_ = getattr(self, 'games', None)
        if gm_ is not None and gm_.isVisible():
            kar_ = (not grade) and self.board_info().get('sinif') in CLASS_PLACES and bool(self.karargah_exam())
            if (st and st.get('phase') in ('before', 'during')) or kar_: gm_.hide()   # sınav (ya da Karargah) başladı: oyun kapanır
            else: st = None; gm_.raise_()   # oyun açıkken teneffüs/sınav yerleri ekranı açılmaz
        if not st and grade and not (gm_ is not None and gm_.isVisible()) and not (an_ is not None and an_.isVisible()) and not (pj_ is not None and pj_.isVisible()) and not (rs_ is not None and rs_.isVisible()): st = self.exam_preview()   # teneffüs modu / sınav yerleri
        btn = getattr(self, 'preview_btn', None)
        if btn is not None:
            show_btn = st is None and getattr(self, 'salons', None) is None and bool(self.next_plan() if grade else self.upcoming_plans('*', started=True))
            if show_btn != btn.isVisible(): btn.setVisible(show_btn); self.place_overlays()
        af_ = getattr(self, 'ara_float', None)
        if af_ is not None:   # öğrenci araması: sınav planı olduğu sürece her tahtada (sınav ekranı açıkken ekrandaki düğme)
            show_af = st is None and getattr(self, 'salons', None) is None and bool(self.upcoming_plans('*', started=True))
            if show_af != af_.isVisible(): af_.setVisible(show_af); self.place_overlays()
        if not st:
            if self.exam_screen is not None: self.exam_screen.hide(); self.exam_screen.deleteLater(); self.exam_screen = None
            self.set_exam_full(False)
            return
        if self.exam_screen is None:
            if self.isMinimized() and st.get('phase') not in ('preview', 'teneffus'): self.showFullScreen()   # sınav saatinde tahta öne gelir
            self.hide_welcome(); self.board.finish(); self.exam_screen = ExamScreen(self); self.place_overlays(); self.exam_screen.show()
        self.exam_screen.set_state(st, grade); self.exam_screen.raise_()
        self.set_exam_full(st.get('phase') in ('before', 'during', 'after', 'preview', 'teneffus'))   # sınav yerleri ve teneffüs modunda da kalem paneli gizli
        try: self.yok_tick(st)
        except Exception as e: print('yoklama:', e)
        it = getattr(self, 'intro', None)
        if it is not None and not it.done: it.raise_()   # açılış logosu sayacın da üstünde
    def set_exam_full(self, on):
        """Sınav anında kalem paneli ve üst sekme şeridi gizlenir; sınav ekranı (fotoğraflı plan, sayaç, yoklama) bütün alanı kaplar. Sınav bitince geri gelir."""
        if bool(on) == getattr(self, '_exam_full', False): return
        self._exam_full = bool(on)
        for w in (getattr(self, 'tool_scroll', None), getattr(self, 'tab_scroll', None), getattr(self, 'top_logo', None)):
            if w is not None: w.setVisible(not on)
        QTimer.singleShot(0, self.place_overlays); QTimer.singleShot(150, self.place_overlays)
    def upcoming_plans(self, sinif=None, started=False):
        """Bu sınıf için henüz başlamamış en yakın sınavın oturma planı: (plan, tarih, ders, başlangıç sn, bitiş sn)."""
        import datetime
        self.take_kelebek()
        if self.kelebek is None:   # açılışta: indirmeyi beklemeden diskteki plan
            try:
                with open(os.path.join(self.data_dir, 'kelebek.bin'), 'rb') as f: self.kelebek = kelebek_open(f.read())
            except Exception: self.kelebek = {}
            self.deneme_inject()
        if sinif is None: sinif = self.board_info().get('sinif', '')
        now = self.exam_clock(); found = []
        for pl in (self.kelebek or {}).get('planlar', []):
            if sinif != '*' and not pl.get('siniflar', {}).get(sinif): continue
            try: day = datetime.date.fromisoformat(pl['tarih'])
            except (KeyError, ValueError): continue
            span = exam_span(day.weekday(), pl.get('ders'), day)
            if not span: continue
            start = datetime.datetime.combine(day, datetime.time()) + datetime.timedelta(seconds=span[0])
            if started:   # öğretmenler odası: bugünün bitmiş sınavları da (kâğıt teslimi vb.)
                if day < now.date(): continue
            elif start - datetime.timedelta(seconds=EXAM_BEFORE) <= now: continue   # artık sayaç gösteriyor
            found.append((pl, day, pl['ders'], span[0], span[1], start))
        return sorted(found, key=lambda x: x[5])
    def next_plan(self):
        lst = self.upcoming_plans(); return lst[0] if lst else None
    def exam_preview(self):
        """Teneffüs ve öğle arasında teneffüs modu (sınav haftasında; sağ altta 'Sınav yerleri'); düğmeyle sınav yerleri ekranı.
        Düğmeyle açılan sınav yerleri ders/teneffüs değişince kendiliğinden kapanır."""
        plans = self.upcoming_plans(); now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        cur = next(((n_, a_, kind) for n_, a_, b_, kind in bell_periods(now.weekday()) if a_ <= t < b_), None)
        brk = cur is not None and cur[2] in ('break', 'prep'); per = cur[1] if cur else -1
        if getattr(self, 'preview_open', False) and getattr(self, 'preview_per', per) != per: self.preview_open = False   # zil çaldı: kapanır
        if not getattr(self, 'preview_open', False) and brk:
            tk = ('tn', now.date().isoformat(), per)
            if self.exam_hidden != tk:
                try: info = teneffus_info(now, self.exams, class_grade(self.board_info().get('sinif')), self.board_info().get('sinif', ''))
                except Exception as e: print('teneffüs:', e); info = None
                if info: return dict(key=tk, lesson='', exams={'': ''}, start=t, end=t, t=t, phase='teneffus', date=now.date(), today=now.date(), tn=info, diger='', yerler=bool(plans))
        if not plans: self.preview_open = False; self.preview_idx = 0; return None
        idx = getattr(self, 'preview_idx', 0) % len(plans) if getattr(self, 'preview_open', False) else 0
        pl, day, lesson, a, b, start = plans[idx]
        key = ('pv', pl.get('tarih'), lesson, per)
        if not getattr(self, 'preview_open', False): return None
        exams = next((g for d_, l_, g in (self.exams or []) if d_ == pl.get('tarih') and l_ == lesson), {})
        nxt = plans[(idx + 1) % len(plans)] if len(plans) > 1 else None
        other = ('%s · %d %s' % (nxt[2], nxt[1].day, TR_MONTHS[nxt[1].month-1])) if nxt else ''
        return dict(key=key, lesson=lesson, exams=exams or {'': 'Ortak Yazılı Sınav'}, start=a, end=b, t=t, phase='preview', date=day, today=now.date(), diger=other)
    def open_games(self):
        """Oyun köşesi (tam ekran). Bu tahtada sınav geri sayımı/sınav varsa açılmaz."""
        grade = class_grade(self.board_info().get('sinif'))
        st = exam_now(self.exam_clock(), getattr(self, 'exams', None)) if grade else None
        kar_ = (not grade) and self.board_info().get('sinif') in CLASS_PLACES and bool(self.karargah_exam())
        if (st and st.get('phase') in ('before', 'during')) or kar_:
            self.show_toast('Sınav sırasında oyunlar açılmaz.'); return
        self.hide_welcome(); self.board.finish(); self.close_exam_screen_for_tool()
        if getattr(self, 'games', None) is None: self.games = GameScreen(self)
        self.games.fit(self.rect()); self.games.show(); self.games.raise_()
    # ---- Anket ----
    def anket_defs(self):
        """Anket tanımları: kelebek paketindekiler + DersMap'te hazırlanıp yayına alınanlar (aynı kimlikte kelebek önceliklidir)."""
        defs = list(self.anket_defs_kelebek())
        ids = {a.get('id') for a in defs if isinstance(a, dict)}
        path = os.path.join(self.data_dir, 'anketler-dersmap.json')
        try:
            m = os.path.getmtime(path)
            if getattr(self, '_anket_dm', (None, None))[0] != m:
                with open(path, encoding='utf-8') as f: dm = json.load(f)
                self._anket_dm = (m, [a for a in dm if isinstance(a, dict) and a.get('id') and a.get('sorular')] if isinstance(dm, list) else [])
            defs += [a for a in self._anket_dm[1] if a.get('id') not in ids]
        except (OSError, ValueError): pass
        return defs
    def anket_defs_kelebek(self):
        """Anket tanımları: kelebek paketinden (gelince yerel dosyaya da yazılır; plan silinse de anket bitiş tarihine kadar kalır)."""
        path = os.path.join(self.data_dir, 'anketler.json'); kel = self.kelebek or {}
        if isinstance(kel, dict) and 'anketler' in kel:
            defs = kel.get('anketler') or []
            if defs != getattr(self, '_anket_saved', None):
                try:
                    with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump(defs, f, ensure_ascii=False)
                    os.replace(path + '.tmp', path); self._anket_saved = defs
                except OSError: pass
            return defs
        try:
            m = os.path.getmtime(path)
            if getattr(self, '_anket_file', (None, None))[0] != m:
                with open(path, encoding='utf-8') as f: self._anket_file = (m, json.load(f))
            return self._anket_file[1] or []
        except (OSError, ValueError): return []
    def anket_active(self, bolum=None):
        """Açık anketler; bolum='anket' ya da 'rehberlik' verilirse yalnız o bölümünkiler (tanımda 'bolum' yoksa 'anket')."""
        import datetime
        sinif = self.board_info().get('sinif', ''); now = datetime.datetime.now()
        out = anket_for_board(self.anket_defs(), sinif, now.date().isoformat(), self.anket_kontrol())
        # K-330: yalnız seçilen derslerde; "sınıfın hepsi doldurunca kapansın"
        out = [a for a in out if anket_ders_uygun(a, now) and not (a.get('otokapat') and anket_tamam(a, sinif, self.anket_answers(a)))]
        return out if bolum is None else [a for a in out if (a.get('bolum') or 'anket') == bolum]
    def ayrilan_yukle(self):
        """K-333: DersMap'te okuldan ayrıldı denenlerin numaraları (tahtada fotoğrafı ve listede adı gizlenir)."""
        path = os.path.join(self.data_dir, 'ayrilanlar.json')
        try: m = os.path.getmtime(path)
        except OSError: return
        if m == getattr(self, '_ayrilan_m', None): return
        self._ayrilan_m = m
        try:
            with open(path, encoding='utf-8') as f: lst = json.load(f)
        except (OSError, ValueError): return
        yeni = {str(r.get('no') if isinstance(r, dict) else r) for r in (lst if isinstance(lst, list) else [])}
        if yeni != AYRILAN:
            AYRILAN.clear(); AYRILAN.update(yeni)
            for no in yeni: _PHOTOS['pix'].pop(no, None)
            self.update()
    def anket_sayim(self):
        """Kontenjanlı sorular: okul genelindeki seçim sayıları (DersMap, dakikada bir)."""
        path = os.path.join(self.data_dir, 'anket-sayim.json')
        try:
            m = os.path.getmtime(path)
            if getattr(self, '_anket_sayim', (None, None))[0] != m:
                with open(path, encoding='utf-8') as f: self._anket_sayim = (m, json.load(f))
            return self._anket_sayim[1] or []
        except (OSError, ValueError): return []
    def anket_sonuc_aday(self):
        """'Kapanınca sonucu sınıfa göster' denmiş, bu sınıfta kapanmış (son 7 gün) anket."""
        import datetime
        sinif = self.board_info().get('sinif', ''); today = datetime.date.today().isoformat(); lim = datetime_today() - 7
        act = {a.get('id') for a in self.anket_active()}
        c = [a for a in self.anket_defs() if isinstance(a, dict) and a.get('sonuc_goster') and sinif in (a.get('siniflar') or {})
             and a.get('id') not in act and str(a.get('baslangic') or '0000') <= today and str(a.get('bitis') or '9999') >= lim
             and (self.anket_answers(a).get('cevaplar'))]
        return max(c, key=lambda a: str(a.get('bitis') or '')) if c else None
    def open_anket_sonuc(self, a):
        self.close_exam_screen_for_tool(); self.hide_welcome(); self.board.finish()
        if getattr(self, 'anket_sonuc', None) is None: self.anket_sonuc = AnketSonucEkrani(self)
        self.anket_sonuc.a = a; self.anket_sonuc.fit(self.rect()); self.anket_sonuc.show(); self.anket_sonuc.raise_()
    def anket_kontrol(self):
        """Öğretmenler odasının 'Anketi aç / kapat' kayıtları {anket id: {durum, gun, zaman}} (Drive'dan, en yenisi geçerli)."""
        out = {}
        for path in (os.path.join(self.data_dir, 'anketdurum-gelen.json'), os.path.join(self.data_dir, 'anketdurum-yerel.json')):
            try:
                with open(path, encoding='utf-8') as f: d = json.load(f)
            except (OSError, ValueError): continue
            for v in (d.values() if isinstance(d, dict) else []):
                if isinstance(v, dict) and v.get('ders_no') and float(v.get('zaman') or 0) >= float((out.get(v['ders_no']) or {}).get('zaman') or 0): out[v['ders_no']] = v
        return out
    def anket_kontrol_yaz(self, a, durum):
        """Öğretmenler odası: anketi bütün tahtalarda kapatır / açar (Drive: Sınav Yoklamaları/.veri/anketdurum_<id>_kontrol.json)."""
        import datetime
        d = dict(tarih='anketdurum', ders_no=a['id'], salon='kontrol', durum=durum, gun=datetime.date.today().isoformat(), zaman=time.time())
        path = os.path.join(self.data_dir, 'anketdurum-%s.json' % ''.join(c for c in a['id'] if c.isalnum() or c in '-_'))
        try:
            with open(path, 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)
            with open(os.path.join(self.data_dir, 'anketdurum-yerel.json'), 'w', encoding='utf-8') as f: json.dump({'yerel': d}, f, ensure_ascii=False)
        except OSError as e: print('anket:', e); return False
        self.run_havuz('--yoklama-yaz', path); return True
    def anket_path(self, a): return os.path.join(self.data_dir, 'anket-%s.json' % ''.join(c for c in a['id'] if c.isalnum() or c in '-_'))
    def anket_answers(self, a):
        try:
            with open(self.anket_path(a), encoding='utf-8') as f: return json.load(f)
        except (OSError, ValueError): return {}
    def anket_save(self, a, no, vals):
        """Cevap tahtada saklanır ve hemen Drive'a gider (Sınav Yoklamaları/.veri/anket_<id>_<sınıf>.json)."""
        d = self.anket_answers(a) or {}; sinif = self.board_info().get('sinif', '')
        d.update(tarih='anket', ders_no=a['id'], salon=sinif, anket=a['id'], zaman=time.time()); d.setdefault('cevaplar', {})[str(no)] = dict(zaman=time.time(), c=vals)
        path = self.anket_path(a)
        try:
            with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)
            os.replace(path + '.tmp', path)
        except OSError as e: print('anket:', e); return
        self.run_havuz('--yoklama-yaz', path)
    def anket_sync(self):
        """Panel düğmesi yalnız açık anket varken (Öğretmenler odasında anket tanımı varken) görünür; bekleyen cevaplar yeniden gönderilir."""
        room = self.board_info().get('sinif') in CLASS_PLACES; sinif = self.board_info().get('sinif', '')
        import datetime as _dt
        now_ = _dt.datetime.now()
        if now_.weekday() < 5 and 7 <= now_.hour < 18 and time.monotonic() - getattr(self, '_anket_dm_t', -1e9) > 60:   # DersMap: hazırlanan anketler, proje aç/kapat
            self._anket_dm_t = time.monotonic(); self.run_havuz('--anket-tanim-oku', os.path.join(self.data_dir, 'anketler-dersmap.json'))
            try: kont = any(q.get('kontenjanlar') for a in self.anket_active() for q in a.get('sorular', []))
            except Exception: kont = False
            if kont: self.run_havuz('--anket-sayim-oku', os.path.join(self.data_dir, 'anket-sayim.json'))
            if time.monotonic() - getattr(self, '_ayrilan_t', -1e9) > 900:   # 15 dk'da bir: okuldan ayrılanlar
                self._ayrilan_t = time.monotonic(); self.run_havuz('--ayrilan-oku', os.path.join(self.data_dir, 'ayrilanlar.json'))
            if not room and class_grade(sinif): self.run_havuz('--proje-durum-oku', os.path.join(self.data_dir, 'proje-durum-gelen.json'))
        try: self.ayrilan_yukle()
        except Exception as e: print('ayrılan:', e)
        if not room and class_grade(sinif):
            try: self.proje_uzak_durum()
            except Exception as e: print('proje durum:', e)
        if time.monotonic() - getattr(self, '_anket_kontrol_t', -1e9) > 45:   # Öğretmenler odası / DersMap aç-kapat dedi mi? (odada: öğretmen anketleri)
            try:
                lim = datetime_today() - 30
                ids = [a['id'] for a in self.anket_defs() if isinstance(a, dict) and a.get('id') and sinif in (a.get('siniflar') or {}) and str(a.get('bitis') or '9999') >= lim]
            except Exception: ids = []
            if ids:
                self._anket_kontrol_t = time.monotonic()
                self.run_havuz('--yoklama-oku', 'anketdurum_', os.path.join(self.data_dir, 'anketdurum-gelen.json'))
        try: show = (not room) and bool(self.anket_active())
        except Exception: show = False
        sc = getattr(self, 'anket_screen', None)
        if not room and not show and sc is not None and sc.isVisible(): sc.hide(); self.show_toast('Anket kapandı.')
        if show and time.monotonic() - getattr(self, '_anket_push_t', -1e9) > 120:   # 2 dk'da bir son hâli Drive'a
            self._anket_push_t = time.monotonic()
            for a in self.anket_active():
                path = self.anket_path(a)
                if os.path.exists(path): self.run_havuz('--yoklama-yaz', path)
    # ---- Proje seçimi ----
    def proje_demo(self):
        """Öğretmenler odası (sınıf olmayan tahta): uydurma öğrencilerle tanıtım sınıfı; gerçek kayıtlara ve Drive'a dokunmaz."""
        return not class_grade(self.board_info().get('sinif'))
    def proje_sinif(self): return PROJE_DEMO if self.proje_demo() else self.board_info().get('sinif', '')
    def proje_path(self): return os.path.join(self.data_dir, ('proje-demo.json' if self.proje_demo() else 'proje-%s.json' % PROJE_DONEM))
    def proje_data(self):
        try:
            with open(self.proje_path(), encoding='utf-8') as f: d = json.load(f)
            if isinstance(d, dict): return d
        except (OSError, ValueError): pass
        return dict(durum='kapali', kont={}, tercihler={}, sonuc={})
    def proje_save(self, d, push=True):
        """Tahtada saklanır ve Drive'a yedeklenir (Sınav Yoklamaları/.veri/proje_<dönem>_<sınıf>.json)."""
        sinif = self.proje_sinif(); d.update(tarih='proje', ders_no=PROJE_DONEM, salon=sinif, zaman=time.time())
        if self.proje_demo(): push = False   # tanıtım: Drive'a gitmez
        path = self.proje_path()
        try:
            with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)
            os.replace(path + '.tmp', path)
        except OSError as e: print('proje:', e); return
        if push: self.run_havuz('--yoklama-yaz', path)
    def proje_tercih(self, no, t):
        d = self.proje_data()
        if d.get('durum') != 'acik' or proje_suresi_doldu(d): return
        d.setdefault('tercihler', {})[str(no)] = list(t); self.proje_save(d)
    def proje_roster(self):
        """Sınıf listesi: kelebek planlarındaki bu sınıfın öğrencileri (okul numarasına göre)."""
        if self.proje_demo(): return list(PROJE_DEMO_LISTE)
        self.take_kelebek(); sinif = self.board_info().get('sinif', ''); seen = {}
        for pl in (self.kelebek or {}).get('planlar', []):
            for r in (pl.get('siniflar') or {}).get(sinif, []) or []:
                no = str(r.get('no', '')).strip()
                if no and no not in seen and no not in AYRILAN: seen[no] = tr_name(r.get('ad', ''))
        cache = os.path.join(self.data_dir, 'proje-liste.json')   # sınav planları silinince de liste kalsın
        if seen:
            try:
                with open(cache, 'w', encoding='utf-8') as f: json.dump(dict(sinif=sinif, liste=seen), f, ensure_ascii=False)
            except OSError: pass
        else:
            try:
                with open(cache, encoding='utf-8') as f: c_ = json.load(f)
                if c_.get('sinif') == sinif: seen = dict(c_.get('liste') or {})
            except (OSError, ValueError, AttributeError): pass
        return sorted(((no, ad) for no, ad in seen.items() if no not in AYRILAN), key=lambda kv: (int(kv[0]) if kv[0].isdigit() else 10**9, kv[1]))
    def proje_pin_file(self): return os.path.join(self.data_dir, 'proje-demo.pin' if self.proje_demo() else 'proje-ogretmen.pin')
    def proje_pin_var(self): return os.path.isfile(self.proje_pin_file())
    def proje_pin_set(self, s_):
        import hashlib; salt = uuid.uuid4().hex
        try:
            with open(self.proje_pin_file(), 'w') as f: f.write(salt + ':' + hashlib.sha256((salt + s_).encode('utf-8')).hexdigest())
        except OSError as e: print('proje pin:', e)
    def proje_pin_ok(self, s_):
        import hashlib
        try:
            with open(self.proje_pin_file()) as f: salt, h = f.read().strip().split(':', 1)
        except (OSError, ValueError): return False
        return hashlib.sha256((salt + s_).encode('utf-8')).hexdigest() == h
    def proje_uzak_durum(self):
        """DersMap'ten 'Tercihi aç / kapat' (bu sınıf ya da bütün sınıflar): yeni bir kayıt geldiyse uygulanır.
        Dağıtım yapılmış sınıfta 'aç' dağıtımı silmez (öğretmen tahtadan yeniden açar)."""
        path = os.path.join(self.data_dir, 'proje-durum-gelen.json')
        try: m = os.path.getmtime(path)
        except OSError: return
        if m == getattr(self, '_proje_uzak_m', None): return
        self._proje_uzak_m = m
        try:
            with open(path, encoding='utf-8') as f: lst = json.load(f)
        except (OSError, ValueError): return
        sinif = str(self.board_info().get('sinif', '')).upper().replace(' ', '')
        uygun = [r for r in (lst if isinstance(lst, list) else []) if isinstance(r, dict) and r.get('durum') in ('acik', 'kapali')
                 and (r.get('sinif') == '*' or str(r.get('sinif', '')).upper().replace(' ', '') == sinif)]
        if not uygun: return
        son = max(uygun, key=lambda r: float(r.get('zaman') or 0))
        d = self.proje_data()
        if float(son.get('zaman') or 0) <= float(d.get('uzak_zaman') or 0): return
        d['uzak_zaman'] = float(son.get('zaman') or 0)
        if son['durum'] == 'kapali' and d.get('durum') == 'acik': d['durum'] = 'kapali'
        elif son['durum'] == 'acik' and d.get('durum') == 'kapali': d['durum'] = 'acik'
        self.proje_save(d); self.proje_refresh()
    def proje_refresh(self):
        ps = getattr(self, 'proje_screen', None)
        if ps is not None: ps.update()
    def open_proje(self):
        st = exam_now(self.exam_clock(), getattr(self, 'exams', None)) if not self.proje_demo() else None
        if st and st.get('phase') in ('before', 'during'): self.show_toast('Sınav sırasında proje seçimi açılmaz.'); return
        self.close_exam_screen_for_tool(); self.hide_welcome(); self.board.finish()
        if getattr(self, 'proje_screen', None) is None: self.proje_screen = ProjeScreen(self)
        self.proje_screen.fit(self.rect()); self.proje_screen.show(); self.proje_screen.raise_()
    def open_rastgele(self):
        st = exam_now(self.exam_clock(), getattr(self, 'exams', None)) if not self.proje_demo() else None
        if st and st.get('phase') in ('before', 'during'): self.show_toast('Sınav sırasında açılmaz.'); return
        self.close_exam_screen_for_tool(); self.hide_welcome(); self.board.finish()
        if getattr(self, 'rastgele_screen', None) is None: self.rastgele_screen = RastgeleScreen(self)
        self.rastgele_screen.fit(self.rect()); self.rastgele_screen.show(); self.rastgele_screen.raise_()
    def open_okul(self):
        self.board.finish(); OkulAraclari(self).exec_()
    def open_anket(self, bolum='anket', canli=False):
        if self.board_info().get('sinif') in CLASS_PLACES and not canli and bolum == 'anket' and self.anket_active('anket'):
            pass   # K-330: öğretmen anketi açık — öğretmenler fotoğraf kartına dokunup doldurur (ekranda "Canlı katılım" düğmesi)
        elif self.board_info().get('sinif') in CLASS_PLACES:
            self.board.finish(); defs = [a for a in self.anket_defs() if isinstance(a, dict) and a.get('id') and str(a.get('bitis') or '9999') >= (datetime_today() - 30)]
            if not defs: self.show_toast('Henüz anket yok.'); return
            self.close_exam_screen_for_tool(); self.hide_welcome()
            if getattr(self, 'anket_canli', None) is None: self.anket_canli = AnketCanli(self)
            self.anket_canli.open_(max(defs, key=lambda a: (str(a.get('baslangic') or ''), str(a.get('bitis') or ''))), defs); return
        grade = class_grade(self.board_info().get('sinif'))
        st = exam_now(self.exam_clock(), getattr(self, 'exams', None)) if grade else None
        if st and st.get('phase') in ('before', 'during'): self.show_toast('Sınav sırasında anket açılmaz.'); return
        if not self.anket_active(bolum):
            sa = self.anket_sonuc_aday() if bolum == 'anket' else None
            if sa is not None: self.open_anket_sonuc(sa); return
            self.show_toast('Bu sınıf için açık form yok.' if bolum == 'rehberlik' else 'Bu sınıf için açık anket yok.'); return
        self.close_exam_screen_for_tool()
        self.hide_welcome(); self.board.finish()
        if getattr(self, 'anket_screen', None) is None: self.anket_screen = AnketScreen(self)
        if self.anket_screen.bolum != bolum: self.anket_screen.bolum = bolum; self.anket_screen.idx = 0
        self.anket_screen.fit(self.rect()); self.anket_screen.show(); self.anket_screen.raise_()
    def anket_kilitli(self):
        """K-339: idare 'tahtayı kilitle' dediyse ders saatinde (anketin dersleri seçiliyse yalnız o derslerde) sınıf tahtasında yalnız anket kalır.
        Sınıfta herkes doldurunca ya da öğretmen 3 sn basılı tutunca (o ders için) kalkar. Teneffüs, okul sonrası ve sınav serbest."""
        if not class_grade(self.board_info().get('sinif')): return None   # Öğretmenler odası kilitlenmez
        key = self.lesson_key(); ara = getattr(self, 'anket_kilit_ara', None)
        sinif = self.board_info().get('sinif', '')
        for a in self.anket_active():
            if not a.get('kilit') or anket_tamam(a, sinif, self.anket_answers(a)): continue
            if a.get('acil'):   # K-343: acil anket — ders ya da teneffüs fark etmez, hemen kaplar
                if ara != self.kilit_anahtari(): return a
            elif key is not None and ara != key: return a
        return None
    def kilit_anahtari(self):
        """Öğretmenin 3 sn ile açtığı süre: ders saatinde o ders, teneffüste o teneffüs."""
        key = self.lesson_key()
        if key is not None: return key
        now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        cur = next((a_ for n_, a_, b_, kind in bell_periods(now.weekday()) if a_ <= t < b_), None)   # teneffüsün başladığı saniye
        return (now.date().isoformat(), 'ara-%s' % (cur if cur is not None else now.hour * 3600))
    def anket_kilit_tick(self):
        t = time.time()
        if t - getattr(self, '_kilit_t', 0) < 4: return
        self._kilit_t = t
        a = self.anket_kilitli(); sc = getattr(self, 'anket_screen', None)
        if a is None:
            if sc is not None and sc.kilit_id: sc.kilit_id = None; sc.layout_btns(); sc.update()
            return
        if sc is not None and sc.isVisible() and sc.kilit_id == a['id']:
            if self.isMinimized() or not self.isFullScreen(): self.showFullScreen()
            self.hide_welcome(); sc.raise_(); return
        for nm in ('games', 'proje_screen', 'rastgele_screen', 'anket_canli', 'salons'):
            w = getattr(self, nm, None)
            if w is not None and w.isVisible(): w.hide()
        if self.isMinimized() or not self.isFullScreen(): self.showFullScreen()
        self.close_exam_screen_for_tool(); self.hide_welcome(); self.board.finish()
        if sc is None: sc = self.anket_screen = AnketScreen(self)
        bolum = a.get('bolum') or 'anket'
        act = self.anket_active(bolum); ids = [x.get('id') for x in act]
        sc.bolum = bolum; sc.idx = ids.index(a['id']) if a['id'] in ids else 0; sc.kilit_id = a['id']
        sc.fit(self.rect()); sc.show(); sc.raise_(); self.raise_(); self.activateWindow()
        if a.get('acil') and getattr(self, '_acil_ses', None) != (a['id'], self.kilit_anahtari()):   # acil: uyarı sesi (her ders / teneffüste bir kez)
            self._acil_ses = (a['id'], self.kilit_anahtari())
            try: play_sound(os.path.join(_APP_DIR, 'sesler', 'bildirim.wav'), 1.0)
            except Exception: pass
    def anket_kilit_ac(self):
        """Öğretmen 3 sn basılı tuttu: bu ders (acil ankette teneffüs de) boyunca kilit yok; sonrakinde yeniden gelir."""
        self.anket_kilit_ara = self.kilit_anahtari(); sc = getattr(self, 'anket_screen', None)
        if sc is not None: sc.kilit_id = None; sc.hide(); sc.layout_btns()
        self.show_toast('Anket kilidi bu ders için kaldırıldı.')
    def atlas_dugme(self):
        """K-350: paneldeki Atlas düğmesi: Atlas paneli açılır (yazarak sor ya da "Tahtadan soru seç"); yeniden basınca kapanır."""
        if getattr(self, '_sinav_su_an', False): self.show_toast("Sınav saatinde Atlas'a sor kapalı."); return
        pn = getattr(self, 'atlas_panel', None)
        if self.tool == 'atlas': self.set_tool('pen'); pn and pn.show(); return
        if pn is not None and pn.isVisible(): pn.kapat(); return
        self.atlas_sor_ac()
    def atlas_sor_ac(self, resim=None):
        """K-344: Atlas'a sor paneli."""
        if getattr(self, 'atlas_panel', None) is None: self.atlas_panel = AtlasPanel(self)
        self.atlas_panel.ac(resim)
    def atlas_cerceve(self, pts):
        """K-350: paneldeki Atlas düğmesi → çerçeve: seçilen bölüm Atlas'a gider ve hemen çözülür. Boş yere dokunmak: yazarak sorma."""
        self.set_tool('pen'); pn = getattr(self, 'atlas_panel', None)
        geri = lambda: (pn.show(), pn.raise_()) if pn is not None else self.atlas_sor_ac()   # çerçeve yok: panel kaldığı yerden
        if len(pts) < 2: geri(); return
        r = QRectF(QPointF(*pts[0]), QPointF(*pts[1])).normalized()
        if min(r.width(), r.height())*self.board.scale < 16: geri(); return
        self.atlas_son_cerceve = (self.page, QRectF(r))   # Tahtaya yaz: cevap bu sorunun altına yazılır
        self.atlas_sor_secim(r, True)
    def atlas_sor_secim(self, r, otomatik=False):
        """Seçilen bölümün görüntüsü (çerçeve olmadan) Atlas'a gider; otomatik: dersin ilk seçeneğiyle (Çöz…) hemen sorulur."""
        b = self.board; k = b.scale; pad = 14
        q = QRectF(r.x()*k - pad, r.y()*k - pad, r.width()*k + 2*pad, r.height()*k + 2*pad).toAlignedRect() & b.rect()
        if q.width() < 16 or q.height() < 16: return
        b._temiz_cek = True
        try: pix = b.grab(q)
        finally: b._temiz_cek = False
        self.atlas_sor_ac(pix)
        pn = self.atlas_panel
        if otomatik and pn.secenek_dug: QTimer.singleShot(0, lambda: pn.sor(pn.secenek_dug[0].text()))
    def close_exam_screen_for_tool(self):
        """Teneffüs modu / sınav yerleri açıkken oyun ya da anket açılınca: o ekran kapanır, panel geri gelir (oyun/anket tam ekran)."""
        es = getattr(self, 'exam_screen', None)
        if es is not None and es.st and es.st.get('phase') in ('teneffus', 'preview'):
            self.preview_open = False; es.hide(); es.deleteLater(); self.exam_screen = None; self.set_exam_full(False)
    def close_games(self):
        if getattr(self, 'games', None) is not None: self.games.hide()
        self.exam_tick()
    def open_salons(self):   # öğretmenler odası: bütün salonlar
        self.hide_welcome(); self.board.finish()
        if getattr(self, 'salons', None) is None: self.salons = SalonBrowser(self)
        self.salons.setGeometry(self.rect()); self.salons.show(); self.salons.raise_(); self.exam_tick()
    def close_salons(self):
        if getattr(self, 'salons', None) is not None: self.salons.hide(); self.salons.deleteLater(); self.salons = None
        self.exam_tick()
    def open_preview(self):
        if not class_grade(self.board_info().get('sinif')):
            if self.board_info().get('sinif') in CLASS_PLACES and (self.karargah_exam() or self.karargah_last()): self.open_karargah(); return
            self.open_salons(); return
        now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        cur = next((a_ for n_, a_, b_, kind in bell_periods(now.weekday()) if a_ <= t < b_), -1)
        self.preview_open = True; self.preview_idx = 0; self.preview_per = cur; self.exam_hidden = None; self.exam_tick()
    def other_exam(self):   # sınav yerleri ekranında: sıradaki öbür sınavın yerleri
        self.preview_open = True; self.preview_idx = getattr(self, 'preview_idx', 0) + 1; self.exam_hidden = None; self.exam_tick()
    def hide_exam(self):
        if self.exam_screen is not None and self.exam_screen.st and self.exam_screen.st.get('phase') in ('preview', 'teneffus'):
            if self.exam_screen.st.get('phase') == 'teneffus': self.exam_hidden = self.exam_screen.st['key']   # bu teneffüs için gizlenir
            self.preview_open = False; self.exam_tick(); return
        st = exam_now(self.exam_clock(), getattr(self, 'exams', None))
        if st: self.exam_hidden = (st['key'], st['phase'])   # yalnız bu bölüm: sınav başlayınca / bitince yeniden çıkar
        self.exam_tick()
    # ---- Sınav yoklaması (salon tahtası) ----
    def yok_dir(self):
        d = os.path.join(self.data_dir, 'yoklama'); os.makedirs(d, exist_ok=True); return d
    @staticmethod
    def yok_key(day, lesson): return '%s_%s' % (day.isoformat(), str(lesson).split('.')[0].strip())
    def kelebek_plan(self, day, lesson):
        self.take_kelebek()
        return next((pl for pl in (self.kelebek or {}).get('planlar', []) if pl.get('tarih') == day.isoformat() and pl.get('ders') == lesson), None)
    def yok_state(self, st):
        """Bu salonun bu sınavdaki yoklaması: {'gelmedi': {sıra: kayıt}, 'onay': bool}; diskte saklanır (tahta yeniden açılsa da kalır)."""
        key = self.yok_key(st['date'], st['lesson']); c = getattr(self, '_yok', None)
        if c is None or c.get('key') != key:
            path = os.path.join(self.yok_dir(), key + '.json'); c = dict(key=key, path=path, gelmedi={}, onay=False, sent=-1e9, final=False, mesajlar=[])
            try:
                with open(path, encoding='utf-8') as f: d = json.load(f)
                c.update(gelmedi={int(r['sira']): r for r in d.get('gelmedi', [])}, onay=bool(d.get('onay')), final=bool(d.get('kapandi')), mesajlar=list(d.get('mesajlar', [])))
            except (OSError, ValueError, KeyError, TypeError): pass
            self._yok = c
        return c
    def yok_open(self, st):
        return bool(st) and st.get('phase') in ('before', 'during') and YOKLAMA_BASLA <= st['t'] - st['start'] and st['t'] < st['end']   # sınavın 5. dakikasında açılır, sınav bitene kadar
    def yok_toggle(self, st, plan, sira):
        if not self.yok_open(st): return
        c = self.yok_state(st); rec = next((r for r in plan['liste'] if r['sira'] == sira), None)
        if rec is None: return
        if sira in c['gelmedi']: del c['gelmedi'][sira]
        else: c['gelmedi'][sira] = dict(sira=sira, ad=rec.get('ad', ''), no=str(rec.get('no', '')), sinif=rec.get('sinif', ''), ders=rec.get('ders', ''))
        c['onay'] = False   # değişiklik oldu: yeniden onaylanır (gönderim her değişiklikte)
        self.yok_send(st, plan)
    def yok_confirm(self, st, plan):
        self.yok_state(st)['onay'] = True; self.yok_send(st, plan)
    def yok_send(self, st, plan, final=False):
        c = self.yok_state(st); pl = self.kelebek_plan(st['date'], st['lesson']) or {}; day = st['date'].isoformat()
        try: n = int(str(st['lesson']).split('.')[0])
        except ValueError: n = 0
        cell = lesson_cell(plan['sinif'], st['date'].weekday(), n) or {}
        data = dict(tarih=day, ders=st['lesson'], ders_no=str(n) if n else str(st['lesson']).split('.')[0].strip(), salon=plan['sinif'], sinav=pl.get('sinav', ''), ogrenci=len(plan['liste']),
                    gozetmen=[pl['gozcu'][plan['sinif']]] if pl.get('gozcu', {}).get(plan['sinif']) else cell.get('ogretmen', []), onay=c['onay'], kapandi=bool(final), zaman=time.time(), mesajlar=c.get('mesajlar', []),
                    gelmedi=[dict(r, ders_adi=tr_title(r.get('ders')) or exam_course(day, st['lesson'], r.get('sinif'), pl.get('sinav', ''))) for r in sorted(c['gelmedi'].values(), key=lambda r: r['sira'])])
        try:
            with open(c['path'] + '.yeni', 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False)
            os.replace(c['path'] + '.yeni', c['path'])
        except OSError: return
        c['sent'] = time.monotonic(); c['final'] = c['final'] or final
        self.run_havuz('--yoklama-yaz', c['path'])
    def salon_message(self, st, plan, metin, kagit=None):
        """Salondan Öğretmenler odasına mesaj (kâğıt eksik, soruda hata…): yoklama dosyasıyla birlikte hemen gönderilir."""
        c = self.yok_state(st); c.setdefault('mesajlar', []).append(dict(id='%s-%d' % (plan['sinif'], int(time.time()*1000)), metin=metin, kagit=kagit or {}, zaman=time.time()))
        self.yok_send(st, plan)
    def kagit_geldi(self, st, plan, ref):
        """Gözcü 'Kâğıt geldi' dedi: Öğretmenler odasındaki alarm/rozet kapanır (mesaj olarak gider, okundu sayılır)."""
        c = self.yok_state(st)
        if any(m.get('tur') == 'geldi' and m.get('ref') == ref for m in c.get('mesajlar', [])): return
        c.setdefault('mesajlar', []).append(dict(id='%s-%d' % (plan['sinif'], int(time.time()*1000)), metin='Kâğıt ulaştı', tur='geldi', ref=ref, kagit={}, zaman=time.time()))
        self.yok_send(st, plan)
    def kagit_events(self, st, plan):
        """Öğretmenler odasından bu salona gelen kâğıt yanıtları: {mesaj id: {'goruldu': kayıt, 'kagit_yolda': kayıt}}."""
        try:
            with open(os.path.join(self.yok_dir(), 'duyuru-gelen.json'), encoding='utf-8') as f: lst = json.load(f)
        except (OSError, ValueError): return {}
        ev = {}
        for d in lst if isinstance(lst, list) else []:
            if not isinstance(d, dict) or d.get('tur') not in ('goruldu', 'kagit_yolda') or not d.get('ref'): continue
            if d.get('tarih') != st['date'].isoformat() or d.get('ders') != st['lesson'] or plan['sinif'] not in d.get('hedef', []): continue
            ev.setdefault(d['ref'], {})[d['tur']] = d
        return ev
    def kagit_last(self, st):
        """Bu salonun henüz 'geldi' denmemiş son kâğıt bildirimi (yoksa None)."""
        ms_ = self.yok_state(st).get('mesajlar', []); done = {m.get('ref') for m in ms_ if m.get('tur') == 'geldi'}
        lst = [m for m in ms_ if any((m.get('kagit') or {}).values()) and m.get('id') not in done]
        return lst[-1] if lst else None
    def yok_tick(self, st):
        """Sınav sürerken: yoklamayı 2 dakikada bir yeniden gönder (bağlantı kopsa da ulaşsın), süre dolunca son hâlini gönder; duyuruları al."""
        if not st or st.get('phase') not in ('before', 'during', 'after'): return
        plan = self.seat_plan(dict(st, phase='during'))
        if not plan or plan.get('tur') != 'salon': return
        c = self.yok_state(st)
        if self.yok_open(st):
            if time.monotonic() - c['sent'] > 120: self.yok_send(st, plan)
        elif not c['final'] and st['t'] >= st['end']: self.yok_send(st, plan, final=True)   # yalnız sınav bitince (açılmadan önce kapatma)
        kl_ = self.kagit_last(st); iv_ = 60
        if kl_ is not None and 'kagit_yolda' not in self.kagit_events(st, plan).get(kl_.get('id'), {}): iv_ = 15   # kâğıt yanıtı beklenirken 15 sn'de bir
        if time.monotonic() - getattr(self, 'duyuru_t', -1e9) > iv_:
            self.duyuru_t = time.monotonic(); self.run_havuz('--duyuru-oku', os.path.join(self.yok_dir(), 'duyuru-gelen.json'))
        es = self.exam_screen
        if es is None: return
        try: es.update_kagit(st, plan)
        except Exception: pass
        try:
            with open(os.path.join(self.yok_dir(), 'duyuru-gelen.json'), encoding='utf-8') as f: lst = json.load(f)
        except (OSError, ValueError): return
        seen = self.duyuru_seen_ids()
        mine = [d for d in lst if isinstance(d, dict) and not d.get('tur') and d.get('tarih') == st['date'].isoformat() and d.get('ders') == st['lesson']
                and ('*' in d.get('hedef', []) or plan['sinif'] in d.get('hedef', [])) and d.get('id') not in seen]
        if mine: es.show_duyuru(max(mine, key=lambda d: d.get('zaman', 0)))
    def duyuru_seen_ids(self):
        try:
            with open(os.path.join(self.yok_dir(), 'duyuru-okundu.json'), encoding='utf-8') as f: return set(json.load(f))
        except (OSError, ValueError, TypeError): return set()
    def duyuru_seen(self, i):
        if not i: return
        ids = sorted(self.duyuru_seen_ids() | {i})[-200:]
        try:
            with open(os.path.join(self.yok_dir(), 'duyuru-okundu.json'), 'w', encoding='utf-8') as f: json.dump(ids, f)
        except OSError: pass
    # ---- Karargah (Öğretmenler odası) ----
    def karargah_exam(self):
        """Bugünün, şu an Karargah'ta gösterilecek kelebek sınavı: (plan, gün, ders, başlangıç, bitiş) — sınavdan 10 dk önce ile bitişten 15 dk sonra arası."""
        import datetime
        self.take_kelebek(); now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        for pl in (self.kelebek or {}).get('planlar', []):
            if pl.get('tarih') != now.date().isoformat() or not pl.get('salonlar'): continue
            span = exam_span(now.weekday(), pl.get('ders'), now.date())
            if span and span[0] - EXAM_BEFORE <= t < span[1] + 15*60: return (pl, now.date(), pl['ders'], span[0], span[1])
        return None
    def karargah_tick(self):
        if self.board_info().get('sinif') not in CLASS_PLACES or getattr(self, '_kar_busy', False): return
        self._kar_busy = True
        try: self._karargah_tick()
        finally: self._kar_busy = False
    def _karargah_tick(self):
        ex = self.karargah_exam(); kg = getattr(self, 'karargah', None)
        if ex is not None:
            key = self.yok_key(ex[1], ex[2])
            if time.monotonic() - getattr(self, 'kar_read_t', -1e9) > 15:
                self.kar_read_t = time.monotonic(); self.run_havuz('--yoklama-oku', '', os.path.join(self.yok_dir(), 'tum.json'))
            if kg is None and self.karargah_kagit_bekliyor(ex): self.karargah_hidden_t = 0   # kâğıt eksik: Gizle'yi beklemeden öne gel
            if kg is None and time.monotonic() > getattr(self, 'karargah_hidden_t', 0):
                self.hide_welcome(); self.board.finish(); self.close_salons()
                if self.isMinimized(): self.showFullScreen()
                kg = self.karargah = KarargahScreen(self); kg.setGeometry(self.rect()); kg.show(); kg.raise_()
            if kg is not None:
                kg.set_exam(ex)
                if getattr(self, 'welcome', None) is not None and self.welcome.isVisible(): self.hide_welcome()
                if kg.isVisible(): kg.raise_()
        elif kg is not None and not kg.manual: self.close_karargah()
        self.report_tick()
    def karargah_kagit_bekliyor(self, ex):
        try:
            key = self.yok_key(ex[1], ex[2]); data = self.yok_all(); done = KagitAlarm.handled_ids(self)
            for s_ in ex[0].get('salonlar', {}):
                ms_ = (data.get('%s_%s.json' % (key, s_)) or {}).get('mesajlar', []); gel = {m.get('ref') for m in ms_ if m.get('tur') == 'geldi'}
                if any(any((m.get('kagit') or {}).values()) and m.get('id') not in done and m.get('id') not in gel for m in ms_): return True
        except Exception: return False
        return False
    def open_karargah(self):
        ex = self.karargah_exam() or self.karargah_last()
        if ex is None: return
        self.karargah_hidden_t = 0; self.hide_welcome(); self.board.finish()
        if getattr(self, 'karargah', None) is None: self.karargah = KarargahScreen(self); self.karargah.setGeometry(self.rect())
        self.karargah.manual = True; self.karargah.set_exam(ex); self.karargah.show(); self.karargah.raise_()
        self.run_havuz('--yoklama-oku', '', os.path.join(self.yok_dir(), 'tum.json'))
    def karargah_last(self):
        import datetime
        self.take_kelebek(); now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second; best = None
        for pl in (self.kelebek or {}).get('planlar', []):
            if pl.get('tarih') != now.date().isoformat() or not pl.get('salonlar'): continue
            span = exam_span(now.weekday(), pl.get('ders'), now.date())
            if span and span[0] <= t: best = (pl, now.date(), pl['ders'], span[0], span[1])
        return best
    def close_karargah(self):
        kg = getattr(self, 'karargah', None)
        if kg is not None:
            if kg.ex: self.karargah_hidden_t = time.monotonic() + 120   # Gizle: 2 dakika sonra sınav ekranı yeniden gelir
            kg.hide(); kg.deleteLater(); self.karargah = None
    def yok_all(self):
        """Drive'dan gelen bütün yoklamalar {dosya adı: içerik} (Karargah)."""
        path = os.path.join(self.yok_dir(), 'tum.json')
        try: m = os.path.getmtime(path)
        except OSError: return {}
        if getattr(self, '_yok_all', (None, None))[0] != m:
            try:
                with open(path, encoding='utf-8') as f: self._yok_all = (m, json.load(f))
            except (OSError, ValueError): return getattr(self, '_yok_all', (None, {}))[1] or {}
        return self._yok_all[1]
    def send_duyuru(self, metin, hedef, ex, extra=None):
        path = os.path.join(self.yok_dir(), 'duyuru.json')
        try:
            with open(path, encoding='utf-8') as f: lst = json.load(f)
        except (OSError, ValueError): lst = []
        lst = [d for d in lst if isinstance(d, dict)]
        try:   # DersMap de aynı dosyaya yazıyor: Drive'dan en son okunan kopyadaki kayıtlar kaybolmasın
            with open(os.path.join(self.yok_dir(), 'duyuru-gelen.json'), encoding='utf-8') as f: uzak = json.load(f)
            ids = {d.get('id') for d in lst}
            lst += [d for d in (uzak if isinstance(uzak, list) else []) if isinstance(d, dict) and d.get('id') not in ids]
            lst.sort(key=lambda d: float(d.get('zaman') or 0))
        except (OSError, ValueError, TypeError): pass
        lst = lst[-80:]
        d_ = dict(id='%d' % int(time.time()*1000), tarih=ex[1].isoformat(), ders=ex[2], metin=metin, hedef=hedef or ['*'], zaman=time.time())
        if extra: d_.update(extra)
        lst.append(d_)
        try:
            with open(path, 'w', encoding='utf-8') as f: json.dump(lst, f, ensure_ascii=False)
        except OSError: return False
        self.run_havuz('--duyuru-yaz', path); return True
    def report_tick(self):
        """Sınav bitiminden 3 dk sonra gelmeyenler PDF'i ve güncel mazeret listesi Drive'daki 'Sınav Yoklamaları' klasörüne."""
        self.take_kelebek(); now = self.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        for pl in (self.kelebek or {}).get('planlar', []):
            if pl.get('tarih') != now.date().isoformat() or not pl.get('salonlar') or pl.get('ders') == DENEME_DERS: continue
            span = exam_span(now.weekday(), pl.get('ders'), now.date())
            if not span or t < span[1] + 60: continue
            key = self.yok_key(now.date(), pl['ders']); flag = os.path.join(self.yok_dir(), 'rapor-%s.tamam' % key)
            if os.path.exists(flag): continue
            if t < span[1] + 180:   # son yoklamalar Drive'a ulaşsın
                if time.monotonic() - getattr(self, 'kar_read_t', -1e9) > 30:
                    self.kar_read_t = time.monotonic(); self.run_havuz('--yoklama-oku', '', os.path.join(self.yok_dir(), 'tum.json'))
                continue
            try: self.make_reports((pl, now.date(), pl['ders'], span[0], span[1]))
            except Exception as e: print('rapor:', e); continue
            open(flag, 'w').close()
    def make_reports(self, ex, upload=True):
        out = yoklama_reports(self, ex, self.yok_all(), self.yok_dir())
        if upload:
            for path, name in out: self.run_havuz('--yukle', path, name)
        return out
    def _msg_poll_tekrar(self): self._msg_poll_bekle = False; self.poll_messages()
    def poll_messages(self):
        # Kalem akıcılığı: yazarken / az önce dokunulmuşken bekler (en çok 15 sn ertelenir)
        drawing = getattr(getattr(self, 'board', None), 'active', None) is not None
        if (drawing or time.time() - getattr(self, 'last_touch', 0) < 3) and time.time() - getattr(self, '_msg_poll_t', 0) < 35:
            if not getattr(self, '_msg_poll_bekle', False):
                self._msg_poll_bekle = True; QTimer.singleShot(3000, self._msg_poll_tekrar)
            return
        self._msg_poll_t = time.time()
        self.run_havuz('--mesajlar', self.board_info().get('sinif') or '-', self.msg_out)
    def load_messages(self):
        try: mt = os.path.getmtime(self.msg_out)
        except OSError: mt = None
        if mt != self.msg_mtime:
            self.msg_mtime = mt
            try:
                with open(self.msg_out, encoding='utf-8') as f: d = json.load(f)
                self.msgs_all = [m for m in d.get('mesajlar', []) if isinstance(m, dict) and m.get('id')]
                self.cmds_all = [m for m in d.get('komutlar', []) if isinstance(m, dict) and m.get('id')]
            except (OSError, ValueError, AttributeError): self.msgs_all = []; self.cmds_all = []
        if getattr(self, 'printer_scan_done', False): self.printer_scan_done = False; self.send_state()
        now = time.time(); done = self.board_info().get('mesaj', {})
        for c in getattr(self, 'cmds_all', []):   # panelden komut: bir kez uygulanır, şerit çıkmaz
            if not done.get(c['id'], {}).get('o') and not (c.get('bitis') and c['bitis'] < now):
                self.run_command(c); done = self.board_info().get('mesaj', {})
        live = [m for m in self.msgs_all if not (m.get('bitis') and m['bitis'] < now) and not done.get(m['id'], {}).get('o')]
        kapla = [m for m in live if m.get('kapla') and m.get('tur') in (None, '', 'bilgi')]   # K-341: tahtayı kaplayan mesaj
        live = [m for m in live if m not in kapla]
        try: self.acil_goster(kapla)
        except Exception as e: print('acil mesaj:', e)
        if self.update_ready and now >= self.update_snooze:   # yeni sürüm kuruldu: yeniden başlatma şeridi en önde
            live.append(dict(id='_surum', tur='surum', zaman=now, metin='Sürüm %s kuruldu. Yeniden başlatınca açık sekmeleriniz, sayfanız ve yazılarınız olduğu gibi geri gelir (birkaç saniye sürer).' % self.update_ready))
        live.sort(key=lambda m: (m.get('tur') != 'surum', m.get('tur') != 'hata', -(m.get('zaman') or 0)))   # hatalı soru önce, sonra en yeni
        if [m['id'] for m in live] != [m['id'] for m in self.msgs]:
            cur = self.msgs[self.msg_index]['id'] if self.msgs else None
            self.msgs = live; self.msg_index = next((i for i, m in enumerate(live) if m['id'] == cur), 0); self.show_message()
        elif self.msgs and self.isVisible() and not self.isMinimized(): self.mark_message(self.msgs[self.msg_index]['id'], 'g')
    def check_installed(self):
        """Arka planda yeni sürüm kurulduysa (otomatik ya da panelden) öğretmene yeniden başlatmayı sorar."""
        v = installed_version()
        if v and v != 'bilinmiyor' and getattr(self, 'version_cached', '') not in ('', 'bilinmiyor', v) and v != self.update_ready:
            self.update_ready = v; self.update_snooze = 0; self.load_messages()
            info = self.board_info()
            if info.get('otomatik_yeniden') != v:   # aynı sürüm için en çok bir kez
                info['otomatik_yeniden'] = v; self.save_board_info(info)
                self.auto_restart_t0 = time.time(); QTimer.singleShot(3000, self.auto_restart)
    def auto_restart(self):
        """Yeni sürüm kurulunca öğretmeni beklemeden yeniden açılır; yalnız kalem yazarken değil (10 sn dokunulmayınca).
        Her şey kaydedilir, aynı sekme ve sayfadan devam eder. Kurulum olmadıysa sürüm değişmez, buraya hiç gelinmez."""
        if not self.update_ready: return
        idle = time.time() - getattr(self, 'last_touch', 0)
        drawing = getattr(self.board, 'active', None) is not None
        if drawing or (idle < 10 and time.time() - getattr(self, 'auto_restart_t0', 0) < 600):
            QTimer.singleShot(3000, self.auto_restart); return   # yazarken hiç; dokunulurken en çok 10 dk beklenir
        self.restart_app()
    def restart_app(self):
        """Yeni sürümle yeniden aç: önce her şey kaydedilir, yeni açılış aynı sekme ve sayfadan devam eder."""
        try:
            self.board.finish(); self.save_session()
            if self.tabs: self.write_tabs()
        except Exception as ex: print('yeniden başlatma kaydı:', ex)
        try:
            with open(os.path.join(self.data_dir, 'yeniden-baslat.json'), 'w', encoding='utf-8') as f:
                json.dump(dict(tam_ekran=self.isFullScreen(), zaman=time.time()), f)
        except OSError: pass
        lock = getattr(QApplication.instance(), 'umal_lock', None)
        if lock is not None: lock.unlock()   # yeni açılış "zaten açık" demesin
        if os.path.isfile(APP_LAUNCHER): ok = QProcess.startDetached(APP_LAUNCHER, ['--yeniden'])
        else: ok = QProcess.startDetached(sys.executable, [os.path.abspath(__file__), '--yeniden'])
        if not ok:
            if lock is not None: lock.tryLock(100)
            self.statusBar().showMessage('Yeniden başlatılamadı; uygulamayı kapatıp açın.'); return
        if self.screen_session: self.screen_session.active = False
        QApplication.instance().quit()
    def resume_after_restart(self):
        path = os.path.join(self.data_dir, 'yeniden-baslat.json')
        try:
            with open(path, encoding='utf-8') as f: d = json.load(f)
            os.remove(path)
        except (OSError, ValueError): return
        if isinstance(d, dict) and d.get('tam_ekran') and time.time() - d.get('zaman', 0) < 120:
            self.showFullScreen(); QTimer.singleShot(100, self.fit_page)   # açılış animasyonu yok
        self.statusBar().showMessage('Yeni sürümle açıldı: ' + version_label())
    def run_command(self, c):
        if c.get('komut') == 'guncelle':   # Ayarlar'daki "Güncellemeyi denetle" ile aynı istek
            try:
                with open(UPDATE_REQUEST, 'w') as f: f.write(str(time.time()))
            except OSError: pass
            QTimer.singleShot(240000, self.send_state)   # kurulduysa panel "kurulu" sürümü görsün
        elif c.get('komut') == 'yazici_ara':   # arka planda; bitince sonuç durum bildirimiyle gider
            import threading
            def run():
                try: res = scan_printers()
                except Exception as ex: res = dict(zaman=time.time(), hata=str(ex)[:200], bulunan=[])
                info = self.board_info(); info['yazicilar'] = res; self.save_board_info(info)
                self.printer_scan_done = True   # ana iş parçacığı (load_messages) durumu gönderir
            threading.Thread(target=run, daemon=True).start()
        self.mark_message(c['id'], 'g'); self.mark_message(c['id'], 'o')
    def show_message(self):
        if not self.msgs: self.msg_bar.hide(); return
        self.msg_index %= len(self.msgs); m = self.msgs[self.msg_index]
        self.msg_bar.show_msg(m, self.msg_index, len(self.msgs))
        if self.isVisible() and not self.isMinimized(): self.mark_message(m['id'], 'g')
    def mark_message(self, mid, key):
        """g: tahtada göründü, o: öğretmen onayladı (Tamam / Sınıfa okudum / Aç). Panel durum bildiriminden okur."""
        if mid.startswith('_'): return   # tahtanın kendi şeridi (yeni sürüm): panele bildirilmez
        info = self.board_info(); d = info.get('mesaj') if isinstance(info.get('mesaj'), dict) else {}
        e = d.setdefault(mid, {})
        if key in e: return
        e[key] = int(time.time())
        for k in sorted(d, key=lambda k: max(d[k].values() or [0]))[:max(0, len(d) - 40)]: d.pop(k)
        info['mesaj'] = d; self.save_board_info(info)
        if key == 'o' or len(e) == 1: QTimer.singleShot(500, self.send_state)   # panel hemen görsün
    def acil_goster(self, L):
        """K-341: idarenin "tahtayı kapla" mesajı: tahta küçültülmüş olsa da öne gelir, tam ekran olur, her şeyin üstünde durur; "Okudum" deyince kalkar."""
        ov = getattr(self, 'acil', None)
        if not L:
            if ov is not None and ov.isVisible(): ov.hide()
            return
        m = max(L, key=lambda m: m.get('zaman') or 0)
        if ov is not None and ov.isVisible() and ov.mid == m['id']: return
        if ov is None: ov = self.acil = AcilMesaj(self)
        try: self.board.finish()
        except Exception: pass
        if self.isMinimized() or not self.isFullScreen(): self.showFullScreen()
        self.hide_welcome(); ov.goster(m); ov.setGeometry(self.rect()); ov.show(); ov.raise_(); self.raise_(); self.activateWindow()
        try: play_sound(os.path.join(_APP_DIR, 'sesler', 'bildirim.wav'), 1.0)
        except Exception: pass
        self.mark_message(m['id'], 'g')
    def acil_ust(self):
        ov = getattr(self, 'acil', None)
        if ov is not None and ov.isVisible():
            if ov.geometry() != self.rect(): ov.setGeometry(self.rect())
            ov.raise_()
    def acil_okudum(self, mid):
        ov = getattr(self, 'acil', None)
        if ov is not None: ov.hide()
        self.mark_message(mid, 'o'); self.msgs_all = [m for m in self.msgs_all if m.get('id') != mid]; self.load_messages()
    def next_message(self):
        if self.msgs: self.msg_index = (self.msg_index + 1) % len(self.msgs); self.show_message()
    def ack_message(self):
        if not self.msgs: return
        if self.msgs[self.msg_index % len(self.msgs)].get('tur') == 'surum': self.restart_app(); return
        m = self.msgs.pop(self.msg_index % len(self.msgs)); self.mark_message(m['id'], 'o'); self.show_message()
    def open_message_pdf(self):
        if not self.msgs: return
        m = self.msgs[self.msg_index % len(self.msgs)]
        if m.get('tur') == 'surum':   # "Sonra": ders bitene kadar sorma
            self.update_snooze = time.time() + 40*60; self.msgs.pop(self.msg_index % len(self.msgs)); self.show_message(); return
        src = m.get('pdf_yol')
        if not src or not os.path.isfile(src): self.statusBar().showMessage('Belge henüz inmedi; biraz sonra yeniden deneyin.'); return
        name = _re.sub(r'[\\/:*?"<>|]+', ' ', str((m.get('pdf') or {}).get('ad') or 'belge.pdf')).strip() or 'belge.pdf'
        if not name.lower().endswith('.pdf'): name += '.pdf'
        folder = os.path.join(self.data_dir, 'Gelen belgeler'); os.makedirs(folder, exist_ok=True)
        dst = os.path.join(folder, name)
        try: shutil.copyfile(src, dst)
        except OSError: dst = src
        self.ack_message(); self.open_pdf_path(dst)
    # ---- PDF Havuzu ------------------------------------------------------
    def run_havuz(self, *args):
        if not havuz_ready(): return
        if HAVUZ_PYTHON: QProcess.startDetached(HAVUZ_PYTHON, [HAVUZ_TOOL] + list(args))
        else: QProcess.startDetached(HAVUZ_TOOL, list(args))
    def open_print(self):
        self.board.finish(); PrintDialog(self).exec_()
    def open_havuz(self):
        self.board.finish(); HavuzDialog(self).exec_()
    def open_calc(self):
        if getattr(self,'calculator',None) is None: self.calculator = CalculatorPanel(self)
        self.calculator.open_calc()
    def open_timer(self):
        if getattr(self,'timer_screen',None) is None: self.timer_screen = TimerScreen(self)
        self.timer_screen.open_timer()
    def maybe_extend(self, stroke):
        """Endless solution area / blank board: writing near the bottom adds more space below."""
        if not self.endless(): return
        low = max(q[1] for q in stroke['points']); screen = self.scroll.viewport().height()/max(self.zoom, .1)
        # Always at least one screen of empty space below the lowest writing.
        need = low + screen + 48
        if need <= self.doc[0].rect.height: return
        # Uzatma pahalı (sayfa baştan oluşur, tamamı yeniden çizilir): seyrek yapılır (bir ekran fazlası)
        # ve kalem yazarken değil, kısa bir arada. Altta yer gerçekten azaldıysa hemen.
        self.extend_target = max(getattr(self, 'extend_target', 0), need + screen)
        if self.doc[0].rect.height - low < screen*.45:   # altta yer azaldı: hemen (eskisi gibi), ama bir ekran fazlasıyla
            target = self.extend_target; self.extend_target = 0
            t = getattr(self, 'extend_timer', None)
            if t is not None: t.stop()
            self.resize_solution(target); return
        t = getattr(self, 'extend_timer', None)
        if t is None:
            t = self.extend_timer = QTimer(self); t.setSingleShot(True); t.timeout.connect(self.extend_now)
        t.start(650)
    def extend_now(self):
        t = getattr(self, 'extend_timer', None)
        if self.board.active is not None:   # hâlâ yazıyor: arayı bekle
            if t is not None: t.start(400)
            return
        target = getattr(self, 'extend_target', 0); self.extend_target = 0
        if t is not None: t.stop()
        if target and self.endless() and target > self.doc[0].rect.height: self.resize_solution(target)
    SOLUTION_MAX = 60000
    def endless(self):   # Çözüm alanı ve boş tahta aşağı doğru sınırsız uzar
        return self.in_solution() or (self.background is not None and self.solution_origin is None and len(self.doc) == 1)
    def in_solution(self):
        return self.solution_origin is not None and (self.doc.metadata.get('keywords') or '') == 'UMAL-solution'
    def scrolled(self, value):
        """Scrolling to the bottom of a solution area adds another screen."""
        bar = self.scroll.verticalScrollBar()
        if self.endless() and bar.maximum() > 0 and value >= bar.maximum() - 4:
            self.resize_solution(self.doc[0].rect.height + self.scroll.viewport().height()/max(self.zoom, .1))
    def resize_solution(self, height):
        old = self.doc; page = old[0].rect
        height = min(self.SOLUTION_MAX, math.ceil(height/24)*24)
        if height <= page.height: return
        if not self.in_solution():   # boş tahta: zemin yeniden çizilir, yazılar ayrı tutulur
            new = make_board(self.background, page.width, height)
        else:
            bg = (self.solution_origin or {}).get('bg', 'grid')
            new = make_board(bg, page.width, height); new[0].show_pdf_page(page, old, 0)
            new.set_metadata(dict(old.metadata or {}, keywords='UMAL-solution'))
        b = self.board; r_ = getattr(b, 'base_rect', None); bk = getattr(b, 'base_key', None)
        pk, fp = b.mark_key()
        # Ekranın hazır kopyası bu sayfanınsa ve ondan sonra yalnızca yeni çizgiler eklendiyse uzatmadan sonra da kullanılabilir
        keep = getattr(b, 'base', None) is not None and r_ is not None and bk is not None and bk[0] == pk and fp[:len(bk[1])] == bk[1]
        self.doc = new; old.close(); self.session_pdf_pending = True
        self.grow_only = True
        try: self.render()
        finally: self.grow_only = False
        if keep and b.base_rect.contains(b.visibleRegion().boundingRect()): b.base_key = (b.mark_key()[0], b.base_key[1])   # sayfa yalnız aşağı uzadı: görünen alan ve içindeki çizgiler aynı
        self.changed()
    def solution_zoom(self):
        # Çözüm alanı genişliğe sığar (soru kartı make_solution'da buna göre boyutlanır), en üstten başlar.
        self.set_zoom(getattr(self,'solution_fit',None) or 2.0)
        self.scroll.horizontalScrollBar().setValue(0);self.scroll.verticalScrollBar().setValue(0)
    def go_to_page(self):
        target=page_number_dialog(self,len(self.doc),self.page+1)
        if target: self.goto(target-1-self.page)
    def content_rect(self):
        """Area actually used on the page (text, drawings, images, notes),
        ignoring white margins and full-page backgrounds."""
        page=self.doc[self.page];full=page.rect;area=full.width*full.height;r=fitz.Rect()
        try:
            for kind,box in page.get_bboxlog():
                b=fitz.Rect(box)&full
                if b.is_empty or b.width*b.height>.9*area:continue
                r|=b
        except Exception:return full
        for s in self.marks.get(self.page,[]):
            if s['tool']=='whiteout':continue
            xs=[q[0] for q in s['points']];ys=[q[1] for q in s['points']];w=s.get('width',3)
            r|=fitz.Rect(min(xs)-w,min(ys)-w,max(xs)+w,max(ys)+w)&full
        if r.is_empty or r.width<20 or r.height<20:return full
        pad=max(8,min(r.width,r.height)*.03)
        return fitz.Rect(r.x0-pad,r.y0-pad,r.x1+pad,r.y1+pad)&full
    def fit_page(self):
        # Sığdır: show the questions as large as possible (content, not margins).
        r=self.content_rect();vw=self.scroll.viewport().width()-8;vh=self.scroll.viewport().height()-8
        if self.endless() and not self.in_solution():   # uzamış boş tahta: genişliğe sığdır, en üstten başla
            w=self.doc[0].rect.width;r=fitz.Rect(0,0,w,min(self.doc[0].rect.height,w*vh/max(vw,1)))
        self.set_zoom(min(vw/r.width,vh/r.height))
        self.scroll.horizontalScrollBar().setValue(int(r.x0*self.zoom-(vw-r.width*self.zoom)/2))
        self.scroll.verticalScrollBar().setValue(int(r.y0*self.zoom-(vh-r.height*self.zoom)/2))
    def render(self):
        if getattr(self, 'pano', None) is not None and self.pano_dir is None: self.load_postits()
        try:
            page = self.doc[self.page]; QTimer.singleShot(0, self.geo_sync_bar)
            # Endless solution area: only the top (question card) is a picture;
            # the grid/white below is painted by the board, so it stays sharp
            # and light however long the area grows.
            self.board.pattern = (self.solution_origin or {}).get('bg','grid') if self.in_solution() else (self.background if self.endless() else None)
            clip = fitz.Rect(0,0,page.rect.width,min(page.rect.height,800)) if self.board.pattern else page.rect
            self.board.image_height = clip.height if self.board.pattern else None
            # Bound rendering memory even for oversized engineering pages.
            scale = min(self.zoom, math.sqrt(14000000/(clip.width*clip.height)))
            prev_h = getattr(self, 'grow_prev_h', None); self.grow_prev_h = clip.height
            reuse = (getattr(self, 'grow_only', False) and self.board.pattern and not self.board.image.isNull()
                     and self.board.scale == self.zoom and prev_h == clip.height)   # sonsuz sayfa aşağı uzadı: üstteki görüntü aynı
            if not reuse:
                pix = page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,colorspace=fitz.csRGB,alpha=False)
                # Limit raster memory without reducing display zoom or pen coordinates.
                self.board.scale = self.zoom
                self.board.image = QImage(pix.samples,pix.width,pix.height,pix.stride,QImage.Format_RGB888).copy()
            al = (Qt.AlignHCenter | Qt.AlignTop) if self.endless() else Qt.AlignCenter   # sonsuz sayfa büyürken yerinden zıplamasın
            if self.scroll.alignment() != al: self.scroll.setAlignment(al)
            self.board.setFixedSize(math.ceil(page.rect.width*self.zoom),math.ceil(page.rect.height*self.zoom)); self.board.update()
            QTimer.singleShot(0,self.scroll.viewport().update)   # gölge sayfanın yeni yerine
            self.page_label.setText('%s / %s  ·  %%%s' % (self.page+1,len(self.doc),round(self.zoom*100)))
            if hasattr(self,'nav'):self.place_overlays()
        except Exception as e: QMessageBox.warning(self,'Sayfa görüntülenemedi',str(e))
    def fullscreen(self):
        going = not self.isFullScreen()
        self.showNormal() if self.isFullScreen() else self.showFullScreen()
        QTimer.singleShot(100,self.fit_page)
        if going: QTimer.singleShot(180, self.play_intro)   # tam ekrana geçerken açılış animasyonu
    def play_intro(self):
        old = getattr(self, 'intro', None)
        if old is not None: old.finish()
        try: self.intro = IntroOverlay(self)
        except Exception as ex: print('açılış animasyonu:', ex); self.intro = None
    def closeEvent(self, e):
        self.board.finish()
        self.save_session()
        if not self.confirm_leave(): e.ignore(); return
        if self.screen_session:
            if not self.screen_session.confirm_close(): e.ignore(); return
            self.screen_session.active=False
            self.screen_session.board.hide(); self.screen_session.toolbar.hide();self.screen_session.floating.hide()
        e.accept()

# ---------------------------------------------------------------------------
# Açılış animasyonu (Tam ekran'a basınca): okul logosu sırayla oluşur — önce mavi daire,
# sonra iç halka (kırmızı zemin ve monogram), en son okulun adı ve yılı; tek kalem sesi ve
# tek kapanış sesi. Yaklaşık 3,6 sn; dokunmak geçer.
_APP_DIR = os.path.dirname(os.path.abspath(__file__))
INTRO_SOUND = os.path.join(_APP_DIR, 'sesler', 'acilis.wav')
from PyQt5.QtGui import QRadialGradient, QLinearGradient, QPainterPath

IT_D0, IT_D1 = .10, .90      # daire
IT_I0, IT_I1 = .85, 1.50     # iç halka
IT_Y0, IT_Y1 = 1.50, 2.25    # okulun adı
IT_S0, IT_S1 = 2.20, 2.55    # yıl
IT_FULL = 2.55              # gerçek logoya geçiş
IT_F0, IT_END = 3.15, 3.65   # tahta görünür
INTRO_A0, INTRO_SWEEP = 240, 278  # adın başladığı açı (saat 8 civarı) ve süpürme (saat yönünde, tepeden geçerek)

def intro_clamp(v): return max(0.0, min(1.0, v))
def intro_ease(v): v = intro_clamp(v); return 1 - (1 - v)**3
def intro_ease_io(v): v = intro_clamp(v); return v*v*(3 - 2*v)
def intro_back(v):
    v = intro_clamp(v); c = 1.5
    return 1 + (c + 1)*(v - 1)**3 + c*(v - 1)**2

def intro_load_assets(folder=_APP_DIR):
    return {k: QImage(os.path.join(folder, 'acilis-%s.png' % k)) for k in ('daire', 'ic', 'yazi', 'logo2')}

def intro_glow(p, c, r, col, a):
    g = QRadialGradient(c, r); g.setColorAt(0, QColor(col.red(), col.green(), col.blue(), int(max(0, min(255, a))))); g.setColorAt(1, QColor(col.red(), col.green(), col.blue(), 0))
    p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(c, r, r)

def intro_wedge(C, rect, a0, sweep):
    path = QPainterPath(C); path.arcTo(rect, a0, sweep); path.closeSubpath(); return path

def intro_draw(p, t, W, H, A, bg=None):
    p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
    base = 1 - intro_ease_io((t - IT_F0)/(IT_END - IT_F0))
    if bg is not None: p.setOpacity(base); bg(p); p.setOpacity(1)
    D = H*.56; C = QPointF(W/2, H*.48); rect = QRectF(C.x() - D/2, C.y() - D/2, D, D); big = rect.adjusted(-D, -D, D, D)
    pulse = 1 + .03*math.sin(math.pi*intro_clamp((t - IT_FULL)/.4))
    p.save(); p.setOpacity(base); p.translate(C); p.scale(pulse, pulse); p.translate(-C)
    intro_glow(p, C, D*.78, QColor(70, 110, 255), 80*intro_ease((t - .05)/.7))
    full = intro_ease_io((t - IT_FULL)/.25)
    # 1) Daire: tepeden başlayıp saat yönünde
    e = intro_ease_io((t - IT_D0)/(IT_D1 - IT_D0))
    if e > 0 and full < 1:
        p.save(); p.setClipPath(intro_wedge(C, big, 90, -360*e)); p.drawImage(rect, A['daire']); p.restore()
        if e < 1:
            an = math.radians(90 - 360*e); q = QPointF(C.x() + math.cos(an)*D*.43, C.y() - math.sin(an)*D*.43)
            intro_glow(p, q, D*.10, QColor(170, 200, 255), 200); intro_glow(p, q, D*.03, QColor(255, 255, 255), 255)
    # 2) İç halka: ortadan açılır, ışınlar parlar
    e = intro_back((t - IT_I0)/(IT_I1 - IT_I0))
    if e > 0 and full < 1:
        r_ = D*.5*e; path = QPainterPath(); path.addEllipse(C, r_, r_)
        p.save(); p.setClipPath(path); p.drawImage(rect, A['ic']); p.restore()
        a = 1 - intro_clamp((t - IT_I0)/.55)
        if a > 0: intro_glow(p, C, D*.30*max(e, .2), QColor(255, 240, 215), 230*a)
    # 3) Okulun adı: harf harf, halka boyunca
    e = intro_ease_io((t - IT_Y0)/(IT_Y1 - IT_Y0))
    if e > 0 and full < 1:
        p.save(); p.setClipPath(intro_wedge(C, big, INTRO_A0, -INTRO_SWEEP*e)); p.drawImage(rect, A['yazi']); p.restore()
        if e < 1:
            an = math.radians(INTRO_A0 - INTRO_SWEEP*e); q = QPointF(C.x() + math.cos(an)*D*.43, C.y() - math.sin(an)*D*.43)
            intro_glow(p, q, D*.07, QColor(255, 245, 210), 220); intro_glow(p, q, D*.022, QColor(255, 255, 255), 255)
    # 4) Yıl: soldan sağa
    e = intro_ease_io((t - IT_S0)/(IT_S1 - IT_S0))
    if e > 0 and full < 1:
        path = QPainterPath(); path.addRect(QRectF(rect.left(), C.y() + D*.20, D*(.28 + .44*e), D*.32))
        p.save(); p.setClipPath(intro_wedge(C, big, INTRO_A0, 360 - INTRO_SWEEP).intersected(path)); p.drawImage(rect, A['yazi']); p.restore()
    # 5) Gerçek logo + parıltı
    if full > 0:
        p.save(); p.setOpacity(base*full); p.drawImage(rect, A['logo2']); p.restore()
        u = intro_clamp((t - IT_FULL - .05)/.55)
        if 0 < u < 1:   # çapraz parlama bandı
            clip = QPainterPath(); clip.addEllipse(C, D/2, D/2); p.save(); p.setClipPath(clip)
            x = rect.left() - D*.4 + (D*1.8)*u; g = QLinearGradient(QPointF(x - D*.18, rect.top()), QPointF(x + D*.18, rect.bottom()))
            g.setColorAt(0, QColor(255, 255, 255, 0)); g.setColorAt(.5, QColor(255, 255, 255, 120)); g.setColorAt(1, QColor(255, 255, 255, 0))
            p.fillRect(rect, g); p.restore()
        u = (t - IT_FULL)/.8
        if 0 < u < 1:
            p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor(190, 210, 255, int(190*(1 - u))), 5*(1 - u) + 1)); p.drawEllipse(C, D*.5*(1 + .45*u), D*.5*(1 + .45*u))
    p.restore()
    # 6) Uygulamanın adı: logonun altında belirir
    u = intro_ease_io((t - IT_FULL - .15)/.5)
    if u > 0:
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); f = QFont(fams.get('Poppins-Bold') or 'Sans'); f.setPixelSize(int(H*.062)); f.setWeight(QFont.Bold); f.setLetterSpacing(QFont.PercentageSpacing, 104)
        p.save(); p.setOpacity(base*u); p.setFont(f); p.setPen(QColor('#ffffff'))
        y = C.y() + D/2 + H*.035 + (1 - u)*H*.02
        p.drawText(QRectF(0, y, W, H*.09), Qt.AlignHCenter | Qt.AlignTop, PRODUCT)
        p.restore()
    return t >= IT_END

class IntroOverlay(QWidget):
    def __init__(self, main, sound=True):
        super().__init__(main); self.main = main; self.setGeometry(main.rect()); self.setFocusPolicy(Qt.StrongFocus)
        from PyQt5.QtCore import QElapsedTimer
        self.assets = intro_load_assets()
        if any(im.isNull() for im in self.assets.values()): raise RuntimeError('açılış görselleri yok')
        self.clock = QElapsedTimer(); self.clock.start(); self.done = False
        self.timer = QTimer(self); self.timer.timeout.connect(self.update); self.timer.start(16)
        if sound and os.path.isfile(INTRO_SOUND): play_sound(INTRO_SOUND, .9)
        self.show(); self.raise_(); self.setFocus()
    def paint_bg(self, p):
        from PyQt5.QtGui import QRadialGradient
        W, H = self.width(), self.height()
        g = QRadialGradient(QPointF(W/2, H*.45), W*.75); g.setColorAt(0, QColor('#1d3566')); g.setColorAt(.6, QColor('#0d1a33')); g.setColorAt(1, QColor('#060c18'))
        p.fillRect(self.rect(), g)
    def finish(self):
        if self.done: return
        self.done = True; self.timer.stop(); self.hide(); self.deleteLater()
        if getattr(self.main, 'intro', None) is self: self.main.intro = None
        try:
            k = getattr(play_sound, 'keep', None)
            if k is not None and k.source().toLocalFile() == INTRO_SOUND: k.stop()
        except Exception: pass
    def mousePressEvent(self, e): self.finish()
    def keyPressEvent(self, e): self.finish()
    def event(self, e):
        if e.type() == QEvent.TouchBegin: self.finish(); return True
        return super().event(e)
    def paintEvent(self, e):
        pw = self.parentWidget()
        if pw is not None and pw.size() != self.size(): self.setGeometry(pw.rect())   # tam ekrana geçiş sürerken
        t = self.clock.elapsed()/1000
        if t >= IT_END: QTimer.singleShot(0, self.finish); return
        p = QPainter(self); intro_draw(p, t, self.width(), self.height(), self.assets, self.paint_bg); p.end()


# ---------------------------------------------------------------------------
# Full-screen classroom timer (Sayaç): ring, digital and analog faces.
TIMER_STYLES = [('ring','Halka'),('digital','Dijital'),('analog','Analog')]
TIMER_PRESETS = [1,3,5,10,15,20,30,40]

def soft_chime_file(folder):
    """A very soft two-note bell, generated once (no external sound file)."""
    import wave, struct
    path = os.path.join(folder, 'yumusak-zil.wav')
    if os.path.isfile(path): return path
    os.makedirs(folder, exist_ok=True)
    rate = 44100; frames = []
    notes = [(0.0, 659.25), (0.55, 523.25)]          # E5 → C5, gentle descending
    length = int(rate*3.2)
    for i in range(length):
        t = i/rate; v = 0.0
        for start, f in notes:
            dt = t-start
            if dt < 0: continue
            env = min(1, dt/0.02) * math.exp(-dt*1.6)   # soft attack, long fade
            v += env*(math.sin(2*math.pi*f*dt) + .35*math.sin(2*math.pi*2*f*dt) + .12*math.sin(2*math.pi*3*f*dt))
        frames.append(struct.pack('<h', int(max(-1, min(1, v*.16))*32767)))
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b''.join(frames))
    return path

def play_sound(path, volume=.7):
    try:
        from PyQt5.QtMultimedia import QSoundEffect
        from PyQt5.QtCore import QUrl
        effect = QSoundEffect(); effect.setSource(QUrl.fromLocalFile(path)); effect.setVolume(volume); effect.play()
        play_sound.keep = effect; return True
    except Exception: pass
    import subprocess
    for cmd in (['paplay', path], ['pw-play', path], ['aplay', '-q', path]):
        try: subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
        except OSError: continue
    return False

class TimerScreen(QWidget):
    def __init__(self, main):
        super().__init__(None, Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.main = main
        self.setWindowTitle('Sayaç • '+PRODUCT); self.setWindowIcon(QIcon(LOGO))
        self.cfg_path = os.path.join(main.data_dir, 'sayac.json')
        try:
            with open(self.cfg_path, encoding='utf-8') as f: cfg = json.load(f)
        except (OSError, ValueError): cfg = {}
        self.total = max(10, min(3*3600, int(cfg.get('seconds', 600))))
        self.face = cfg.get('style', 'ring') if cfg.get('style') in dict(TIMER_STYLES) else 'ring'
        self.state = 'setup'; self.remaining = self.total; self.end_at = None; self.done_at = None
        self.ticker = QTimer(self); self.ticker.setInterval(40); self.ticker.timeout.connect(self.tick)
        self.setStyleSheet('''QPushButton{background:rgba(255,255,255,.07);color:#e8eefc;border:1px solid rgba(255,255,255,.16);
                border-radius:26px;font-family:"DejaVu Sans";font-size:20px;padding:0 22px;min-height:52px;}
            QPushButton:hover{background:rgba(255,255,255,.13);}
            QPushButton:checked{background:rgba(125,211,252,.22);border:2px solid #7dd3fc;}
            QPushButton#start{background:#3b82f6;border:none;font-weight:bold;font-size:22px;}
            QPushButton#close{background:rgba(251,113,133,.16);border:1px solid rgba(251,113,133,.6);}''')
        def btn(text, fn, name=''):
            b = QPushButton(text, self); b.setObjectName(name); b.clicked.connect(fn); b.setFocusPolicy(Qt.NoFocus); return b
        self.close_btn = btn('✕  Kapat', self.close_timer, 'close')
        self.face_btns = {}
        for key, label in TIMER_STYLES:
            b = btn(label, lambda checked=False, k=key: self.set_face(k)); b.setCheckable(True); self.face_btns[key] = b
        self.presets = [btn('%d dk' % m, lambda checked=False, m=m: self.set_total(m*60)) for m in TIMER_PRESETS]
        self.adjust = [btn(t, lambda checked=False, d=d: self.set_total(self.total+d)) for t, d in
                       (('−5 dk',-300),('−1 dk',-60),('−10 sn',-10),('+10 sn',10),('+1 dk',60),('+5 dk',300))]
        self.start_btn = btn('▶  Başlat', self.start, 'start')
        self.pause_btn = btn('❚❚  Duraklat', self.toggle_pause)
        self.restart_btn = btn('↺  Yeniden başlat', self.start)
        self.change_btn = btn('Süreyi değiştir', self.back_to_setup)
        self.set_face(self.face, save=False); self.update_controls()

    # ---- state ----------------------------------------------------------
    def save_cfg(self):
        try:
            os.makedirs(os.path.dirname(self.cfg_path), exist_ok=True)
            with open(self.cfg_path, 'w', encoding='utf-8') as f: json.dump(dict(seconds=self.total, style=self.face), f)
        except OSError: pass
    def set_face(self, key, save=True):
        self.face = key
        for k, b in self.face_btns.items(): b.setChecked(k == key)
        if save: self.save_cfg()
        self.update()
    def set_total(self, seconds):
        self.total = max(10, min(3*3600, int(seconds)))
        if self.state == 'setup': self.remaining = self.total
        self.update()
    def start(self):
        import time
        self.save_cfg()   # the last started duration becomes the default
        self.state = 'running'; self.remaining = self.total; self.end_at = time.monotonic()+self.total
        self.ticker.start(); self.update_controls(); self.update()
    def toggle_pause(self):
        import time
        if self.state == 'running':
            self.remaining = max(0, self.end_at-time.monotonic()); self.state = 'paused'
        elif self.state == 'paused':
            self.end_at = time.monotonic()+self.remaining; self.state = 'running'
        self.update_controls(); self.update()
    def back_to_setup(self):
        self.state = 'setup'; self.remaining = self.total; self.ticker.stop(); self.update_controls(); self.update()
    def tick(self):
        import time
        if self.state == 'running':
            self.remaining = max(0, self.end_at-time.monotonic())
            if self.remaining <= 0:
                self.state = 'done'; self.done_at = time.monotonic(); self.update_controls()
                try: play_sound(soft_chime_file(self.main.data_dir))
                except Exception: pass
        elif self.state == 'done' and time.monotonic()-self.done_at > 30: self.ticker.stop()
        self.update()
    def open_timer(self):
        if getattr(self, 'mini_timer', None) is not None: self.mini_timer.hide()
        screen = self.main.windowHandle().screen() if self.main.windowHandle() else QApplication.primaryScreen()
        self.setGeometry(screen.geometry()); self.showFullScreen(); self.raise_(); self.activateWindow()
    def close_timer(self):
        # Süre işliyorsa "Kapat" sayacı kapatmaz: tahtanın kenarına küçük sayaç olarak iner.
        if self.state in ('running', 'paused'):
            self.hide(); self.mini().show_mini(); return
        self.stop_timer()
    def stop_timer(self):
        """Sayacı tamamen kapatır (küçük sayaçtaki ✕)."""
        self.ticker.stop(); self.state = 'setup'; self.remaining = self.total; self.update_controls(); self.hide()
        if getattr(self, 'mini_timer', None) is not None: self.mini_timer.hide()
    def mini(self):
        if getattr(self, 'mini_timer', None) is None: self.mini_timer = MiniTimer(self)
        return self.mini_timer
    def closeEvent(self, e):
        self.ticker.stop(); self.state = 'setup'; self.remaining = self.total; self.update_controls(); super().closeEvent(e)

    # ---- layout ----------------------------------------------------------
    def update_controls(self):
        setup = self.state == 'setup'
        for b in self.presets+self.adjust+[self.start_btn]: b.setVisible(setup)
        for b in (self.pause_btn, self.restart_btn, self.change_btn): b.setVisible(not setup)
        self.pause_btn.setVisible(self.state in ('running','paused'))
        self.pause_btn.setText('▶  Devam' if self.state == 'paused' else '❚❚  Duraklat')
        self.layout_controls()
    def row(self, buttons, y, gap=14):
        widths = [230 if b is self.start_btn else (128 if b in self.presets+self.adjust else max(150, b.fontMetrics().boundingRect(b.text()).width()+64)) for b in buttons]
        x = (self.width()-sum(widths)-gap*(len(buttons)-1))//2
        for b, w in zip(buttons, widths): b.setGeometry(x, y, w, 56); x += w+gap
    def layout_controls(self):
        W, H = self.width(), self.height()
        self.close_btn.setGeometry(W-200, 28, 172, 56)
        self.row([self.face_btns[k] for k, _ in TIMER_STYLES], 28)
        if self.state == 'setup':
            self.row(self.presets, H-212); self.row(self.adjust[:3]+[self.start_btn]+self.adjust[3:], H-136)
        else:
            self.row([b for b in (self.pause_btn, self.restart_btn, self.change_btn) if b.isVisible()], H-120)
    def resizeEvent(self, e): self.layout_controls(); super().resizeEvent(e)

    # ---- drawing ---------------------------------------------------------
    def palette(self):
        frac = self.remaining/self.total if self.total else 0
        if self.state == 'done': return QColor('#34d399'), QColor('#6ee7b7')
        if frac <= .1: return QColor('#fb7185'), QColor('#f43f5e')
        if frac <= .25: return QColor('#fbbf24'), QColor('#f59e0b')
        return QColor('#38bdf8'), QColor('#818cf8')
    def time_text(self):
        s = int(math.ceil(self.remaining-1e-6)); h, m, sec = s//3600, s%3600//60, s%60
        return '%d:%02d:%02d' % (h, m, sec) if h else '%02d:%02d' % (m, sec)
    def end_text(self):
        import datetime
        if self.state == 'setup': return 'Süre: %d dakika%s' % (self.total//60, ' %d saniye' % (self.total%60) if self.total%60 else '')
        if self.state == 'done': return 'Süre doldu'
        if self.state == 'paused': return 'Duraklatıldı'
        return 'Bitiş  %s' % (datetime.datetime.now()+datetime.timedelta(seconds=self.remaining)).strftime('%H:%M')
    def font(self, px, bold=False, light=False):
        from PyQt5.QtGui import QFont
        f = QFont('DejaVu Sans'); f.setPixelSize(max(8, int(px))); f.setBold(bold)
        if light: f.setWeight(QFont.Light)
        return f
    def paintEvent(self, e):
        from PyQt5.QtGui import QLinearGradient, QRadialGradient
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height()
        g = QLinearGradient(0, 0, W, H); g.setColorAt(0, QColor('#070d1a')); g.setColorAt(1, QColor('#111c33'))
        p.fillRect(self.rect(), g)
        a, b = self.palette()
        glow = QRadialGradient(W/2, H/2, min(W, H)*.55); c = QColor(a); c.setAlpha(28); glow.setColorAt(0, c); glow.setColorAt(1, QColor(0,0,0,0))
        p.fillRect(self.rect(), glow)
        p.setPen(QColor(232,238,252,150)); p.setFont(self.font(20, True)); p.drawText(QRectF(32, 28, 300, 56), Qt.AlignVCenter, '◷  Sayaç')
        bottom = 240 if self.state == 'setup' else 150
        R = QRectF(0, 100, W, H-100-bottom)
        getattr(self, 'draw_'+self.face)(p, R, a, b)
    def pulse(self):
        import time
        if self.state != 'done': return 1
        return .55+.45*(.5+.5*math.cos((time.monotonic()-self.done_at)*2.4))
    def frac(self): return 1.0 if self.state == 'setup' else (self.remaining/self.total if self.total else 0)
    def draw_ring(self, p, R, a, b):
        from PyQt5.QtGui import QConicalGradient
        size = min(R.width(), R.height())*.92; c = R.center(); r = size/2; thick = size*.055
        box = QRectF(c.x()-r+thick/2, c.y()-r+thick/2, size-thick, size-thick)
        p.setPen(QPen(QColor(255,255,255,22), thick, Qt.SolidLine, Qt.RoundCap)); p.drawEllipse(box)
        f = self.frac()
        if self.state == 'done': f = 1
        if f > 0:
            grad = QConicalGradient(c, 90); grad.setColorAt(0, a); grad.setColorAt(1, b)
            pen = QPen(grad, thick, Qt.SolidLine, Qt.RoundCap); p.setPen(pen); p.setOpacity(self.pulse())
            p.drawArc(box, 90*16, int(-f*360*16)); p.setOpacity(1)
            ang = math.radians(90-f*360); hx = c.x()+math.cos(ang)*box.width()/2; hy = c.y()-math.sin(ang)*box.height()/2
            p.setPen(Qt.NoPen); p.setBrush(QColor('#ffffff')); p.drawEllipse(QPointF(hx, hy), thick*.32, thick*.32)
        self.center_text(p, c, size, a)
    def center_text(self, p, c, size, a):
        p.setPen(QColor(232,238,252,140)); p.setFont(self.font(size*.045, True))
        p.drawText(QRectF(c.x()-size/2, c.y()-size*.24, size, size*.08), Qt.AlignCenter, 'KALAN SÜRE' if self.state != 'setup' else 'SÜRE')
        p.setPen(QColor('#f4f7ff')); p.setFont(self.font(size*(.2 if self.remaining >= 3600 else .26), light=True))
        p.setOpacity(self.pulse()); p.drawText(QRectF(c.x()-size/2, c.y()-size*.17, size, size*.3), Qt.AlignCenter, self.time_text()); p.setOpacity(1)
        p.setPen(a); p.setFont(self.font(size*.05, True))
        p.drawText(QRectF(c.x()-size/2, c.y()+size*.15, size, size*.09), Qt.AlignCenter, self.end_text())
    def draw_digital(self, p, R, a, b):
        from PyQt5.QtGui import QLinearGradient
        import time
        text = self.time_text(); px = min(R.height()*.5, R.width()/(len(text)*.62))
        p.setFont(self.font(px, True)); fm = p.fontMetrics()
        cy = R.center().y()-R.height()*.06
        tw = fm.horizontalAdvance(text) if hasattr(fm, 'horizontalAdvance') else fm.width(text)
        x = R.center().x()-tw/2
        blink = self.state == 'running' and (time.monotonic() % 1) > .5
        p.setOpacity(self.pulse())
        for ch in text:
            w = fm.horizontalAdvance(ch) if hasattr(fm, 'horizontalAdvance') else fm.width(ch)
            col = QColor('#f4f7ff') if ch != ':' else QColor(a)
            if ch == ':' and blink: col.setAlpha(70)
            p.setPen(col); p.drawText(QRectF(x, cy-px*.6, w, px*1.2), Qt.AlignCenter, ch); x += w
        p.setOpacity(1)
        bw = R.width()*.62; bh = max(10, R.height()*.03); bx = R.center().x()-bw/2; by = cy+px*.62
        p.setPen(Qt.NoPen); p.setBrush(QColor(255,255,255,22)); p.drawRoundedRect(QRectF(bx, by, bw, bh), bh/2, bh/2)
        f = 1 if self.state == 'done' else self.frac()
        if f > 0:
            g = QLinearGradient(bx, 0, bx+bw, 0); g.setColorAt(0, a); g.setColorAt(1, b); p.setBrush(g)
            p.drawRoundedRect(QRectF(bx, by, max(bh, bw*f), bh), bh/2, bh/2)
        p.setPen(a); p.setFont(self.font(R.height()*.05, True))
        p.drawText(QRectF(R.left(), by+bh*2.2, R.width(), R.height()*.09), Qt.AlignCenter, self.end_text())
    def draw_analog(self, p, R, a, b):
        size = min(R.width(), R.height())*.9; c = R.center(); r = size/2
        scale = 60*60 if self.total <= 3600 else int(math.ceil(self.total/1800.0))*1800
        p.setPen(Qt.NoPen); p.setBrush(QColor(255,255,255,12)); p.drawEllipse(c, r, r)
        p.setPen(QPen(QColor(255,255,255,40), 2)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, r, r)
        for i in range(60):
            ang = math.radians(90-i*6); major = i % 5 == 0
            r1 = r*(.86 if major else .91); r2 = r*.95
            p.setPen(QPen(QColor(232,238,252,200 if major else 70), 4 if major else 2, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(QPointF(c.x()+math.cos(ang)*r1, c.y()-math.sin(ang)*r1), QPointF(c.x()+math.cos(ang)*r2, c.y()-math.sin(ang)*r2))
            if major:
                label = str(int(i/60*scale/60)); tr = r*.76
                p.setPen(QColor(232,238,252,170)); p.setFont(self.font(size*.045, True))
                p.drawText(QRectF(c.x()+math.cos(ang)*tr-size*.06, c.y()-math.sin(ang)*tr-size*.035, size*.12, size*.07), Qt.AlignCenter, label)
        rem = self.total if self.state == 'setup' else self.remaining
        span = 0 if self.state == 'done' else min(1, rem/scale)
        sr = r*.68
        if span > 0:
            col = QColor(a); col.setAlpha(225); p.setPen(Qt.NoPen); p.setBrush(col)
            p.drawPie(QRectF(c.x()-sr, c.y()-sr, 2*sr, 2*sr), 90*16, int(-span*360*16))
            ang = math.radians(90-span*360)
            p.setPen(QPen(QColor('#ffffff'), 5, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(c, QPointF(c.x()+math.cos(ang)*sr, c.y()-math.sin(ang)*sr))
        p.setPen(QPen(QColor(255,255,255,60), 2)); p.setBrush(QColor('#0b1426')); p.drawEllipse(c, size*.07, size*.07)
        p.setPen(QColor('#f4f7ff')); p.setFont(self.font(size*.045, True)); p.setOpacity(self.pulse())
        p.drawText(QRectF(c.x()-size*.07, c.y()-size*.03, size*.14, size*.06), Qt.AlignCenter, self.time_text() if len(self.time_text()) <= 5 else self.time_text()[:-3])
        p.setOpacity(1); p.setPen(a); p.setFont(self.font(size*.05, True))
        p.drawText(QRectF(R.left(), c.y()+r*.3, R.width(), size*.08), Qt.AlignCenter, self.end_text() if self.state != 'setup' else '')
# ---------------------------------------------------------------------------
# Scientific calculator (touch friendly, safe evaluation — no eval()).
class Celebration(QWidget):
    """Alkış gösterisi: art arda roketler havada patlar, iki yandan ve üstten konfeti
    yağar; yaklaşık 6 saniye sonra kendiliğinden biter. Yazılara dokunmaz, dokunmayı engellemez."""
    DUR = 6.0; COLS = ['#e8132b', '#0057ff', '#00a24a', '#ffe14d', '#ff2d95', '#8a2be2', '#ff8a00', '#ffffff', '#38bdf8']
    def __init__(self, main):
        super().__init__(main); self.main = main
        self.setAttribute(Qt.WA_TransparentForMouseEvents); self.setAttribute(Qt.WA_NoSystemBackground); self.hide()
        self.timer = QTimer(self); self.timer.setInterval(30); self.timer.timeout.connect(self.step)
        self.cols = [QColor(c) for c in self.COLS]
    def start(self):
        import random
        R = random.Random(); self.rnd = R.uniform
        self.setGeometry(self.main.rect()); W, H = self.width(), self.height(); self.W, self.H = W, H; k = max(.6, H/1000)
        self.k = k; self.conf = []; self.sparks = []; self.rockets = []
        for side in (0, 1):   # konfeti topları
            x0 = W*(.97 if side else .03)
            for _ in range(230):
                a = R.uniform(.28, .62)*math.pi; v = R.uniform(14, 30)*k
                self.add_conf(x0, H*.98, (-1 if side else 1)*math.cos(a)*v, -math.sin(a)*v)
        for _ in range(200): self.add_conf(R.uniform(0, W), R.uniform(-H*.6, 0), R.uniform(-1, 1)*k, R.uniform(0, 3)*k)
        for i in range(9):   # roketler: alkış sesindeki gümbürtülerle aynı an (i·0.42 s'de kalkar, 0.95 s sonra patlar)
            self.rockets.append(dict(x=W*R.uniform(.15, .85), t=i*.42, vx=R.uniform(-1.5, 1.5)*k, c=R.randrange(7), peak=R.uniform(.55, .78), done=False, trail=[]))
        self.t0 = time.monotonic(); self.last = self.t0; self.show(); self.raise_(); self.timer.start()
    def add_conf(self, x, y, vx, vy):
        self.conf.append([x, y, vx, vy, self.rnd(8, 16)*self.k, self.rnd(4, 8)*self.k, self.rnd(0, 6), self.rnd(-.3, .3), int(self.rnd(0, len(self.COLS)-.01)), self.rnd(0, 6)])
    def rocket_pos(self, r, el):
        t = el - r['t']; H = self.H; fl = .95
        y = H - H*r['peak']*(1 - (1 - min(t, fl)/fl)**2); x = r['x'] + r['vx']*t*30
        return x, y
    def step(self):
        now = time.monotonic(); el = now - self.t0; f = min(3.0, (now - self.last)/.03); self.last = now
        if el > self.DUR: self.timer.stop(); self.hide(); self.conf = []; self.sparks = []; return
        g = .5*self.k*f
        for c in self.conf:
            c[3] += g; c[2] *= .985**f; c[3] *= .985**f; c[9] += .12*f
            c[0] += (c[2] + math.sin(c[9])*.8*self.k)*f; c[1] += c[3]*f; c[6] += c[7]*f
        for r in self.rockets:
            if el < r['t'] or r['done']: continue
            x, y = self.rocket_pos(r, el); r['trail'] = (r['trail'] + [(x, y)])[-12:]
            if el - r['t'] >= .95:
                r['done'] = True
                for i in range(80):
                    a = i/80*math.pi*2; v = self.rnd(4, 10)*self.k
                    self.sparks.append([x, y, math.cos(a)*v, math.sin(a)*v, 1.0, r['c'] if self.rnd(0, 1) > .25 else 7])
                for _ in range(30): self.add_conf(x, y, self.rnd(-7, 7)*self.k, self.rnd(-9, 3)*self.k)
        for s_ in self.sparks:
            s_[2] *= .96**f; s_[3] = s_[3]*.96**f + .12*self.k*f; s_[0] += s_[2]*f; s_[1] += s_[3]*f; s_[4] -= .016*f
        self.sparks = [s_ for s_ in self.sparks if s_[4] > 0]
        self.conf = [c for c in self.conf if c[1] < self.H + 40]
        self.update()
    def paintEvent(self, e):
        el = time.monotonic() - self.t0; p = QPainter(self)
        fade = 1.0 if el < 5.2 else max(0.0, 1 - (el - 5.2)/.8); p.setOpacity(fade); p.setPen(Qt.NoPen)
        for c in self.conf:   # dönen kâğıt: döndürülmüş dikdörtgen (dönüşümsüz, hızlı)
            x, y, w, h, r = c[0], c[1], c[4]/2, c[5]/2*abs(math.cos(c[6]*2)) + .5, c[6]
            ca, sa = math.cos(r), math.sin(r)
            p.setBrush(self.cols[c[8]])
            p.drawPolygon(QPolygonF([QPointF(x + ca*dx - sa*dy, y + sa*dx + ca*dy) for dx, dy in ((-w, -h), (w, -h), (w, h), (-w, h))]))
        p.setRenderHint(QPainter.Antialiasing)
        for r in self.rockets:
            if el < r['t'] or r['done'] or not r['trail']: continue
            n = len(r['trail'])
            for i, (x, y) in enumerate(r['trail']):
                a = (i + 1)/n; col = QColor(255, int(120 + 120*a), 40); col.setAlphaF(a); p.setBrush(col)
                rr = (1.5 + 3.5*a)*self.k; p.drawEllipse(QPointF(x, y + (n - i)*2*self.k), rr, rr)
            x, y = r['trail'][-1]; p.setBrush(self.cols[r['c']]); p.drawEllipse(QPointF(x, y), 4*self.k, 4*self.k)
        for s_ in self.sparks:
            col = QColor(self.cols[s_[5]]); col.setAlphaF(max(0.0, min(1.0, s_[4]))); p.setBrush(col)
            p.drawEllipse(QPointF(s_[0], s_[1]), 2.6*self.k, 2.6*self.k)

class MiniTimer(QWidget):
    """Küçük sayaç: tam ekran sayaç kapatılınca süre kenarda işlemeye devam eder.
    Dokun: tam ekrana döner · sürükle: yerini değiştirir · ✕: sayacı tamamen kapatır."""
    W, H = 236, 64
    def __init__(self, timer):
        super().__init__(None, Qt.Tool|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.timer = timer; self.press = None; self.moved = False; self.placed = False
        self.setFixedSize(self.W, self.H); self.setCursor(Qt.PointingHandCursor)
        from PyQt5.QtGui import QPainterPath
        path = QPainterPath(); path.addRoundedRect(QRectF(0, 0, self.W, self.H), 16, 16)
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))
        self.refresh = QTimer(self); self.refresh.setInterval(250); self.refresh.timeout.connect(self.update)
    def show_mini(self):
        if not self.placed:   # ilk kez: tahtanın sol üstü (oklar ve soru listesiyle çakışmaz)
            m = self.timer.main; vp = m.scroll.viewport(); g = vp.mapToGlobal(QPoint(14, 14)); self.move(g); self.placed = True
        self.refresh.start(); self.show(); self.raise_()
    def hideEvent(self, e): self.refresh.stop(); super().hideEvent(e)
    def close_rect(self): return QRectF(self.W-46, (self.H-34)/2, 34, 34)
    def paintEvent(self, e):
        t = self.timer; p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        done = t.state == 'done'; col = t.palette()[0]; paused = t.state == 'paused'
        p.setPen(QPen(col if done else QColor('#3a5577'), 2)); p.setBrush(QColor('#0f2442')); p.drawRoundedRect(QRectF(1, 1, self.W-2, self.H-2), 15, 15)
        c = QPointF(32, self.H/2); r = 18
        p.setPen(QPen(QColor('#24344f'), 5)); p.setBrush(Qt.NoBrush); p.drawEllipse(c, r, r)
        frac = 1.0 if done else (t.remaining/t.total if t.total else 0)
        p.setPen(QPen(col, 5, Qt.SolidLine, Qt.RoundCap)); p.drawArc(QRectF(c.x()-r, c.y()-r, 2*r, 2*r), 90*16, int(-360*16*frac))
        if paused:
            p.setPen(Qt.NoPen); p.setBrush(col); p.drawRect(QRectF(c.x()-6, c.y()-7, 4, 14)); p.drawRect(QRectF(c.x()+2, c.y()-7, 4, 14))
        f = p.font(); f.setPixelSize(19 if done else 26); f.setBold(True); p.setFont(f)
        p.setPen(col if (paused or done) else QColor('#f4f7ff'))
        p.drawText(QRectF(60, 0, self.W-112, self.H), Qt.AlignVCenter|Qt.AlignLeft, 'Süre doldu' if done else t.time_text())
        x = self.close_rect(); p.setPen(QPen(QColor(251, 113, 133, 160), 1)); p.setBrush(QColor(251, 113, 133, 40)); p.drawEllipse(x)
        p.setPen(QPen(QColor('#fb7185'), 2.2)); k = 6
        p.drawLine(QPointF(x.center().x()-k, x.center().y()-k), QPointF(x.center().x()+k, x.center().y()+k))
        p.drawLine(QPointF(x.center().x()-k, x.center().y()+k), QPointF(x.center().x()+k, x.center().y()-k))
    def mousePressEvent(self, e):
        self.press = (e.globalPos(), self.pos()); self.moved = False
    def mouseMoveEvent(self, e):
        if self.press is None: return
        d = e.globalPos() - self.press[0]
        if self.moved or abs(d.x()) + abs(d.y()) > 10: self.moved = True; self.move(self.press[1] + d)
    def mouseReleaseEvent(self, e):
        if self.press is None: return
        self.press = None
        if self.moved: return
        if self.close_rect().adjusted(-8, -8, 8, 8).contains(QPointF(e.pos())): self.timer.stop_timer()
        else: self.timer.open_timer()

def calc_evaluate(expr, degrees=True):
    import ast, re
    text = expr.replace('×','*').replace('÷','/').replace('−','-').replace(',','.').replace('π','pi').replace('^','**')
    text = text.replace('√','sqrt').replace('²','**2')
    text = re.sub(r'(\d+(?:\.\d+)?|\))\s*%', r'(\1/100)', text)
    # postfix factorial: number! or (...)!  ->  fact(...)
    while '!' in text:
        i = text.index('!'); j = i-1
        if j >= 0 and text[j] == ')':
            depth = 0
            while j >= 0:
                depth += text[j] == ')'; depth -= text[j] == '('
                if depth == 0: break
                j -= 1
        else:
            while j >= 0 and (text[j].isdigit() or text[j] == '.'): j -= 1
            j += 1
        if j < 0 or j >= i: raise ValueError('Hata')
        text = text[:j]+'fact('+text[j:i]+')'+text[i+1:]
    text = re.sub(r'(\d|\))\s*(?=\(|pi|e\b|sqrt|sin|cos|tan|ln|log|fact)', r'\1*', text)   # 2π, 3(4), 2sin(30)
    trig = (lambda f: (lambda x: f(math.radians(x)))) if degrees else (lambda f: f)
    def tan(x):
        a = math.radians(x) if degrees else x
        if abs(math.cos(a)) < 1e-12: raise ZeroDivisionError
        return math.tan(a)
    def fact(x):
        if x != int(x) or x < 0 or x > 170: raise ValueError('Hata')
        return float(math.factorial(int(x)))
    funcs = dict(sin=trig(math.sin), cos=trig(math.cos), tan=tan, ln=math.log, log=math.log10, sqrt=math.sqrt, fact=fact)
    names = dict(pi=math.pi, e=math.e)
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return float(n.value)
        if isinstance(n, ast.Name) and n.id in names: return names[n.id]
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            v = ev(n.operand); return v if isinstance(n.op, ast.UAdd) else -v
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add): return a+b
            if isinstance(n.op, ast.Sub): return a-b
            if isinstance(n.op, ast.Mult): return a*b
            if isinstance(n.op, ast.Div): return a/b
            if isinstance(n.op, ast.Pow):
                if abs(b) > 1000 or (abs(a) > 1 and abs(b*math.log10(abs(a))) > 300): raise OverflowError
                return a**b
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in funcs and len(n.args) == 1 and not n.keywords:
            return funcs[n.func.id](ev(n.args[0]))
        raise ValueError('Hata')
    value = ev(ast.parse(text, mode='eval'))
    if isinstance(value, complex) or math.isnan(value) or math.isinf(value): raise ValueError('Hata')
    return value

def calc_format(v):
    if abs(v) < 1e-12: v = 0.0
    if v == int(v) and abs(v) < 1e15: return '{:,}'.format(int(v)).replace(',', '.')
    s = ('%.12g' % v)
    if 'e' in s: m, ex = s.split('e'); return m.replace('.', ',')+' × 10^'+str(int(ex))
    return s.replace('.', ',')

class CalculatorPanel(QWidget):
    KEYS = [['sin','cos','tan','ln','log'],
            ['√','x²','xʸ','(',')'],
            ['π','e','n!','1/x','%'],
            ['7','8','9','÷','AC'],
            ['4','5','6','×','⌫'],
            ['1','2','3','−','Ans'],
            ['0',',','±','+','=']]
    def __init__(self, main):
        super().__init__(None, Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.main = main; self.expr = ''; self.result = ''; self.ans = 0.0; self.degrees = True; self.drag_from = None; self.just_evaluated = False
        self.setWindowTitle('Hesap makinesi • '+PRODUCT); self.setWindowIcon(QIcon(LOGO))
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet('''QWidget#calc{background:#0b1426;border:1px solid #2a3b57;border-radius:18px;}
            QLabel{color:#e8eefc;font-family:"DejaVu Sans";background:transparent;}
            QPushButton{font-family:"DejaVu Sans";font-size:22px;color:#e8eefc;background:#16233a;border:1px solid #24344f;border-radius:14px;}
            QPushButton:pressed{background:#24395c;}
            QPushButton#fn{font-size:19px;color:#a5c8ff;background:#111d31;}
            QPushButton#op{font-size:26px;color:#7dd3fc;background:#132a46;}
            QPushButton#eq{font-size:28px;font-weight:bold;background:#3b82f6;border:none;color:white;}
            QPushButton#ac{color:#fda4af;background:#2a1724;border:1px solid #4a2236;}
            QPushButton#mode{font-size:16px;border-radius:16px;padding:0 14px;}
            QPushButton#close{font-size:17px;border-radius:18px;padding:0 16px;color:#fecdd3;background:rgba(251,113,133,.16);border:1px solid rgba(251,113,133,.6);}''')
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0)
        panel = QWidget(); panel.setObjectName('calc'); outer.addWidget(panel)
        layout = QVBoxLayout(panel); layout.setContentsMargins(16,12,16,16); layout.setSpacing(10)
        bar = QHBoxLayout(); layout.addLayout(bar)
        title = QLabel('⋮⋮  Hesap makinesi'); title.setStyleSheet('font-size:17px;font-weight:bold;color:#9fb3d1;'); bar.addWidget(title, 1)
        self.mode = QPushButton('DEG'); self.mode.setObjectName('mode'); self.mode.setFixedHeight(36); self.mode.setToolTip('Derece / Radyan')
        self.mode.clicked.connect(self.toggle_mode); bar.addWidget(self.mode)
        close = QPushButton('✕  Kapat'); close.setObjectName('close'); close.setFixedHeight(40); close.clicked.connect(self.hide); bar.addWidget(close)
        screen = QWidget(); screen.setStyleSheet('background:#060c18;border-radius:14px;'); sl = QVBoxLayout(screen); sl.setContentsMargins(16,10,16,10); sl.setSpacing(2)
        self.expr_label = QLabel(''); self.expr_label.setAlignment(Qt.AlignRight|Qt.AlignVCenter); self.expr_label.setStyleSheet('font-size:20px;color:#8aa0c2;'); self.expr_label.setMinimumHeight(30)
        self.main_label = QLabel('0'); self.main_label.setAlignment(Qt.AlignRight|Qt.AlignVCenter); self.main_label.setStyleSheet('font-size:46px;color:#f4f7ff;'); self.main_label.setMinimumHeight(64)
        sl.addWidget(self.expr_label); sl.addWidget(self.main_label); layout.addWidget(screen)
        grid = QGridLayout(); grid.setSpacing(8); layout.addLayout(grid)
        for r, row in enumerate(self.KEYS):
            for c, key in enumerate(row):
                b = QPushButton(key); b.setFixedSize(84, 62); b.setFocusPolicy(Qt.NoFocus)
                b.setObjectName('eq' if key == '=' else 'ac' if key in ('AC','⌫') else 'op' if key in ('÷','×','−','+') else 'fn' if r < 3 or key == 'Ans' else '')
                b.clicked.connect(lambda checked=False, k=key: self.press(k)); grid.addWidget(b, r, c)
        self.adjustSize()
    def toggle_mode(self):
        self.degrees = not self.degrees; self.mode.setText('DEG' if self.degrees else 'RAD'); self.preview()
    def press(self, k):
        if k == 'AC': self.expr = ''; self.result = ''; self.just_evaluated = False; self.refresh(); return
        if k == '⌫':
            for token in ('sin(','cos(','tan(','ln(','log(','√('):
                if self.expr.endswith(token): self.expr = self.expr[:-len(token)]; break
            else: self.expr = self.expr[:-1]
            self.just_evaluated = False; self.refresh(); return
        if k == '=':
            if not self.expr: return
            try:
                v = calc_evaluate(self.expr, self.degrees); self.ans = v
                self.result = self.expr; self.expr = calc_format(v).replace('.', '') if ' × 10^' not in calc_format(v) else repr(v).replace('.', ',')
                self.just_evaluated = True
            except ZeroDivisionError: self.result = self.expr; self.expr = ''; self.main_label.setText('Tanımsız'); self.expr_label.setText(self.result+' ='); return
            except Exception: self.result = self.expr; self.expr = ''; self.main_label.setText('Hata'); self.expr_label.setText(self.result+' ='); return
            self.expr_label.setText(self.result+' ='); self.main_label.setText(calc_format(self.ans)); return
        operator = k in ('÷','×','−','+','xʸ','x²','n!','%')
        if self.just_evaluated and not operator: self.expr = ''
        self.just_evaluated = False
        insert = {'sin':'sin(','cos':'cos(','tan':'tan(','ln':'ln(','log':'log(','√':'√(','x²':'²','xʸ':'^','n!':'!','Ans':'Ans'}.get(k, k)
        if k == 'Ans': insert = calc_format(self.ans).replace('.', '') if ' × 10^' not in calc_format(self.ans) else repr(self.ans).replace('.', ',')
        if k == '1/x': self.expr = '1÷(' + (self.expr or '0') + ')'; self.refresh(); return
        if k == '±': self.expr = '−(' + self.expr + ')' if self.expr else '−'; self.refresh(); return
        self.expr += insert; self.refresh()
    def preview(self):
        try: return calc_format(calc_evaluate(self.expr, self.degrees))
        except Exception: return ''
    def refresh(self):
        self.main_label.setText(self.expr or '0')
        p = self.preview() if self.expr else ''
        self.expr_label.setText(('= '+p) if p and p != self.expr else '')
        f = self.main_label.font(); f.setPixelSize(46 if len(self.expr) < 15 else max(22, int(46*15/len(self.expr)))); self.main_label.setFont(f)
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton: self.drag_from = e.globalPos()-self.frameGeometry().topLeft()
    def mouseMoveEvent(self, e):
        if self.drag_from is not None: self.move(e.globalPos()-self.drag_from)
    def mouseReleaseEvent(self, e): self.drag_from = None
    def open_calc(self):
        screen = self.main.windowHandle().screen() if self.main.windowHandle() else QApplication.primaryScreen()
        g = screen.availableGeometry(); self.adjustSize()
        if not self.isVisible(): self.move(g.right()-self.width()-40, g.top()+120)
        self.show(); self.raise_(); self.activateWindow()
# ---------------------------------------------------------------------------
# Themes: colours + a subtle subject pattern around the page.
THEMES = {
    'default':  dict(name='Ümraniye Merkez Anadolu Lisesi', bg='#122034', btn='#22344c', btn2='#1b2b41', border='#364a63', hover='#304b68', sel='#bb1826', sel2='#d42335', selb='#e23b4d', view='#091423', ink='#3d5a80'),
    'turkiye':  dict(name='Türkiye',    bg='#1d0a0d', btn='#4a141b', btn2='#38101a', border='#7a2330', hover='#5e1a24', sel='#e30a17', sel2='#ff2a36', selb='#ffffff', view='#140507', ink='#e30a17'),
    'matematik':dict(name='Matematik',  bg='#10173a', btn='#222d66', btn2='#1a2352', border='#3a4a96', hover='#2c3a80', sel='#5b5bf0', sel2='#7c7cff', selb='#c7d2fe', view='#0a0f29', ink='#6d7cff'),
    'kimya':    dict(name='Kimya',      bg='#082425', btn='#10403f', btn2='#0c3231', border='#1d6966', hover='#145250', sel='#0d9488', sel2='#14b8a6', selb='#99f6e4', view='#051a1b', ink='#2dd4bf'),
    'cografya': dict(name='Coğrafya',   bg='#1a2214', btn='#33421f', btn2='#283418', border='#5a6e35', hover='#3f5226', sel='#b7791f', sel2='#d69e2e', selb='#fde68a', view='#11180c', ink='#a3b86c'),
    'fizik':    dict(name='Fizik',      bg='#140d2b', btn='#2a1c55', btn2='#211646', border='#4b3590', hover='#35246b', sel='#7c3aed', sel2='#9f67ff', selb='#ddd6fe', view='#0d081f', ink='#a78bfa'),
    'biyoloji': dict(name='Biyoloji',   bg='#0b2015', btn='#14402a', btn2='#103321', border='#23683f', hover='#1a5233', sel='#16a34a', sel2='#22c55e', selb='#bbf7d0', view='#06150d', ink='#4ade80'),
    'resim':    dict(name='Resim',      bg='#21141c', btn='#43263a', btn2='#351d2e', border='#74435f', hover='#56304a', sel='#d9482b', sel2='#f26b3f', selb='#ffd8a8', view='#170c13', ink='#f2a07b'),
}
THEME_ORDER = ['default','turkiye','matematik','kimya','cografya','fizik','biyoloji','resim']

def rgba(hexcol, a):
    c = QColor(hexcol); return 'rgba(%d,%d,%d,%.2f)' % (c.red(), c.green(), c.blue(), a)

def theme_style(t, tile):
    """Gece iskeleti (her temada aynı): cam görünümlü düğmeler, hap biçiminde sekmeler,
    yuvarlak köşeler; tema yalnızca rengi verir."""
    d = dict(t, glass='rgba(255,255,255,0.055)', glassb='rgba(255,255,255,0.11)', hover='rgba(255,255,255,0.10)',
             on=rgba(t['sel'], .34), onb=t['sel2'], font=(ui_fonts().get('Poppins-Regular') or 'DejaVu Sans'))
    return """QMainWindow,QWidget{background:%(bg)s;color:#eef3ff;font-family:"%(font)s","DejaVu Sans";font-size:15px;}
        QPushButton{background:%(glass)s;border:1px solid %(glassb)s;border-radius:12px;padding:8px 12px;min-height:24px;color:#eef3ff;}
        QPushButton:hover{background:%(hover)s;}
        QPushButton:pressed{background:rgba(255,255,255,0.14);}
        QPushButton:checked{background:%(on)s;border:2px solid %(onb)s;}
        QPushButton:disabled{color:rgba(238,243,255,0.35);}
        QPushButton#primary{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %(sel2)s,stop:1 %(sel)s);color:white;font-weight:600;border:1px solid rgba(255,255,255,0.22);}
        QScrollArea{background:%(view)s;border:none;border-radius:14px;}
        QScrollArea#tabs,QScrollArea#tabs > QWidget#qt_scrollarea_viewport{background:transparent;}
        QPushButton#tab{padding:6px 14px;border-radius:16px;border-top-right-radius:0;border-bottom-right-radius:0;border-right:none;}
        QPushButton#tabclose{padding:0;border-radius:16px;border-top-left-radius:0;border-bottom-left-radius:0;font-size:18px;}
        QPushButton#tab:checked,QPushButton#tabclose:checked{background:%(on)s;border:2px solid %(onb)s;}
        QPushButton#tab:checked{border-right:none;}
        QSpinBox,QLineEdit{padding:8px 10px;background:%(glass)s;border:1px solid %(glassb)s;border-radius:10px;}
        QLineEdit:focus{border:2px solid %(onb)s;}
        QComboBox{background:%(glass)s;border:1px solid %(glassb)s;border-radius:10px;padding:6px 10px;}
        QMenu{background:%(bg)s;border:1px solid %(glassb)s;border-radius:12px;padding:6px;}
        QMenu::item{border-radius:8px;} QMenu::item:selected{background:%(on)s;}
        QScrollBar:vertical{background:transparent;width:12px;margin:2px;} QScrollBar::handle:vertical{background:rgba(255,255,255,0.18);border-radius:5px;min-height:40px;}
        QScrollBar:horizontal{background:transparent;height:12px;margin:2px;} QScrollBar::handle:horizontal{background:rgba(255,255,255,0.18);border-radius:5px;min-width:40px;}
        QScrollBar::add-line,QScrollBar::sub-line{width:0;height:0;} QScrollBar::add-page,QScrollBar::sub-page{background:transparent;}
        QCheckBox{spacing:10px;background:transparent;}
        QCheckBox::indicator{width:22px;height:22px;border-radius:7px;border:1.5px solid rgba(255,255,255,0.40);background:rgba(255,255,255,0.06);}
        QCheckBox::indicator:checked{background:%(sel2)s;border:1.5px solid %(sel2)s;}
        QLabel{padding:2px;background:transparent;}""" % d

class PageScroll(QScrollArea):
    """Sayfanın arkası: konu deseni, tema renginde yumuşak ışık ve sayfanın gölgesi.
    Yalnızca sayfanın çevresi açıldığında çizilir; kalem yazarken çalışmaz."""
    def __init__(self):
        super().__init__(); self.tile = None; self.view = QColor('#091423'); self.accent = QColor('#bb1826')
        for bar in (self.horizontalScrollBar(), self.verticalScrollBar()): bar.valueChanged.connect(lambda _v: self.viewport().update())
    def set_theme(self, view, accent, tile_path):
        self.view = QColor(view); self.accent = QColor(accent)
        self.tile = QPixmap(tile_path) if tile_path and os.path.isfile(tile_path) else None
        self.bg = None; self.viewport().update()
    def background(self, size):
        """Desen + ışık bir kez hazır görüntüye çizilir (kaydırırken yalnızca kopyalanır)."""
        if getattr(self, 'bg', None) is not None and self.bg.size() == size: return self.bg
        from PyQt5.QtGui import QRadialGradient
        bg = QPixmap(size); bg.fill(self.view); p = QPainter(bg); r = QRect(QPoint(0, 0), size)
        if self.tile is not None and not self.tile.isNull(): p.drawTiledPixmap(r, self.tile)
        glow = QRadialGradient(QPointF(r.center()), max(r.width(), r.height())*.62)
        a = QColor(self.accent); a.setAlpha(80); glow.setColorAt(0, a); a2 = QColor(self.accent); a2.setAlpha(26); glow.setColorAt(.5, a2); glow.setColorAt(1, QColor(0, 0, 0, 0))
        p.fillRect(r, glow); p.end(); self.bg = bg; return bg
    def shadow(self, w, h):
        """Sayfa gölgesi: köşe/kenar parçaları bir kez çizilir (dokuz parça), her boyuta uyar."""
        if getattr(self, 'sh', None) is None:
            S = 40; img = QPixmap(3*S, 3*S); img.fill(Qt.transparent); p = QPainter(img); p.setRenderHint(QPainter.Antialiasing); p.setPen(Qt.NoPen)
            g = QRectF(S, S, S, S)
            for k in range(16, 0, -1): p.setBrush(QColor(0, 0, 0, int(4 + (16-k)*1.5))); p.drawRoundedRect(g.adjusted(-k, -k*.5, k, k*1.4), k, k)
            p.end(); self.sh = img
        return self.sh
    def paintEvent(self, e):
        vp = self.viewport(); p = QPainter(vp); er = e.rect()
        bg = self.background(vp.size()); p.drawPixmap(er, bg, er)
        b = self.widget()
        if b is not None and b.isVisible():   # yumuşak gölge: sayfa zeminden yükselmiş gibi
            g = b.geometry(); S = 40; sh = self.shadow(g.width(), g.height())
            x0, y0, x1, y1 = g.left()-S, g.top()-S, g.right()+1, g.bottom()+1
            parts = [(QRect(x0, y0, S, S), QRect(0, 0, S, S)), (QRect(x1, y0, S, S), QRect(2*S, 0, S, S)), (QRect(x0, y1, S, S), QRect(0, 2*S, S, S)), (QRect(x1, y1, S, S), QRect(2*S, 2*S, S, S)),
                     (QRect(g.left(), y0, g.width(), S), QRect(S, 0, S, S)), (QRect(g.left(), y1, g.width(), S), QRect(S, 2*S, S, S)),
                     (QRect(x0, g.top(), S, g.height()), QRect(0, S, S, S)), (QRect(x1, g.top(), S, g.height()), QRect(2*S, S, S, S))]
            for dst, src in parts:
                if dst.intersects(er): p.drawPixmap(dst, sh, src)

def make_theme_tile(key, path):
    """Seamless 480×480 pattern of faint subject motifs (drawn, no image files)."""
    import random
    from PyQt5.QtGui import QFont, QPainterPath, QTransform
    t = THEMES[key]; size = 480
    img = QImage(size, size, QImage.Format_RGB32); img.fill(QColor(t['view']))
    p = QPainter(img); p.setRenderHint(QPainter.Antialiasing); rnd = random.Random(key)
    ink = QColor(t['ink'])
    soft = 1.8 if key == 'default' else 1.0   # konu desenleri soluk: sayfayla yarışmasın
    def col(a): c = QColor(ink); c.setAlpha(min(255, int(a*soft))); return c
    def pen(a, w=2): p.setPen(QPen(col(a), w, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.setBrush(Qt.NoBrush)
    def text(s, x, y, px, a, serif=False, rot=0):
        f = QFont('DejaVu Serif' if serif else 'DejaVu Sans'); f.setPixelSize(px); f.setBold(not serif)
        p.save(); p.translate(x, y); p.rotate(rot); p.setFont(f); p.setPen(col(a)); p.drawText(QRectF(-200, -px, 400, px*2), Qt.AlignCenter, s); p.restore()
    def around(fn):   # draw at offsets so the tile repeats seamlessly
        for dx in (-size, 0, size):
            for dy in (-size, 0, size):
                p.save(); p.translate(dx, dy); fn(); p.restore()
    if key == 'default':
        def f():
            pen(22, 1)
            for i in range(0, size, 24): p.drawLine(i, 0, i, size); p.drawLine(0, i, size, i)
        around(f)
    elif key == 'turkiye':
        def crescent(cx, cy, r, a, rot):
            p.save(); p.translate(cx, cy); p.rotate(rot)
            outer = QPainterPath(); outer.addEllipse(QPointF(0, 0), r, r)
            inner = QPainterPath(); inner.addEllipse(QPointF(r*.25, 0), r*.8, r*.8)
            p.setPen(Qt.NoPen); p.setBrush(col(a)); p.drawPath(outer.subtracted(inner))
            star = QPolygonF([QPointF(r*.95+math.cos(math.radians(-90+i*36))*(r*.38 if i % 2 == 0 else r*.15),
                                      math.sin(math.radians(-90+i*36))*(r*.38 if i % 2 == 0 else r*.15)) for i in range(10)])
            p.drawPolygon(star); p.restore()
        def f():
            crescent(120, 120, 46, 70, -8); crescent(360, 330, 34, 52, 10); crescent(380, 90, 20, 40, 0); crescent(110, 380, 24, 44, -14)
            pen(30, 1.5)
            for k in range(3): p.drawArc(QRectF(-80+k*40, 200+k*14, 640, 240), 20*16, 140*16)
        around(f)
    elif key == 'matematik':
        def f():
            pen(26, 1)
            for i in range(0, size, 40): p.drawLine(i, 0, i, size); p.drawLine(0, i, size, i)
            pen(60, 2.5); path = QPainterPath(QPointF(40, 120))
            for x in range(40, 260, 4): path.lineTo(x, 120-((x-150)/40.0)**2*-6-60)
            p.drawPath(path)
            p.drawPolygon(QPolygonF([QPointF(300, 420), QPointF(440, 420), QPointF(300, 300)]))
            for s, x, y, px, a, r in [('π',380,90,64,70,-8),('∑',90,300,58,60,6),('√x',250,250,40,62,0),('∫',420,230,70,55,10),
                                       ('∞',170,430,44,55,0),('x²+y²=r²',230,40,22,60,0),('Δ',60,200,40,55,-6),('θ',340,190,36,55,4),('f(x)',140,190,26,55,0)]:
                text(s, x, y, px, a, True, r)
        around(f)
    elif key == 'kimya':
        def hexagon(cx, cy, r, a):
            pen(a, 2.5); p.drawPolygon(QPolygonF([QPointF(cx+r*math.cos(math.radians(30+60*i)), cy+r*math.sin(math.radians(30+60*i))) for i in range(6)]))
            p.drawEllipse(QPointF(cx, cy), r*.55, r*.55)
        def f():
            hexagon(110, 110, 52, 70); hexagon(110+90, 110+52, 52, 50); hexagon(380, 360, 40, 55)
            pen(60, 2.5); flask = QPainterPath(QPointF(330, 60)); flask.lineTo(330, 120); flask.lineTo(290, 200); flask.lineTo(410, 200); flask.lineTo(370, 120); flask.lineTo(370, 60)
            p.drawPath(flask); p.drawLine(QPointF(320, 60), QPointF(380, 60)); p.drawLine(QPointF(300, 180), QPointF(400, 180))
            for r in (0, 60, 120):
                p.save(); p.translate(120, 360); p.rotate(r); p.drawEllipse(QPointF(0, 0), 58, 20); p.restore()
            p.setBrush(col(70)); p.drawEllipse(QPointF(120, 360), 7, 7)
            for s, x, y, px, a in [('H₂O',260,300,30,65),('CO₂',420,250,26,55),('NaCl',250,440,26,55),('pH',40,260,30,60)]:
                text(s, x, y, px, a)
        around(f)
    elif key == 'cografya':
        def f():
            pen(40, 1.6)
            for k in range(6): p.drawEllipse(QPointF(130, 330), 30+k*22, 18+k*15)
            for k in range(4): p.drawEllipse(QPointF(380, 120), 20+k*20, 14+k*13)
            pen(28, 1)
            for y in range(40, size, 80):
                path = QPainterPath(QPointF(0, y))
                for x in range(0, size+1, 10): path.lineTo(x, y+math.sin(x/76.4)*8)
                p.drawPath(path)
            cx, cy = 360, 360; p.setPen(Qt.NoPen); p.setBrush(col(60))
            p.drawPolygon(QPolygonF([QPointF(cx+math.cos(math.radians(-90+i*45))*(52 if i % 2 == 0 else 14), cy+math.sin(math.radians(-90+i*45))*(52 if i % 2 == 0 else 14)) for i in range(8)]))
            text('K', cx, cy-72, 24, 80)
            p.setBrush(col(45)); p.drawPolygon(QPolygonF([QPointF(30, 170), QPointF(80, 90), QPointF(130, 170)])); p.drawPolygon(QPolygonF([QPointF(95, 170), QPointF(135, 110), QPointF(180, 170)]))
        around(f)
    elif key == 'fizik':
        def f():
            for r in (0, 60, 120):
                pen(55, 2); p.save(); p.translate(120, 130); p.rotate(r); p.drawEllipse(QPointF(0, 0), 70, 24); p.restore()
            p.setPen(Qt.NoPen); p.setBrush(col(80)); p.drawEllipse(QPointF(120, 130), 9, 9)
            pen(55, 2.5); path = QPainterPath(QPointF(220, 320))
            for x in range(220, 470, 3): path.lineTo(x, 320+math.sin((x-220)/20.0)*26)
            p.drawPath(path)
            pen(45, 2); p.drawEllipse(QPointF(70, 380), 14, 60); p.drawLine(QPointF(0, 380), QPointF(160, 380))
            for s, x, y, px, a, r in [('E = mc²',350,90,34,70,0),('F = m·a',300,200,28,60,-4),('λ',420,420,50,60,0),('Ω',240,430,40,50,0),('ħ',30,250,40,55,0),('v = λ·f',170,270,22,55,0)]:
                text(s, x, y, px, a, True, r)
        around(f)
    elif key == 'biyoloji':
        def f():
            for phase in (0, math.pi):
                pen(70, 3); path = QPainterPath()
                for i, y in enumerate(range(0, size+1, 4)):
                    x = 90+math.sin(y/30.0+phase)*36
                    path.moveTo(x, y) if i == 0 else path.lineTo(x, y)
                p.drawPath(path)
            pen(40, 2)
            for y in range(0, size, 16):
                p.drawLine(QPointF(90+math.sin(y/30.0)*36, y), QPointF(90+math.sin(y/30.0+math.pi)*36, y))
            pen(60, 2.5); leaf = QPainterPath(QPointF(300, 160)); leaf.cubicTo(330, 60, 430, 60, 440, 40); leaf.cubicTo(430, 140, 360, 190, 300, 160)
            p.drawPath(leaf); p.drawLine(QPointF(300, 160), QPointF(420, 60))
            p.drawEllipse(QPointF(330, 350), 80, 60); p.setBrush(col(45)); p.drawEllipse(QPointF(350, 340), 24, 20)
            p.setBrush(Qt.NoBrush); p.drawEllipse(QPointF(290, 370), 16, 8)
            for s, x, y, px, a in [('DNA',200,250,28,60),('ATP',220,440,24,50),('H₂O + CO₂',420,250,18,45)]:
                text(s, x, y, px, a)
        around(f)
    elif key == 'resim':
        paints = ('#e04f3a', '#f2b33d', '#3f7fd9', '#3fae6a', '#b05cc9', '#f2f2f2')
        def blob(cx, cy, r, c, a):
            q = QColor(c); q.setAlpha(a); p.setPen(Qt.NoPen); p.setBrush(q); p.drawEllipse(QPointF(cx, cy), r, r*.86)
        def f():
            # Palet: thumb hole and notch, with paint blobs
            pal = QPainterPath(); pal.addEllipse(QPointF(130, 130), 92, 66)
            hole = QPainterPath(); hole.addEllipse(QPointF(92, 158), 13, 11); notch = QPainterPath(); notch.addEllipse(QPointF(46, 168), 24, 18)
            pen(70, 2.6); p.drawPath(pal.subtracted(hole).subtracted(notch))
            for (x, y), c in zip([(110, 95), (150, 88), (188, 108), (196, 148), (160, 176), (128, 128)], paints): blob(x, y, 12, c, 95)
            # Fırça and its stroke
            p.save(); p.translate(380, 120); p.rotate(-38)
            pen(70, 7); p.drawLine(QPointF(0, -95), QPointF(0, 10))
            pen(70, 2.4); p.drawRect(QRectF(-6, 10, 12, 22))
            tip = QPainterPath(QPointF(-6, 32)); tip.cubicTo(-10, 54, -2, 70, 0, 78); tip.cubicTo(2, 70, 10, 54, 6, 32)
            q = QColor(paints[0]); q.setAlpha(120); p.setBrush(q); p.drawPath(tip); p.restore()
            stroke = QPainterPath(QPointF(250, 250)); stroke.cubicTo(300, 205, 360, 290, 420, 235); stroke.cubicTo(445, 215, 465, 230, 470, 250)
            q = QColor(paints[0]); q.setAlpha(70); p.setPen(QPen(q, 12, Qt.SolidLine, Qt.RoundCap)); p.setBrush(Qt.NoBrush); p.drawPath(stroke)
            # Renk çemberi
            for i, c in enumerate(paints[:5] + ('#f27b3a',)):
                q = QColor(c); q.setAlpha(85); p.setPen(Qt.NoPen); p.setBrush(q)
                p.drawPie(QRectF(320, 315, 110, 110), (90+i*60)*16, 60*16)
            p.setBrush(QColor(t['view'])); p.drawEllipse(QPointF(375, 370), 20, 20)
            # Kurşun kalem
            p.save(); p.translate(70, 400); p.rotate(-30); pen(60, 2.4)
            p.drawPolygon(QPolygonF([QPointF(0, -8), QPointF(120, -8), QPointF(120, 8), QPointF(0, 8)]))
            p.drawPolygon(QPolygonF([QPointF(120, -8), QPointF(146, 0), QPointF(120, 8)])); p.drawLine(QPointF(20, -8), QPointF(20, 8)); p.restore()
            # Çerçeve içinde küçük manzara
            pen(55, 2.4); p.drawRect(QRectF(200, 330, 104, 78)); pen(40, 1.6); p.drawRect(QRectF(208, 338, 88, 62))
            pen(55, 2); p.drawPolyline(QPolygonF([QPointF(210, 396), QPointF(236, 362), QPointF(254, 380), QPointF(272, 354), QPointF(294, 396)]))
            blob(282, 352, 7, paints[1], 110)
            # Boya damlaları
            for (x, y, r), c in zip([(250, 60, 6), (300, 150, 4), (40, 260, 7), (460, 420, 5), (180, 280, 4), (440, 40, 3)], paints*2): blob(x, y, r, c, 80)
        around(f)
    p.end(); img.save(path); return path

# --- Ders zaman çizelgesi (Ümraniye Merkez Anadolu Lisesi, 2026-2027) ---
_LESSONS = [('1. Ders','08:00','08:40'),('2. Ders','08:50','09:30'),('3. Ders','09:40','10:20'),
            ('4. Ders','10:30','11:10'),('5. Ders','11:20','12:00')]
BELL_DAYS = {   # weekday() -> periods; gaps between them are teneffüs
    'normal': [('Derse hazırlık','07:30','08:00')]+_LESSONS+[('Öğle arası','12:00','12:30'),('6. Ders','12:30','13:10'),
               ('7. Ders','13:20','14:00'),('8. Ders','14:10','14:50'),('DYK 1. Ders','15:00','15:40'),('DYK 2. Ders','15:50','16:30')],
    # Cuma (okulun ders zaman çizelgesi): öğle arası 6. dersten sonra 12.50–13.30 (40 dk); 7. ders 13.30–14.10, 8. ders 14.20–15.00; okul 15.00'te biter
    'cuma':   [('Derse hazırlık','07:30','08:00')]+_LESSONS+[('6. Ders','12:10','12:50'),('Öğle arası','12:50','13:30'),
               ('7. Ders','13:30','14:10'),('8. Ders','14:20','15:00'),('DYK 1. Ders','15:00','15:40'),('DYK 2. Ders','15:50','16:30')]}
TR_DAYS = ['Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi','Pazar']
TR_MONTHS = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık']

SINAV_SAAT = {}   # zil çizelgesinden farklı saatte yapılan sınavlar (tarih, ders) → (başlangıç, bitiş)
DENEME_DERS = 'Deneme'
_DENEME = {}   # etkin deneme sınavı: {'id', 'tarih', 'a', 'b', 'hedef': [salonlar]} (Öğretmenler odasındaki "Sınav anı" düğmesi)
def exam_span(weekday, name, day=None):
    """Bir dersin (sınavın) başlangıç–bitiş saniyesi; deneme sınavı saat çizelgesinde olmadığı için ayrıca.
    day verilirse o günün özel sınav saati (SINAV_SAAT) önce gelir."""
    if day is not None:
        ov = SINAV_SAAT.get((str(day)[:10], name))
        if ov: return (int(ov[0][:2])*3600 + int(ov[0][3:])*60, int(ov[1][:2])*3600 + int(ov[1][3:])*60)
    if name == DENEME_DERS:
        try:
            import datetime
            if _DENEME and datetime.date.fromisoformat(_DENEME['tarih']).weekday() == weekday: return (int(_DENEME['a']), int(_DENEME['b']))
        except (KeyError, ValueError, TypeError): pass
        return None
    return next(((a, b) for name_, a, b, kind in bell_periods(weekday) if name_ == name), None)
def bell_periods(weekday):
    """[(name, start_s, end_s, kind)] with teneffüs filling the gaps; seconds of day."""
    if weekday >= 5: return []
    sec = lambda t: int(t[:2])*3600+int(t[3:])*60
    out = []
    for name, a, b in BELL_DAYS['cuma' if weekday == 4 else 'normal']:
        a, b = sec(a), sec(b)
        if out and a > out[-1][2]: out.append(('Teneffüs', out[-1][2], a, 'break'))
        kind = 'break' if name == 'Öğle arası' else ('prep' if name == 'Derse hazırlık' else 'lesson')
        out.append((name, a, b, kind))
    return out

def bell_state(now):
    """What the corner clock shows at datetime `now`."""
    t = now.hour*3600+now.minute*60+now.second
    periods = bell_periods(now.weekday())
    st = dict(kind='off', tag='', span='', left=None, frac=0, next='')
    hm = lambda x: '%02d.%02d' % (x//3600, x%3600//60)
    if not periods:
        st.update(tag='HAFTA SONU'); return st
    if t < periods[0][1]:
        st.update(kind='before', tag='GÜNAYDIN', left=periods[0][1]-t, next='Derse hazırlık %s' % hm(periods[0][1])); return st
    if t >= periods[-1][2]:
        st.update(tag='OKUL BİTTİ'); return st
    for i, (name, a, b, kind) in enumerate(periods):
        if a <= t < b:
            nxt = periods[i+1] if i+1 < len(periods) else None
            st.update(kind=kind, tag=name.replace('i','İ').upper(), span='%s – %s' % (hm(a), hm(b)), left=b-t, frac=(t-a)/(b-a),
                      next=('Sonra: %s %s – %s' % (nxt[0], hm(nxt[1]), hm(nxt[2]))) if nxt else 'Sonra: okul bitiyor')
            return st
    return st

# --- Ortak yazılı sınavlar (2026-2027 1. dönem 1. yazılı; okul takvimi) ---
# Yalnız bütün şubelerin girdiği sınavlar; şubeye göre seçmeli/mazeret sınavları yok.
# Kelebek sistemi: öğrenciler salonlara karışık oturur, bu yüzden o saatteki bütün sınavlar her tahtada gösterilir.
EXAMS = [
    ('2026-11-03', '4. Ders', {'9': 'Biyoloji', '10': 'Biyoloji'}),
    ('2026-11-04', '4. Ders', {'9': 'Kimya', '10': 'Kimya'}),
    ('2026-11-04', '7. Ders', {'9': 'Tarih', '10': 'Tarih', '11': 'Tarih', '12': 'T.C. İnkılap Tarihi'}),
    ('2026-11-05', '4. Ders', {'9': 'Matematik', '10': 'Matematik', '11': 'Matematik', '12': 'Matematik'}),
    ('2026-11-06', '4. Ders', {'9': 'Fizik', '10': 'Fizik'}),
    ('2026-11-06', '7. Ders', {'9': 'Sağlık Bilgisi ve Trafik Kültürü', '10': 'Felsefe', '11': 'Felsefe', '12': 'Klasik Ahlak Metinleri'}),
    ('2026-11-10', '4. Ders', {'9': 'Coğrafya', '10': 'Coğrafya'}),
    ('2026-11-11', '4. Ders', {'9': 'Türk Dili ve Edebiyatı', '11': 'Türk Dili ve Edebiyatı', '12': 'Türk Dili ve Edebiyatı'}),
    ('2026-11-11', '7. Ders', {'9': 'Din Kültürü ve Ahlak Bilgisi', '10': 'Din Kültürü ve Ahlak Bilgisi', '11': 'Din Kültürü ve Ahlak Bilgisi', '12': 'Din Kültürü ve Ahlak Bilgisi'}),
    ('2026-11-13', '7. Ders', {'9': 'Yabancı Dil', '10': 'Yabancı Dil', '11': 'Yabancı Dil', '12': 'Yabancı Dil'}),
]
EXAM_BEFORE = 10*60   # sınavdan bu kadar önce geri sayım başlar (teneffüs)
EXAM_AFTER = 2*60     # bitince "Sınav bitti" bu kadar kalır

EXAM_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sinav-takvimi.json')
def load_exams():
    """Sınav modu: takvim sinav-takvimi.json'dan (her sınav haftası yalnız bu dosya değişir); yoksa gömülü liste."""
    try:
        with open(EXAM_FILE, encoding='utf-8') as f: d = json.load(f)
        out = [(x['tarih'], x['ders'], {str(k): str(v) for k, v in x['siniflar'].items()}) for x in d.get('sinavlar', [])]
        return out or EXAMS
    except (OSError, ValueError, KeyError, TypeError, AttributeError): return EXAMS

# Derse göre sayaç teması: (anahtar sözcükler, vurgu rengi, desen)
EXAM_THEMES = [
    (('biyoloji',), '#4fd18b', 'dna'), (('kimya',), '#5cc8ff', 'molekul'), (('fizik',), '#7aa2ff', 'dalga'),
    (('matematik',), '#ffc145', 'formul'), (('tarih', 'inkılap', 'inkilap'), '#e0a96d', 'zaman'),
    (('coğrafya', 'cografya'), '#3fd0c9', 'harita'), (('edebiyat', 'türk dili'), '#ff8fa3', 'harf'),
    (('din', 'ahlak'), '#9bd36b', 'yildiz'), (('yabancı', 'ingilizce', 'almanca'), '#b794ff', 'dil'),
    (('felsefe',), '#8fa8ff', 'felsefe'), (('sağlık', 'trafik'), '#ff9f5a', 'yol')]
def exam_theme(ders):
    low = (ders or '').replace('İ', 'i').replace('I', 'ı').lower()
    for keys, color, kind in EXAM_THEMES:
        if any(k in low for k in keys): return color, kind
    return '#5cc8ff', 'genel'

def draw_exam_theme(p, W, H, k, kind, color, t):
    """Derse uygun, soluk ve yavaş kayan arka plan deseni (saniyede bir çizilir; ucuz)."""
    from PyQt5.QtGui import QFont
    c = QColor(color); p.save(); p.setRenderHint(QPainter.Antialiasing)
    def pen(a, w=2): q = QColor(c); q.setAlpha(a); p.setPen(QPen(q, w*k)); p.setBrush(Qt.NoBrush)
    drift = (t % 240)/240.0   # 4 dakikada bir tur: yavaş ama gözle görülür
    if kind == 'dna':
        for col in range(3):
            x0 = W*(.08 + col*.42); ph = drift*2*math.pi + col
            for side in (0, math.pi):
                pts = [QPointF(x0 + 60*k*math.sin(y/(70*k) + ph + side), y) for y in range(0, int(H)+20, 8)]
                pen(40, 3); p.drawPolyline(QPolygonF(pts))
            for y in range(0, int(H), int(36*k) or 1):
                a = x0 + 60*k*math.sin(y/(70*k) + ph); b = x0 + 60*k*math.sin(y/(70*k) + ph + math.pi)
                pen(22, 2); p.drawLine(QPointF(a, y), QPointF(b, y))
    elif kind == 'molekul':
        r = 46*k; dx = r*math.sqrt(3); off = drift*dx*2
        for row in range(-1, int(H/(r*1.5)) + 2):
            for col in range(-1, int(W/dx) + 2):
                cx = col*dx + (dx/2 if row % 2 else 0) + off - dx; cy = row*r*1.5
                if (row*7 + col*3) % 5: continue
                poly = QPolygonF([QPointF(cx + r*math.cos(math.radians(30 + 60*i)), cy + r*math.sin(math.radians(30 + 60*i))) for i in range(7)])
                pen(40, 2.4); p.drawPolyline(poly); pen(26, 2); p.drawEllipse(QPointF(cx, cy), r*.5, r*.5)
                pen(30, 2); p.drawLine(QPointF(cx + r, cy), QPointF(cx + r*1.9, cy - r*.5))
                q = QColor(c); q.setAlpha(45); p.setBrush(q); p.setPen(Qt.NoPen); p.drawEllipse(QPointF(cx + r*1.9, cy - r*.5), 7*k, 7*k)
    elif kind == 'dalga':
        for i in range(6):
            y0 = H*(.12 + i*.16); amp = (18 + 10*(i % 3))*k; ln = (160 + 40*i)*k
            pts = [QPointF(x, y0 + amp*math.sin(x/ln*2*math.pi + drift*2*math.pi*(1 + i*.3))) for x in range(0, int(W)+10, 10)]
            pen(26 + 6*(i % 2), 2.5); p.drawPolyline(QPolygonF(pts))
        cx, cy = W*.88, H*.2
        for a in (0, 60, 120):
            p.save(); p.translate(cx, cy); p.rotate(a + drift*360); pen(38, 2); p.drawEllipse(QPointF(0, 0), 90*k, 32*k); p.restore()
    elif kind == 'formul':   # matematik: yalnız geometri (sınavda ipucu olacak formül yok)
        pen(16, 1)
        g = 60*k; off = drift*g
        for i in range(int(W/g) + 2): p.drawLine(QPointF(i*g - off, 0), QPointF(i*g - off, H))
        for j in range(int(H/g) + 2): p.drawLine(QPointF(0, j*g), QPointF(W, j*g))
        shapes = [(.08, .2, 'c'), (.88, .16, 't'), (.1, .78, 't'), (.9, .8, 'c'), (.05, .5, 's'), (.95, .5, 's')]
        for i, (fx, fy, sh) in enumerate(shapes):
            cx, cy, r = W*fx, H*fy, (70 + 20*(i % 2))*k
            p.save(); p.translate(cx, cy); p.rotate(drift*360*(1 if i % 2 else -1)); pen(42, 2.5)
            if sh == 'c': p.drawEllipse(QPointF(0, 0), r, r); p.drawLine(QPointF(-r, 0), QPointF(r, 0))
            elif sh == 't': p.drawPolygon(QPolygonF([QPointF(0, -r), QPointF(r*.87, r*.5), QPointF(-r*.87, r*.5)]))
            else: p.drawRect(QRectF(-r*.7, -r*.7, r*1.4, r*1.4)); p.drawLine(QPointF(-r*.7, -r*.7), QPointF(r*.7, r*.7))
            p.restore()
    elif kind in ('harf', 'dil', 'felsefe', 'genel'):
        words = {
                 'harf': ['A', 'Ç', 'Ğ', 'Ş', '“ ”', 'Ü', 'Ö', 'İ', '¶', '…', 'Aa', 'Ee'],
                 'dil': ['Hello', 'Good luck!', 'Hallo', 'Bonjour', 'Hola', 'Ciao', 'Hi!', 'Read', 'Write', 'Listen'],
                 'felsefe': ['?', '?', '!', '?', '…', '?'],   # kavram adı yok (ipucu olmasın)
                 'genel': ['✓', '✎', '?', '!', '✓', '✎']}[kind]
        f = QFont(); f.setPixelSize(int(46*k)); p.setFont(f); n = len(words)
        for i in range(18):
            w_ = words[i % n]; x = (i*0.29 % 1)*W*1.1 - W*.05 + drift*W*.12; y = ((i*0.41 + .07) % 1)*H
            if x > W: x -= W*1.1
            if W*.2 < x < W*.74 and H*.06 < y < H*.92: x = x - W*.3 if x < W*.47 else x + W*.3   # sayacın üstüne binmesin
            pen(30 + (i % 3)*8, 1); p.drawText(QPointF(x, y), w_)
    elif kind == 'zaman':
        y = H*.86; pen(40, 3); p.drawLine(QPointF(0, y), QPointF(W, y)); f = QFont(); f.setPixelSize(int(26*k)); p.setFont(f)
        step = 170*k; off = drift*step*3
        for i in range(-2, int(W/step) + 3):
            x = i*step + off % step; pen(50, 3); p.drawLine(QPointF(x, y - 14*k), QPointF(x, y + 14*k))
            pen(34, 3); p.drawEllipse(QPointF(x, y), 6*k, 6*k)   # yıl yazılmaz (ipucu olmasın)
        pen(26, 2); p.drawEllipse(QPointF(W*.9, H*.22), 120*k, 120*k); p.drawLine(QPointF(W*.9, H*.22), QPointF(W*.9, H*.22 - 80*k)); p.drawLine(QPointF(W*.9, H*.22), QPointF(W*.9 + 55*k, H*.22))
    elif kind == 'harita':
        cx, cy, R = W*.84, H*.3, 230*k
        pen(34, 2); p.drawEllipse(QPointF(cx, cy), R, R)
        for i in range(1, 6): p.drawEllipse(QPointF(cx, cy), R*abs(math.cos(i*math.pi/6 + drift*math.pi)), R)
        for i in range(1, 6): y = cy - R + 2*R*i/6; hw = math.sqrt(max(0, R*R - (y - cy)**2)); p.drawLine(QPointF(cx - hw, y), QPointF(cx + hw, y))
        for i in range(5):
            pts = [QPointF(x, H*(.55 + i*.09) + 22*k*math.sin(x/(130*k) + i + drift*6)) for x in range(0, int(W*.7), 12)]
            pen(22, 2); p.drawPolyline(QPolygonF(pts))
    elif kind == 'yildiz':
        r = 70*k; step = r*2.6; off = drift*step
        for row in range(-1, int(H/step) + 2):
            for col in range(-1, int(W/step) + 2):
                if (row + col) % 2: continue
                cx, cy = col*step + off, row*step + step/2
                for rot in (0, 45):
                    p.save(); p.translate(cx, cy); p.rotate(rot); pen(30, 2); p.drawRect(QRectF(-r*.7, -r*.7, r*1.4, r*1.4)); p.restore()
                pen(24, 1.5); p.drawEllipse(QPointF(cx, cy), r*.35, r*.35)
    elif kind == 'yol':
        for lane in (.3, .7):
            y = H*lane; pen(30, 3); p.drawLine(QPointF(0, y - 60*k), QPointF(W, y - 60*k)); p.drawLine(QPointF(0, y + 60*k), QPointF(W, y + 60*k))
            dash = 80*k; off = drift*dash*8
            for i in range(-1, int(W/(dash*2)) + 2): x = i*dash*2 + off % (dash*2); pen(40, 5); p.drawLine(QPointF(x, y), QPointF(x + dash, y))
    p.restore()

def exam_now(now, exams=None):
    """Şu an geri sayımı, süresi ya da bitişi gösterilecek sınav: dict ya da None."""
    day = now.strftime('%Y-%m-%d'); t = now.hour*3600 + now.minute*60 + now.second
    for d, lesson, by_grade in (exams if exams is not None else EXAMS):
        if d != day: continue
        span = exam_span(now.weekday(), lesson, d)
        if not span: continue
        a, b = span
        if a - EXAM_BEFORE <= t < b + EXAM_AFTER:
            phase = 'before' if t < a else ('during' if t < b else 'after')
            return dict(key=d + lesson, lesson=lesson, exams=by_grade, start=a, end=b, t=t, phase=phase, date=now.date())
    return None

KELEBEK_KEY = bytes.fromhex('9a10b9b4d6dd4182bf883f56e9cb8f6515b67773f31505189f7832f8556af494')
KELEBEK_URLS = ('https://raw.githubusercontent.com/299ygp9529-prog/umal-tahta/kelebek/plan.bin',
                'https://github.com/299ygp9529-prog/umal-tahta/raw/kelebek/plan.bin')
KELEBEK_FOTO_URLS = tuple(u.replace('plan.bin', 'foto.bin') for u in ('https://raw.githubusercontent.com/299ygp9529-prog/umal-tahta/kelebek/plan.bin',
                                                                        'https://github.com/299ygp9529-prog/umal-tahta/raw/kelebek/plan.bin'))
_PHOTOS = {'data': None, 'pix': {}}
AYRILAN = set()   # K-333: okuldan ayrılan öğrenciler (DersMap): fotoğrafı ve listelerde adı görünmez
def student_photo(no):
    """Öğrenci fotoğrafı (okul numarasıyla); yoksa None. Kelebek sınav listelerinde kimlik denetimi için."""
    d = _PHOTOS['data']
    if not d or not no or str(no) in FOTO_GIZLI or str(no) in AYRILAN: return None
    pm = _PHOTOS['pix'].get(no)
    if pm is None and no in d:
        import base64
        pm = QPixmap(); pm.loadFromData(base64.b64decode(d[no]), 'JPG'); _PHOTOS['pix'][no] = pm
    return pm
BOARD_PHOTOS = True   # tahtalarda öğrenci fotoğrafları
FOTO_GIZLI = {'101'}   # fotoğrafı hiçbir yerde gösterilmeyecek öğrenciler (okul no); yerine baş harfler
YOKLAMA_BASLA = 5*60   # sn: yoklama sınav başladıktan bu kadar sonra açılır, sınav bitene kadar
YOKLAMA_SURE = 15*60   # sn: sınav başladıktan sonra yoklama bu kadar açık
LOGO_RESMI = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'okul-logo-resmi.png')
DUYURU_HAZIR = ['Sınav süresi 10 dakika uzatıldı.', 'Sorulardaki hata için gözetmen öğretmeni dinleyiniz.',
                'Son 10 dakika.', 'Cevap kâğıtlarına ad, soyad ve numara yazılmasını kontrol ediniz.']
_SUBELER = {}
def exam_course(tarih, ders, sinif, fallback=''):
    """Kelebek sınavında bir şubenin girdiği ders (takvimdeki 'subeler'), yoksa sınıf düzeyinin dersi."""
    if not _SUBELER:
        try:
            with open(EXAM_FILE, encoding='utf-8') as f: d = json.load(f)
            for x in d.get('subeler', []): _SUBELER[(x['tarih'], x['ders'])] = x.get('subeler', {})
            for x in d.get('sinavlar', []): _SUBELER.setdefault(('*', x['tarih'], x['ders']), x.get('siniflar', {}))
        except (OSError, ValueError, KeyError, TypeError, AttributeError): pass
        _SUBELER.setdefault('_', 1)
    c = _SUBELER.get((tarih, ders), {}).get(str(sinif or ''))
    if c: return c
    return _SUBELER.get(('*', tarih, ders), {}).get(class_grade(sinif) or '') or fallback
def tr_title(s_):
    """Kelebekteki BÜYÜK HARFLİ ders adı → 'Din Kültürü ve Ahlak Bilgisi' (Türkçe i/ı ile)."""
    s_ = str(s_ or '').strip()
    if not s_ or any(w != w.upper() for w in s_.split() if w.lower() not in ('ve', 'ile')): return s_
    low = lambda w: w.replace('I', 'ı').replace('İ', 'i').lower()
    out = []
    for j, w in enumerate(s_.split()):
        lw = low(w)
        if j and lw in ('ve', 'ile'): out.append(lw)
        elif len(w) <= 2 and w.endswith('.'): out.append(w)
        else: out.append(w[0] + low(w[1:]))
    return ' '.join(out)
def tr_date(day):
    return '%d %s %d' % (day.day, TR_MONTHS[day.month-1], day.year)
def _salon_key(s_):
    a = str(s_).split('-')[0]
    return (int(a) if a.isdigit() else 99, str(s_))

def draw_photo(p, r, no, name, k):
    pm = student_photo(no)
    p.save(); path = QPainterPath(); path.addRoundedRect(r, 6*k, 6*k); p.setClipPath(path)
    if pm is not None and not pm.isNull():
        sc = max(r.width()/pm.width(), r.height()/pm.height()); w_, h_ = pm.width()*sc, pm.height()*sc
        p.drawPixmap(QRectF(r.center().x() - w_/2, r.center().y() - h_/2, w_, h_), pm, QRectF(pm.rect()))
    else:   # fotoğraf yok: baş harfler
        p.fillRect(r, QColor('#2a3a52')); p.setPen(QColor('#9fb3cc')); f = p.font(); f.setPixelSize(max(9, int(r.height()*.34))); p.setFont(f)
        p.drawText(r, Qt.AlignCenter, ''.join(w[0] for w in name.split()[:2]))
    p.restore()
def kelebek_open(blob):
    """Kelebek oturma planı (şifreli, imzalı): SHA-256 sayaç kipi + HMAC; yalnız standart kitaplık."""
    import hashlib, hmac
    if blob[:3] != b'UK1': raise ValueError('biçim')
    nonce, tag, ct = blob[3:19], blob[19:51], blob[51:]
    if not hmac.compare_digest(tag, hmac.new(KELEBEK_KEY, nonce + ct, hashlib.sha256).digest()): raise ValueError('imza')
    out = bytearray(); i = 0
    while len(out) < len(ct): out += hashlib.sha256(KELEBEK_KEY + nonce + i.to_bytes(8, 'big')).digest(); i += 1
    return json.loads(bytes(a ^ b for a, b in zip(ct, out)).decode('utf-8'))
LESSON_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ders-programi.json')
_LESSON_TABLE = {}
def lesson_now(sinif, now):
    """Panel için: bu sınıfta şu an hangi ders, hangi öğretmen (okulun haftalık ders programından)."""
    if not _LESSON_TABLE:
        try:
            with open(LESSON_FILE, encoding='utf-8') as f: _LESSON_TABLE.update(json.load(f).get('siniflar', {}))
        except (OSError, ValueError, AttributeError): _LESSON_TABLE['_'] = {}
    t = now.hour*3600 + now.minute*60 + now.second; hm = lambda x: '%02d.%02d' % (x//3600, x%3600//60)
    for name, a, b, kind in bell_periods(now.weekday()):
        if a <= t < b:
            if kind != 'lesson': return dict(durum='teneffus' if kind == 'break' else 'ders_disi', saat=name)
            try: n = int(name.split('.')[0])
            except ValueError: return dict(durum='ders_disi', saat=name)   # DYK
            cell = _LESSON_TABLE.get(str(sinif or ''), {}).get('%d-%d' % (now.weekday(), n))
            if not cell: return dict(durum='bos', saat=name, bas=hm(a), bit=hm(b))
            return dict(durum='ders', saat=name, bas=hm(a), bit=hm(b), ders=cell.get('ders', ''), ogretmen=cell.get('ogretmen', []))
    nxt = [p_ for p_ in bell_periods(now.weekday()) if p_[1] > t]
    return dict(durum='teneffus' if nxt and any(p_[2] <= t for p_ in bell_periods(now.weekday())) else 'okul_disi')

def lesson_cell(sinif, weekday, n):
    """Ders programında bir sınıfın o gün o dersteki kaydı: {'ders', 'ogretmen'} ya da None."""
    if not _LESSON_TABLE:
        try:
            with open(LESSON_FILE, encoding='utf-8') as f: _LESSON_TABLE.update(json.load(f).get('siniflar', {}))
        except (OSError, ValueError, AttributeError): _LESSON_TABLE['_'] = {}
    return _LESSON_TABLE.get(str(sinif or ''), {}).get('%d-%d' % (weekday, n))

def class_grade(sinif):
    s = str(sinif or '').strip()
    g = s.split('-')[0].strip()
    return g if g in ('9', '10', '11', '12') else None
GRADE_COLORS = {'9': '#22e8ff', '10': '#3ef08a', '11': '#b06bff', '12': '#ff9a3a'}   # sınıf seviyesi renkleri (sıra kartı şeridi, numara, sınıf)
def grade_color(sinif, fallback='#5cc8ff'):
    return GRADE_COLORS.get(class_grade(sinif) or '', fallback)
TENEFFUS_AHEAD = 7   # gün: bu sınıf düzeyinin bu kadar gün içinde sınavı varsa teneffüste teneffüs modu açılır
def teneffus_info(now, exams, grade, sinif=''):
    """Teneffüs modu verisi: sıradaki ders, bu sınıfın sıradaki sınavı (geri sayım), 5 iş günlük sınav takvimi.
    Sınav yoksa (TENEFFUS_AHEAD gün içinde) None."""
    import datetime
    if not grade: return None
    t = now.hour*3600 + now.minute*60 + now.second; today = now.date(); lst = []
    for d_, l_, g_ in (exams or []):
        if l_ == DENEME_DERS or grade not in g_: continue
        try: day = datetime.date.fromisoformat(d_)
        except (TypeError, ValueError): continue
        if not (0 <= (day - today).days <= 31): continue
        span = exam_span(day.weekday(), l_, day)
        if not span: continue
        crs = tr_title(exam_course(d_, l_, sinif, g_.get(grade, ''))) or g_.get(grade, '')
        lst.append((day, span[0], span[1], l_, crs))
    lst.sort()
    nxt = next((e for e in lst if (e[0], e[1]) > (today, t)), None)
    if nxt is None or (nxt[0] - today).days > TENEFFUS_AHEAD: return None
    per = bell_periods(now.weekday()); cur = next((x for x in per if x[1] <= t < x[2]), None)
    after = next((x for x in per if x[1] >= t and x[3] == 'lesson'), None)
    nowtxt = (cur[0] if cur and cur[0] != 'Teneffüs' else 'Teneffüs') if cur else ''
    if after: nowtxt = (nowtxt + '  ·  ' if nowtxt else '') + 'Sıradaki: %s  %02d.%02d' % (after[0], after[1]//3600, after[1]%3600//60)
    start = datetime.datetime.combine(nxt[0], datetime.time()) + datetime.timedelta(seconds=nxt[1]); left = max(0, int((start - now).total_seconds()))
    days, d = [], today
    while len(days) < 5:
        if d.weekday() < 5:
            label = 'Bugün' if d == today else ('Yarın' if (d - today).days == 1 else TR_DAYS[d.weekday()])
            sub = ('%s %d %s' % (TR_DAYS[d.weekday()], d.day, TR_MONTHS[d.month-1])) if (d - today).days <= 1 else '%d %s' % (d.day, TR_MONTHS[d.month-1])
            items = [(e[4], e[3], '%02d.%02d' % (e[1]//3600, e[1]%3600//60), (e[0], e[2]) <= (today, t)) for e in lst if e[0] == d]
            days.append((label, sub, items))
        d += datetime.timedelta(days=1)
    when = 'Bugün' if nxt[0] == today else ('Yarın' if (nxt[0] - today).days == 1 else '%d %s' % (nxt[0].day, TR_MONTHS[nxt[0].month-1]))
    return dict(saat='%02d.%02d' % (now.hour, now.minute), tarih='%s · %d %s' % (TR_DAYS[now.weekday()], now.day, TR_MONTHS[now.month-1]),
                simdi=nowtxt, sonraki='%s · %s · %s' % (when, nxt[3], nxt[4]), kalan=(left//86400, left%86400//3600, left%3600//60), gunler=days)

class ExamScreen(QWidget):
    """Sınav saatinde tahta alanını kaplayan büyük saat: kalan süre, o saatteki sınavlar."""
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.st = None; self.grade = None
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.hide_btn = QPushButton('Gizle', self); self.hide_btn.setFocusPolicy(Qt.NoFocus); self.hide_btn.setMinimumHeight(46)
        self.hide_btn.setStyleSheet('QPushButton{background:rgba(255,255,255,0.10);color:#c9d6ea;border:1px solid rgba(255,255,255,0.18);border-radius:10px;padding:0 18px;font-size:17px;}')
        self.hide_btn.clicked.connect(main.hide_exam)
        self.other_btn = QPushButton(self); self.other_btn.setFocusPolicy(Qt.NoFocus); self.other_btn.setMinimumHeight(52); self.other_btn.hide()
        self.other_btn.setStyleSheet('QPushButton{background:#13233a;color:white;border:1px solid #2f6fd6;border-radius:14px;padding:0 22px;font-size:19px;font-weight:600;}')
        self.other_btn.clicked.connect(main.other_exam)
        self.yok_btn = QPushButton('Yoklamayı onayla', self); self.yok_btn.setFocusPolicy(Qt.NoFocus); self.yok_btn.hide()
        self.yok_btn.clicked.connect(self.confirm_yoklama); self.absent = set(); self.seat_rects = {}; self.yok_on = False
        self.press_timer = QTimer(self); self.press_timer.setSingleShot(True); self.press_timer.timeout.connect(self.long_press)
        self.press_seat = None
        self.duyuru_box = QFrame(self); self.duyuru_box.hide(); self.duyuru_box.setStyleSheet('QFrame{background:#ffb020;border-radius:16px;}')
        lay_ = QHBoxLayout(self.duyuru_box); lay_.setContentsMargins(24, 14, 14, 14); lay_.setSpacing(18)
        self.duyuru_lbl = QLabel(self.duyuru_box); self.duyuru_lbl.setWordWrap(True)
        self.duyuru_lbl.setStyleSheet('QLabel{color:#1a1206;font-size:26px;font-weight:700;background:transparent;}')
        ok_ = QPushButton('Tamam', self.duyuru_box); ok_.setFocusPolicy(Qt.NoFocus); ok_.setMinimumHeight(52)
        ok_.setStyleSheet('QPushButton{background:#1a1206;color:#ffd78a;border:none;border-radius:12px;padding:0 26px;font-size:20px;font-weight:700;}')
        ok_.clicked.connect(self.dismiss_duyuru); lay_.addWidget(self.duyuru_lbl, 1); lay_.addWidget(ok_)
        self.duyuru_id = None
        self.kagit_btn = QPushButton('  Kâğıt eksik', self); self.kagit_btn.setFocusPolicy(Qt.NoFocus); self.kagit_btn.hide()
        self.kagit_btn.setStyleSheet('QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ff9a3a,stop:1 #f06d0c);color:white;border:none;border-radius:12px;padding:0 20px;font-size:19px;font-weight:700;}'
                                     'QPushButton:pressed{background:#c85a08;}')
        self.kagit_btn.clicked.connect(self.open_kagit)
        self.kag_pill = QLabel(self); self.kag_pill.hide(); self.kag_ref = None
        self.gel_box = QFrame(self); self.gel_box.hide(); self.gel_box.setStyleSheet('QFrame{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #118a57,stop:1 #22c07a);border-radius:16px;}')
        gl_ = QHBoxLayout(self.gel_box); gl_.setContentsMargins(24, 14, 14, 14); gl_.setSpacing(18)
        self.gel_lbl = QLabel(self.gel_box); self.gel_lbl.setWordWrap(True); self.gel_lbl.setStyleSheet('QLabel{color:white;font-size:24px;font-weight:700;background:transparent;}')
        gok_ = QPushButton('Kâğıt geldi', self.gel_box); gok_.setFocusPolicy(Qt.NoFocus); gok_.setMinimumHeight(56)
        gok_.setStyleSheet('QPushButton{background:rgba(0,0,0,0.25);color:white;border:none;border-radius:12px;padding:0 26px;font-size:21px;font-weight:700;}')
        gok_.clicked.connect(self.kagit_ok); gl_.addWidget(self.gel_lbl, 1); gl_.addWidget(gok_); self.gel_shown = None; self.gel_anim = None
        self.msg_btn = QPushButton('  Diğer mesaj', self); self.msg_btn.setFocusPolicy(Qt.NoFocus); self.msg_btn.hide()
        self.msg_btn.setIcon(tool_icon('Post-it')); self.msg_btn.setIconSize(QSize(24, 24))
        self.msg_btn.setStyleSheet('QPushButton{background:#13233a;color:white;border:1px solid #ffb020;border-radius:12px;padding:0 18px;font-size:18px;font-weight:600;}')
        self.msg_btn.clicked.connect(self.open_msg)
        self.ara_btn = neon_button(self, main.open_ara, 22)
        self.yer_btn = neon_button(self, main.open_preview, 24); self.yer_btn.setText('  Sınav yerleri'); self.yer_btn.setIcon(tool_icon('Sayaç')); self.yer_btn.setIconSize(QSize(30, 30)); self.yer_btn.hide()   # teneffüs modu: sağ altta
        self.okul_btn = neon_button(self, main.open_okul, 24); self.okul_btn.setText('  Okul araçları'); self.okul_btn.setIcon(tool_icon('Okul araçları')); self.okul_btn.setIconSize(QSize(30, 30)); self.okul_btn.hide()   # teneffüs: panel gizli, araçlar buradan
    def place_ara(self):
        """'Nerede sınava gireceğim?' en üstte, ortada."""
        self.ara_btn.adjustSize(); self.ara_btn.move((self.width() - self.ara_btn.width())//2, 12); self.ara_btn.raise_()
    def open_msg(self):
        st = self.st; plan = self.main.seat_plan(dict(st, phase='during')) if st else None
        if st and plan and plan.get('tur') == 'salon': SalonMesajDialog(self.main, st, plan).exec_()
    def open_kagit(self):
        st = self.st; plan = self.main.seat_plan(dict(st, phase='during')) if st else None
        if st and plan and plan.get('tur') == 'salon':
            if KagitDialog(self.main, st, plan).exec_(): self.update_kagit(st, plan)
    def update_kagit(self, st, plan):
        """Gözcünün son kâğıt bildiriminin durumu: Gönderildi → Görüldü → Kâğıt yolda (yeşil şerit, 'Kâğıt geldi')."""
        m = self.main.kagit_last(st) if st else None
        if m is None:
            self.kag_pill.hide(); self.gel_box.hide(); self.kag_ref = None; return
        ev = self.main.kagit_events(st, plan).get(m.get('id'), {}); yolda = ev.get('kagit_yolda'); self.kag_ref = m.get('id')
        lst_ = ', '.join('%s %d' % (c, n) for c, n in (m.get('kagit') or {}).items() if n)
        if yolda:
            if time.time() - float(yolda.get('zaman') or time.time()) > 600:   # 10 dk içinde 'Kâğıt geldi' denmezse kendiliğinden kapanır
                self.main.kagit_geldi(st, plan, m['id']); self.kag_pill.hide(); self.gel_box.hide(); return
            pill = ('Kâğıt yolda  ·  ' + lst_, '#9ff0c9', 'rgba(34,192,122,0.20)', '#22c07a')
            if self.gel_shown != m['id']:
                self.gel_shown = m['id']; t_ = time.localtime(float(yolda.get('zaman') or time.time()))
                self.gel_lbl.setText('Kâğıdınız geliyor\n%s  ·  yola çıktı %02d.%02d' % (lst_, t_.tm_hour, t_.tm_min))
                w = min(self.width() - 80, 1200); self.gel_box.setFixedWidth(w); self.gel_box.adjustSize(); self.gel_box.show(); self.gel_box.raise_()
                x_ = (self.width() - w)//2; a_ = QVariantAnimation(self); a_.setStartValue(-self.gel_box.height() - 10); a_.setEndValue(18); a_.setDuration(650)
                a_.setEasingCurve(QEasingCurve.OutBack); a_.valueChanged.connect(lambda v: self.gel_box.move(x_, int(v))); a_.start(); self.gel_anim = a_
                try: play_sound(os.path.join(_APP_DIR, 'sesler', 'bildirim.wav'), 0.8)
                except Exception: pass
        elif ev.get('goruldu'): pill = ('Görüldü  ·  Öğretmenler odasında alarm çalıyor', '#ffd88a', 'rgba(255,176,32,0.18)', '#ffb020')
        else: pill = ('Gönderildi  ·  Öğretmenler odasına iletiliyor', '#b8ccff', 'rgba(47,107,255,0.20)', '#2f6bff')
        k_ = min(self.width()/1600, self.height()/900)
        self.kag_pill.setText('  ●  ' + pill[0] + '  ')
        self.kag_pill.setStyleSheet('QLabel{color:%s;background:%s;border:1px solid %s;border-radius:%dpx;padding:6px 14px;font-size:%dpx;font-weight:600;}' % (pill[1], pill[2], pill[3], int(18*k_), max(12, int(17*k_))))
        self.kag_pill.adjustSize(); self.kag_pill.move(20, int(self.height() - 58*k_ - self.kag_pill.height() - 10*k_)); self.kag_pill.show(); self.kag_pill.raise_()
    def kagit_ok(self):
        st = self.st; plan = self.main.seat_plan(dict(st, phase='during')) if st else None
        if st and plan and self.kag_ref: self.main.kagit_geldi(st, plan, self.kag_ref)
        self.gel_box.hide(); self.kag_pill.hide(); self.kag_ref = None
    def show_duyuru(self, d):
        if not d or d.get('id') == self.duyuru_id and self.duyuru_box.isVisible(): return
        self.duyuru_id = d.get('id'); self.duyuru_lbl.setText('Duyuru:  ' + d.get('metin', ''))
        w = min(self.width() - 80, 1200); self.duyuru_box.setFixedWidth(w); self.duyuru_box.adjustSize()
        self.duyuru_box.move((self.width() - w)//2, 18); self.duyuru_box.show(); self.duyuru_box.raise_()
    def dismiss_duyuru(self):
        self.duyuru_box.hide(); self.main.duyuru_seen(self.duyuru_id)
    def confirm_yoklama(self):
        st = self.st; plan = self.main.seat_plan(st) if st else None
        if st and plan and plan['tur'] == 'salon':
            self.main.yok_confirm(st, plan); self.update_yok_btn(); self.fx_kind = 'ok'; self.fx_t0 = time.monotonic(); self.start_fx(1.7)
    def update_yok_btn(self):
        st = self.st; show = bool(st and self.yok_on)
        k_ = min(self.width()/1600, self.height()/900)
        self.kagit_btn.setVisible(show); self.kagit_btn.setFixedHeight(int(46*k_)); self.kagit_btn.adjustSize(); self.kagit_btn.move(20, int(self.height() - 58*k_))
        self.msg_btn.setVisible(show); self.msg_btn.setFixedHeight(int(46*k_)); self.msg_btn.adjustSize()
        self.msg_btn.move(self.kagit_btn.geometry().right() + 10 if show else 20, int(self.height() - 58*k_))
        self.yok_btn.setVisible(show)
        if not show: return
        done = self.main.yok_state(st)['onay']
        self.yok_btn.setText('Onaylandı  ✓' if done else 'Yoklamayı onayla'); self.yok_btn.setEnabled(not done)
        self.yok_btn.setStyleSheet('QPushButton{background:%s;color:%s;border:none;border-radius:12px;padding:0 22px;font-size:19px;font-weight:700;}'
                                   % (('#1f4d36', '#9fe3bd') if done else ('#2fbf71', '#06240f')))
        k = min(self.width()/1600, self.height()/900); h = int(46*k); self.yok_btn.setFixedHeight(h); self.yok_btn.adjustSize()
        self.yok_btn.move(int(self.width()/2 + 300*k), int(self.height() - 58*k))
    def seat_at(self, pos):
        return next((no for no, r in self.seat_rects.items() if r.contains(QPointF(pos))), None)
    def mousePressEvent(self, e):
        if self.yok_on:   # tek dokunuş: gelmedi / geri al (basılı tutma yok)
            self.press_seat = self.seat_at(e.pos())
            if self.press_seat is not None:
                no_ = self.press_seat; self.long_press(); self.fx_seat = no_; self.fx_t0 = time.monotonic(); self.fx_kind = 'tap'; self.start_fx(.6)
        e.accept()
    def mouseReleaseEvent(self, e):
        self.press_timer.stop(); self.press_seat = None; e.accept()
    def start_fx(self, dur):
        self.fx_until = time.monotonic() + dur
        if not hasattr(self, 'anim_timer'): self.anim_timer = QTimer(self); self.anim_timer.timeout.connect(self.update)
        if not self.anim_timer.isActive(): self.anim_timer.start(33)
    def draw_fx(self, p, k):
        """Dokunuş: sıranın çevresinde genişleyen kırmızı dalga; onay: kartlar sırayla yeşil parlar."""
        t = time.monotonic() - getattr(self, 'fx_t0', -99)
        if getattr(self, 'fx_kind', '') == 'tap' and t < .6 and getattr(self, 'fx_seat', None) in self.seat_rects:
            r = self.seat_rects[self.fx_seat]; g = t/.6; q = QColor(255, 77, 94, int(220*(1 - g)))
            p.setPen(QPen(q, 4*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r.adjusted(-18*k*g, -18*k*g, 18*k*g, 18*k*g), 12*k, 12*k)
        if getattr(self, 'fx_kind', '') == 'ok' and t < 1.6:
            for i, no in enumerate(sorted(self.seat_rects)):
                if no in self.absent: continue
                u = t - i*.025
                if 0 < u < .9: a = math.sin(u/.9*math.pi); p.setPen(Qt.NoPen); p.setBrush(QColor(47, 191, 113, int(110*a))); p.drawRoundedRect(self.seat_rects[no], 10*k, 10*k)
    def long_press(self):
        st = self.st; no = self.press_seat; self.press_seat = None
        if st is None or no is None or not self.yok_on: return
        plan = self.main.seat_plan(st)
        if plan and plan['tur'] == 'salon':
            self.main.yok_toggle(st, plan, no); self.absent = set(self.main.yok_state(st)['gelmedi']); self.update_yok_btn(); self.update()
    def fit(self, vp):
        self.setGeometry(vp); self.hide_btn.adjustSize()
        self.hide_btn.move(self.width() - self.hide_btn.width() - 20, self.height() - self.hide_btn.height() - 20)
        if hasattr(self, 'yok_btn'): self.update_yok_btn()
        if hasattr(self, 'ara_btn'): self.place_ara()
    MATH_INTRO = 6.0   # sn: matematik sınavının açılışı (altın oran sarmalı çizilir)
    def set_state(self, st, grade):
        self.st = st; self.grade = grade
        tn_ = st.get('phase') == 'teneffus' and st.get('yerler')
        if tn_ != self.yer_btn.isVisible() or tn_:
            self.yer_btn.setVisible(bool(tn_)); self.yer_btn.adjustSize()
            self.yer_btn.move(self.width() - self.yer_btn.width() - 24, self.height() - self.yer_btn.height() - 24); self.yer_btn.raise_()
        tk_ = st.get('phase') == 'teneffus'
        if tk_ != self.okul_btn.isVisible() or tk_:
            self.okul_btn.setVisible(tk_); self.okul_btn.adjustSize()
            self.okul_btn.move(24, self.height() - self.okul_btn.height() - 24); self.okul_btn.raise_()   # sol altta (sağ alt: Sınav yerleri / Gizle)
        if True:
            self.hide_btn.adjustSize(); self.hide_btn.move((self.yer_btn.x() - self.hide_btn.width() - 16) if tn_ else (self.width() - self.hide_btn.width() - 20), self.height() - self.hide_btn.height() - (34 if tn_ else 20))
        other = st.get('diger') if st.get('phase') == 'preview' else ''
        self.other_btn.setVisible(bool(other))
        if other:   # sağ altta, Gizle'nin solunda
            self.other_btn.setText('Diğer sınav:  %s  ›' % other); self.other_btn.adjustSize()
            self.other_btn.move(self.hide_btn.x() - self.other_btn.width() - 14, self.height() - self.other_btn.height() - 20)
        own = st['exams'].get(grade) or next(iter(st['exams'].values()))
        if exam_theme(own)[1] == 'formul' and st['phase'] in ('before', 'during') and getattr(self, 'intro_key', None) != st['key']:
            self.intro_key = st['key']; self.anim_t0 = time.monotonic()   # ekran ilk açıldığında bir kez
        anim = time.monotonic() - getattr(self, 'anim_t0', -99) < self.MATH_INTRO or (st['phase'] == 'during' and st['end'] - st['t'] <= 60 and exam_theme(own)[1] == 'formul')
        iv_ = 33 if anim else 50
        if not anim and st['phase'] in ('teneffus', 'after'): anim = True   # canlı tema / nefes alan neon (oturma düzeni olmayan ekranlar)
        if not anim and st['phase'] in ('before', 'during'):
            pl_ = self.main.seat_plan(st) if hasattr(self.main, 'seat_plan') else None
            anim = not (pl_ and seat_layout(pl_))   # sayaç ekranı: tema akıcı; fotoğraflı plan saniyede bir
        if getattr(self, 'fx_until', 0) > time.monotonic(): anim = True   # dokunuş/onay efekti
        if anim and not hasattr(self, 'anim_timer'):
            self.anim_timer = QTimer(self); self.anim_timer.timeout.connect(self.update)
        if hasattr(self, 'anim_timer'):
            if anim and (not self.anim_timer.isActive() or self.anim_timer.interval() != iv_): self.anim_timer.start(iv_)
            elif not anim and self.anim_timer.isActive(): self.anim_timer.stop()
        self.update()
    def draw_math_intro(self, p, W, H, k, font, theme, e):
        """Altın oran sarmalı kalemle çiziliyormuş gibi oluşur, ardından 'Matematik' yazısı belirir."""
        p.save(); p.fillRect(QRectF(0, 0, W, H), QColor(10, 16, 28, int(255*min(1, (self.MATH_INTRO - e)/.6))))
        fade = min(1, (self.MATH_INTRO - e)/.6)
        # altın oran sarmalı: r = r0·φ^(2θ/π), içten dışa kalemle çizilir; yanında altın dikdörtgen bölmeleri silik
        phi = (1 + 5**.5)/2; c = QColor(theme); prog = min(1, e/3.4)
        th_max = 4.5*math.pi; rmax = min(W, H)*.30; r0 = rmax/phi**(2*th_max/math.pi)
        cx, cy = W/2 + rmax*.12, H*.42
        q = QColor(c); q.setAlpha(int(60*fade)); p.setPen(QPen(q, 1.5*k)); p.setBrush(Qt.NoBrush)
        for n_ in range(1, 9):   # her çeyrek turda bir çember yayı kılavuzu
            th = n_*math.pi/2
            if th > th_max*prog: break
            rr = r0*phi**(2*th/math.pi); p.drawEllipse(QPointF(cx, cy), rr, rr)
        pts = [QPointF(cx + r0*phi**(2*th/math.pi)*math.cos(th), cy - r0*phi**(2*th/math.pi)*math.sin(th))
               for th in [th_max*prog*i_/240 for i_ in range(241)]]
        q = QColor(c); q.setAlpha(int(255*fade)); p.setPen(QPen(q, 5*k, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.drawPolyline(QPolygonF(pts))
        if prog < 1:   # kalemin ucu
            tip = pts[-1]; g = QRadialGradient(tip, 26*k); g.setColorAt(0, QColor(255, 255, 255, 230)); g.setColorAt(1, QColor(255, 255, 255, 0))
            p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(tip, 26*k, 26*k)
        t2 = max(0.0, min(1.0, (e - 3.4)/1.2))
        if t2 > 0:
            q = QColor('#ffffff'); q.setAlpha(int(255*t2*fade)); p.setPen(q); p.setFont(font(110, True))
            p.drawText(QRectF(0, H*.74, W, 140*k), Qt.AlignCenter, 'Matematik')
            q = QColor('#9fb3cc'); q.setAlpha(int(255*t2*fade)); p.setPen(q); p.setFont(font(30))
            p.drawText(QRectF(0, H*.74 + 130*k, W, 50*k), Qt.AlignCenter, 'Ortak Yazılı Sınav')
        p.restore()
    def paintEvent(self, e):
        st = self.st
        if not st: return
        from PyQt5.QtGui import QFont
        import datetime
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or fams.get('Poppins-Regular') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        exams = st['exams']; own = exams.get(self.grade) or next(iter(exams.values()))
        title = own if self.grade in exams or '' in exams else 'Ortak Yazılı Sınav'   # bu sınıf düzeyinin o saatte ortak sınavı yoksa (seçmeli)
        theme, kind = exam_theme(own)
        g = QLinearGradient(0, 0, 0, H); g.setColorAt(0, QColor('#0f1c2e')); g.setColorAt(1, QColor('#0a121e')); p.fillRect(self.rect(), g)
        def font(px, bold=False):
            f = QFont(famb if bold else fam); f.setPixelSize(max(10, int(px*k))); return f
        if st['phase'] == 'teneffus':   # teneffüs modu: saat, sıradaki ders, sınava geri sayım, 5 günlük takvim
            draw_teneffus(p, W, H, k, font, st['tn']); p.end(); return
        draw_exam_theme(p, W, H, k, kind, theme, time.time() % 86400)   # canlı: akıcı ekranlarda saniyede ~11 kez çizilir
        def text(rect, s_, px, color, bold=False, align=Qt.AlignCenter):
            p.setFont(font(px, bold)); p.setPen(QColor(color)); p.drawText(rect, align, s_)
        hm = lambda x: '%02d.%02d' % (x//3600, x%3600//60)
        ms = lambda x: '%02d:%02d' % (x//60, x%60) if x < 3600 else '%d:%02d:%02d' % (x//3600, x%3600//60, x%60)
        phase = st['phase']; left = st['end'] - st['t'] if phase == 'during' else st['start'] - st['t']
        accent = theme
        if phase == 'during' and left <= 600: accent = '#ff5d5d' if left <= 300 else '#ffc145'
        if phase == 'after': accent = '#9fb3cc'
        day = st.get('date') or datetime.date.today()
        plan = self.main.seat_plan(st) if hasattr(self.main, 'seat_plan') else None
        if plan and plan['tur'] == 'sinif' and phase in ('before', 'preview'):
            ev = home_seat_plan(plan)   # sınavdan önce: sınıf, okul numarasına göre kendi sıralarında; her öğrencinin altında gideceği salon ve sıra
            if ev:
                own_ = exam_course(day.isoformat(), st['lesson'], plan['sinif'], own) if hasattr(day, 'isoformat') else own
                when = ('Başlamasına %s' % ms(max(0, left))) if phase == 'before' else ('%s %d %s · %s – %s' % ('Bugün' if day == st.get('today', day) else '', day.day, TR_MONTHS[day.month-1], hm(st['start']), hm(st['end']))).strip()
                ev['baslik'] = 'Sınav yerleri  ·  %s' % plan['sinif']
                self.absent = set()
                ev['saat'] = ('Başlamasına %s' % ms(max(0, left))) if phase == 'before' else '%s – %s' % (hm(st['start']), hm(st['end']))
                self.draw_seatmap(p, W, H - 40*k, k, font, ev, theme, accent, '%s  ·  %s  ·  %s' % (st['lesson'], own_, ('Bugün' if day == st.get('today', day) else '%d %s' % (day.day, TR_MONTHS[day.month-1]))))
                p.end(); return
        seatmap = bool(plan and plan['tur'] == 'salon' and phase in ('before', 'during') and seat_layout(plan))
        yok_on = seatmap and self.main.yok_open(st)
        if yok_on != self.yok_on: self.yok_on = yok_on; QTimer.singleShot(0, self.update_yok_btn)
        if seatmap:
            self.absent = set(self.main.yok_state(st)['gelmedi'])
            self.draw_seatmap(p, W, H, k, font, dict(plan, saat=('Kalan %s' if phase == 'during' else 'Başlamasına %s') % ms(max(0, left)), hb_per=.6 if phase == 'during' and left <= 300 else 1.0), theme, accent, '%s  ·  %s' % (st['lesson'], own if self.grade in exams else 'Ortak Yazılı Sınav'))
            self.draw_fx(p, k)   # dokunuş / onay efekti
            if yok_on:   # yoklama şeridi: geri sayım + gelmeyen sayısı
                yl = st['end'] - st['t']
                bx_ = max(W/2 - 520*k, self.msg_btn.geometry().right() + 16 if self.msg_btn.isVisible() else 0); bn = QRectF(bx_, H - 58*k, W/2 + 286*k - bx_, 46*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#3b2a10')); p.drawRoundedRect(bn, 12*k, 12*k)
                p.setBrush(QColor('#ffb020')); p.drawRoundedRect(QRectF(bn.x(), bn.y(), 230*k, bn.height()), 12*k, 12*k)
                text(QRectF(bn.x(), bn.y(), 230*k, bn.height()), 'YOKLAMA  %s' % ms(max(0, yl)), 21, '#1a1206', True)
                self.hb_items['yok'] = dict(rect=QRectF(bn.x(), bn.y(), 230*k, bn.height()), m=0, kind='box', text='YOKLAMA  %s' % ms(max(0, yl)), font=font(21, True), color='#ffb020', fg='#1a1206', k=k, bg='#0d1726', strip='#3b2a10', per=.6 if yl <= 300 else 1.0)
                text(QRectF(bn.x() + 246*k, bn.y(), bn.width() - 260*k, bn.height()), ('Gelmeyenin fotoğrafına dokunun  ·  Gelmeyen: %d' if BOARD_PHOTOS else 'Gelmeyenin adına dokunun  ·  Gelmeyen: %d') % len(self.absent), 18, '#ffd78a', True, Qt.AlignLeft | Qt.AlignVCenter)
            e_ = time.monotonic() - getattr(self, 'anim_t0', -99)
            if kind == 'formul' and e_ < self.MATH_INTRO: self.draw_math_intro(p, W, H, k, font, theme, e_)
            p.end(); return
        X0, CW, sc = (W*.62, W*.38, .55) if plan else (0, W, 1)   # oturma planı varsa sayaç sağda
        if plan: self.draw_plan(p, QRectF(24*k, 24*k, W*.62 - 32*k, H - 48*k), plan, k, font, theme, phase)
        text(QRectF(X0, 34*k, CW, 44*k), ('%s  ·  %d %s' % (st['lesson'].upper(), day.day, TR_MONTHS[day.month-1])) if plan else
             'ORTAK YAZILI SINAV  ·  %s  ·  %d %s %s' % (st['lesson'].upper(), day.day, TR_MONTHS[day.month-1], TR_DAYS[day.weekday()]), 26, '#8ea3c0', True)
        # Karşılama: bu sınıfın dersi büyük, öbür sınıf düzeyleri altında tek satır
        num = lambda kv: int(kv[0]) if kv[0].isdigit() else 0
        same = [gr for gr, d in sorted(exams.items(), key=num) if d == own and gr]
        text(QRectF(X0, 82*k, CW, 110*k), title, 84*sc if plan and len(title) > 14 else 84, theme, True)
        others = ['%s. sınıflar: %s' % (gr, d) for gr, d in sorted(exams.items(), key=num) if d != own and gr]
        line = ((', '.join(same[:-1]) + ' ve ' + same[-1] if len(same) > 1 else same[0]) + '. sınıflar') if same else '' + (('   ·   ' + '   ·   '.join(others)) if others and not plan else '')
        if plan and self.grade not in exams: line = ''   # seçmeli sınava giren düzeyde öbür düzeylerin listesi kafa karıştırır
        text(QRectF(X0, 190*k, CW, 44*k), line, 28, '#c9d6ea')
        top = 250*k; rest = H - top - 30*k
        if phase == 'preview':
            when = 'Bugün' if day == st.get('today') else ('Yarın' if st.get('today') and (day - st['today']).days == 1 else TR_DAYS[day.weekday()])
            text(QRectF(X0, top, CW, 56*k), '%s  ·  %d %s %s' % (when, day.day, TR_MONTHS[day.month-1], TR_DAYS[day.weekday()]), 34, '#c9d6ea')
            text(QRectF(X0, top + 40*k, CW, rest*.42), st['lesson'], 150*sc, theme, True)
            text(QRectF(X0, top + 40*k + rest*.42, CW, 60*k), 'Sınav %s – %s' % (hm(st['start']), hm(st['end'])), 40, '#ffffff', True)
            text(QRectF(X0, top + 110*k + rest*.42, CW, 90*k), 'Sınav saatinde salonunuza ve\nsıranıza geçin.', 28, '#9fb3cc')
        elif phase == 'after':
            from PyQt5.QtGui import QFontMetrics
            fE = font(130*sc, True); tE = 'Sınav bitti'; twE = QFontMetrics(fE).horizontalAdvance(tE); hE = QFontMetrics(fE).height()*1.25
            rE = QRectF(X0 + (CW - twE - 120*k)/2, top + (rest*.6 - hE)/2, twE + 120*k, hE)   # mavi neon tabela, yavaşça nefes alır
            draw_neon(p, rE, tE, fE, '#22e8ff', k, .75 + .25*math.sin(time.monotonic()*2*math.pi/2.4))
            text(QRectF(X0, top + rest*.6, CW, 60*k), 'Kâğıtlar toplanabilir  ·  Bitiş %s' % hm(st['end']), 32*(.8 if plan else 1), '#9fb3cc')
        else:
            text(QRectF(X0, top, CW, 56*k), ("Sınav %s'da başlıyor" % hm(st['start'])) if phase == 'before' else 'Kalan süre', 36, '#c9d6ea')
            pulse = 1 + .05*heart_beat(.6 if phase == 'during' and left <= 300 else 1.0)   # kalp atışı
            if kind == 'formul' and phase == 'during' and left <= 60: pulse = 1 + .05*abs(math.sin(time.monotonic()*math.pi))   # son dakika: nabız
            text(QRectF(X0, top + 40*k, CW, rest*.6), ms(max(0, left)), 250*sc*pulse, accent, True)
            bar_y = top + 40*k + rest*.6 + 6*k; bw = CW*.6; bx = X0 + (CW - bw)/2
            if phase == 'during' and kind == 'formul':   # matematik: her dakika bir dilim
                n_ = max(1, (st['end'] - st['start'])//60); used = (st['t'] - st['start'])/60.0; sw = bw/n_
                for i_ in range(n_):
                    fill = max(0.0, min(1.0, used - i_)); r_ = QRectF(bx + i_*sw + 1.5*k, bar_y - 4*k, sw - 3*k, 22*k)
                    p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 28)); p.drawRoundedRect(r_, 4*k, 4*k)
                    if fill > 0: p.setBrush(QColor(accent)); p.drawRoundedRect(QRectF(r_.x(), r_.y(), r_.width()*fill, r_.height()), 4*k, 4*k)
            elif phase == 'during':
                frac = min(1, max(0, (st['t'] - st['start'])/max(1, st['end'] - st['start'])))
                p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 30)); p.drawRoundedRect(QRectF(bx, bar_y, bw, 14*k), 7*k, 7*k)
                p.setBrush(QColor(accent)); p.drawRoundedRect(QRectF(bx, bar_y, bw*frac, 14*k), 7*k, 7*k)
            info = 'Saat %s  ·  Başlangıç %s  ·  Bitiş %s  ·  Süre %d dakika' % (hm(st['t']), hm(st['start']), hm(st['end']), (st['end'] - st['start'])//60)
            if plan: info = 'Saat %s  ·  %s – %s' % (hm(st['t']), hm(st['start']), hm(st['end']))
            text(QRectF(X0, bar_y + 28*k, CW, 50*k), info, 28, '#9fb3cc')
        e_ = time.monotonic() - getattr(self, 'anim_t0', -99)
        if kind == 'formul' and e_ < self.MATH_INTRO: self.draw_math_intro(p, W, H, k, font, theme, e_)
        p.end()

    def draw_plan(self, p, R, plan, k, font, theme, phase):
        """Oturma planı: sıra numarasına göre 4 sütun; her satırda sıra, ad soyad, sınıfı."""
        from PyQt5.QtGui import QFontMetrics, QFont
        p.save(); p.setPen(Qt.NoPen); p.setBrush(QColor(10, 18, 30, 235)); p.drawRoundedRect(R, 18*k, 18*k)   # desen okunurluğu bozmasın
        pad = 18*k; title_h = 54*k
        p.setFont(font(30, True)); p.setPen(QColor('#ffffff'))
        p.drawText(QRectF(R.x() + pad, R.y() + 8*k, R.width() - 2*pad, title_h), Qt.AlignVCenter | Qt.AlignLeft, ('Sınav yerleri  ·  %s' if plan['tur'] == 'sinif' else 'Bu salonda oturanlar  ·  %s') % plan['sinif'])
        p.setFont(font(20)); p.setPen(QColor('#8ea3c0'))
        p.drawText(QRectF(R.x() + pad, R.y() + 8*k, R.width() - 2*pad, title_h), Qt.AlignVCenter | Qt.AlignRight, '%d öğrenci' % len(plan['liste']))
        lst = plan['liste']; n = max(1, len(lst))
        if BOARD_PHOTOS and _PHOTOS['data'] and sum(1 for r in lst if r.get('no') in _PHOTOS['data']) >= len(lst)/2:
            self.draw_plan_photos(p, R, plan, k, font, theme, pad, title_h); p.restore(); return
        # Kâğıttaki gibi liste: Ad Soyad · Salon · Sıra; 20'den fazlaysa iki sütun
        cols = 1 if n <= 20 else 2; per = math.ceil(n/cols); gap = 24*k
        gx = R.x() + pad; gy = R.y() + title_h + 14*k; gw = (R.width() - 2*pad - gap*(cols - 1))/cols
        head_h = 34*k; rh = (R.bottom() - pad - gy - head_h)/per
        hf = font(17, True); af = font(min(24, rh/k*.52)); bf = font(min(26, rh/k*.56), True)
        for c in range(cols):
            x = gx + c*(gw + gap); no_w = (62 if plan['tur'] == 'salon' else 44)*k; sal_w = 84*k; sira_w = (16 if plan['tur'] == 'salon' else 64)*k
            p.setFont(hf); p.setPen(QColor('#8ea3c0'))
            salon_mode = plan['tur'] == 'salon'   # salonda: Sıra · Ad Soyad · Sınıf
            p.drawText(QRectF(x + no_w, gy, gw - no_w - sal_w - sira_w, head_h), Qt.AlignVCenter | Qt.AlignLeft, 'Ad Soyad')
            p.drawText(QRectF(x + gw - sal_w - sira_w, gy, sal_w, head_h), Qt.AlignVCenter | Qt.AlignHCenter, 'Sınıf' if salon_mode else 'Salon')
            p.drawText(QRectF(x + gw - sira_w, gy, sira_w - 6*k, head_h), Qt.AlignVCenter | Qt.AlignRight, '' if salon_mode else 'Sıra')
            if salon_mode: p.drawText(QRectF(x, gy, no_w - 8*k, head_h), Qt.AlignVCenter | Qt.AlignRight, 'Sıra')
            p.setPen(QPen(QColor(255, 255, 255, 40), 1)); p.drawLine(QPointF(x, gy + head_h), QPointF(x + gw, gy + head_h))
            for r_ in range(per):
                idx = c*per + r_
                if idx >= len(lst): continue
                y = gy + head_h + r_*rh; st_ = lst[idx]
                if r_ % 2 == 0: p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 12)); p.drawRect(QRectF(x, y, gw, rh))
                if salon_mode: p.setFont(bf); p.setPen(QColor(theme)); p.drawText(QRectF(x, y, no_w - 8*k, rh), Qt.AlignVCenter | Qt.AlignRight, str(st_['sira']))
                else: p.setFont(font(min(18, rh/k*.4))); p.setPen(QColor('#5d6f88')); p.drawText(QRectF(x + 4*k, y, no_w - 8*k, rh), Qt.AlignVCenter | Qt.AlignRight, str(idx + 1))
                name_r = QRectF(x + no_w + 4*k, y, gw - no_w - sal_w - sira_w - 10*k, rh)
                f_ = QFont(af); px = f_.pixelSize()
                while px > 11 and QFontMetrics(f_).horizontalAdvance(st_['ad']) > name_r.width(): px -= 1; f_.setPixelSize(px)   # ad sığana kadar küçülür
                p.setFont(f_); p.setPen(QColor('#ffffff')); p.drawText(name_r, Qt.AlignVCenter | Qt.AlignLeft, st_['ad'])
                if salon_mode:
                    p.setFont(af); p.setPen(QColor('#9fb3cc')); p.drawText(QRectF(x + gw - sal_w - sira_w, y, sal_w, rh), Qt.AlignVCenter | Qt.AlignHCenter, str(st_['sinif'])); continue
                p.setFont(bf); p.setPen(QColor(theme)); p.drawText(QRectF(x + gw - sal_w - sira_w, y, sal_w, rh), Qt.AlignVCenter | Qt.AlignHCenter, str(st_['salon']))
                p.setPen(QColor('#ffffff')); p.drawText(QRectF(x + gw - sira_w, y, sira_w - 6*k, rh), Qt.AlignVCenter | Qt.AlignRight, str(st_['sira']))
        p.restore()

class WelcomeCard(QWidget):
    """Açılışta ve her dersin başında: Boş tahta · Son PDF'im · Sınav modu · Bu derste kullanmayacağım."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.info = {}
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.buttons = []
        for label, icon, fn in (('Boş tahta', 'Yeni tahta', main.welcome_blank), ('Son PDF’im', 'PDF aç', main.welcome_pdf), ('Sınav modu', 'Sayaç', main.welcome_exam)):
            from PyQt5.QtWidgets import QToolButton
            b = QToolButton(self); b.setFocusPolicy(Qt.NoFocus); b.setIcon(tool_icon(icon)); b.setIconSize(QSize(64, 64)); b.setText(label)
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)   # simge üstte, yazı altta
            b.setStyleSheet('QToolButton{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:22px;color:white;font-size:22px;font-weight:600;padding:22px 6px 18px 6px;}'
                            'QToolButton:pressed{background:rgba(255,255,255,0.14);}')
            b.clicked.connect(fn); self.buttons.append(b)
        self.skip = QPushButton('Bu derste tahtayı kullanmayacağım', self); self.skip.setFocusPolicy(Qt.NoFocus); self.skip.clicked.connect(main.welcome_skip)
        self.skip.setStyleSheet('QPushButton{background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.18);border-radius:16px;color:#c9d6ea;font-size:22px;font-weight:600;}'
                                'QPushButton:pressed{background:rgba(255,255,255,0.12);}')
    def card(self):
        W, H = min(980, self.width() - 40), 560
        return QRectF((self.width() - W)/2, (self.height() - H)/2, W, H)
    def resizeEvent(self, e):
        R = self.card(); x = R.x() + 56; w = R.width() - 112; bw = (w - 40)/3
        for i, b in enumerate(self.buttons): b.setGeometry(int(x + i*(bw + 20)), int(R.y() + 250), int(bw), 170)
        self.skip.setGeometry(int(x), int(R.bottom() - 104), int(w), 62)
    def set_info(self, info): self.info = info; self.update()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(px); return f
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        p.fillRect(self.rect(), QColor(8, 14, 26, 170)); R = self.card()
        g = QLinearGradient(R.topLeft(), R.bottomLeft()); g.setColorAt(0, QColor('#13233a')); g.setColorAt(1, QColor('#0d1828'))
        p.setPen(QPen(QColor(255, 255, 255, 40), 1.5)); p.setBrush(g); p.drawRoundedRect(R, 28, 28)
        x = R.x() + 56; w = R.width() - 112; i = self.info
        def text(y, h, s, f, c): p.setFont(f); p.setPen(QColor(c)); p.drawText(QRectF(x, y, w, h), Qt.AlignLeft | Qt.AlignVCenter, s)
        p.setFont(font(20, True)); p.setPen(QColor('#5cc8ff')); p.drawText(QRectF(x, R.y() + 40, w, 34), Qt.AlignRight | Qt.AlignVCenter, PRODUCT)
        text(R.y() + 40, 34, i.get('ust', ''), font(22, True), '#8ea3c0')
        text(R.y() + 82, 80, i.get('baslik', 'Hoş geldiniz'), font(52 if len(i.get('baslik', '')) < 30 else 42, True), '#ffffff')
        text(R.y() + 160, 44, i.get('alt', ''), font(32), '#5cc8ff')
        p.setFont(font(16)); p.setPen(QColor('#6c7f99'))
        p.drawText(QRectF(x, R.bottom() - 38, w, 26), Qt.AlignLeft | Qt.AlignVCenter, 'Uygulama kapanmaz, alttaki görev çubuğuna iner; sonraki dersin başında yeniden sorar.')
        p.end()
    def mousePressEvent(self, e): e.accept()   # kartın dışına dokunmak tahtaya yazmasın

class SalonBrowser(QWidget):
    """Öğretmenler odası: her sınavın her salonunda kim oturuyor, o saatte salonda dersi olan öğretmen kim."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.plans = main.upcoming_plans('*', started=True); self.pi = 0; self.salon = None
        self.exam_btns = []; self.salon_btns = {}
        self.close_btn = QPushButton('Kapat', self); self.close_btn.setFocusPolicy(Qt.NoFocus); self.close_btn.setMinimumHeight(50)
        self.close_btn.setStyleSheet('QPushButton{background:rgba(255,255,255,0.10);color:white;border:1px solid rgba(255,255,255,0.2);border-radius:12px;padding:0 26px;font-size:19px;}')
        self.close_btn.clicked.connect(main.close_salons)
        self.deneme_btn = QPushButton('Sınav anı (deneme)', self); self.deneme_btn.setFocusPolicy(Qt.NoFocus); self.deneme_btn.setMinimumHeight(50)
        self.deneme_btn.setStyleSheet('QPushButton{background:#3a1f12;color:#ffd9b8;border:1px solid #f06d0c;border-radius:12px;padding:0 26px;font-size:19px;font-weight:600;}')
        self.deneme_btn.clicked.connect(main.open_deneme)
        self.ara_btn = neon_button(self, main.open_ara, 19)
        for i, pl in enumerate(self.plans):
            p_, day, lesson = pl[0], pl[1], pl[2]
            b = QPushButton('%d %s · %s' % (day.day, TR_MONTHS[day.month-1], lesson), self); b.setCheckable(True); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(48)
            b.clicked.connect(lambda c=False, i_=i: self.pick_exam(i_)); self.exam_btns.append(b)
        self.pick_exam(0)
    def chip_style(self, on): return ('QPushButton{background:%s;color:white;border:1px solid %s;border-radius:12px;padding:0 16px;font-size:18px;font-weight:600;}'
                                      % (('#2f6fd6', '#2f6fd6') if on else ('rgba(255,255,255,0.06)', 'rgba(255,255,255,0.16)')))
    def pick_exam(self, i):
        self.pi = i
        for k, b in enumerate(self.exam_btns): b.setChecked(k == i); b.setStyleSheet(self.chip_style(k == i))
        for b in self.salon_btns.values(): b.deleteLater()
        self.salon_btns = {}
        if not self.plans: return
        salons = sorted(self.plans[i][0].get('salonlar', {}), key=lambda s_: (int(s_.split('-')[0]) if s_.split('-')[0].isdigit() else 99, s_))
        for s_ in salons:
            b = QPushButton(s_, self); b.setFocusPolicy(Qt.NoFocus); b.setFixedHeight(48); b.clicked.connect(lambda c=False, x=s_: self.pick_salon(x)); b.show()
            self.salon_btns[s_] = b
        self.pick_salon(self.salon if self.salon in self.salon_btns else (salons[0] if salons else None)); self.relayout()
    def pick_salon(self, s_):
        self.salon = s_
        for k, b in self.salon_btns.items(): b.setStyleSheet(self.chip_style(k == s_))
        self.update()
    def resizeEvent(self, e): self.relayout()
    def relayout(self):
        W = self.width(); x = 32; y = 92
        for b in self.exam_btns:
            b.adjustSize(); b.move(int(x), int(y)); x += b.width() + 10
        self.close_btn.adjustSize(); self.close_btn.move(W - self.close_btn.width() - 32, 24)
        self.deneme_btn.adjustSize(); self.deneme_btn.move(W - self.close_btn.width() - self.deneme_btn.width() - 48, 24)
        self.ara_btn.adjustSize(); self.ara_btn.move(self.deneme_btn.x() - self.ara_btn.width() - 16, 24)
        cols = 4; bw = 96; gx = 32; gy = 170
        for n, b in enumerate(self.salon_btns.values()):
            b.setFixedWidth(bw); b.move(int(gx + (n % cols)*(bw + 10)), int(gy + (n // cols)*58))
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        k = min(self.width()/1600, self.height()/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); return f
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        p.fillRect(self.rect(), QColor('#0d1726'))
        p.setFont(font(34, True)); p.setPen(QColor('#ffffff')); p.drawText(QRectF(32, 22, self.width() - 300, 56), Qt.AlignVCenter | Qt.AlignLeft, 'Sınav salonları')
        if not self.plans or not self.salon:
            p.setFont(font(24)); p.setPen(QColor('#9fb3cc')); p.drawText(self.rect(), Qt.AlignCenter, 'Gösterilecek sınav planı yok.'); p.end(); return
        pl, day, lesson, a, b, start = self.plans[self.pi]
        lst = pl.get('salonlar', {}).get(self.salon, [])
        # o saatte bu salonda (sınıfta) dersi olan öğretmen: ders programından
        try: n = int(lesson.split('.')[0])
        except ValueError: n = 0
        cell = lesson_cell(self.salon, day.weekday(), n)
        L = 32 + 4*106 + 20; R = QRectF(L, 160, self.width() - L - 32, self.height() - 190)
        hm = lambda x: '%02d.%02d' % (x//3600, x%3600//60)
        p.setFont(font(22)); p.setPen(QColor('#8ea3c0'))
        teach = ', '.join(cell.get('ogretmen', [])) if cell else '—'
        ty = 170 + math.ceil(len(self.salon_btns)/4)*58 + 24   # salon düğmelerinin altında
        p.drawText(QRectF(32, ty, L - 52, 160), Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap,
                   '%s  ·  %s – %s\nSalonda dersi olan öğretmen:\n%s' % (lesson, hm(a), hm(b), teach))
        plan_ = dict(tur='salon', sinif=self.salon, liste=lst)
        if seat_layout(plan_):   # salonun gerçek sıra düzeni (sınav anındaki tahta görünümü)
            top2 = max([76] + [b.geometry().bottom() + 12 for b in self.exam_btns if b.isVisible()])   # sınav düğmelerinin altı
            R2 = QRectF(L - 10, top2, self.width() - L - 22, self.height() - top2 - 14); k2 = min(R2.width()/1600, R2.height()/900)
            def font2(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k2))); f.setWeight(QFont.Bold if b else QFont.Medium); return f
            p.save(); p.translate(R2.topLeft())
            _draw_seatmap(self, p, R2.width(), R2.height(), k2, font2, plan_, '#5cc8ff', '#5cc8ff', '%s  ·  %d %s  ·  %d öğrenci' % (lesson, day.day, TR_MONTHS[day.month-1], len(lst)))
            p.restore()
        else: ExamScreen.draw_plan(self, p, R, plan_, k, font, '#5cc8ff', 'during')
        p.end()
    def mousePressEvent(self, e): e.accept()

class KarargahScreen(QWidget):
    """Öğretmenler odası, sınav saatinde: bütün salonlar, yoklamalar, gözetmenler; salona dokununca fotoğraflı sıra planı."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.ex = None; self.detail = None; self.manual = False; self.tiles = {}
        self.absent = set(); self.seat_rects = {}
        def btn(t, f, prim=False):
            b = QPushButton(t, self); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(52); b.clicked.connect(f)
            b.setStyleSheet('QPushButton{background:%s;color:white;border:1px solid %s;border-radius:12px;padding:0 24px;font-size:19px;font-weight:600;}'
                            % (('#2f6fd6', '#2f6fd6') if prim else ('#1d3150', '#2a4468'))); return b
        self.b_duyuru = btn('Salonlara duyuru gönder', self.open_duyuru)
        self.b_pdf = btn('Gelmeyenler PDF (şimdi)', self.pdf_now)
        self.b_deneme = btn('Sınav anı (deneme)', self.main.open_deneme)
        self.b_ara = neon_button(self, self.main.open_ara, 20)
        self.b_deneme.setStyleSheet('QPushButton{background:#3a1f12;color:#ffd9b8;border:1px solid #f06d0c;border-radius:12px;padding:0 24px;font-size:19px;font-weight:600;}')
        self.b_hide = btn('Gizle', self.main.close_karargah)
        self.b_back = btn('‹  Bütün salonlar', self.back, True); self.b_back.hide()
        self.note_bar = QFrame(self); self.note_bar.hide(); self.note_bar.setStyleSheet('QFrame{background:#ffb020;border-radius:14px;}')
        nl = QHBoxLayout(self.note_bar); nl.setContentsMargins(20, 10, 10, 10); nl.setSpacing(14)
        self.note_lbl = QLabel(self.note_bar); self.note_lbl.setWordWrap(True); self.note_lbl.setStyleSheet('QLabel{color:#1a1206;font-size:22px;font-weight:700;background:transparent;}')
        self.note_open = QPushButton('Salonu aç', self.note_bar); self.note_ok = QPushButton('Gördüm', self.note_bar)
        for b_ in (self.note_open, self.note_ok):
            b_.setFocusPolicy(Qt.NoFocus); b_.setMinimumHeight(56); b_.setStyleSheet('QPushButton{background:#1a1206;color:#ffd78a;border:none;border-radius:10px;padding:12px 24px;font-size:20px;font-weight:700;}')
        self.note_ok.clicked.connect(self.seen_note); self.note_open.clicked.connect(lambda: self.seen_note(True))
        nl.addWidget(self.note_lbl, 1); nl.addWidget(self.note_open); nl.addWidget(self.note_ok); self.note_cur = None
        self.alarm = KagitAlarm(self)
        self.note = ''; self.timer = QTimer(self); self.timer.timeout.connect(self.update); self.timer.start(1000)
    def set_exam(self, ex):
        if self.ex is None or self.ex[2] != ex[2] or self.ex[1] != ex[1]: self.detail = None
        self.ex = ex; self.relayout(); self.update()
    def resizeEvent(self, e): self.relayout()
    def relayout(self):
        W, H = self.width(), self.height(); y = H - 70
        if hasattr(self, 'alarm'): self.alarm.setGeometry(self.rect())
        x = 40
        for b in (self.b_duyuru, self.b_pdf, self.b_deneme):
            b.setVisible(self.detail is None); b.adjustSize(); b.move(x, y); x += b.width() + 16
        self.b_ara.adjustSize(); self.b_ara.move((W - self.b_ara.width())//2, 12); self.b_ara.raise_()   # en üstte, ortada
        self.b_back.setVisible(self.detail is not None); self.b_back.adjustSize(); self.b_back.move(40, y)
        self.b_hide.adjustSize(); self.b_hide.move(W - self.b_hide.width() - 40, y)
    def back(self): self.detail = None; self.relayout(); self.update()
    def read_ids(self):
        try:
            with open(os.path.join(self.main.yok_dir(), 'mesaj-okundu.json'), encoding='utf-8') as f: return set(json.load(f))
        except (OSError, ValueError, TypeError): return set()
    def seen_note(self, open_=False):
        if self.note_cur:
            ids = sorted(self.read_ids() | {self.note_cur['id']})[-500:]
            try:
                with open(os.path.join(self.main.yok_dir(), 'mesaj-okundu.json'), 'w', encoding='utf-8') as f: json.dump(ids, f)
            except OSError: pass
            if open_: self.detail = self.note_cur['salon']; self.relayout()
        self.note_cur = None; self.note_bar.hide(); self.update()
    def check_notes(self, ys):
        """Salonlardan gelen okunmamış mesaj: üstte turuncu bildirim (yeni gelince ses)."""
        seen = self.read_ids(); un = []
        for s_, v in ys.items():
            for m in (v or {}).get('mesajlar', []):
                if m.get('tur') == 'geldi' or any((m.get('kagit') or {}).values()): continue   # kâğıt bildirimleri büyük alarmda
                if m.get('id') not in seen: un.append(dict(m, salon=s_))
        self.unread = {}
        for m in un: self.unread[m['salon']] = self.unread.get(m['salon'], 0) + 1
        for a_ in self.alarm.pending: self.unread[a_['salon']] = self.unread.get(a_['salon'], 0) + 1
        if not un: self.note_cur = None; self.note_bar.hide(); return
        m = min(un, key=lambda m: m.get('zaman', 0))
        if self.note_cur is None or self.note_cur['id'] != m['id']:
            self.note_cur = m; t_ = time.localtime(m.get('zaman', time.time()))
            more = len(un) - 1
            self.note_lbl.setText('%s salonundan mesaj  ·  %02d.%02d\n%s%s' % (m['salon'], t_.tm_hour, t_.tm_min, m.get('metin', ''), ('\n(+%d mesaj daha)' % more) if more else ''))
            W = self.width(); w_ = min(W - 80, 1300); self.note_bar.setFixedWidth(w_); self.note_bar.adjustSize(); self.note_bar.move((W - w_)//2, 12)
            self.note_bar.show(); self.note_bar.raise_()
            if m['id'] not in getattr(self, 'rung', set()):
                self.rung = getattr(self, 'rung', set()) | {m['id']}
                try: play_sound(os.path.join(_APP_DIR, 'sesler', 'bildirim.wav'), 1.0)
                except Exception: pass
    def info(self):
        pl, day, lesson, a, b = self.ex; data = self.main.yok_all(); key = Window.yok_key(day, lesson)
        now = self.main.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second
        return pl, day, lesson, a, b, {s_: data.get('%s_%s.json' % (key, s_)) for s_ in pl.get('salonlar', {})}, t
    def mousePressEvent(self, e):
        if self.detail is None:
            hit = next((s_ for s_, r in self.tiles.items() if r.contains(QPointF(e.pos()))), None)
            if hit:
                ys_ = self.info()[5]; ids = {m_.get('id') for m_ in (ys_.get(hit) or {}).get('mesajlar', [])}
                if ids:   # salona dokununca mesajları okundu sayılır
                    try:
                        with open(os.path.join(self.main.yok_dir(), 'mesaj-okundu.json'), 'w', encoding='utf-8') as f: json.dump(sorted(self.read_ids() | ids)[-500:], f)
                    except OSError: pass
                    self.note_cur = None
                self.detail = hit; self.relayout(); self.update()
        e.accept()
    def pdf_now(self):
        if not self.ex: return
        try: out = self.main.make_reports(self.ex)
        except Exception as e: self.note = 'PDF hazırlanamadı: %s' % e; return
        self.note = '“%s” Drive’daki Sınav Yoklamaları klasörüne gönderiliyor…' % out[0][1]
    def open_duyuru(self):
        if self.ex: DuyuruDialog(self.main, self.ex).exec_()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); f.setWeight(QFont.Bold if b else QFont.Medium); return f
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        p.fillRect(self.rect(), QColor('#0d1726'))
        def text(r, s_, f, c, al=Qt.AlignLeft | Qt.AlignVCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
        if not self.ex: p.end(); return
        pl, day, lesson, a, b, ys, t = self.info()
        ms = lambda x: '%02d:%02d' % (x//60, x%60)
        try: self.alarm.sync(ys)
        except Exception: pass
        self.check_notes(ys)
        started = t >= a + YOKLAMA_BASLA; yok_open = started and t < b   # yoklama sınavın 5. dakikasında açılır, sınav bitene kadar
        try: n = int(lesson.split('.')[0])
        except ValueError: n = 0
        if self.detail is not None:
            lst = pl['salonlar'].get(self.detail, []); y_ = ys.get(self.detail) or {}
            msgs_ = y_.get('mesajlar', [])
            self.absent = {int(r['sira']) for r in y_.get('gelmedi', [])}
            plan = dict(tur='salon', sinif=self.detail, liste=lst)
            if seat_layout(plan):
                head = '%s  ·  Gelmeyen: %d  ·  %s' % (lesson, len(self.absent), ('Kalan %s' % ms(max(0, b - t))) if a <= t < b else ('Başlamasına %s' % ms(a - t) if t < a else 'Sınav bitti'))
                _draw_seatmap(self, p, W, H - 60*k, k, font, plan, '#5cc8ff', '#5cc8ff', head)
                if msgs_:   # bu salonun mesajları, altta
                    mt = '   ·   '.join('%s  %s' % (time.strftime('%H.%M', time.localtime(m_.get('zaman', 0))), m_.get('metin', '')) for m_ in msgs_[-3:])
                    mr = QRectF(300*k, H - 66*k, W - 600*k, 46*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#3b2a10')); p.drawRoundedRect(mr, 12*k, 12*k)
                    text(mr.adjusted(16*k, 0, -16*k, 0), '✉  ' + mt, font(18, True), '#ffd78a')
            else:
                ExamScreen.draw_plan(self, p, QRectF(40, 40, W - 80, H - 140), plan, k, font, '#5cc8ff', 'during')
            p.end(); return
        title = 'Sınav salonları  ·  %s  ·  %s' % (lesson, tr_date(day))
        try: bw_ = self.b_ara.width() if self.b_ara.isVisible() else 0
        except Exception: bw_ = 420
        tz = (W/2 - bw_/2 - 20) - 40*k   # başlık ortadaki arama düğmesinin solunda biter
        fT = font(32, True)
        while fT.pixelSize() > 12 and QFontMetrics(fT).horizontalAdvance(title) > tz: fT.setPixelSize(fT.pixelSize() - 1)
        text(QRectF(40*k, 18*k, tz, 52*k), title, fT, '#ffffff')
        right = ('Kalan %s' % ms(b - t)) if a <= t < b else (('Başlamasına %s' % ms(a - t)) if t < a else 'Sınav bitti')
        rz = W/2 + bw_/2 + 20
        text(QRectF(rz, 18*k, W - 40*k - rz, 52*k), right, font(30, True), '#5ec8ff', Qt.AlignRight | Qt.AlignVCenter)
        if t < b:   # kalp atışı
            tw_ = QFontMetrics(font(30, True)).horizontalAdvance(right) + 8*k
            self.hb_items['clock'] = dict(rect=QRectF(W - 40*k - tw_, 18*k, tw_, 52*k), kind='text', text=right, font=font(30, True), color='#5ec8ff', k=k, bg='#0d1726', per=.6 if a <= t and b - t <= 300 else 1.0)
        tot = sum(len(v) for v in pl['salonlar'].values()); gel = sum(len((v or {}).get('gelmedi', [])) for v in ys.values())
        waiting = [s_ for s_, v in ys.items() if not v] if started else []
        stats = [('Salon', str(len(ys)), '#ffffff'), ('Öğrenci', str(tot), '#ffffff'), ('Gelmeyen', str(gel), '#ff5d6c'),
                 ('Yoklama gelmeyen', str(len(waiting)) if started else '—', '#ffb020'),
                 ('Yoklama kapanışı', ms(b - t) if yok_open else ('kapandı' if started else '—'), '#ffb020')]
        sw = (W - 80*k - 4*16*k)/5; x = 40*k
        for lab, val, col in stats:
            r = QRectF(x, 80*k, sw, 74*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#16243a')); p.drawRoundedRect(r, 12*k, 12*k)
            text(QRectF(x + 16*k, 86*k, sw, 24*k), lab, font(16), '#8fa6c4'); text(QRectF(x + 16*k, 110*k, sw, 38*k), val, font(28, True), col)
            if lab == 'Yoklama kapanışı' and yok_open: self.hb_items['yok'] = dict(rect=QRectF(r), m=0, kind='stat', label=lab, lfont=font(16), text=val, font=font(28, True), color=col, k=k, bg='#0d1726', per=.6 if b - t <= 300 else 1.0)
            x += sw + 16*k
        salons = sorted(pl['salonlar'], key=_salon_key); cols = 7; gap = 14*k
        rows = max(1, math.ceil(len(salons)/cols)); top = 172*k; bot = H - 90*k
        cw = (W - 80*k - (cols - 1)*gap)/cols; ch = min(190*k, (bot - top - (rows - 1)*gap)/rows); self.tiles = {}
        for i, s_ in enumerate(salons):
            r_, q_ = divmod(i, cols); r = QRectF(40*k + q_*(cw + gap), top + r_*(ch + gap), cw, ch); self.tiles[s_] = r
            v = ys.get(s_); ng = len((v or {}).get('gelmedi', []))
            if not started: st_, col, bg, bd = ('Yoklama %02d.%02d' % ((a + YOKLAMA_BASLA)//3600, (a + YOKLAMA_BASLA)%3600//60) if t >= a else 'Sınav başlamadı'), '#8fa6c4', '#16243a', '#24364f'
            elif not v: st_, col, bg, bd = ('Yoklama bekleniyor' if yok_open else 'Yoklama gelmedi'), '#ffb020', '#2e2410', '#ffb020'
            elif ng: st_, col, bg, bd = 'Gelmeyen: %d' % ng, '#ff5d6c', '#16243a', '#e5323f'
            elif v.get('onay'): st_, col, bg, bd = 'Tam', '#4fd18b', '#16243a', '#24364f'
            else: st_, col, bg, bd = ('İşaretleniyor' if yok_open else 'Gelmeyen yok · onaysız'), '#c9d6e8', '#16243a', '#24364f'
            if getattr(self, 'unread', {}).get(s_) and int(time.time()) % 2 == 0:   # okunmamış mesaj: kutu yanıp söner
                bg, bd = '#5a3a08', '#ffb020'; p.setPen(QPen(QColor(255, 176, 32, 90), 10*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 12*k, 12*k)
            p.setPen(QPen(QColor(bd), 3 if getattr(self, 'unread', {}).get(s_) else 2)); p.setBrush(QColor(bg)); p.drawRoundedRect(r, 12*k, 12*k)
            cmp_ = ch < 150*k   # kalabalık sınav (5 sıra kutu): satırlar sıkışır, üst üste binmez
            yN, hN, fN, yG, yK, hS, fS0 = (4, 36, 24, 38, 60, 32, 17) if cmp_ else (8, 40, 26, 50, 78, 36, 19)
            text(QRectF(r.x() + 16*k, r.y() + yN*k, r.width(), hN*k), s_, font(fN, True), '#ffffff')
            nm_ = getattr(self, 'unread', {}).get(s_, 0); nall = len((v or {}).get('mesajlar', []))
            if nm_ or nall:   # salondan mesaj: turuncu (okunmamış) ya da soluk rozet
                mb = QRectF(r.right() - 64*k, r.y() + (yN + 4)*k, 52*k, 28*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#ffb020' if nm_ else '#2a3a52')); p.drawRoundedRect(mb, 15*k, 15*k)
                text(mb, '✉ %d' % (nm_ or nall), font(16, True), '#1a1206' if nm_ else '#c9d6e8', Qt.AlignCenter)
            else: text(QRectF(r.x(), r.y() + yN*k, r.width() - 16*k, hN*k), '%d öğr.' % len(pl['salonlar'][s_]), font(16), '#8fa6c4', Qt.AlignRight | Qt.AlignVCenter)
            cell = lesson_cell(s_, day.weekday(), n) or {}; tch = pl.get('gozcu', {}).get(s_) or ', '.join(cell.get('ogretmen', [])) or '—'   # kelebekteki gözcü, yoksa ders programı
            text(QRectF(r.x() + 16*k, r.y() + yG*k, r.width() - 24*k, 22*k), QFontMetrics(font(15)).elidedText(tch, Qt.ElideRight, int(r.width() - 26*k)), font(15), '#c9d6e8')
            fs_ = fS0
            while fs_ > 12 and QFontMetrics(font(fs_, True)).horizontalAdvance(st_) > r.width() - 28*k: fs_ -= 1   # sığmazsa küçülür
            text(QRectF(r.x() + 14*k, r.bottom() - (hS + 6)*k, r.width() - 20*k, hS*k), st_, font(fs_, True), col)
            kg_ = {}; ms_all = (v or {}).get('mesajlar', []); gel_ = {m_.get('ref') for m_ in ms_all if m_.get('tur') == 'geldi'}; open_ = []
            for m_ in ms_all:
                if m_.get('id') in gel_ or m_.get('tur') == 'geldi': continue   # 'Kâğıt geldi' denmiş bildirim kapanır
                if any((m_.get('kagit') or {}).values()): open_.append(m_)
                for c_, n_ in (m_.get('kagit') or {}).items(): kg_[c_] = n_   # aynı dersin son bildirilen sayısı
            if any(kg_.values()):
                yolda_ = all(m_.get('id') in self.alarm.handled for m_ in open_)
                kt = ('Kâğıt yolda: ' if yolda_ else 'Kâğıt eksik: ') + ', '.join('%s %d' % (c_, n_) for c_, n_ in kg_.items() if n_)
                text(QRectF(r.x() + 16*k, r.y() + yK*k, r.width() - 24*k, 22*k), QFontMetrics(font(15, True)).elidedText(kt, Qt.ElideRight, int(r.width() - 26*k)), font(15, True), '#4fd18b' if yolda_ else '#ffb020')
        if self.note: text(QRectF(W*.45, H - 70, W*.55 - 160, 52), self.note, font(15), '#9fb3cc', Qt.AlignRight | Qt.AlignVCenter)
        p.end()

class HoldButton(QPushButton):
    """Yarım saniye basılı tutulunca çalışan düğme (yanlışlıkla gönderimi önler); doluluk soldan sağa ilerler."""
    def __init__(self, text, parent, on_done, ms=500, tap=False):
        super().__init__(text, parent); self.on_done = on_done; self.ms = ms; self.prog = 0.0; self.base = text
        self.setFocusPolicy(Qt.NoFocus); self.setMinimumHeight(62)
        self.anim = QVariantAnimation(self); self.anim.setStartValue(0.0); self.anim.setEndValue(1.0); self.anim.setDuration(ms)
        self.anim.valueChanged.connect(self._prog); self.anim.finished.connect(self._done)
        if tap: self.prog = 1.0; self.clicked.connect(self._tap)   # tek dokunuş
        else: self.pressed.connect(self._start); self.released.connect(self._stop)
        self._style()
    def _tap(self):
        if self.isEnabled(): self.setText('Gönderildi'); self.on_done()
    def _style(self):
        on = self.isEnabled(); p = max(0.0001, min(0.9999, self.prog))
        bg = ('qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #f06d0c,stop:%.4f #ff9a3a,stop:%.4f #3a1f12,stop:1 #3a1f12)' % (p, min(1, p + 0.0001))) if on else '#2a2030'
        self.setStyleSheet('QPushButton{background:%s;color:%s;border:1px solid #f06d0c;border-radius:12px;padding:14px 22px;font-size:21px;font-weight:700;}' % (bg, '#ffffff' if on else '#7a6a70'))
    def _prog(self, v): self.prog = float(v); self._style()
    def _start(self):
        if self.isEnabled(): self.setText('Bırakmayın…'); self.anim.stop(); self.anim.start()
    def _stop(self):
        if self.anim.state() == QVariantAnimation.Running: self.anim.stop(); self.prog = 0.0; self.setText(self.base); self._style()
    def _done(self):
        if self.prog >= 0.99: self.setText('Gönderildi'); self.on_done()
    def setEnabled(self, b): super().setEnabled(b); self._style()

class KagitDialog(QDialog):
    """Gözcü: salondaki her sınav için kaç kâğıt eksik (+1/+2/+5, − / +); Gönder basılı tutulur."""
    def __init__(self, main, st, plan):
        super().__init__(main); self.main = main; self.st = st; self.plan = plan
        self.setWindowTitle('Kâğıt eksik'); self.setMinimumWidth(fit_w(1000))
        self.setStyleSheet('QDialog{background:#111a3a;} QLabel{color:white;font-size:20px;background:transparent;}'
                           'QPushButton{background:#24305a;color:white;border:none;border-radius:10px;padding:10px 14px;font-size:19px;font-weight:600;}'
                           'QPushButton:pressed{background:#3a4a8a;}')
        v = QVBoxLayout(self); v.setSpacing(12); v.setContentsMargins(28, 24, 28, 24)
        day = st['date'].isoformat(); info = {}
        for r in plan['liste']:
            c = tr_title(r.get('ders')) or exam_course(day, st['lesson'], r.get('sinif'), '')
            if not c: continue
            e = info.setdefault(c, [0, []]); e[0] += 1
            if r.get('sinif') and r['sinif'] not in e[1]: e[1].append(r['sinif'])
        courses = sorted(info, key=lambda c: (c.startswith('S. '), c))
        h = QHBoxLayout(); t_ = QLabel('Hangi dersten kaç kâğıt eksik?'); t_.setStyleSheet('QLabel{font-size:27px;font-weight:700;}'); h.addWidget(t_, 1)
        s_ = QLabel('Salon %s  ·  %s' % (plan['sinif'], st['lesson'])); s_.setStyleSheet('QLabel{color:#93a0c8;font-size:19px;}'); h.addWidget(s_); v.addLayout(h)
        self.counts = {}
        for c in courses:
            row = QFrame(self); row.setStyleSheet('QFrame{background:rgba(255,255,255,0.03);border:1px solid #24305a;border-radius:12px;}')
            rl = QHBoxLayout(row); rl.setContentsMargins(16, 8, 12, 8); rl.setSpacing(10)
            cl = sorted(info[c][1], key=_salon_key) if info[c][1] else []
            lab = QLabel('%s\n<small>' % c); lab.setTextFormat(Qt.RichText)
            lab.setText('<span style="font-size:21px;font-weight:700">%s</span><br><span style="color:#93a0c8;font-size:16px">%s%d öğrenci</span>' % (c, (', '.join(cl[:5]) + (' …' if len(cl) > 5 else '') + '  ·  ') if cl else '', info[c][0]))
            rl.addWidget(lab, 1)
            for d_ in (1, 2, 5):
                b_ = QPushButton('+%d' % d_, row); b_.setFocusPolicy(Qt.NoFocus); b_.setFixedSize(64, 52); b_.clicked.connect(lambda _=False, x=c, d=d_: self.step(x, d)); rl.addWidget(b_)
            rl.addSpacing(10)
            mn = QPushButton('−', row); pl_ = QPushButton('+', row); n_ = QLabel('0')
            for b_ in (mn, pl_): b_.setFocusPolicy(Qt.NoFocus); b_.setFixedSize(64, 64); b_.setStyleSheet('QPushButton{background:#2a3870;border-radius:32px;font-size:28px;}')
            n_.setStyleSheet('QLabel{font-size:34px;font-weight:700;min-width:64px;qproperty-alignment:AlignCenter;}')
            mn.clicked.connect(lambda _=False, x=c: self.step(x, -1)); pl_.clicked.connect(lambda _=False, x=c: self.step(x, 1))
            rl.addWidget(mn); rl.addWidget(n_); rl.addWidget(pl_); v.addWidget(row); self.counts[c] = [0, n_, row]
        self.sum = QLabel('Sayı girin; Öğretmenler odasına ders ders gidecek.'); self.sum.setStyleSheet('QLabel{color:#93a0c8;font-size:19px;}'); v.addWidget(self.sum)
        b = QHBoxLayout(); c_ = QPushButton('Vazgeç'); c_.setFocusPolicy(Qt.NoFocus); c_.setMinimumHeight(62); c_.clicked.connect(self.reject); b.addWidget(c_)
        self.send_b = HoldButton('Gönder', self, self.send, tap=True); self.send_b.setEnabled(False); b.addWidget(self.send_b, 1); v.addLayout(b)
    def step(self, c, d):
        e = self.counts[c]; e[0] = max(0, min(60, e[0] + d)); e[1].setText(str(e[0]))
        e[2].setStyleSheet('QFrame{background:%s;border:1px solid %s;border-radius:12px;}' % (('rgba(255,138,31,0.10)', '#ff8a1f') if e[0] else ('rgba(255,255,255,0.03)', '#24305a')))
        parts = ['%s %d' % (c_, e_[0]) for c_, e_ in self.counts.items() if e_[0]]
        self.sum.setText(('Gidecek:  ' + '  ·  '.join(parts)) if parts else 'Sayı girin; Öğretmenler odasına ders ders gidecek.')
        self.send_b.setEnabled(bool(parts))
    def send(self):
        kag = {c: e[0] for c, e in self.counts.items() if e[0]}
        if not kag: return
        self.main.salon_message(self.st, self.plan, 'Kâğıt eksik: ' + ', '.join('%s %d' % (c, n) for c, n in kag.items()), kag)
        QTimer.singleShot(250, self.accept)

class KagitAlarm(QWidget):
    """Öğretmenler odası: salondan kâğıt eksik bildirimi gelince tam ekran, ışık dalgalı, nabız gibi atan kart; 5 sn'de bir zil.
    'Kâğıt yola çıktı' → kart kâğıt uçağına dönüşüp salonun kutusuna uçar, salona 'Kâğıdınız geliyor' gider. Birden çok bildirim sırayla."""
    @staticmethod
    def handled_ids(main):
        try:
            with open(os.path.join(main.yok_dir(), 'kagit-yolda.json'), encoding='utf-8') as f: return set(json.load(f))
        except (OSError, ValueError, TypeError): return set()
    def __init__(self, kg):
        super().__init__(kg); self.kg = kg; self.main = kg.main; self.pending = []; self.cur = None; self.fly = None; self.t0 = time.monotonic()
        self.handled = KagitAlarm.handled_ids(self.main); self.seen_sent = set(); self.hide()
        self.btn = QPushButton('Kâğıt yola çıktı', self); self.btn.setFocusPolicy(Qt.NoFocus)
        self.btn.setStyleSheet('QPushButton{background:#22c07a;color:#05230f;border:none;border-radius:16px;padding:0 40px;font-size:26px;font-weight:800;}QPushButton:pressed{background:#1a9a61;}')
        self.btn.clicked.connect(self.sent)
        self.anim = QTimer(self); self.anim.timeout.connect(self.update); self.ring = QTimer(self); self.ring.timeout.connect(self.chime)
    def chime(self):
        try: play_sound(os.path.join(_APP_DIR, 'sesler', 'bildirim.wav'), 1.0)
        except Exception: pass
    def sync(self, ys):
        pl = self.kg.ex[0] if self.kg.ex else {}; day = self.kg.ex[1] if self.kg.ex else None
        try: n = int(str(self.kg.ex[2]).split('.')[0])
        except (ValueError, TypeError, IndexError): n = 0
        lst = []
        for s_, v in ys.items():
            ms_ = (v or {}).get('mesajlar', []); gel = {m.get('ref') for m in ms_ if m.get('tur') == 'geldi'}
            for m in ms_:
                if any((m.get('kagit') or {}).values()) and m.get('id') not in self.handled and m.get('id') not in gel:
                    cell = lesson_cell(s_, day.weekday(), n) if day else None
                    lst.append(dict(m, salon=s_, gozcu=pl.get('gozcu', {}).get(s_) or ', '.join((cell or {}).get('ogretmen', [])) or ''))
        lst.sort(key=lambda m: m.get('zaman', 0)); self.pending = lst
        if self.fly is not None: return
        if not lst:
            if self.isVisible(): self.hide(); self.anim.stop(); self.ring.stop()
            self.cur = None; return
        if self.cur is None or self.cur['id'] not in {m['id'] for m in lst}: self.cur = lst[0]; self.t0 = time.monotonic(); self.chime()
        if self.cur['id'] not in self.seen_sent and self.kg.ex:   # salona 'Görüldü' bilgisi (sessiz)
            self.seen_sent.add(self.cur['id']); self.main.send_duyuru('', [self.cur['salon']], self.kg.ex, dict(tur='goruldu', ref=self.cur['id']))
        if not self.isVisible():
            self.setGeometry(self.kg.rect()); self.show(); self.raise_(); self.anim.start(33); self.ring.start(5000)
        self.raise_(); self.btn.show(); self.place_btn()
    def card_rect(self):
        W, H = self.width(), self.height(); w = min(W*.62, 1100); h = min(H*.56, 520)
        return QRectF((W - w)/2, (H - h)/2 - H*.03, w, h)
    def place_btn(self):
        r = self.card_rect(); k = min(self.width()/1600, self.height()/900); bw, bh = int(420*k), int(86*k)
        self.btn.setGeometry(int(r.center().x() - bw/2), int(r.bottom() - bh - 34*k), bw, bh)
    def resizeEvent(self, e): self.place_btn()
    def mousePressEvent(self, e): e.accept()
    def sent(self):
        m = self.cur
        if not m or self.fly is not None: return
        lst_ = ', '.join('%s %d' % (c, n) for c, n in (m.get('kagit') or {}).items() if n)
        if self.kg.ex: self.main.send_duyuru('Kâğıdınız geliyor: ' + lst_, [m['salon']], self.kg.ex, dict(tur='kagit_yolda', ref=m['id'], kagit=m.get('kagit') or {}))
        self.handled.add(m['id'])
        try:
            with open(os.path.join(self.main.yok_dir(), 'kagit-yolda.json'), 'w', encoding='utf-8') as f: json.dump(sorted(self.handled)[-500:], f)
        except OSError: pass
        self.ring.stop(); self.btn.hide(); self.fly = (time.monotonic(), m['salon'])
        try: play_sound(os.path.join(_APP_DIR, 'sesler', 'acilis.wav'), 0.5)
        except Exception: pass
    def fly_end(self):
        if self.fly is None: return
        self.fly = None; self.cur = None; self.kg.update()
        if not [x for x in self.pending if x['id'] not in self.handled]: self.hide(); self.anim.stop()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        W, H = self.width(), self.height(); k = min(W/1600, H/900); now = time.monotonic()
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); f.setWeight(QFont.Bold if b else QFont.Medium); return f
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        m = self.cur
        if self.fly is not None:
            ft = now - self.fly[0]; tile = self.kg.tiles.get(self.fly[1])
            p.fillRect(self.rect(), QColor(5, 8, 20, int(185*max(0, 1 - ft/0.5))))
            r0 = self.card_rect()
            if ft < 0.45:   # kart küçülür
                s_ = 1 - ft/0.45*0.88; p.save(); p.translate(r0.center()); p.rotate(-12*ft/0.45); p.scale(s_, s_); p.translate(-r0.center())
                p.setOpacity(1 - ft/0.45*0.6); p.setPen(QPen(QColor('#e3343c'), 3)); p.setBrush(QColor('#1a2550')); p.drawRoundedRect(r0, 22*k, 22*k); p.restore(); p.setOpacity(1)
            if 0.3 <= ft < 1.6:   # kâğıt uçağı salonun kutusuna uçar
                u = min(1, (ft - 0.3)/1.2); u = QEasingCurve(QEasingCurve.InOutCubic).valueForProgress(u)
                x1, y1 = r0.center().x(), r0.center().y(); x2, y2 = (tile.center().x(), tile.center().y()) if tile else (W*.9, H*.1)
                mx, my = (x1 + x2)/2, min(y1, y2) - H*.22
                x = (1-u)**2*x1 + 2*(1-u)*u*mx + u*u*x2; y = (1-u)**2*y1 + 2*(1-u)*u*my + u*u*y2
                dx = 2*(1-u)*(mx-x1) + 2*u*(x2-mx); dy = 2*(1-u)*(my-y1) + 2*u*(y2-my)
                sc = (1.3 - 0.7*u)*k; p.save(); p.translate(x, y); p.rotate(math.degrees(math.atan2(dy, dx))); p.scale(sc, sc)
                p.setPen(Qt.NoPen); p.setBrush(QColor('#eef2ff')); p.drawPolygon(QPolygonF([QPointF(40, 0), QPointF(-30, -26), QPointF(-14, 0), QPointF(-30, 26)]))
                p.setBrush(QColor('#9fb6ff')); p.drawPolygon(QPolygonF([QPointF(40, 0), QPointF(-14, 0), QPointF(-30, 26)])); p.restore()
            if ft >= 1.6:
                if tile:   # kutuda yeşil halka
                    a_ = max(0, 1 - (ft - 1.6)/0.6); p.setPen(QPen(QColor(34, 192, 122, int(255*a_)), 8*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(tile.adjusted(-6*k, -6*k, 6*k, 6*k), 14*k, 14*k)
                if ft >= 2.2:
                    p.end(); QTimer.singleShot(0, self.fly_end); return
            p.end(); return
        if not m: p.end(); return
        el = now - self.t0
        p.fillRect(self.rect(), QColor(5, 8, 20, 190))
        for i, col in enumerate(((227, 52, 60), (47, 107, 255))):   # kenarlardan içe ışık dalgası (okul renkleri)
            ph = ((el*0.625) + i*0.5) % 1.0; wd = (14 + 80*ph)*k
            p.setPen(QPen(QColor(col[0], col[1], col[2], int(230*(1 - ph))), wd)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(wd/2, wd/2, W - wd, H - wd))
        r = self.card_rect(); pu = 0.5 + 0.5*math.sin(el*2*math.pi/1.2)
        p.setPen(QPen(QColor(227, 52, 60, int(120*(1 - pu))), (6 + 26*pu)*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r.adjusted(-8*k, -8*k, 8*k, 8*k), 26*k, 26*k)
        p.save(); s_ = 1 + 0.025*pu; p.translate(r.center()); p.scale(s_, s_); p.translate(-r.center())
        g = QLinearGradient(r.topLeft(), r.bottomLeft()); g.setColorAt(0, QColor('#1a2550')); g.setColorAt(1, QColor('#121a38'))
        p.setPen(QPen(QColor('#e3343c'), 4*k)); p.setBrush(g); p.drawRoundedRect(r, 22*k, 22*k)
        def tx(rr, s__, f, c, al=Qt.AlignCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(rr, al, s__)
        tx(QRectF(r.x(), r.y() + 26*k, r.width(), 34*k), 'K Â Ğ I T   E K S İ K', font(20, True), '#ffb020')
        tx(QRectF(r.x(), r.y() + 62*k, r.width(), 130*k), m['salon'], font(110, True), '#ffffff')
        items = ['%s  ·  %d kâğıt' % (c, n) for c, n in (m.get('kagit') or {}).items() if n]
        f_ = font(26, True); fm = QFontMetrics(f_); ws = [fm.horizontalAdvance(t_) + 44*k for t_ in items]; gap = 14*k
        while ws and sum(ws) + gap*(len(ws) - 1) > r.width() - 60*k and f_.pixelSize() > 12:
            f_.setPixelSize(f_.pixelSize() - 1); fm = QFontMetrics(f_); ws = [fm.horizontalAdvance(t_) + 44*k for t_ in items]
        x = r.center().x() - (sum(ws) + gap*(len(ws) - 1))/2; cy = r.y() + 208*k
        for t_, w_ in zip(items, ws):
            cr = QRectF(x, cy, w_, 56*k); p.setPen(QPen(QColor(227, 52, 60, 170), 2)); p.setBrush(QColor(227, 52, 60, 46)); p.drawRoundedRect(cr, 28*k, 28*k)
            tx(cr, t_, f_, '#ffffff'); x += w_ + gap
        t_ = time.localtime(m.get('zaman', time.time())); ago = max(0, int(time.time() - m.get('zaman', time.time())))
        sub = ('Gözcü: %s  ·  ' % m['gozcu'] if m.get('gozcu') else '') + '%02d.%02d' % (t_.tm_hour, t_.tm_min) + ('  ·  %d dk önce' % (ago//60) if ago >= 60 else '  ·  az önce')
        tx(QRectF(r.x() + 20*k, r.y() + 282*k, r.width() - 40*k, 30*k), QFontMetrics(font(18)).elidedText(sub, Qt.ElideRight, int(r.width() - 40*k)), font(18), '#93a0c8')
        extra = (m.get('metin') or '').split('  ·  ', 1)
        if len(extra) > 1 and extra[1].strip():
            tx(QRectF(r.x() + 20*k, r.y() + 316*k, r.width() - 40*k, 30*k), QFontMetrics(font(18, True)).elidedText('✉  ' + extra[1].strip(), Qt.ElideRight, int(r.width() - 40*k)), font(18, True), '#ffd78a')
        p.restore()
        more = len([x for x in self.pending if x['id'] != m['id']])
        if more: tx(QRectF(0, r.bottom() + 30*k, W, 40*k), '+%d salon daha bekliyor  ·  %s' % (more, ', '.join(x['salon'] for x in self.pending if x['id'] != m['id'])[:80]), font(22, True), '#ffb020')
        p.end()

def ara_html(rs, photo=None):
    """Öğrenci araması sonuçları (zengin metin): ad · sınıf · no; her sınav için salon ve sıra, o anki sınav sarı.
    photo: tek öğrenci biletinde solda gösterilecek fotoğraf dosyası (yoksa yalnız yazı)."""
    esc = lambda x: str(x).replace('&', '&amp;').replace('<', '&lt;')
    if len(rs) == 1 and rs[0][1]:   # tek öğrenci: bilet gibi — büyük neon salon ve sıra, altında sonraki sınavlar
        r, ws = rs[0]; key, lab, now_, ders, s_, sira, crs = ws[0]
        nxt = ''.join('<div style="color:#c9d6ea;font-size:20px;margin-top:6px">Sonraki: <span style="color:#ffe14d;font-weight:700">%s · %s%s</span> → Salon %s · Sıra %s</div>'
                      % (esc(w[1]), esc(w[3]), (' ' + esc(w[6])) if w[6] else '', esc(w[4]), esc(w[5])) for w in ws[1:3])
        ph = ('<td valign="top" width="170"><img src="%s" width="150" height="194"></td>' % esc(photo)) if photo else ''
        return ('<table width="100%%" border="3" cellspacing="0" cellpadding="18" bgcolor="#13233a" style="border-color:#22e8ff;border-style:solid"><tr>' + ph.replace('%', '%%') + '<td valign="top">'
                '<div style="color:white;font-size:38px;font-weight:700">%s</div><div style="color:#9fb3cc;font-size:22px">%s · Okul no %s</div>'
                '<div style="margin-top:10px"><span style="background:#ffe14d;color:#1a1206;font-size:22px;font-weight:700">&nbsp;%s · %s%s&nbsp;</span></div>'
                '<table cellspacing="14" cellpadding="12" style="margin-top:10px"><tr>'
                '<td bgcolor="#0b1422" style="padding:12px 26px"><div style="color:#9fb3cc;font-size:18px;font-weight:600">SALON</div><div style="color:#7ff6ff;font-size:60px;font-weight:800">%s</div></td>'
                '<td bgcolor="#0b1422" style="padding:12px 26px"><div style="color:#9fb3cc;font-size:18px;font-weight:600">SIRA</div><div style="color:#ffe14d;font-size:60px;font-weight:800">%s</div></td>'
                '</tr></table>%s</td></tr></table>') % (esc(tr_name(r.get('ad', ''))), esc(r.get('sinif', '')), esc(r.get('no', '')), esc(lab), esc(ders), (' · ' + esc(crs)) if crs else '', esc(s_), esc(sira), nxt)
    rows = []
    for r, ws in rs:
        ch = []
        for key, lab, now_, ders, s_, sira, crs in ws[:3]:
            body = '%s · %s%s → <b>Salon %s · Sıra %s</b>' % (esc(lab), esc(ders), (' ' + esc(crs)) if crs else '', esc(s_), esc(sira))
            bg, fg = ('#ffb020', '#1a1206') if now_ else ('#1d3150', '#ffffff')
            ch.append('<span style="background:%s;color:%s;">&nbsp;%s&nbsp;</span>' % (bg, fg, body))
        rows.append('<div style="margin-bottom:12px"><span style="color:white;font-size:24px;font-weight:700">%s</span>'
                    '<span style="color:#9fb3cc;font-size:18px">&nbsp;&nbsp;%s · %s</span><br>%s</div>' % (esc(r.get('ad', '')), esc(r.get('sinif', '')), esc(r.get('no', '')), '&nbsp;&nbsp;'.join(ch)))
    return ''.join(rows)

class OgrenciAraDialog(QDialog):
    """Herhangi bir tahtada: öğrenci adını ya da numarasını yazar, bugünün ve sonraki sınavlarda salonunu ve sırasını görür.
    Klavye hemen açık; 1 dakika dokunulmazsa kendiliğinden kapanır."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle(NEON_ARA_TEXT); self.setMinimumWidth(fit_w(1100))
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:20px;background:transparent;} QLineEdit{font-size:30px;padding:12px 16px;border:2px solid #2f6fd6;border-radius:12px;}'
                           'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:10px;padding:10px 16px;font-size:19px;font-weight:600;}')
        v = QVBoxLayout(self); v.setSpacing(12); v.setContentsMargins(26, 20, 26, 20)
        h = QHBoxLayout(); t_ = QLabel(NEON_ARA_TEXT); t_.setStyleSheet('QLabel{font-size:28px;font-weight:800;color:#7ff6ff;}'); h.addWidget(t_, 1)
        c_ = QPushButton('Kapat'); c_.setFocusPolicy(Qt.NoFocus); c_.clicked.connect(self.reject); h.addWidget(c_); v.addLayout(h)
        self.edit = QLineEdit(); self.edit.setPlaceholderText('Okul numaranız ya da adınız'); v.addWidget(self.edit)
        self.res = QLabel('Okul numaranızı ya da adınızın bir kısmını yazın.'); self.res.setTextFormat(Qt.RichText); self.res.setWordWrap(True)
        self.res.setMinimumHeight(330); self.res.setAlignment(Qt.AlignTop | Qt.AlignLeft); self.res.setStyleSheet('QLabel{color:#9fb3cc;font-size:20px;}'); v.addWidget(self.res)
        kb = attach_touch_keyboard(self, self.edit, v); kb.attach(self.edit); kb.set_shift(False); kb.show()
        self.edit.textChanged.connect(self.search); self.edit.textChanged.connect(self.poke)
        self.idle = QTimer(self); self.idle.setSingleShot(True); self.idle.timeout.connect(self.reject); self.idle.start(60000)
        QTimer.singleShot(0, self.edit.setFocus)
    def poke(self, *a): self.idle.start(60000)
    def search(self, q):
        try: rs = self.main.ogrenci_ara(q)
        except Exception as e: rs = []; print('ara:', e)
        if not q.strip(): self.res.setText('Okul numaranızı ya da adınızın bir kısmını yazın.'); return
        if not rs: self.res.setText('<span style="color:#ffb020">Bulunamadı.</span> Adınızı ya da numaranızı kontrol edin.'); return
        photo = None
        if len(rs) == 1 and rs[0][1] and BOARD_PHOTOS:   # tek öğrenci: biletin solunda fotoğrafı (gizli listede olanlar hariç)
            try:
                pm = student_photo(str(rs[0][0].get('no', '')))
                if pm is not None and not pm.isNull():
                    import tempfile
                    photo = os.path.join(tempfile.gettempdir(), 'umal-ara-foto.jpg')
                    sc = pm.scaled(300, 388, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                    sc = sc.copy((sc.width() - 300)//2, (sc.height() - 388)//2, 300, 388)   # ortadan kırp: yüz bozulmasın
                    if not sc.save(photo, 'JPG', 90): photo = None
            except Exception as e: photo = None; print('ara foto:', e)
        self.res.setText(ara_html(rs, photo))

class DenemeDialog(QDialog):
    """Öğretmenler odası: seçilen salon tahtaları birkaç dakikalığına sınav anındaki gibi sınav moduna geçer (tanıtım/deneme).
    Öğrenci listeleri en son kelebek planından; yoklama ve mesajlar 'Deneme' adıyla gider, gelmeyenler raporuna/mazerete girmez."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Sınav anı (deneme)'); self.setMinimumWidth(fit_w(1000))
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:20px;background:transparent;}'
                           'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:10px;padding:10px 14px;font-size:19px;font-weight:600;}'
                           'QPushButton:checked{background:#f06d0c;border-color:#ff9a3a;}')
        v = QVBoxLayout(self); v.setSpacing(12); v.setContentsMargins(26, 22, 26, 22)
        main.take_kelebek(); salons = set()
        for pl in (main.kelebek or {}).get('planlar', []):
            if pl.get('ders') != DENEME_DERS: salons |= set(pl.get('salonlar', {}))
        salons = sorted(salons, key=_salon_key)
        if _DENEME:
            now = main.exam_clock(); t = now.hour*3600 + now.minute*60 + now.second; b_ = int(_DENEME.get('b', 0))
            h_ = QLabel('Deneme sınavı sürüyor  ·  %s  ·  %s' % (', '.join(_DENEME.get('hedef', [])), ('%d dk kaldı' % max(0, (b_ - t)//60 + 1)) if t < b_ else 'bitti'))
            h_.setStyleSheet('QLabel{font-size:24px;font-weight:700;color:#ffd9b8;}'); v.addWidget(h_)
            r = QHBoxLayout(); c_ = QPushButton('Kapat'); c_.clicked.connect(self.reject); r.addWidget(c_)
            s_ = QPushButton('Denemeyi bitir'); s_.setStyleSheet('QPushButton{background:#e3343c;color:white;border:none;}'); s_.clicked.connect(self.stop); r.addWidget(s_, 1); v.addLayout(r); return
        t_ = QLabel('Sınav anı (deneme)'); t_.setStyleSheet('QLabel{font-size:27px;font-weight:700;}'); v.addWidget(t_)
        i_ = QLabel('Seçtiğiniz salon tahtaları 1 dakika sonra sınav moduna geçer: oturma planı, yoklama, Kâğıt eksik ve Öğretmenler odası ekranı gerçek sınavdaki gibi çalışır. '
                    'Öğrenci listeleri son kelebek planından gelir. Deneme yoklamaları raporlara ve mazeret listesine girmez. Seçilmeyen sınıflar etkilenmez.')
        i_.setWordWrap(True); i_.setStyleSheet('QLabel{color:#9fb3cc;font-size:17px;}'); v.addWidget(i_)
        if not salons:
            v.addWidget(QLabel('Kelebek planı yok; deneme için en az bir sınav planı gerekir.')); c_ = QPushButton('Kapat'); c_.clicked.connect(self.reject); v.addWidget(c_); return
        g = QGridLayout(); g.setSpacing(8); self.sel = {}
        for i, s_ in enumerate(salons):
            b_ = QPushButton(s_); b_.setCheckable(True); b_.setFocusPolicy(Qt.NoFocus); b_.setMinimumHeight(52); b_.toggled.connect(self.upd); g.addWidget(b_, i // 8, i % 8); self.sel[s_] = b_
        v.addLayout(g)
        r = QHBoxLayout(); r.addWidget(QLabel('Süre')); self.dk = 15; self.dk_btns = {}
        for m in (10, 15, 20, 40):
            b_ = QPushButton('%d dk' % m); b_.setCheckable(True); b_.setFocusPolicy(Qt.NoFocus); b_.setChecked(m == 15); b_.clicked.connect(lambda _=False, x=m: self.pick(x)); r.addWidget(b_); self.dk_btns[m] = b_
        r.addStretch(1); v.addLayout(r)
        self.msg = QLabel(''); self.msg.setStyleSheet('QLabel{color:#ff8a8a;font-size:17px;}'); v.addWidget(self.msg)
        r = QHBoxLayout(); c_ = QPushButton('Vazgeç'); c_.setMinimumHeight(60); c_.clicked.connect(self.reject); r.addWidget(c_)
        self.go = QPushButton('Başlat'); self.go.setMinimumHeight(60); self.go.setEnabled(False); self.go.clicked.connect(self.start); r.addWidget(self.go, 1); v.addLayout(r); self.upd()
    def pick(self, m):
        self.dk = m
        for k_, b_ in self.dk_btns.items(): b_.setChecked(k_ == m)
    def upd(self, *a):
        n = [s_ for s_, b_ in self.sel.items() if b_.isChecked()]
        self.go.setEnabled(bool(n)); self.go.setText(('Başlat  ·  %d salon' % len(n)) if n else 'Salon seçin')
        self.go.setStyleSheet('QPushButton{background:%s;color:white;border:none;border-radius:12px;font-size:21px;font-weight:700;}' % ('#f06d0c' if n else '#2a3040'))
    def start(self):
        n = [s_ for s_, b_ in self.sel.items() if b_.isChecked()]
        if not n: return
        if self.main.deneme_start(n, self.dk): self.accept()
        else: self.msg.setText('Deneme kaydı yazılamadı.')
    def stop(self): self.main.deneme_stop(); self.accept()

class SalonMesajDialog(QDialog):
    """Salon tahtasından Öğretmenler odasına mesaj. Önce 'Kâğıt eksik': salondaki her ders için kaç kâğıt eksik (− / +);
    altta hazır mesajlar (soruda hata, zümre öğretmeni, öğrenci rahatsızlandı) ve serbest yazı."""
    def __init__(self, main, st, plan):
        super().__init__(main); self.main = main; self.st = st; self.plan = plan
        self.setWindowTitle('Öğretmenler odasına mesaj'); self.setMinimumWidth(fit_w(900))
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:20px;} QLineEdit{font-size:22px;padding:10px;border-radius:10px;}'
                           'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:10px;padding:12px 16px;font-size:19px;}'
                           'QPushButton:checked{background:#2f6fd6;border-color:#2f6fd6;}')
        v = QVBoxLayout(self); v.setSpacing(10)
        t_ = QLabel('Salon %s  ·  %s' % (plan['sinif'], st['lesson'])); t_.setStyleSheet('QLabel{font-size:24px;font-weight:700;}'); v.addWidget(t_)
        day = st['date'].isoformat(); courses = []
        for r in plan['liste']:
            c = tr_title(r.get('ders')) or exam_course(day, st['lesson'], r.get('sinif'), '')
            if c and c not in courses: courses.append(c)
        courses.sort(key=lambda c: (c.startswith('S. '), c))
        h_ = QLabel('Kâğıt eksik  (hangi dersten kaç tane)'); h_.setStyleSheet('QLabel{color:#ffd78a;font-size:21px;font-weight:700;}'); v.addWidget(h_)
        self.counts = {}; grid = QGridLayout(); grid.setHorizontalSpacing(12); grid.setVerticalSpacing(8)
        for i, c in enumerate(courses):
            lab = QLabel(c); mn = QPushButton('−'); pl_ = QPushButton('+'); n_ = QLabel('0')
            n_.setStyleSheet('QLabel{font-size:28px;font-weight:700;min-width:56px;qproperty-alignment:AlignCenter;}')
            for b_ in (mn, pl_): b_.setFocusPolicy(Qt.NoFocus); b_.setFixedWidth(70)
            mn.clicked.connect(lambda c_=False, x=c: self.step(x, -1)); pl_.clicked.connect(lambda c_=False, x=c: self.step(x, 1))
            grid.addWidget(lab, i, 0); grid.addWidget(mn, i, 1); grid.addWidget(n_, i, 2); grid.addWidget(pl_, i, 3); self.counts[c] = [0, n_]
        grid.setColumnStretch(0, 1); v.addLayout(grid)
        h2 = QLabel('Başka bir durum'); h2.setStyleSheet('QLabel{color:#9fb3cc;font-size:19px;font-weight:700;}'); v.addWidget(h2)
        self.q = 1; row = QHBoxLayout()
        self.qb = QPushButton('Soruda hata var:  1. soru'); self.qb.setFocusPolicy(Qt.NoFocus); self.qb.clicked.connect(lambda: self.edit.setText('%d. soruda hata olabilir, zümre öğretmeni gelsin.' % self.q))
        qm = QPushButton('−'); qp = QPushButton('+')
        for b_ in (qm, qp): b_.setFocusPolicy(Qt.NoFocus); b_.setFixedWidth(70)
        qm.clicked.connect(lambda: self.qstep(-1)); qp.clicked.connect(lambda: self.qstep(1))
        row.addWidget(self.qb, 1); row.addWidget(qm); row.addWidget(qp); v.addLayout(row)
        g2 = QGridLayout(); g2.setSpacing(8)
        for i, tx in enumerate(['Zümre öğretmeni salona gelsin.', 'Bir öğrenci rahatsızlandı, idareden biri gelsin.']):
            b_ = QPushButton(tx); b_.setFocusPolicy(Qt.NoFocus); b_.clicked.connect(lambda c_=False, x=tx: self.edit.setText(x)); g2.addWidget(b_, 0, i)
        v.addLayout(g2)
        self.edit = QLineEdit(); self.edit.setPlaceholderText('Mesaj (isteğe bağlı)'); v.addWidget(self.edit)
        attach_touch_keyboard(self, self.edit, v)
        h = QHBoxLayout(); self.msg = QLabel(''); self.msg.setStyleSheet('QLabel{color:#ff8a8a;}'); h.addWidget(self.msg, 1)
        c_ = QPushButton('Vazgeç'); c_.clicked.connect(self.reject); h.addWidget(c_)
        s_ = QPushButton('Gönder'); s_.setStyleSheet('QPushButton{background:#2fbf71;color:#06240f;font-weight:700;}'); s_.clicked.connect(self.send); h.addWidget(s_)
        v.addLayout(h)
    def step(self, c, d):
        e = self.counts[c]; e[0] = max(0, min(60, e[0] + d)); e[1].setText(str(e[0]))
    def qstep(self, d):
        self.q = max(1, min(60, self.q + d)); self.qb.setText('Soruda hata var:  %d. soru' % self.q)
    def send(self):
        kag = {c: e[0] for c, e in self.counts.items() if e[0]}
        parts = []
        if kag: parts.append('Kâğıt eksik: ' + ', '.join('%s %d' % (c, n) for c, n in kag.items()))
        if self.edit.text().strip(): parts.append(self.edit.text().strip())
        if not parts: self.msg.setText('Eksik kâğıt sayısı ya da mesaj girin.'); return
        self.main.salon_message(self.st, self.plan, '  ·  '.join(parts), kag); self.accept()

class DuyuruDialog(QDialog):
    """Karargah: seçilen salonların tahtalarına sınav sırasında duyuru."""
    def __init__(self, main, ex):
        super().__init__(main); self.main = main; self.ex = ex
        self.setWindowTitle('Salonlara duyuru'); self.setMinimumWidth(fit_w(900))
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:20px;} QLineEdit{font-size:22px;padding:10px;border-radius:10px;}'
                           'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:10px;padding:10px 16px;font-size:18px;}'
                           'QPushButton:checked{background:#2f6fd6;border-color:#2f6fd6;}')
        v = QVBoxLayout(self); v.setSpacing(12)
        v.addWidget(QLabel('Hazır duyurular'))
        for t_ in DUYURU_HAZIR:
            b = QPushButton(t_); b.setFocusPolicy(Qt.NoFocus); b.clicked.connect(lambda c=False, x=t_: self.edit.setText(x)); v.addWidget(b)
        v.addWidget(QLabel('Duyuru metni'))
        self.edit = QLineEdit(); v.addWidget(self.edit)
        attach_touch_keyboard(self, self.edit, v)
        v.addWidget(QLabel('Hangi salonlar'))
        grid = QGridLayout(); grid.setSpacing(8); self.all = QPushButton('Bütün salonlar'); self.all.setCheckable(True); self.all.setChecked(True)
        grid.addWidget(self.all, 0, 0, 1, 2); self.chips = {}
        for i, s_ in enumerate(sorted(ex[0].get('salonlar', {}), key=_salon_key)):
            b = QPushButton(s_); b.setCheckable(True); b.setFocusPolicy(Qt.NoFocus); b.clicked.connect(lambda c=False: self.all.setChecked(False))
            grid.addWidget(b, 1 + i//7, i % 7); self.chips[s_] = b
        self.all.clicked.connect(lambda c: [b.setChecked(False) for b in self.chips.values()] if c else None)
        v.addLayout(grid)
        h = QHBoxLayout(); self.msg = QLabel(''); h.addWidget(self.msg, 1)
        c_ = QPushButton('Vazgeç'); c_.clicked.connect(self.reject); h.addWidget(c_)
        s_ = QPushButton('Gönder'); s_.setStyleSheet('QPushButton{background:#2fbf71;color:#06240f;font-weight:700;}'); s_.clicked.connect(self.send); h.addWidget(s_)
        v.addLayout(h)
    def send(self):
        t_ = self.edit.text().strip()
        if not t_: self.msg.setText('Duyuru metni boş.'); return
        hedef = ['*'] if self.all.isChecked() else [s_ for s_, b in self.chips.items() if b.isChecked()]
        if not hedef: self.msg.setText('Salon seçilmedi.'); return
        if self.main.send_duyuru(t_, hedef, self.ex): self.accept()
        else: self.msg.setText('Gönderilemedi.')

def yoklama_reports(main, ex, data, folder):
    """Sınav sonu: gelmeyenler PDF'i + bütün sınavların mazeret listesi (PDF ve CSV). [(yerel yol, Drive'daki ad)]"""
    from PyQt5.QtGui import QPdfWriter, QPageSize, QFont
    import datetime, csv
    pl, day, lesson, a, b = ex[:5]; key = Window.yok_key(day, lesson)
    fams = ui_fonts(); fam = fams.get('Poppins-Regular') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
    def F(px, bold=False): f = QFont(famb if bold else fam); f.setPixelSize(px); f.setWeight(QFont.Bold if bold else QFont.Normal); return f
    def esc(s_): return ''.join(c for c in s_ if c not in '/\\:*?"<>|').strip()
    courses = []
    for s_, lst in pl.get('salonlar', {}).items():
        for r in lst:
            c = tr_title(r.get('ders')) or exam_course(day.isoformat(), lesson, r.get('sinif'), '')
            if c and c not in courses: courses.append(c)
    order = ['Kimya', 'Matematik', 'Fizik', 'Biyoloji', 'Tarih']
    courses.sort(key=lambda c: (c.startswith('S. '), c))
    ys = {s_: data.get('%s_%s.json' % (key, s_)) for s_ in pl.get('salonlar', {})}
    absent = []
    for s_, v in ys.items():
        for r in (v or {}).get('gelmedi', []): absent.append(dict(r, salon=s_))
    total = sum(len(v) for v in pl.get('salonlar', {}).values())
    missing = sorted([s_ for s_, v in ys.items() if not v], key=_salon_key)
    unconf = sorted([s_ for s_, v in ys.items() if v and not v.get('onay') and not v.get('gelmedi')], key=_salon_key)
    try: n = int(lesson.split('.')[0])
    except ValueError: n = 0
    def teacher(s_): return pl.get('gozcu', {}).get(s_) or ', '.join((lesson_cell(s_, day.weekday(), n) or {}).get('ogretmen', [])) or '—'
    W, H, M = 1240, 1754, 70
    def new_writer(path):
        w = QPdfWriter(path); w.setPageSize(QPageSize(QPageSize.A4)); w.setResolution(150); w.setTitle(os.path.basename(path))
        from PyQt5.QtCore import QMarginsF
        try: w.setPageMargins(QMarginsF(0, 0, 0, 0))
        except Exception: pass
        return w
    def header(p, sub, right1, right2):
        lg = QPixmap(LOGO_RESMI if os.path.isfile(LOGO_RESMI) else LOGO)
        if not lg.isNull(): p.drawPixmap(QRectF(M, 56, 112, 112), lg, QRectF(lg.rect()))
        p.setPen(QColor('#14223a')); p.setFont(F(34, True)); p.drawText(QRectF(200, 60, 700, 50), Qt.AlignLeft | Qt.AlignVCenter, 'Ümraniye Merkez Anadolu Lisesi')
        p.setFont(F(28)); p.drawText(QRectF(200, 108, 700, 44), Qt.AlignLeft | Qt.AlignVCenter, sub)
        p.setPen(QColor('#444')); p.setFont(F(21)); p.drawText(QRectF(W - M - 500, 64, 500, 34), Qt.AlignRight | Qt.AlignVCenter, right1)
        p.setFont(F(21, True)); p.drawText(QRectF(W - M - 500, 98, 500, 34), Qt.AlignRight | Qt.AlignVCenter, right2)
        p.setPen(QPen(QColor('#14223a'), 3)); p.drawLine(QPointF(M, 192), QPointF(W - M, 192))
    def footer(p, page, txt):
        p.setPen(QColor('#888')); p.setFont(F(16)); p.drawText(QRectF(0, H - 70, W, 30), Qt.AlignCenter, '%s  ·  Sayfa %d' % (txt, page))
    # --- 1) Gelmeyenler ---
    title = '%s - %s' % (tr_date(day), ', '.join(courses) or (pl.get('sinav') or lesson))
    path1 = os.path.join(folder, 'rapor-%s.pdf' % key); name1 = esc(title) + '.pdf'
    w = new_writer(path1); p = QPainter(w); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
    sc = w.width()/W; p.scale(sc, sc); page = 1
    header(p, 'Sınava Gelmeyen Öğrenciler', '%s %s' % (tr_date(day), TR_DAYS[day.weekday()]), '%s · %s–%s' % (lesson, '%02d.%02d' % (a//3600, a%3600//60), '%02d.%02d' % (b//3600, b%3600//60)))
    y = 214
    p.setPen(QColor('#14223a')); p.setFont(F(19)); r_ = QRectF(M, y, W - 2*M, 60)
    p.drawText(r_, Qt.AlignLeft | Qt.TextWordWrap, 'Sınav: ' + ', '.join(courses)); y += 64
    boxes = [('Sınava girecek', str(total), '#14223a'), ('Gelen', str(total - len(absent)), '#14223a'), ('Gelmeyen', str(len(absent)), '#c0202e'), ('Yoklama gelmeyen salon', str(len(missing)), '#14223a')]
    bw = (W - 2*M - 3*16)/4; x = M
    for lab, val, col in boxes:
        p.setPen(QPen(QColor('#c9d2de'), 2)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(QRectF(x, y, bw, 80), 10, 10)
        p.setPen(QColor('#666')); p.setFont(F(18)); p.drawText(QRectF(x + 16, y + 8, bw, 26), Qt.AlignLeft | Qt.AlignVCenter, lab)
        p.setPen(QColor(col)); p.setFont(F(30, True)); p.drawText(QRectF(x + 16, y + 34, bw, 40), Qt.AlignLeft | Qt.AlignVCenter, val); x += bw + 16
    y += 112
    by = {}
    for r in absent: by.setdefault(r.get('sinif', ''), []).append(r)
    def need(h):
        nonlocal y, page
        if y + h > H - 100:
            footer(p, page, 'UMAL Atlas · sınav bitiminde hazırlandı'); w.newPage(); page += 1; y = 70
    if not absent:
        p.setPen(QColor('#1f7a46')); p.setFont(F(24, True)); p.drawText(QRectF(M, y, W - 2*M, 50), Qt.AlignLeft | Qt.AlignVCenter, 'Yoklama gönderen salonlarda gelmeyen öğrenci yok.'); y += 70
    for c in sorted(by, key=_salon_key):
        need(56 + 88)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#eef2f7')); p.drawRoundedRect(QRectF(M, y, W - 2*M, 44), 8, 8)
        p.setPen(QColor('#14223a')); p.setFont(F(22, True)); p.drawText(QRectF(M + 16, y, 600, 44), Qt.AlignLeft | Qt.AlignVCenter, '%s sınıfı' % c)
        p.setPen(QColor('#555')); p.setFont(F(20)); p.drawText(QRectF(W - M - 400, y, 384, 44), Qt.AlignRight | Qt.AlignVCenter, '%d öğrenci' % len(by[c])); y += 56
        for r in sorted(by[c], key=lambda r: r.get('ad', '')):
            need(88)
            pm = student_photo(r.get('no'))
            if pm is not None and not pm.isNull(): p.drawPixmap(QRectF(M + 16, y, 58, 75), pm, QRectF(pm.rect()))
            p.setPen(QColor('#111')); p.setFont(F(24, True)); p.drawText(QRectF(M + 90, y + 2, 640, 34), Qt.AlignLeft | Qt.AlignVCenter, r.get('ad', ''))
            p.setPen(QColor('#555')); p.setFont(F(19)); p.drawText(QRectF(M + 90, y + 38, 640, 30), Qt.AlignLeft | Qt.AlignVCenter, 'No: %s  ·  %s' % (r.get('no', ''), r.get('ders_adi') or exam_course(day.isoformat(), lesson, c, '')))
            p.setPen(QColor('#222')); p.setFont(F(21)); p.drawText(QRectF(W - M - 420, y + 2, 404, 34), Qt.AlignRight | Qt.AlignVCenter, 'Salon %s · Sıra %s' % (r['salon'], r.get('sira')))
            y += 88; p.setPen(QPen(QColor('#e3e7ed'), 1)); p.drawLine(QPointF(M + 16, y - 7), QPointF(W - M - 16, y - 7))
        y += 8
    for lab, lst in (('Yoklama göndermeyen salonlar', missing), ('Yoklamayı onaylamayan salonlar (gelmeyen işaretlenmedi)', unconf)):
        if not lst: continue
        txt = ' · '.join('%s (%s)' % (s_, teacher(s_)) for s_ in lst)
        hh = 60 + 28*math.ceil(len(txt)/90); need(hh + 20)
        p.setPen(QPen(QColor('#e0a100'), 2)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(QRectF(M, y + 6, W - 2*M, hh), 8, 8)
        p.setPen(QColor('#8a5a00')); p.setFont(F(20, True)); p.drawText(QRectF(M + 16, y + 14, W - 2*M - 32, 30), Qt.AlignLeft | Qt.AlignVCenter, lab)
        p.setPen(QColor('#333')); p.setFont(F(19)); p.drawText(QRectF(M + 16, y + 46, W - 2*M - 32, hh - 44), Qt.AlignLeft | Qt.TextWordWrap, txt); y += hh + 20
    footer(p, page, 'UMAL Atlas · sınav bitiminde hazırlandı'); p.end()
    # --- 2) Mazeret listesi: Drive'daki bütün sınavların yoklamalarından ---
    rows = []
    for nm, v in data.items():
        if not isinstance(v, dict) or v.get('ders') == DENEME_DERS: continue   # deneme sınavı mazerete girmez
        for r in v.get('gelmedi', []):
            rows.append(dict(r, tarih=v.get('tarih', ''), ders=v.get('ders', ''), salon=v.get('salon', ''), ders_adi=r.get('ders_adi') or exam_course(v.get('tarih', ''), v.get('ders', ''), r.get('sinif'), v.get('sinav', ''))))
    # bu sınavın henüz Drive'a ulaşmamış yerel kopyası yok; Karargah yalnız Drive'dakini bilir
    rows.sort(key=lambda r: (r['tarih'], r['ders'], r['ders_adi'], _salon_key(r.get('sinif', '')), r.get('ad', '')))
    path2 = os.path.join(folder, 'mazeret.pdf'); name2 = 'Mazeret Sınavı Listesi.pdf'
    w = new_writer(path2); p = QPainter(w); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing); p.scale(w.width()/W, w.width()/W); page = 1
    now_ = main.exam_clock()
    header(p, 'Mazeret Sınavı Listesi', '1. Dönem 1. Ortak Yazılılar', 'Güncelleme: %s, %02d.%02d' % (tr_date(now_.date()), now_.hour, now_.minute))
    y = 222
    def need2(h):
        nonlocal y, page
        if y + h > H - 100:
            footer(p, page, 'UMAL Atlas · her sınavdan sonra güncellenir'); w.newPage(); page += 1; y = 70
    p.setPen(QColor('#14223a')); p.setFont(F(26, True)); p.drawText(QRectF(M, y, 600, 40), Qt.AlignLeft | Qt.AlignVCenter, 'Derse göre'); y += 50
    grp = {}
    for r in rows: grp.setdefault((r['ders_adi'], r['tarih'], r['ders']), []).append(r)
    if not rows:
        p.setFont(F(20)); p.setPen(QColor('#555')); p.drawText(QRectF(M, y, W - 2*M, 40), Qt.AlignLeft | Qt.AlignVCenter, 'Henüz gelmeyen öğrenci kaydı yok.'); y += 50
    for (ca, tarih, ders), lst in sorted(grp.items(), key=lambda kv: (kv[0][1], kv[0][2], kv[0][0])):
        need2(52 + 34)
        try: d_ = datetime.date.fromisoformat(tarih); dt = '%d %s' % (d_.day, TR_MONTHS[d_.month-1][:3])
        except ValueError: dt = tarih
        p.setPen(Qt.NoPen); p.setBrush(QColor('#eef2f7')); p.drawRoundedRect(QRectF(M, y, W - 2*M, 44), 8, 8)
        p.setPen(QColor('#14223a')); p.setFont(F(21, True)); p.drawText(QRectF(M + 16, y, W - 2*M - 220, 44), Qt.AlignLeft | Qt.AlignVCenter, '%s  ·  %s · %s' % (ca, dt, ders))
        p.setPen(QColor('#555')); p.setFont(F(19)); p.drawText(QRectF(W - M - 220, y, 204, 44), Qt.AlignRight | Qt.AlignVCenter, '%d öğrenci' % len(lst)); y += 52
        for r in lst:
            need2(34)
            p.setPen(QColor('#333')); p.setFont(F(19, True)); p.drawText(QRectF(M + 20, y, 80, 30), Qt.AlignLeft | Qt.AlignVCenter, r.get('sinif', ''))
            p.setPen(QColor('#111')); p.setFont(F(19)); p.drawText(QRectF(M + 100, y, 700, 30), Qt.AlignLeft | Qt.AlignVCenter, r.get('ad', ''))
            p.setPen(QColor('#555')); p.drawText(QRectF(W - M - 300, y, 280, 30), Qt.AlignRight | Qt.AlignVCenter, 'No: %s' % r.get('no', '')); y += 34
        y += 12
    need2(140); y += 10
    p.setPen(QColor('#14223a')); p.setFont(F(26, True)); p.drawText(QRectF(M, y, 600, 40), Qt.AlignLeft | Qt.AlignVCenter, 'Öğrenciye göre'); y += 50
    per = {}
    for r in rows:
        k_ = (r.get('sinif', ''), r.get('ad', ''), str(r.get('no', '')))
        if r['ders_adi'] not in per.setdefault(k_, []): per[k_].append(r['ders_adi'])
    def thead():
        nonlocal y
        p.setPen(Qt.NoPen); p.setBrush(QColor('#14223a')); p.drawRoundedRect(QRectF(M, y, W - 2*M, 40), 8, 8); p.setPen(QColor('#ffffff')); p.setFont(F(18, True))
        for x_, t_ in ((M + 16, 'Sınıf'), (M + 100, 'Ad Soyad'), (M + 490, 'No'), (M + 610, 'Mazerete gireceği dersler')): p.drawText(QRectF(x_, y, 400, 40), Qt.AlignLeft | Qt.AlignVCenter, t_)
        y += 48
    thead()
    for (c, ad, no), lst in sorted(per.items(), key=lambda kv: (_salon_key(kv[0][0]), kv[0][1])):
        txt = ', '.join(lst); hh = 34*max(1, math.ceil(len(txt)/38))
        if y + hh > H - 100: need2(hh); thead()
        p.setPen(QColor('#333')); p.setFont(F(19, True)); p.drawText(QRectF(M + 16, y, 80, 30), Qt.AlignLeft | Qt.AlignVCenter, c)
        p.setPen(QColor('#111')); p.setFont(F(19)); p.drawText(QRectF(M + 100, y, 380, 30), Qt.AlignLeft | Qt.AlignVCenter, ad)
        p.setPen(QColor('#555')); p.drawText(QRectF(M + 490, y, 110, 30), Qt.AlignLeft | Qt.AlignVCenter, no)
        p.setPen(QColor('#c0202e')); p.setFont(F(19, True)); p.drawText(QRectF(M + 610, y, W - 2*M - 626, hh), Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, txt)
        y += hh; p.setPen(QPen(QColor('#e3e7ed'), 1)); p.drawLine(QPointF(M + 16, y - 3), QPointF(W - M - 16, y - 3))
    footer(p, page, 'UMAL Atlas · her sınavdan sonra güncellenir'); p.end()
    path3 = os.path.join(folder, 'mazeret.csv'); name3 = 'Mazeret Sınavı Listesi.csv'
    with open(path3, 'w', encoding='utf-8-sig', newline='') as f:
        cw = csv.writer(f, delimiter=';'); cw.writerow(['Tarih', 'Ders saati', 'Ders', 'Sınıf', 'Ad Soyad', 'Okul No', 'Salon', 'Sıra'])
        for r in rows: cw.writerow([r['tarih'], r['ders'], r['ders_adi'], r.get('sinif', ''), r.get('ad', ''), r.get('no', ''), r.get('salon', ''), r.get('sira', '')])
    return [(path1, name1), (path2, name2), (path3, name3)]

def _draw_plan_photos(self, p, R, plan, k, font, theme, pad, title_h):
    """Fotoğraflı liste. Salonda: sıra numarasına göre kart ızgarası (fotoğraf, ad, sınıf).
    Sınıfta (sınavdan önce): her satırda fotoğraf, ad, salon, sıra."""
    from PyQt5.QtGui import QFontMetrics, QFont
    lst = plan['liste']; gy = R.y() + title_h + 14*k; gx = R.x() + pad; GW = R.width() - 2*pad; GH = R.bottom() - pad - gy
    def fit(text, f, w):
        f = QFont(f); px = f.pixelSize()
        while px > 9 and QFontMetrics(f).horizontalAdvance(text) > w: px -= 1; f.setPixelSize(px)
        return f
    if plan['tur'] == 'salon':
        seats = {r['sira']: r for r in lst}; n = max(max(seats) if seats else 1, 1)
        cols = 8 if n > 30 else 6 if n > 18 else 5; rows = math.ceil(n/cols); gap = 8*k
        cw = (GW - gap*(cols - 1))/cols; ch = (GH - gap*(rows - 1))/rows
        for i in range(n):
            no = i + 1; st_ = seats.get(no); c, r_ = i % cols, i // cols
            cell = QRectF(gx + c*(cw + gap), gy + r_*(ch + gap), cw, ch)
            p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 16 if st_ else 6)); p.drawRoundedRect(cell, 10*k, 10*k)
            ph = cell.height()*.64; pw = min(cell.width() - 12*k, ph*.77); pr = QRectF(cell.center().x() - pw/2, cell.y() + 6*k, pw, ph - 6*k)
            if st_: draw_photo(p, pr, st_.get('no'), st_['ad'], k)
            p.setPen(Qt.NoPen); p.setBrush(QColor(theme)); b = QRectF(cell.x() + 4*k, cell.y() + 4*k, 34*k, 26*k); p.drawRoundedRect(b, 8*k, 8*k)
            p.setFont(font(17, True)); p.setPen(QColor('#0b1422')); p.drawText(b, Qt.AlignCenter, str(no))
            if not st_:
                p.setFont(font(15)); p.setPen(QColor('#5d6f88')); p.drawText(pr, Qt.AlignCenter, 'boş'); continue
            nr = QRectF(cell.x() + 4*k, cell.y() + ph + 2*k, cell.width() - 8*k, (cell.height() - ph)*.55)
            f_ = fit(st_['ad'], font(17, True), nr.width()); p.setPen(QColor('#ffffff'))
            if f_.pixelSize() < 13*k: f_ = font(13, True); p.setFont(f_); p.drawText(nr.adjusted(0, -6*k, 0, 6*k), Qt.AlignCenter | Qt.TextWordWrap, st_['ad'])   # uzun ad: iki satır
            else: p.setFont(f_); p.drawText(nr, Qt.AlignCenter, st_['ad'])
            p.setFont(font(15)); p.setPen(QColor('#9fb3cc')); p.drawText(QRectF(nr.x(), nr.bottom(), nr.width(), cell.bottom() - nr.bottom()), Qt.AlignHCenter | Qt.AlignTop, st_['sinif'])
        return
    n = max(1, len(lst)); cols = 1 if n <= 20 else 2; per = math.ceil(n/cols); gap = 24*k
    gw = (GW - gap*(cols - 1))/cols; head_h = 30*k; rh = (GH - head_h)/per
    for c in range(cols):
        x = gx + c*(gw + gap); sal_w = 84*k; sira_w = 56*k; ph_w = (rh - 4*k)*.77
        p.setFont(font(16, True)); p.setPen(QColor('#8ea3c0'))
        p.drawText(QRectF(x + ph_w + 12*k, gy, gw, head_h), Qt.AlignVCenter | Qt.AlignLeft, 'Ad Soyad')
        p.drawText(QRectF(x + gw - sal_w - sira_w, gy, sal_w, head_h), Qt.AlignVCenter | Qt.AlignHCenter, 'Salon')
        p.drawText(QRectF(x + gw - sira_w, gy, sira_w - 6*k, head_h), Qt.AlignVCenter | Qt.AlignRight, 'Sıra')
        for r_ in range(per):
            idx = c*per + r_
            if idx >= len(lst): continue
            y = gy + head_h + r_*rh; st_ = lst[idx]
            if r_ % 2 == 0: p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 12)); p.drawRect(QRectF(x, y, gw, rh))
            draw_photo(p, QRectF(x + 4*k, y + 2*k, ph_w, rh - 4*k), st_.get('no'), st_['ad'], k)
            nr = QRectF(x + ph_w + 12*k, y, gw - ph_w - sal_w - sira_w - 16*k, rh)
            p.setFont(fit(st_['ad'], font(min(24, rh/k*.42)), nr.width())); p.setPen(QColor('#ffffff')); p.drawText(nr, Qt.AlignVCenter | Qt.AlignLeft, st_['ad'])
            p.setFont(font(min(26, rh/k*.46), True)); p.setPen(QColor(theme)); p.drawText(QRectF(x + gw - sal_w - sira_w, y, sal_w, rh), Qt.AlignVCenter | Qt.AlignHCenter, str(st_['salon']))
            p.setPen(QColor('#ffffff')); p.drawText(QRectF(x + gw - sira_w, y, sira_w - 6*k, rh), Qt.AlignVCenter | Qt.AlignRight, str(st_['sira']))
ExamScreen.draw_plan_photos = _draw_plan_photos
SALON_LAYOUT = {'11-H': '11h', '12-I': 'ozel'}   # masa sütunu sayısı (her masada 2 kişi, 5 sıra) ya da özel düzen
def _snake(cols, rows):
    """Genel salon: sütunlar soldan sağa; yılan düzeni (1. sütun önden arkaya, 2. arkadan öne…)."""
    desks = []
    for c in range(cols):
        for r in range(rows):
            rr = r if c % 2 == 0 else rows - 1 - r
            n0 = c*rows*2 + rr*2 + 1
            desks.append((c*2.4, r, 2, [n0, n0 + 1]))
    return desks
def _layout_12i():
    """12-I (tahtadan bakınca aynalı; aşağıdaki sol/sağ planın çizimine göre): sol duvar sütununda 7 sıra, orta ve kapı sütununda 5 sıra, arkada iki tekli sıra.
    Öğretmen masasından başlar: sol sütun önden arkaya 1–10, orta arkadan öne 11–20, kapı sütunu önden arkaya 21–30,
    tekli sıralar 31–32; sol sütunun en arkadaki iki sırası (görünmesi zor köşe) en son, 33–36."""
    d = [(0, r, 2, [r*2 + 1, r*2 + 2]) for r in range(5)]
    d += [(2.4, r, 2, [11 + (4 - r)*2, 12 + (4 - r)*2]) for r in range(5)]
    d += [(4.8, r, 2, [21 + r*2, 22 + r*2]) for r in range(5)]
    d += [(2.4, 5, 1, [31]), (2.4, 6, 1, [32]), (0, 5, 2, [33, 34]), (0, 6, 2, [35, 36])]
    # tahtadan bakınca: solda kapı, sağda öğretmen masası, hemen solunda akıllı tahta, onun solunda beyaz tahta → plan aynada çevrilir
    W_ = max(x + w for x, y, w, _ in d); d = [(round(W_ - x - w, 2), y, w, list(reversed(ns))) for x, y, w, ns in d]
    return dict(desks=d, sol='', sag='DUVAR', on=[('DOLAP · KAPI', 'sol'), ('BEYAZ TAHTA', 'orta'), ('AKILLI TAHTA', 'sagic'), ('Öğretmen masası', 'sag')])
def _layout_11h():
    """11-H (en çok 20 kişi): iki duvar kenarında beşer sıra, her sırada iki kişi; arkada cam.
    Önde solda kapı, sağda öğretmen masası. Öğretmen masasından başlar: sağ sütun önden arkaya 1–10, sol sütun arkadan öne 11–20."""
    d = [(4.4, r, 2, [r*2 + 1, r*2 + 2]) for r in range(5)] + [(0, r, 2, [11 + (4 - r)*2, 12 + (4 - r)*2]) for r in range(5)]
    return dict(desks=d, sol='DUVAR', sag='DUVAR', arka='CAM', on=[('KAPI', 'sol'), ('TAHTA', 'orta'), ('Öğretmen masası', 'sag')])
def seat_layout(plan):
    lay = SALON_LAYOUT.get(plan.get('sinif'), 4)
    if not lay: return None
    if lay == 'ozel': L_ = _layout_12i()
    elif lay == '11h': L_ = _layout_11h()
    else:
        n = max([r['sira'] for r in plan['liste']] or [1]); rows = max(5, math.ceil(n/(lay*2)))
        L_ = dict(desks=_snake(lay, rows), sol='CAM', sag='DUVAR', on=[('Öğretmen masası', 'sol'), ('TAHTA', 'orta'), ('KAPI', 'sag')], wide_aisle=(lay <= 2))
    L_['W'] = max(x + w for x, y, w, _ in L_['desks']); L_['H'] = max(y for x, y, w, _ in L_['desks']) + 1
    L_['seats'] = {n_ for *_, ns in L_['desks'] for n_ in ns}
    return L_
def draw_neon(p, r, s_, f, color, k, glow=1.0):
    """Neon tabela: koyu zemin, parlayan çerçeve ve parlayan yazı (glow: ışıma çarpanı, nefes efekti için)."""
    c = QColor(color); p.save(); p.setBrush(Qt.NoBrush)
    for w_, a in ((14, 22), (9, 40), (5, 70)):
        q = QColor(c); q.setAlpha(int(min(255, a*glow))); p.setPen(QPen(q, w_*k)); p.drawRoundedRect(r, 16*k, 16*k)
    p.setPen(Qt.NoPen); p.setBrush(QColor(8, 14, 26, 235)); p.drawRoundedRect(r, 16*k, 16*k)
    p.setPen(QPen(c, 2.5*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 16*k, 16*k)
    path = QPainterPath(); fm = QFontMetrics(f); tw = fm.horizontalAdvance(s_)
    path.addText(QPointF(r.center().x() - tw/2, r.center().y() + (fm.ascent() - fm.descent())/2), f, s_)
    for w_, a in ((12, 30), (7, 60), (3.5, 120)):
        q = QColor(c); q.setAlpha(int(min(255, a*glow))); p.setPen(QPen(q, w_*k, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.drawPath(path)
    core = QColor(c).lighter(160); p.setPen(Qt.NoPen); p.setBrush(core); p.drawPath(path)
    p.restore()
def home_seat_plan(plan):
    """Sınavdan önce kendi sınıfında: öğrenciler okul numarasına göre (küçükten büyüğe) her sırada iki kişi,
    sütun sütun önden arkaya oturtulur; her kartta gideceği salon ve sıra yazar."""
    lst = sorted(plan['liste'], key=lambda r: (int(r['no']) if str(r.get('no', '')).isdigit() else 10**9, r.get('ad', '')))
    probe = dict(sinif=plan['sinif'], liste=[dict(sira=i + 1) for i in range(len(lst))])
    lay = seat_layout(probe)
    if not lay: return None
    order = [n_ for x, y, w, ns in sorted(lay['desks'], key=lambda d: (d[0], d[1])) for n_ in ns]
    if plan['sinif'] in OZEL_SIRA: order = [n_ for n_ in OZEL_SIRA[plan['sinif']] if n_ in lay['seats']] + [n_ for n_ in order if n_ not in OZEL_SIRA[plan['sinif']]]
    out = [dict(sira=order[i], ad=r['ad'], no=r.get('no', ''), sinif=plan['sinif'], ders=r.get('ders', ''), git='%s · Sıra %s' % (r['salon'], r['sira'])) for i, r in enumerate(lst) if i < len(order)]
    return dict(tur='salon', sinif=plan['sinif'], liste=out, ev=True)
OZEL_SIRA = {'12-I': list(range(1, 37)), '11-H': list(range(1, 9)) + list(range(13, 21)) + [9, 10, 11, 12]}   # özel sınıflarda oturtma sırası (öğretmen masasından)

def hata_ozet(tail):
    """Hata kaydının son satırı + uygulamadaki son çağrı yeri (panelde kök nedeni görmek için):
    'IndexError: page 156 not in document · satır 3333 fit_page ← 2901 place_overlays'."""
    import re
    msg = (tail[-1] if tail else '').strip()
    fr = [(m.group(1), m.group(2)) for l in tail for m in [re.search(r'tahta_kalem\.py", line (\d+), in (\w+)', l)] if m]
    if fr: msg += ' · satır ' + ' ← '.join('%s %s' % (n, f) for n, f in reversed(fr[-3:]))
    return msg[:240]
def tr_name(ad):
    """Öğrenci adı ekranda: her kelimenin baş harfi büyük, gerisi küçük (Türkçe I/ı, İ/i doğru): 'SÜMEYYE ÇAĞLAYAN' → 'Sümeyye Çağlayan'."""
    lo = lambda x: x.replace('I', 'ı').replace('İ', 'i').lower()
    up = lambda x: x.replace('i', 'İ').replace('ı', 'I').upper()
    return ' '.join(up(w[:1]) + lo(w[1:]) for w in (ad or '').split())

def seat_courses(plan):
    """Planda (salon ya da sınıf) hangi sınavlar var: Türkçe yazımla, en çok öğrencisi olandan başlayarak."""
    import collections
    c = collections.Counter(tr_title(r.get('ders')) for r in plan.get('liste', []) if r.get('ders'))
    return [x for x, _ in c.most_common() if x]

CARD_COURSE = {'Din Kültürü ve Ahlak Bilgisi': 'Din Kültürü', 'Sağlık Bilgisi ve Trafik': 'Sağlık Bilgisi', 'S. Klasik Ahlak Metinleri': 'S. Klasik Ahlak',
               'S. Türk Dili ve Edebiyatı': 'S. Edebiyat', 'Türk Dili ve Edebiyatı': 'Edebiyat', 'S. Metin Tahlilleri': 'S. Metin Tahlili',
               'S. Temel Matematik': 'S. Temel Mat.', 'S. Peygamberimizin Hayatı': 'S. Peygamber Hayatı', 'S. Türk Kültür ve Medeniyet Tarihi': 'S. Medeniyet Tarihi', 'T.C. İnkılap Tarihi ve Atatürkçülük': 'İnkılap Tarihi', 'S. Türk Kültür ve Medeniyet Tarihi': 'S. Medeniyet Tarihi'}
def course_short(c):
    """Sıra kartında ders adı tek satır: uzun adların kısa biçimi (başlıkta tam adı kalır)."""
    if not c: return c
    c = CARD_COURSE.get(c, c)
    if len(c) > 18 and ' ve ' in c: c = c.split(' ve ')[0]
    return c
def course_wrap(c):
    """Ders adı satır kırılırken 'S.' kendi kelimesinden ayrılmasın."""
    c = course_short(c)
    return c.replace('S. ', 'S.\u00a0') if c else c
def seat_card_parts(hfun, avail, items, gap):
    """Kartın yazı sütunu: ad, ders, sınıf alt alta, dikeyde ortalı. Sığmazsa önce sınıf, sonra ders düşer.
    Döner: [(font, metin, y, yükseklik)] (metin boşsa yükseklik 0)."""
    items = list(items)
    while True:
        hs = [hfun(f, t) if t else 0 for f, t in items]; n = sum(1 for h in hs if h)
        tot = sum(hs) + gap*max(0, n - 1)
        if tot <= avail or n <= 1: break
        for i in (2, 1):
            if items[i][1]: items[i] = (items[i][0], ''); break
    y = max(0, (avail - tot)/2); out = []
    for (f, t), h in zip(items, hs):
        out.append((f, t, y, h if t else 0))
        if t: y += h + gap
    return out
def desk_extend(desks, keep=0.3):
    """Aynı sıradaki komşu masalar arası en dar boşluktan 'keep' kadarı koridor kalır; gerisi masalara eklenir."""
    rows = {}
    for x, y, w, _ in desks: rows.setdefault(y, []).append((x, w))
    gaps = [b[0] - (a[0] + a[1]) for r in rows.values() for a, b in zip(sorted(r), sorted(r)[1:])]
    gaps = [g_ for g_ in gaps if g_ > 0]
    return min(0.4, max(0.0, min(gaps) - keep)) if gaps else 0.0
def seat_fonts(adv, width, names, courses, photos=True):
    """Salonun ortak puntoları (k'siz px): ad için en büyük boy ki en uzun kelime sığsın (alt sınır 14),
    ders için de aynısı (11–15). adv(px, bold, metin) -> genişlik."""
    def best(hi, lo, bold, texts):
        words = {w for t in texts for w in (t or '').split(' ') if w}   # (S.\u00a0Matematik tek kelime sayılır)
        if not words: return hi
        for px in range(hi, lo - 1, -1):
            if max(adv(px, bold, w) for w in words) <= width: return px
        return lo
    def best_line(hi, lo, bold, texts):   # ders adı tek satıra sığsın (en uzun ders adına göre); olmazsa en küçük boy, iki satır
        texts = [t for t in texts if t]
        if not texts: return hi
        for px in range(hi, lo - 1, -1):
            if max(adv(px, bold, t) for t in texts) <= width: return px
        return lo
    return best(22 if photos else 26, 14, False, names), best_line(15, 10, True, courses)
def meta_parts(meta):
    """'4. Ders  ·  6 Kasım  ·  38 öğrenci' → [(parça, sarı_neon_mu)]: öğrenci sayısı sarı neon."""
    return [(m_.strip(), 'öğrenci' in m_) for m_ in (meta or '').split('·') if m_.strip()]
def draw_meta_right(p, r, meta, font, accent, k):
    """Sağa yaslı bilgi satırı; parçalar ' · ' ile, öğrenci sayısı sarı neon ışımalı."""
    from PyQt5.QtGui import QFontMetrics
    parts = meta_parts(meta); sep = '  ·  '
    if not parts: return
    f = font(24)
    while f.pixelSize() > 11 and QFontMetrics(f).horizontalAdvance(sep.join(t for t, _ in parts)) > r.width(): f.setPixelSize(f.pixelSize() - 1)
    fm = QFontMetrics(f); x = r.right(); p.setFont(f)
    for i, (t, neon) in reversed(list(enumerate(parts))):
        w = fm.horizontalAdvance(t); rr = QRectF(x - w, r.y(), w + 2, r.height())
        if neon:
            for dx_, dy_ in ((-1, 0), (1, 0), (0, -1), (0, 1)): p.setPen(QColor(255, 200, 0, 90)); p.drawText(rr.translated(dx_*k*1.5, dy_*k*1.5), Qt.AlignLeft | Qt.AlignVCenter, t)
            p.setPen(QColor('#ffe14d'))
        else: p.setPen(QColor(accent))
        p.drawText(rr, Qt.AlignLeft | Qt.AlignVCenter, t); x -= w
        if i:
            ws = fm.horizontalAdvance(sep); p.setPen(QColor(accent)); p.drawText(QRectF(x - ws, r.y(), ws + 2, r.height()), Qt.AlignLeft | Qt.AlignVCenter, sep); x -= ws
def seat_name_fit(hh, nf, cf, avail, pairs, gap, lo=12):
    """Ad puntosunu (salonun tek puntosu) gerekirse küçült: her kartta ad + ders alt alta sığsın. hh(px, kalın, metin) -> yükseklik."""
    while nf > lo and any(hh(nf, False, ad) + ((hh(cf, True, c) + gap) if c else 0) > avail for ad, c in pairs if ad): nf -= 1
    return nf
def seat_head_zone(self, W, k, hx, hr):
    """Başlık yazısının sağ sınırı: ortada neon arama düğmesi varsa onun solunda biter."""
    b = getattr(self, 'ara_btn', None) or getattr(self, 'b_ara', None)
    if b is None or isinstance(self, SalonBrowser): return hr
    try: bw = b.width()
    except Exception: return hr
    return max(hx + 40*k, min(hr, W/2 - bw/2 - 20*k))
def heart_beat(per=1.0, t=None):
    """Kalp atışı (0..1): saniyenin başında iki kısa vuruş (tık-tık), sonra dinlenme. per: vuruş aralığı (son 5 dk'da .6)."""
    ph = ((time.time() if t is None else t) % per)/per
    return max(math.exp(-((ph - .07)/.035)**2), .6*math.exp(-((ph - .21)/.035)**2))
class HeartOverlay(QWidget):
    """Ağır ekranların (fotoğraflı plan, Karargah) üstünde yalnız saat/sayaç kutusunu saniyede 20 kez çizen küçük katman:
    alttaki ekran saniyede bir çizilmeye devam eder. item: dict(rect, kind, text, font, color, k, bg[, label, lfont])."""
    def __init__(self, parent):
        super().__init__(parent); self.item = None
        self.setAttribute(Qt.WA_OpaquePaintEvent, True); self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.timer = QTimer(self); self.timer.timeout.connect(self.update)
    def set_item(self, it):
        if not it: self.item = None; self.timer.stop(); self.hide(); return
        self.item = it; r = it['rect']; k = it['k']; m = it.get('m', 7*k + r.width()*.03)   # ışıma + büyüme payı (komşu yazıya değmez)
        g = QRectF(r.x() - m, r.y() - m, r.width() + 2*m, r.height() + 2*m).toAlignedRect().intersected(self.parent().rect())
        if g != self.geometry(): self.setGeometry(g)
        if not self.isVisible(): self.show()
        if not self.timer.isActive(): self.timer.start(50)
        self.update()
    def paintEvent(self, e):
        it = self.item
        if not it: return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        p.fillRect(self.rect(), QColor(it.get('bg', '#0d1726'))); p.translate(-self.x(), -self.y())
        v = heart_beat(it.get('per', 1.0)); s_ = 1 + .06*v; r = it['rect']; k = it['k']
        rr = QRectF(r.center().x() - r.width()*s_/2, r.center().y() - r.height()*s_/2, r.width()*s_, r.height()*s_)
        f = QFont(it['font']); f.setPixelSize(max(8, int(it['font'].pixelSize()*s_)))
        if it['kind'] == 'neon': draw_neon(p, rr, it['text'], f, it['color'], k, 1 + 1.3*v)
        elif it['kind'] == 'box':   # dolu kutu (yoklama sayacı): kutu yerinde, parlar; yazı atar
            p.setPen(Qt.NoPen)
            if it.get('strip'): p.setBrush(QColor(it['strip'])); p.drawRoundedRect(r, 12*k, 12*k); p.drawRect(QRectF(r.center().x(), r.y(), r.width()/2, r.height()))   # şeridin devamı
            q = QColor(it['color']); p.setBrush(q.lighter(int(100 + 22*v))); p.drawRoundedRect(r, 12*k, 12*k)
            f2 = QFont(it['font']); f2.setPixelSize(max(8, int(it['font'].pixelSize()*(1 + .08*v))))
            p.setFont(f2); p.setPen(QColor(it.get('fg', '#1a1206'))); p.drawText(r, Qt.AlignCenter, it['text'])
        elif it['kind'] == 'stat':   # Karargah istatistik kutusu: etiket sabit, değer atar
            p.setPen(Qt.NoPen); p.setBrush(QColor('#16243a')); p.drawRoundedRect(r, 12*k, 12*k)
            p.setFont(it['lfont']); p.setPen(QColor('#8fa6c4')); p.drawText(QRectF(r.x() + 16*k, r.y() + 6*k, r.width(), 24*k), Qt.AlignLeft | Qt.AlignVCenter, it['label'])
            vr = QRectF(r.x() + 16*k, r.y() + 30*k, r.width() - 20*k, 38*k); p.save(); p.translate(vr.x(), vr.center().y()); p.scale(s_, s_)
            p.setFont(it['font']); q = QColor(it['color']); p.setPen(q.lighter(int(100 + 30*v))); p.drawText(QRectF(0, -vr.height()/2, vr.width(), vr.height()), Qt.AlignLeft | Qt.AlignVCenter, it['text']); p.restore()
        else:   # düz yazı (sağa yaslı)
            p.save(); p.translate(r.right(), r.center().y()); p.scale(s_, s_)
            p.setFont(it['font']); q = QColor(it['color']); p.setPen(q.lighter(int(100 + 30*v))); p.drawText(QRectF(-r.width(), -r.height()/2, r.width(), r.height()), Qt.AlignRight | Qt.AlignVCenter, it['text']); p.restore()
        p.end()
def hb_sync(w):
    """Ekran çizildikten sonra: kaydedilen saat/sayaç kutularına kalp atışı katmanı koy, gerekmeyenleri gizle."""
    items = getattr(w, 'hb_items', {}) or {}; ov = getattr(w, 'hb_ov', None)
    if ov is None: ov = w.hb_ov = {}
    for key in set(ov) | set(items):
        if key not in ov: ov[key] = HeartOverlay(w); ov[key].lower()   # düğmelerin, duyurunun ve kâğıt alarmının altında kalır
        try: ov[key].set_item(items.get(key))
        except Exception as e: print('kalp:', e); ov[key].hide()
def hb_wrap(cls):
    inner = cls.paintEvent
    def paintEvent(self, e):
        self.hb_items = {}
        inner(self, e)
        hb_sync(self)
    cls.paintEvent = paintEvent
def draw_teneffus(p, W, H, k, font, tn):
    """Teneffüs modu ekranı (Atlas renkleri): büyük neon saat, tarih, şimdi/sıradaki ders, sıradaki sınava geri sayım, 5 iş günü takvim."""
    from PyQt5.QtGui import QFontMetrics
    def text(r, s_, f, c, al=Qt.AlignLeft | Qt.AlignVCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    v_ = heart_beat(); fC = font(170, True); fC.setPixelSize(int(fC.pixelSize()*(1 + .05*v_))); r = QRectF(60*k, 30*k, 700*k, 190*k)
    p.setFont(fC)
    for w_, a in ((10, 40), (5, 70)):   # neon ışıma
        q = QColor('#22e8ff'); q.setAlpha(int(min(255, a*(1 + 1.2*v_))))
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)): p.setPen(q); p.drawText(r.translated(dx*w_*k*.4, dy*w_*k*.4), Qt.AlignLeft | Qt.AlignVCenter, tn['saat'])
    text(r, tn['saat'], fC, '#7ff6ff')
    text(QRectF(70*k, 225*k, 700*k, 44*k), tn['tarih'], font(32, True), '#c9d6ea')
    if tn.get('simdi'):
        f_ = font(24, True); w_ = QFontMetrics(f_).horizontalAdvance(tn['simdi']) + 36*k; rr = QRectF(70*k, 282*k, w_, 46*k)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#ffb020')); p.drawRoundedRect(rr, 12*k, 12*k); text(rr, tn['simdi'], f_, '#1a1206', Qt.AlignCenter)
    cd = QRectF(W - 60*k - 600*k, 92*k, 600*k, 250*k)   # üst ortadaki arama düğmesinin altında
    for w_, a in ((16, 25), (8, 50)):
        q = QColor('#ffe14d'); q.setAlpha(a); p.setPen(QPen(q, w_*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(cd, 24*k, 24*k)
    p.setPen(QPen(QColor('#ffe14d'), 3*k)); p.setBrush(QColor(30, 24, 5, 200)); p.drawRoundedRect(cd, 24*k, 24*k)
    text(QRectF(cd.x() + 30*k, cd.y() + 16*k, cd.width() - 60*k, 30*k), 'Bu sınıfın sıradaki sınavı', font(20, True), '#ffe9a0')
    fs = font(28, True)
    while fs.pixelSize() > 12 and QFontMetrics(fs).horizontalAdvance(tn['sonraki']) > cd.width() - 60*k: fs.setPixelSize(fs.pixelSize() - 1)
    text(QRectF(cd.x() + 30*k, cd.y() + 48*k, cd.width() - 60*k, 40*k), tn['sonraki'], fs, '#ffffff')
    bw = (cd.width() - 60*k - 2*14*k)/3
    for i, (v, lab) in enumerate(zip(tn['kalan'], ('gün', 'saat', 'dakika'))):
        b = QRectF(cd.x() + 30*k + i*(bw + 14*k), cd.y() + 100*k, bw, 140*k); p.setPen(Qt.NoPen); p.setBrush(QColor(255, 225, 77, 26)); p.drawRoundedRect(b, 16*k, 16*k)
        fv = font(72, True); fv.setPixelSize(int(fv.pixelSize()*(1 + .06*v_)))
        text(QRectF(b.x(), b.y() + 6*k, b.width(), 92*k), str(v), fv, QColor('#ffe14d').lighter(int(100 + 25*v_)).name(), Qt.AlignCenter); text(QRectF(b.x(), b.y() + 96*k, b.width(), 34*k), lab, font(19), '#ffe9a0', Qt.AlignCenter)
    days = tn['gunler']; n = max(1, len(days)); gap = 20*k; x0 = 60*k; top = 370*k; bot = H - 110*k
    cw = (W - 2*x0 - (n - 1)*gap)/n
    for i, (lab, sub, items) in enumerate(days):
        r_ = QRectF(x0 + i*(cw + gap), top, cw, bot - top); today = lab == 'Bugün'
        p.setPen(QPen(QColor('#22e8ff') if today else QColor(255, 255, 255, 40), (3 if today else 1.2)*k)); p.setBrush(QColor(34, 232, 255, 16) if today else QColor(255, 255, 255, 12)); p.drawRoundedRect(r_, 20*k, 20*k)
        text(QRectF(r_.x() + 20*k, r_.y() + 14*k, r_.width() - 40*k, 38*k), lab, font(28, True), '#ffffff')
        text(QRectF(r_.x() + 20*k, r_.y() + 50*k, r_.width() - 40*k, 26*k), sub, font(17), '#9fb3cc')
        y = r_.y() + 92*k
        if not items: text(QRectF(r_.x() + 20*k, r_.bottom() - 50*k, r_.width() - 40*k, 30*k), 'Sınav yok', font(18), '#9fb3cc')
        for crs, les, hm_, done in items[:3]:
            e_ = QRectF(r_.x() + 14*k, y, r_.width() - 28*k, 78*k)
            if e_.bottom() > r_.bottom() - 8*k: break
            col_, _k = exam_theme(crs); p.setPen(Qt.NoPen); p.setBrush(QColor(8, 14, 30, 200)); p.drawRoundedRect(e_, 12*k, 12*k)
            p.setBrush(QColor(col_)); p.drawRoundedRect(QRectF(e_.x(), e_.y(), 6*k, e_.height()), 3*k, 3*k)
            fc = font(22, True); cs = QFontMetrics(fc).elidedText(course_short(crs) + ('  · bitti' if done else ''), Qt.ElideRight, int(e_.width() - 30*k))
            text(QRectF(e_.x() + 18*k, e_.y() + 8*k, e_.width() - 26*k, 34*k), cs, fc, '#7f8da3' if done else '#ffffff')
            text(QRectF(e_.x() + 18*k, e_.y() + 42*k, e_.width() - 26*k, 26*k), '%s · %s' % (les, hm_), font(16), '#9fb3cc')
            y += 88*k
def _draw_seatmap(self, p, W, H, k, font, plan, theme, accent, head):
    """Sınav anında salonun gerçek oturma düzeni (fotoğraflı): önde öğretmen masası, tahta, kapı; masalar ve numaralar seat_layout'tan."""
    from PyQt5.QtGui import QFontMetrics, QFont
    lay = seat_layout(plan); seats = {r['sira']: r for r in plan['liste']}
    absent = getattr(self, 'absent', None) or set(); self.seat_rects = {}
    p.fillRect(QRectF(0, 0, W, H), QColor('#0d1726'))
    crs = seat_courses(plan)   # salondaki sınav(lar): en kalabalıktan başlayarak
    if crs:   # arka planda o dersin teması (soluk, yavaş kayan desen)
        tcol, tkind = exam_theme(crs[0]); draw_exam_theme(p, W, H, k, tkind, tcol, time.time() % 86400)
    def text(r, s_, f, c, al=Qt.AlignCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    fT = font(34, True); twT = QFontMetrics(fT).horizontalAdvance(plan['sinif'])   # başlık: yalnız salon adı, neon mavi
    pillT = QRectF(30*k, 8*k, twT + 48*k, 58*k); draw_neon(p, pillT, plan['sinif'], fT, '#22e8ff', k)
    meta = ''   # ders saati, tarih, öğrenci sayısı: sağa yaslı ayrı bölme (sınav adlarıyla karışmasın)
    if crs and not any(c_.lower() in (head or '').lower() for c_ in crs): head, meta = ' / '.join(c_.replace('S. ', 'S.\u00a0') for c_ in crs[:3]), (head or '')
    hr = W - 36*k
    if plan.get('saat'):   # neon saat: sağ üstte, uzaktan okunur
        fn = font(40, True); tw = QFontMetrics(fn).horizontalAdvance(plan['saat'])
        pill = QRectF(W - 30*k - tw - 44*k, 8*k, tw + 44*k, 58*k); draw_neon(p, pill, plan['saat'], fn, accent, k); hr = pill.x() - 18*k
        if isinstance(getattr(self, 'hb_items', None), dict) and not p.transform().isTranslating():   # kalp atışı (yalnız tam ekran plan)
            self.hb_items['clock'] = dict(rect=QRectF(pill), kind='neon', text=plan['saat'], font=QFont(fn), color=accent, k=k, bg='#0d1726', per=plan.get('hb_per', 1.0))
    hx = pillT.right() + 20*k; hz = seat_head_zone(self, W, k, hx, hr)   # sol bölme: ortadaki 'Nerede sınava gireceğim?' düğmesine binmez
    if meta:
        mz = (W - hz) if hz < hr else hx + (hr - hx)*.55   # sağ bölme: düğmenin sağından (düğme yoksa ortadan) saate kadar
        if hz >= hr: hz = mz - 20*k
        draw_meta_right(p, QRectF(mz, 6*k, hr - mz, 62*k), meta, font, accent, k)
    fH = font(24); hrect = QRectF(hx, 6*k, hz - hx, 62*k)
    while fH.pixelSize() > 11 and QFontMetrics(fH).boundingRect(hrect.toRect(), Qt.TextWordWrap, head).height() > hrect.height(): fH.setPixelSize(fH.pixelSize() - 1)
    text(hrect, head, fH, accent, Qt.AlignLeft | Qt.AlignVCenter | Qt.TextWordWrap)
    fy = 84*k; fh = 28*k   # neon ışıması (7k) ön şeride değmesin
    pos = {'sol': QRectF(56*k, fy, 240*k, fh), 'sol2': QRectF(310*k, fy, 240*k, fh), 'sag2': QRectF(W - 56*k - 240*k, fy, 240*k, fh), 'sagic': QRectF(W - 56*k - 494*k, fy, 240*k, fh), 'orta': QRectF(W/2 - (280 if len(lay['on']) < 4 else 170)*k, fy, (560 if len(lay['on']) < 4 else 340)*k, fh), 'sag': QRectF(W - 56*k - 200*k, fy, 200*k, fh)}
    col = {'Öğretmen masası': ('#3a2f1f', '#ead6b0'), 'KAPI': ('#2a2f45', '#c9d0ff'), 'DOLAP · KAPI': ('#2a2f45', '#c9d0ff')}
    for lab, where in lay['on']:
        r_ = pos['sag2'] if (where == 'sag' and lab == 'Öğretmen masası') else pos[where]; bg, fg = col.get(lab, ('#1f3a2c', '#b9e3c9'))
        if where == 'orta' and lab == 'BEYAZ TAHTA': bg, fg = '#2f3640', '#e6e9ee'
        p.setPen(Qt.NoPen); p.setBrush(QColor(bg)); p.drawRoundedRect(r_, 8*k, 8*k); text(r_, lab, font(17, True), fg)
    if lay['sol']: text(QRectF(4*k, 120*k, 40*k, H - 140*k), '\n'.join(lay['sol']), font(20, True), '#5d7fa8')
    if lay['sag']: text(QRectF(W - 44*k, 120*k, 40*k, H - 140*k), '\n'.join(lay['sag']), font(20, True), '#5d7fa8')
    L, R0, top, bot = 48*k, W - 48*k, fy + fh + 8*k, H - 70*k
    if lay.get('arka'):   # arka duvardaki pencere
        bot = H - 100*k; text(QRectF(W/2 - 200*k, bot + 4*k, 400*k, 26*k), lay['arka'], font(18, True), '#5d7fa8')
    if lay.get('wide_aisle'):   # iki sütunlu salon: geniş koridor
        ux = (R0 - L)/(lay['W'] + 4)
        xof = lambda x: L + (x if x < 2.4 else x + 4 - 0.4)*ux
    ext = 0.0 if lay.get('wide_aisle') else desk_extend(lay['desks'])   # masalar koridora doğru genişler (dar koridor, büyük kartlar)
    if not lay.get('wide_aisle'):
        ux = (R0 - L)/(lay['W'] + ext); xof = lambda x: L + x*ux
    rh = (bot - top)/lay['H']; gap = 8*k
    dwf = lambda w_: w_*ux + (ext*ux if w_ > 1 else -0.1*ux) - (0 if ext or w_ <= 1 else 0.4*ux)   # masa eni
    trw0 = 1e9   # bütün salon için tek punto: en dar yazı alanı ve en uzun kelimeye göre bir kez seçilir
    for x_, y_, w_, nums in lay['desks']:
        cw0 = (dwf(w_) - gap*(len(nums) + 1))/len(nums); ch0 = (rh - 8*k - 2*gap)*(.7 if plan.get('ev') else 1)
        trw0 = min(trw0, cw0 - 5*k - (min((ch0 - 10*k)*.77, cw0*.45) if BOARD_PHOTOS else 0) - 9*k)
    nf_, cf_ = seat_fonts(lambda px, b, t_: QFontMetrics(font(px, b)).horizontalAdvance(t_), trw0,
                          [tr_name(r['ad']) for r in plan['liste']], [course_wrap(tr_title(r.get('ders')) or '') for r in plan['liste']], BOARD_PHOTOS)
    trh0 = min((rh - 8*k - 2*gap)*(.7 if plan.get('ev') else 1) for _ in [0]) - 8*k   # yazı sütununun yüksekliği
    def _hh(px, b_, t_): return QFontMetrics(font(px, b_)).boundingRect(QRect(0, 0, max(1, int(trw0)), 4000), Qt.TextWordWrap, t_).height()
    pairs = [(tr_name(r['ad']), course_wrap(tr_title(r.get('ders')) or '')) for r in plan['liste']]
    nf_ = seat_name_fit(_hh, nf_, cf_, trh0, pairs, 3*k)   # ad + ders her kartta sığsın (ders adı düşmesin); punto yine tek
    for x_, y_, w_, nums in lay['desks']:
        x = xof(x_); y = top + y_*rh + 4*k; dw = dwf(w_); desk = QRectF(x, y, dw, rh - 8*k)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#8f949b'))   # sıra ayakları (masanın altında, boşlukta)
        for lx in (x + 10*k, x + dw - 20*k): p.drawRect(QRectF(lx, desk.bottom() - 2*k, 10*k, 7*k)); p.setBrush(QColor('#2f3237')); p.drawRoundedRect(QRectF(lx - 2*k, desk.bottom() + 4*k, 14*k, 3*k), 1.5*k, 1.5*k); p.setBrush(QColor('#8f949b'))
        p.setPen(QPen(QColor(222, 196, 150, 70), 1.5)); p.setBrush(QColor(222, 196, 150, 14)); p.drawRoundedRect(desk, 12*k, 12*k)   # ahşap tonlu tabla
        p.setPen(Qt.NoPen); p.setBrush(QColor('#c9ad7c')); p.drawRoundedRect(QRectF(desk.x() + 4*k, desk.bottom() - 5*k, dw - 8*k, 4*k), 2*k, 2*k)   # tabla ön kenarı
        cw = (dw - gap*(len(nums) + 1))/len(nums)
        for si, no in enumerate(nums):
            st_ = seats.get(no); cell = QRectF(x + gap + si*(cw + gap), y + gap, cw, rh - 8*k - 2*gap)
            p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 18 if st_ else 6)); p.drawRoundedRect(cell, 10*k, 10*k)
            gcol = grade_color(st_.get('sinif'), theme) if st_ else theme   # sınıf seviyesi rengi
            if st_:   # solda seviye şeridi (hafif ışımalı)
                q_ = QColor(gcol); q_.setAlpha(70); p.setBrush(q_); p.drawRoundedRect(QRectF(cell.x() - 1*k, cell.y() + 2*k, 7*k, cell.height() - 4*k), 3*k, 3*k)
                p.setBrush(QColor(gcol)); p.drawRoundedRect(QRectF(cell.x(), cell.y() + 3*k, 4*k, cell.height() - 6*k), 2*k, 2*k)
            gstrip = None
            if plan.get('ev') and st_:   # sınavdan önce: altta tam genişlikte gideceği salon ve sıra
                gh_ = cell.height()*.3; gstrip = QRectF(cell.x() + 4*k, cell.bottom() - gh_, cell.width() - 8*k, gh_ - 4*k); cell = QRectF(cell.x(), cell.y(), cell.width(), cell.height() - gh_)
            pw_ = min((cell.height() - 10*k)*.77, cell.width()*.45); ph_ = pw_/.77   # fotoğrafın kendi oranı (en/boy .77): yanlardan kesilmesin
            ph = QRectF(cell.x() + 5*k, cell.y() + (cell.height() - ph_)/2, pw_, ph_)
            if not BOARD_PHOTOS: ph = QRectF(cell.x() + 4*k, cell.y() + 26*k, 0, cell.height() - 30*k)   # fotoğrafsız: ad bütün kartı kullanır
            if st_ and BOARD_PHOTOS:
                p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 230)); p.drawRoundedRect(ph.adjusted(-1.5*k, -1.5*k, 1.5*k, 1.5*k), 6*k, 6*k)   # ince beyaz çerçeve
                draw_photo(p, ph, st_.get('no'), st_['ad'], k)
            if st_: self.seat_rects[no] = QRectF(cell)
            if st_ and no in absent:   # yoklama: gelmedi
                p.setPen(Qt.NoPen); p.setBrush(QColor(13, 23, 38, 150)); p.drawRoundedRect(cell, 10*k, 10*k)
                p.setPen(QPen(QColor('#ff4d5e'), 3*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(cell.adjusted(1.5*k, 1.5*k, -1.5*k, -1.5*k), 10*k, 10*k)
                gb = QRectF(ph.x(), ph.bottom() - 22*k, ph.width(), 22*k) if BOARD_PHOTOS else QRectF(cell.right() - 86*k, cell.y() + 4*k, 82*k, 22*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#e5323f')); p.drawRoundedRect(gb, 6*k, 6*k)
                text(gb, 'GELMEDİ', font(13, True), '#ffffff')
            if not plan.get('ev'):
                b = QRectF(cell.x() + 3*k, cell.y() + 3*k, 32*k, 22*k); p.setPen(Qt.NoPen); p.setBrush(QColor(gcol)); p.drawRoundedRect(b, 7*k, 7*k)
                text(b, str(no), font(15, True), '#0b1422')
            tr = QRectF(ph.right() + 6*k, cell.y() + 4*k, cell.right() - ph.right() - 9*k, cell.height() - 8*k) if BOARD_PHOTOS else QRectF(cell.x() + 10*k, cell.y() + 28*k, cell.width() - 20*k, cell.height() - 32*k)
            if not st_: text(tr, 'boş', font(15), '#5d6f88'); continue
            ad_ = tr_name(st_['ad']); f_ = font(nf_)   # bütün salonda aynı punto, yarı kalın (Medium)
            cname = course_wrap(tr_title(st_.get('ders')) or ''); fc_ = font(cf_, True); fs_ = font(min(14, cf_))
            for ff_, tt_ in ((f_, ad_), (fc_, cname)):   # yine de sığmayan tek kelime: boyu aynı, yalnız yatayda hafifçe daralır
                ww_ = max([QFontMetrics(ff_).horizontalAdvance(w2) for w2 in tt_.split(' ') if w2] or [0])
                if ww_ > tr.width(): ff_.setStretch(max(70, int(100*tr.width()/ww_)))
            parts = seat_card_parts(lambda f, t_: QFontMetrics(f).boundingRect(QRect(0, 0, max(1, int(tr.width())), 4000), Qt.TextWordWrap, t_).height(),
                                    tr.height(), [(f_, ad_), (fc_, cname), (fs_, '' if gstrip is not None else st_['sinif'])], 3*k)
            for (fp_, tp_, yy_, hh_), col_ in zip(parts, ('#ffffff', '#ffe14d', gcol)):
                if not tp_: continue
                r_ = QRectF(tr.x(), tr.y() + yy_, tr.width(), hh_); p.setFont(fp_)
                if col_ == '#ffe14d':   # sarı neon ışıma
                    for dx_, dy_ in ((-1, 0), (1, 0), (0, -1), (0, 1)): p.setPen(QColor(255, 200, 0, 80)); p.drawText(r_.translated(dx_*k, dy_*k), Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, tp_)
                p.setPen(QColor(col_)); p.drawText(r_, Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, tp_)
            if gstrip is not None:   # sınavdan önce, kendi sınıfında: gideceği salon ve sıra
                p.setPen(Qt.NoPen); p.setBrush(QColor(theme).darker(300)); p.drawRoundedRect(gstrip, 7*k, 7*k)
                fg_ = font(min(24, gstrip.height()/k*.62), True)
                while fg_.pixelSize() > 9 and QFontMetrics(fg_).horizontalAdvance(st_['git']) > gstrip.width() - 10*k: fg_.setPixelSize(fg_.pixelSize() - 1)
                text(gstrip, st_['git'], fg_, theme)
    # düzende yeri olmayan numara (masadan fazla) olursa altta yazılır
    extra = [r for r in plan['liste'] if r['sira'] not in lay['seats']]
    if extra: text(QRectF(36*k, H - 64*k, W - 72*k, 40*k), 'Düzen dışı: ' + ', '.join('%d %s (%s)' % (r['sira'], r['ad'], r['sinif']) for r in extra), font(18), '#ffc145', Qt.AlignLeft | Qt.AlignVCenter)
ExamScreen.draw_seatmap = _draw_seatmap
hb_wrap(ExamScreen); hb_wrap(KarargahScreen)
SalonBrowser.draw_plan_photos = _draw_plan_photos

# ---------------- Oyunlar: satranç, Türk daması, XOX (iki kişi, tahtada, makineye karşı değil) ----------------
CHESS_GLYPH = {'K': '♚', 'Q': '♛', 'R': '♜', 'B': '♝', 'N': '♞', 'P': '♟'}
def chess_new():
    b = {}
    for c, p in enumerate('RNBQKBNR'): b[(0, c)] = 'b' + p; b[(7, c)] = 'w' + p
    for c in range(8): b[(1, c)] = 'bP'; b[(6, c)] = 'wP'
    return dict(b=b, turn='w', castle={'wK', 'wQ', 'bK', 'bQ'}, ep=None, last=None)
def _on(r, c): return 0 <= r < 8 and 0 <= c < 8
def chess_attacked(b, sq, by):
    """sq karesi 'by' renginin saldırısında mı?"""
    r, c = sq; fwd = -1 if by == 'w' else 1
    for dc in (-1, 1):   # piyon
        if b.get((r - fwd, c + dc)) == by + 'P': return True
    for dr, dc in ((1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)):
        if b.get((r + dr, c + dc)) == by + 'N': return True
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if (dr or dc) and b.get((r + dr, c + dc)) == by + 'K': return True
    for dirs, kinds in ((((1, 0), (-1, 0), (0, 1), (0, -1)), 'RQ'), (((1, 1), (1, -1), (-1, 1), (-1, -1)), 'BQ')):
        for dr, dc in dirs:
            rr, cc = r + dr, c + dc
            while _on(rr, cc):
                p = b.get((rr, cc))
                if p:
                    if p[0] == by and p[1] in kinds: return True
                    break
                rr += dr; cc += dc
    return False
def chess_king(b, col): return next((sq for sq, p in b.items() if p == col + 'K'), None)
def chess_pseudo(st, col):
    b = st['b']; out = []; fwd = -1 if col == 'w' else 1; opp = 'b' if col == 'w' else 'w'
    for (r, c), p in list(b.items()):
        if p[0] != col: continue
        k = p[1]
        if k == 'P':
            if _on(r + fwd, c) and (r + fwd, c) not in b:
                out.append(((r, c), (r + fwd, c)))
                if r == (6 if col == 'w' else 1) and (r + 2*fwd, c) not in b: out.append(((r, c), (r + 2*fwd, c)))
            for dc in (-1, 1):
                t = (r + fwd, c + dc)
                if _on(*t) and ((t in b and b[t][0] == opp) or t == st['ep']): out.append(((r, c), t))
        elif k == 'N':
            for dr, dc in ((1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)):
                t = (r + dr, c + dc)
                if _on(*t) and (t not in b or b[t][0] == opp): out.append(((r, c), t))
        elif k == 'K':
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    t = (r + dr, c + dc)
                    if (dr or dc) and _on(*t) and (t not in b or b[t][0] == opp): out.append(((r, c), t))
            row = 7 if col == 'w' else 0
            if (r, c) == (row, 4) and not chess_attacked(b, (row, 4), opp):   # rok
                if col + 'K' in st['castle'] and b.get((row, 7)) == col + 'R' and all((row, x) not in b for x in (5, 6)) and not any(chess_attacked(b, (row, x), opp) for x in (5, 6)):
                    out.append(((r, c), (row, 6)))
                if col + 'Q' in st['castle'] and b.get((row, 0)) == col + 'R' and all((row, x) not in b for x in (1, 2, 3)) and not any(chess_attacked(b, (row, x), opp) for x in (2, 3)):
                    out.append(((r, c), (row, 2)))
        else:
            dirs = {'R': ((1, 0), (-1, 0), (0, 1), (0, -1)), 'B': ((1, 1), (1, -1), (-1, 1), (-1, -1))}
            ds = dirs.get(k) or dirs['R'] + dirs['B']
            for dr, dc in ds:
                rr, cc = r + dr, c + dc
                while _on(rr, cc):
                    if (rr, cc) in b:
                        if b[(rr, cc)][0] == opp: out.append(((r, c), (rr, cc)))
                        break
                    out.append(((r, c), (rr, cc))); rr += dr; cc += dc
    return out
def chess_apply(st, mv, promo='Q'):
    (fr, fc), (tr, tc) = mv; b = dict(st['b']); p = b.pop((fr, fc)); col = p[0]; cap = b.get((tr, tc))
    if p[1] == 'P' and (tr, tc) == st['ep'] and not cap: cap = b.pop((fr, tc), None)   # geçerken alma
    if p[1] == 'K' and abs(tc - fc) == 2:   # rok: kale de geçer
        if tc == 6: b[(fr, 5)] = b.pop((fr, 7))
        else: b[(fr, 3)] = b.pop((fr, 0))
    if p[1] == 'P' and tr in (0, 7): p = col + promo
    b[(tr, tc)] = p
    castle = set(st['castle'])
    if p[1] == 'K': castle -= {col + 'K', col + 'Q'}
    for sq, right in (((7, 0), 'wQ'), ((7, 7), 'wK'), ((0, 0), 'bQ'), ((0, 7), 'bK')):
        if (fr, fc) == sq or (tr, tc) == sq: castle.discard(right)
    ep = ((fr + tr)//2, fc) if p[1] == 'P' and abs(tr - fr) == 2 else None
    return dict(b=b, turn='b' if col == 'w' else 'w', castle=castle, ep=ep, last=((fr, fc), (tr, tc)), cap=cap)
def chess_legal(st, col=None):
    col = col or st['turn']; opp = 'b' if col == 'w' else 'w'; out = []
    for mv in chess_pseudo(st, col):
        n = chess_apply(st, mv); k = chess_king(n['b'], col)
        if k is not None and not chess_attacked(n['b'], k, opp): out.append(mv)
    return out
def chess_status(st):
    """'mat', 'pat', 'sah' ya da ''; (yalnız iki şah kalırsa 'yetersiz')."""
    col = st['turn']; opp = 'b' if col == 'w' else 'w'; k = chess_king(st['b'], col)
    chk = k is not None and chess_attacked(st['b'], k, opp)
    if not chess_legal(st): return 'mat' if chk else 'pat'
    if all(p[1] == 'K' for p in st['b'].values()): return 'yetersiz'
    return 'sah' if chk else ''

def dama_new():
    """Türk daması: 8×8, her oyuncu 16 taş (2. ve 3. sıra); beyaz (alt) önce oynar. 'w','b' taş; 'W','B' dama."""
    b = {}
    for c in range(8):
        for r in (5, 6): b[(r, c)] = 'w'
        for r in (1, 2): b[(r, c)] = 'b'
    return dict(b=b, turn='w', last=None)
def _dama_caps(b, sq, piece, came=None):
    """sq'deki taşın alabileceği bütün yollar: [(yol karesi listesi, alınan kareler listesi)]; alınan taş hemen kalkar."""
    col = piece.lower(); king = piece.isupper(); opp = 'b' if col == 'w' else 'w'; r, c = sq; res = []
    dirs = [(0, -1), (0, 1), (-1 if col == 'w' else 1, 0)] if not king else [(1, 0), (-1, 0), (0, 1), (0, -1)]
    for dr, dc in dirs:
        if came is not None and (dr, dc) == (-came[0], -came[1]): continue   # 180 derece dönüş yok
        if not king:
            e = (r + dr, c + dc); t = (r + 2*dr, c + 2*dc)
            if _on(*t) and b.get(e, ' ').lower() == opp and t not in b: lands = [(e, t)]
            else: lands = []
        else:
            rr, cc = r + dr, c + dc
            while _on(rr, cc) and (rr, cc) not in b: rr += dr; cc += dc
            lands = []
            if _on(rr, cc) and b[(rr, cc)].lower() == opp:
                e = (rr, cc); rr += dr; cc += dc
                while _on(rr, cc) and (rr, cc) not in b: lands.append((e, (rr, cc))); rr += dr; cc += dc
        for e, t in lands:
            nb = dict(b); del nb[sq]; del nb[e]; nb[t] = piece
            more = _dama_caps(nb, t, piece, (dr, dc))
            if more: res += [([t] + p_, [e] + c_) for p_, c_ in more]
            else: res.append(([t], [e]))
    return res
def dama_legal(st, col=None):
    """Yasal hamleler: [(başlangıç, yol, alınanlar)]. Alma zorunlu ve en çok taş alan yol seçilmeli."""
    col = col or st['turn']; b = st['b']; caps = []
    for sq, p in b.items():
        if p.lower() != col: continue
        caps += [(sq, path, cp) for path, cp in _dama_caps(b, sq, p)]
    if caps:
        mx = max(len(x[2]) for x in caps); return [x for x in caps if len(x[2]) == mx]
    out = []; fwd = -1 if col == 'w' else 1
    for (r, c), p in b.items():
        if p.lower() != col: continue
        if p.isupper():
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                rr, cc = r + dr, c + dc
                while _on(rr, cc) and (rr, cc) not in b: out.append(((r, c), [(rr, cc)], [])); rr += dr; cc += dc
        else:
            for dr, dc in ((fwd, 0), (0, -1), (0, 1)):
                t = (r + dr, c + dc)
                if _on(*t) and t not in b: out.append(((r, c), [t], []))
    return out
def dama_apply(st, mv):
    sq, path, cp = mv; b = dict(st['b']); p = b.pop(sq)
    for e in cp: b.pop(e, None)
    t = path[-1]
    if p == 'w' and t[0] == 0: p = 'W'
    if p == 'b' and t[0] == 7: p = 'B'
    b[t] = p
    return dict(b=b, turn='b' if st['turn'] == 'w' else 'w', last=(sq, t), path=[sq] + path)

XOX_LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6)]
def xox_winner(cells):
    for a, b_, c in XOX_LINES:
        if cells[a] and cells[a] == cells[b_] == cells[c]: return cells[a], (a, b_, c)
    return (None, None) if any(x is None for x in cells) else ('=', None)

# ---- Mangala (MEB kuralları): 2×6 kuyu, 4'er taş; 6: alttakinin hazinesi, 13: üsttekinin ----
def mangala_new(start='a'):
    return dict(p=[4]*6 + [0] + [4]*6 + [0], turn=start, last=None, bitti=False, start=start)
def mangala_side(turn): return range(0, 6) if turn == 'a' else range(7, 13)
def mangala_store(turn): return 6 if turn == 'a' else 13
def mangala_legal(st):
    if st.get('bitti'): return []
    return [i for i in mangala_side(st['turn']) if st['p'][i] > 0]
def mangala_apply(st, i):
    """Taşlar saatin tersine dağıtılır: ilk taş alınan kuyuya (kuyuda tek taş varsa yan kuyuya geçer); rakibin hazinesi atlanır.
    Son taş kendi hazinene düşerse yine sen oynarsın. Son taş rakip kuyusunu çift yaparsa o kuyudakileri alırsın.
    Son taş kendi boş kuyuna düşer ve karşıdaki kuyu doluysa ikisini de alırsın. Kendi tarafı ilk boşalan, rakibin kuyularındakileri de alır."""
    p = list(st['p']); t = st['turn']; my, op = mangala_store(t), mangala_store('b' if t == 'a' else 'a')
    n = p[i]; p[i] = 0; j = i
    if n == 1: j = (i + 1) % 14; j = (j + 1) % 14 if j == op else j; p[j] += 1
    else:
        p[i] = 1; n -= 1
        while n:
            j = (j + 1) % 14
            if j == op: continue
            p[j] += 1; n -= 1
    nxt = 'b' if t == 'a' else 'a'; note = ''
    if j == my: nxt = t; note = 'Hazineye düştü: yine sen'
    elif j not in mangala_side(t):   # rakip kuyu
        if p[j] % 2 == 0: p[my] += p[j]; note = 'Çift yaptın: %d taş aldın' % p[j]; p[j] = 0
    elif p[j] == 1:   # kendi boş kuyuna son taş
        k = 12 - j
        if p[k]: got = p[k] + 1; p[my] += got; p[j] = 0; p[k] = 0; note = 'Karşıdakileri aldın: %d taş' % got
    bitti = False
    for side_t in (t, 'b' if t == 'a' else 'a'):
        if all(p[x] == 0 for x in mangala_side(side_t)):   # bu tarafın kuyuları boş: o oyuncu rakibinkileri alır
            o = 'b' if side_t == 'a' else 'a'; s_ = sum(p[x] for x in mangala_side(o))
            for x in mangala_side(o): p[x] = 0
            p[mangala_store(side_t)] += s_; bitti = True; break
    return dict(p=p, turn=nxt, last=j, bitti=bitti, start=st.get('start', 'a'), note=note)
def mangala_winner(st):
    if not st.get('bitti'): return None
    a, b = st['p'][6], st['p'][13]
    return 'a' if a > b else ('b' if b > a else '=')

# ---- Tavla: 24 hane; beyaz 24→1 (evi 1–6), siyah 1→24 (evi 19–24). +: beyaz, −: siyah ----
def tavla_new():
    pts = [0]*25
    for i, n in ((24, 2), (13, 5), (8, 3), (6, 5)): pts[i] = n
    for i, n in ((1, 2), (12, 5), (17, 3), (19, 5)): pts[i] = -n
    return dict(pts=pts, bar={'w': 0, 'b': 0}, off={'w': 0, 'b': 0}, turn=None, dice=[], first=None, last=[], bitti=None)
def _sg(c): return 1 if c == 'w' else -1
def tavla_home_all(st, c):
    pts = st['pts']; s = _sg(c)
    if st['bar'][c]: return False
    rng = range(7, 25) if c == 'w' else range(1, 19)
    return not any(pts[i]*s > 0 for i in rng)
def tavla_single(st, c, d):
    """Tek zarla oynanabilecek hamleler: (nereden, nereye); nereden 'bar', nereye 'off' olabilir."""
    pts = st['pts']; s = _sg(c); out = []
    def open_(i): return pts[i]*s >= 0 or abs(pts[i]) == 1
    if st['bar'][c]:
        t = 25 - d if c == 'w' else d
        return [('bar', t)] if open_(t) else []
    home = tavla_home_all(st, c)
    for i in range(1, 25):
        if pts[i]*s <= 0: continue
        t = i - d if c == 'w' else i + d
        if 1 <= t <= 24:
            if open_(t): out.append((i, t))
        elif home:
            exact = (t == 0) if c == 'w' else (t == 25)
            if exact: out.append((i, 'off'))
            else:   # büyük zarla toplama: daha geride taş yoksa
                farther = range(i + 1, 7) if c == 'w' else range(19, i)
                if not any(pts[k]*s > 0 for k in farther): out.append((i, 'off'))
    return out
def tavla_move(st, c, mv):
    pts = list(st['pts']); bar = dict(st['bar']); off = dict(st['off']); s = _sg(c); f, t = mv; hit = False
    if f == 'bar': bar[c] -= 1
    else: pts[f] -= s
    if t == 'off': off[c] += 1
    else:
        if pts[t]*s < 0: pts[t] = 0; bar['b' if c == 'w' else 'w'] += 1; hit = True
        pts[t] += s
    n = dict(st); n.update(pts=pts, bar=bar, off=off); return n, hit
def tavla_seqs(st, c, dice):
    """Kalan zarlarla oynanabilecek bütün hamle dizileri (en uzunları). [(hamle, zar), ...]"""
    best = []
    def rec(s_, ds, acc):
        nonlocal best
        any_ = False
        for k, d in enumerate(ds):
            if d in ds[:k]: continue
            for mv in tavla_single(s_, c, d):
                any_ = True; n, _ = tavla_move(s_, c, mv); rec(n, ds[:k] + ds[k+1:], acc + [(mv, d)])
        if not any_:
            if len(acc) > (len(best[0]) if best else 0): best = [acc]
            elif best and len(acc) == len(best[0]): best.append(acc)
            elif not best: best = [acc]
    rec(st, list(dice), [])
    best = [b for b in best if b]
    if best and len(best[0]) == 1 and len(dice) == 2 and dice[0] != dice[1]:
        big = max(dice); bb = [b for b in best if b[0][1] == big]
        if bb: best = bb
    return best
def tavla_legal(st):
    """Şu an oynanabilecek tek adımlar: {(nereden, nereye): zar}"""
    if not st['turn'] or not st['dice'] or st.get('bitti'): return {}
    out = {}
    for seq in tavla_seqs(st, st['turn'], st['dice']):
        mv, d = seq[0]; out.setdefault(mv, d)
    return out
def tavla_roll(st, rnd):
    n = dict(st)
    if n['turn'] is None:   # başlangıç: herkes bir zar atar, büyük atan başlar ve bu iki zarla oynar
        a, b = rnd.randint(1, 6), rnd.randint(1, 6)
        n['first'] = (a, b)
        if a == b: n['dice'] = []; return n
        n['turn'] = 'w' if a > b else 'b'; n['dice'] = [a, b]; n['rolled'] = (a, b); n['last'] = []; return n
    a, b = rnd.randint(1, 6), rnd.randint(1, 6)
    n['dice'] = [a]*4 if a == b else [a, b]; n['rolled'] = (a, b); n['last'] = []; return n
def tavla_play(st, mv):
    lg = tavla_legal(st); d = lg[mv]; c = st['turn']
    n, hit = tavla_move(st, c, mv); ds = list(st['dice']); ds.remove(d); n['dice'] = ds; n['last'] = list(st.get('last', [])) + [mv]
    if n['off'][c] == 15:
        o = 'b' if c == 'w' else 'w'; n['bitti'] = (c, 2 if n['off'][o] == 0 else 1); n['dice'] = []
    return n, hit
def tavla_end_turn(st):
    n = dict(st); n['turn'] = 'b' if st['turn'] == 'w' else 'w'; n['dice'] = []; n['last'] = []; return n

class GameScreen(QWidget):
    """Tam ekran oyun köşesi: iki öğrenci aynı tahtada oynar (dokun-seç-dokun-götür). Satranç · Dama · Tavla · Mangala · XOX."""
    GAMES = (('satranc', 'Satranç'), ('dama', 'Dama'), ('tavla', 'Tavla'), ('mangala', 'Mangala'), ('xox', 'XOX'))
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setAttribute(Qt.WA_StyledBackground, False)
        self.game = 'satranc'; self.sel = None; self.promo = None; self.msg = ''; self.score = {g: [0, 0, 0] for g, _ in self.GAMES}
        self.tabs = {}
        for key, lab in self.GAMES:
            b = QPushButton(lab, self); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(58); b.clicked.connect(lambda c=False, k_=key: self.pick(k_)); self.tabs[key] = b
        self.new_b = QPushButton('Yeni oyun', self); self.new_b.setFocusPolicy(Qt.NoFocus); self.new_b.setMinimumHeight(58); self.new_b.clicked.connect(self.reset)
        self.close_b = QPushButton('Kapat', self); self.close_b.setFocusPolicy(Qt.NoFocus); self.close_b.setMinimumHeight(58); self.close_b.clicked.connect(main.close_games)
        for b in (self.new_b, self.close_b):
            b.setStyleSheet('QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:14px;padding:0 26px;font-size:22px;font-weight:700;}QPushButton:pressed{background:#2a4468;}')
        self.states = {}; self.reset_all(); self.pick('satranc')
    def reset_all(self):
        import random; self.rnd = random.Random()
        self.states = {'satranc': chess_new(), 'dama': dama_new(), 'xox': dict(cells=[None]*9, turn='X', start='X'), 'mangala': mangala_new('a'), 'tavla': tavla_new()}
    def reset(self):
        if self.game == 'satranc': self.states['satranc'] = chess_new()
        elif self.game == 'dama': self.states['dama'] = dama_new()
        elif self.game == 'mangala': self.states['mangala'] = mangala_new('b' if self.states['mangala'].get('start') == 'a' else 'a')   # sırayla başlar
        elif self.game == 'tavla': self.states['tavla'] = tavla_new()
        else:
            s0 = 'O' if self.states['xox'].get('start') == 'X' else 'X'   # sırayla başlar
            self.states['xox'] = dict(cells=[None]*9, turn=s0, start=s0)
        self.sel = None; self.promo = None; self.msg = ''; self.update()
    def pick(self, key):
        self.game = key; self.sel = None; self.promo = None
        for k_, b in self.tabs.items():
            on = k_ == key
            b.setStyleSheet('QPushButton{background:%s;color:%s;border:%s;border-radius:14px;padding:0 30px;font-size:24px;font-weight:800;}'
                            % (('rgba(8,14,30,0.92)', '#7ff6ff', '3px solid #22e8ff') if on else ('#13233a', '#c9d6ea', '1px solid #24364f')))
        self.update()
    def fit(self, rect): self.setGeometry(rect); self.layout_btns()
    def resizeEvent(self, e): self.layout_btns()
    def layout_btns(self):
        x = 30
        for k_, _ in self.GAMES:
            b = self.tabs[k_]; b.adjustSize(); b.move(x, 20); x += b.width() + 12
        self.close_b.adjustSize(); self.close_b.move(self.width() - self.close_b.width() - 30, 20)
        self.new_b.adjustSize(); self.new_b.move(self.close_b.x() - self.new_b.width() - 14, 20)
    # ---- geometri ----
    def board_rect(self):
        W, H = self.width(), self.height(); top = 100; side = 330
        if self.game in ('tavla', 'mangala'):   # geniş tahtalar
            aw, ah = W - 2*side - 40, H - top - 30; ar = 15/11 if self.game == 'tavla' else 8/3.2
            w = min(aw, ah*ar); h = w/ar; cell = w/(15 if self.game == 'tavla' else 8)
            return QRectF((W - w)/2, top + (H - top - h)/2, w, h), cell, 0
        n = 3 if self.game == 'xox' else 8
        s = min(W - 2*side - 40, H - top - 30); s = max(240, s); cell = s/n
        return QRectF((W - s)/2, top + (H - top - s)/2, s, s), cell, n
    def cell_at(self, pos):
        R, cell, n = self.board_rect(); x, y = pos.x() - R.x(), pos.y() - R.y()
        if 0 <= x < R.width() and 0 <= y < R.height(): return int(y//cell), int(x//cell)
        return None
    # ---- dokunma ----
    def mousePressEvent(self, e):
        pos = QPointF(e.pos())
        if self.promo is not None:   # piyon terfisi seçimi
            for k_, r in self.promo_rects():
                if r.contains(pos):
                    st = self.states['satranc']; self.states['satranc'] = chess_apply(st, self.promo, k_); self.promo = None; self.after_move(); return
            return
        g = self.game
        if g == 'mangala': self.tap_mangala(pos); return
        if g == 'tavla': self.tap_tavla(pos); return
        sq = self.cell_at(pos)
        if sq is None: return
        if g == 'xox':
            st = self.states['xox']; i = sq[0]*3 + sq[1]
            if st['cells'][i] is None and xox_winner(st['cells'])[0] is None:
                st['cells'][i] = st['turn']; st['turn'] = 'O' if st['turn'] == 'X' else 'X'; self.after_move()
            return
        st = self.states[g]
        if g == 'satranc':
            legal = chess_legal(st)
            if chess_status(st) in ('mat', 'pat', 'yetersiz'): return
            if self.sel is not None and (self.sel, sq) in legal:
                p = st['b'][self.sel]
                if p[1] == 'P' and sq[0] in (0, 7): self.promo = (self.sel, sq); self.sel = None; self.update(); return
                self.states['satranc'] = chess_apply(st, (self.sel, sq)); self.sel = None; self.after_move(); return
            p = st['b'].get(sq)
            self.sel = sq if p and p[0] == st['turn'] and any(m[0] == sq for m in legal) else None; self.update()
        else:
            legal = dama_legal(st)
            if not legal: return
            if self.sel is not None:
                mv = next((m for m in legal if m[0] == self.sel and m[1][-1] == sq), None)
                if mv: self.states['dama'] = dama_apply(st, mv); self.sel = None; self.after_move(); return
            p = st['b'].get(sq)
            if p and p.lower() == st['turn'] and any(m[0] == sq for m in legal): self.sel = sq
            elif p and p.lower() == st['turn'] and legal and legal[0][2]: self.sel = None; self.msg = 'Alma zorunlu: en çok taş alan hamle'
            else: self.sel = None
            self.update()
    # ---- mangala ----
    def mangala_rects(self):
        R, cell, _ = self.board_rect(); out = {}; py = R.height()*.08; ph = (R.height() - 3*py)/2
        for i in range(6):
            out[i] = QRectF(R.x() + (1 + i)*cell + cell*.08, R.y() + 2*py + ph, cell*.84, ph)          # alt oyuncu: soldan sağa
            out[7 + i] = QRectF(R.x() + (6 - i)*cell + cell*.08, R.y() + py, cell*.84, ph)            # üst oyuncu: sağdan sola
        out[6] = QRectF(R.right() - cell + cell*.1, R.y() + py, cell*.8, R.height() - 2*py)          # alt oyuncunun hazinesi (sağda)
        out[13] = QRectF(R.x() + cell*.1, R.y() + py, cell*.8, R.height() - 2*py)                    # üst oyuncunun hazinesi (solda)
        return out
    def tap_mangala(self, pos):
        st = self.states['mangala']
        for i, r in self.mangala_rects().items():
            if r.contains(pos) and i in mangala_legal(st):
                self.states['mangala'] = mangala_apply(st, i); self.after_move(); self.msg = self.states['mangala'].get('note', ''); self.update(); return
    # ---- tavla ----
    def tavla_geom(self):
        R, c, _ = self.board_rect(); x0 = R.x() + c*.5; ih = R.height() - c; hh = ih*.43
        def col_x(col): return x0 + col*c
        pts = {}
        for k in range(6):
            pts[13 + k] = QRectF(col_x(k), R.y() + c*.5, c, hh); pts[19 + k] = QRectF(col_x(7 + k), R.y() + c*.5, c, hh)
            pts[12 - k] = QRectF(col_x(k), R.bottom() - c*.5 - hh, c, hh); pts[6 - k] = QRectF(col_x(7 + k), R.bottom() - c*.5 - hh, c, hh)
        bar = QRectF(col_x(6), R.y() + c*.5, c, ih); tray = QRectF(col_x(13) + c*.1, R.y() + c*.5, c*.8, ih)
        mid = QRectF(col_x(7), R.y() + c*.5 + hh, 6*c, ih - 2*hh)   # zarlar: sağ yarının ortası
        return R, c, pts, bar, tray, mid
    def tavla_hit(self, pos):
        """Dokunulan hane: üçgenin kendisi değil, kenardan ortaya kadar bütün sütun (taş yığını ortaya taşabilir)."""
        R, c, pts, bar, tray, mid = self.tavla_geom(); my = R.center().y()
        if bar.contains(pos): return 'bar'
        if tray.contains(pos): return 'off'
        for i, r in pts.items():
            col = QRectF(r.x(), R.y() + c*.5, r.width(), my - R.y() - c*.5) if i >= 13 else QRectF(r.x(), my, r.width(), R.bottom() - c*.5 - my)
            if col.contains(pos): return i
        return None
    def tap_fx(self, pos):
        """Dokunma efekti: dokunulan yerde kısa bir neon halka."""
        self.fx = (QPointF(pos), time.monotonic())
        if not hasattr(self, 'fx_timer'):
            self.fx_timer = QTimer(self); self.fx_timer.setInterval(30); self.fx_timer.timeout.connect(self.fx_tick)
        self.fx_timer.start()
    def fx_tick(self):
        busy = (time.monotonic() - getattr(self, 'fx', (None, -9))[1] < .45) or (time.monotonic() - getattr(self, 'roll_t0', -9) < TAVLA_ZAR_SURE)
        if not busy: self.fx_timer.stop()
        self.update()
    def tap_tavla(self, pos):
        st = self.states['tavla']
        if st.get('bitti'): return
        R, c, pts, bar, tray, mid = self.tavla_geom()
        if not R.contains(pos): return
        self.tap_fx(pos)
        if not st['dice']:   # zar at: zarlar kısa bir süre döner, sonra durur
            acilis = st['turn'] is None; st = tavla_roll(st, self.rnd); self.sel = None; self.roll_t0 = time.monotonic()
            if st['turn'] is None: self.msg = 'Zarlar eşit (%d–%d): yeniden atın' % st['first']; self.states['tavla'] = st; self.update(); return
            self.msg = ('%s başlıyor (%d–%d)' % ('Beyaz' if st['turn'] == 'w' else 'Siyah', max(st['first']), min(st['first']))) if acilis else ''
            if not tavla_legal(st): self.msg = 'Oynanacak hamle yok, sıra geçti'; st = tavla_end_turn(st)
            self.states['tavla'] = st; self.update(); return
        if time.monotonic() - getattr(self, 'roll_t0', -9) < TAVLA_ZAR_SURE: return   # zarlar dönerken
        lg = tavla_legal(st); hit = self.tavla_hit(pos)
        if hit is None: return
        if self.sel is not None and (self.sel, hit) in lg:
            st, _ = tavla_play(st, (self.sel, hit)); self.sel = None; self.msg = ''
            if st.get('bitti'): self.states['tavla'] = st; self.after_move(); return
            if not tavla_legal(st):
                if st['dice']: self.msg = 'Kalan zar oynanamıyor'
                st = tavla_end_turn(st)
            self.states['tavla'] = st; self.update(); return
        self.sel = hit if any(m[0] == hit for m in lg) else None; self.update()
    def after_move(self):
        self.msg = ''; g = self.game
        if g == 'mangala':
            w = mangala_winner(self.states['mangala'])
            if w: self.score['mangala'][{'a': 0, 'b': 1, '=': 2}[w]] += 1
            self.update(); return
        if g == 'tavla':
            b_ = self.states['tavla'].get('bitti')
            if b_: self.score['tavla'][0 if b_[0] == 'w' else 1] += b_[1]
            self.update(); return
        if g == 'satranc':
            s_ = chess_status(self.states['satranc'])
            if s_ == 'mat': self.score['satranc'][0 if self.states['satranc']['turn'] == 'b' else 1] += 1
            elif s_ in ('pat', 'yetersiz'): self.score['satranc'][2] += 1
        elif g == 'dama':
            if not dama_legal(self.states['dama']): self.score['dama'][0 if self.states['dama']['turn'] == 'b' else 1] += 1
        else:
            w, _ = xox_winner(self.states['xox']['cells'])
            if w == 'X': self.score['xox'][0] += 1
            elif w == 'O': self.score['xox'][1] += 1
            elif w == '=': self.score['xox'][2] += 1
        self.update()
    def promo_rects(self):
        R, cell, n = self.board_rect(); w = cell*1.1; x0 = R.center().x() - 2*w - 15; y = R.center().y() - w/2
        return [(k_, QRectF(x0 + i*(w + 10), y, w, w)) for i, k_ in enumerate('QRBN')]
    # ---- çizim ----
    def info(self):
        """(sıra yazısı, renk, durum yazısı, bitti mi)"""
        g = self.game
        if g == 'mangala':
            st = self.states['mangala']; w = mangala_winner(st); nm = {'a': 'Alt', 'b': 'Üst'}
            if w == '=': return ('Berabere', '#c9d6ea', '%d – %d' % (st['p'][6], st['p'][13]), True)
            if w: return ('%s kazandı!' % nm[w], '#ffe14d', '%d – %d taş' % (max(st['p'][6], st['p'][13]), min(st['p'][6], st['p'][13])), True)
            return ('Sıra: %s' % nm[st['turn']], '#7ff6ff' if st['turn'] == 'a' else '#ff8fa3', 'Kendi kuyuna dokun', False)
        if g == 'tavla':
            st = self.states['tavla']; nm = {'w': 'Beyaz', 'b': 'Siyah'}
            if st.get('bitti'): return ('%s kazandı!' % nm[st['bitti'][0]], '#ffe14d', 'Mars! 2 puan' if st['bitti'][1] == 2 else '1 puan', True)
            if st['turn'] is None: return ('Tavla', '#ffffff', 'Kim başlar?', False)
            if not st['dice']: return ('Sıra: %s' % nm[st['turn']], '#ffffff', 'Zar at', False)
            return ('Sıra: %s' % nm[st['turn']], '#ffffff', 'Zar: ' + ' · '.join(str(d) for d in st['dice']), False)
        if g == 'xox':
            st = self.states['xox']; w, _ = xox_winner(st['cells'])
            if w == '=': return ('Berabere', '#c9d6ea', 'Yeni oyun ile tekrar', True)
            if w: return ('%s kazandı!' % w, '#ffe14d', 'Tebrikler', True)
            return ('Sıra: %s' % st['turn'], '#7ff6ff' if st['turn'] == 'X' else '#ff8fa3', '', False)
        st = self.states[g]; who = 'Beyaz' if st['turn'] == 'w' else 'Siyah'; oth = 'Siyah' if st['turn'] == 'w' else 'Beyaz'
        if g == 'satranc':
            s_ = chess_status(st)
            if s_ == 'mat': return ('Mat!', '#ffe14d', '%s kazandı' % oth, True)
            if s_ == 'pat': return ('Pat', '#c9d6ea', 'Berabere', True)
            if s_ == 'yetersiz': return ('Berabere', '#c9d6ea', 'Yalnız şahlar kaldı', True)
            return ('Sıra: %s' % who, '#ffffff', 'Şah!' if s_ == 'sah' else '', False)
        if not dama_legal(st): return ('%s kazandı!' % oth, '#ffe14d', '%s oynayamıyor' % who, True)
        lg = dama_legal(st); return ('Sıra: %s' % who, '#ffffff', ('Alma zorunlu (%d taş)' % len(lg[0][2])) if lg and lg[0][2] else '', False)
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height()
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px))); return f
        p.fillRect(QRectF(0, 0, W, H), QColor('#0d1726'))
        draw_game(p, W, H, font, self)
        p.end()

def draw_mangala(p, g, font, text):
    R, cell, _ = g.board_rect(); st = g.states['mangala']; rects = g.mangala_rects(); lg = set(mangala_legal(st))
    p.setPen(QPen(QColor('#3b2410'), 4)); p.setBrush(QColor('#8a5a2b')); p.drawRoundedRect(R, cell*.45, cell*.45)   # ahşap
    p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 18)); p.drawRoundedRect(R.adjusted(8, 8, -8, -R.height()*.55), cell*.4, cell*.4)
    import math
    for i, r in rects.items():
        store = i in (6, 13); mine = (i in range(0, 7)) == (st['turn'] == 'a')
        p.setPen(QPen(QColor('#3b2410'), 3)); p.setBrush(QColor('#5e3a17')); p.drawRoundedRect(r, r.width()*.45, r.width()*.45)
        if i == st.get('last'): p.setPen(QPen(QColor('#ffe14d'), 5)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, r.width()*.45, r.width()*.45)
        elif i in lg and not st.get('bitti'): p.setPen(QPen(QColor('#22e8ff'), 4)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r.adjusted(3, 3, -3, -3), r.width()*.42, r.width()*.42)
        n = st['p'][i]; rad = cell*.085; cx, cy = r.center().x(), r.center().y() + (0 if store else -r.height()*.06)
        for k in range(min(n, 40 if store else 16)):   # taşlar: altın oranlı sarmal, sayıyla birlikte
            a_ = k*2.39996; rr = rad*1.75*math.sqrt(k + .35)
            x, y = cx + rr*math.cos(a_), cy + rr*math.sin(a_)*(1.6 if store else 1)
            p.setPen(Qt.NoPen); col = ('#7ff6ff', '#ff8fa3', '#ffe14d', '#c9d6ea')[k % 4]; p.setBrush(QColor(col)); p.drawEllipse(QRectF(x - rad, y - rad, 2*rad, 2*rad))
        lab = QRectF(r.x(), r.bottom() - cell*.34, r.width(), cell*.3) if not store else QRectF(r.x(), r.bottom() - cell*.5, r.width(), cell*.42)
        text(lab, str(n), font(cell*(.3 if store else .22), True), '#ffffff')
    # oyuncu adları: sol üst köşe yerine tahtanın üst/alt kenarında
    text(QRectF(R.x(), R.y() - 34, R.width(), 30), 'Üst oyuncu · hazinesi solda', font(19, True), '#ff8fa3')
    text(QRectF(R.x(), R.bottom() + 4, R.width(), 30), 'Alt oyuncu · hazinesi sağda', font(19, True), '#7ff6ff')

TAVLA_ZAR_SURE = 0.7   # sn: zar atılınca zarların dönme süresi
TAVLA_NEON = '#ff3b4e'   # seçilen pul ve gidebileceği yerler: kırmızı neon halka
def draw_tavla(p, g, font, text):
    R, c, pts, bar, tray, mid = g.tavla_geom(); st = g.states['tavla']; lg = tavla_legal(st)
    p.setPen(Qt.NoPen); p.setBrush(QColor('#5a3b1e')); p.drawRoundedRect(R, c*.35, c*.35)
    for half in (QRectF(R.x() + c*.5, R.y() + c*.5, 6*c, R.height() - c), QRectF(R.x() + 7.5*c, R.y() + c*.5, 6*c, R.height() - c)):
        p.setBrush(QColor('#e9dcc0')); p.drawRect(half)
    p.setBrush(QColor('#4a2f17')); p.drawRect(bar); p.setBrush(QColor('#3e2713')); p.drawRoundedRect(tray, c*.2, c*.2)
    targets = [m[1] for m in lg if m[0] == g.sel] if g.sel is not None else []
    for i, r in pts.items():
        top = i >= 13; col = QColor('#6d8fb3' if i % 2 else '#b5452f')
        tri = QPolygonF([QPointF(r.x() + c*.06, r.top() if top else r.bottom()), QPointF(r.right() - c*.06, r.top() if top else r.bottom()), QPointF(r.center().x(), r.bottom() if top else r.top())])
        p.setPen(Qt.NoPen); p.setBrush(col); p.drawPolygon(tri)
        num = QRectF(r.x(), (r.top() - c*.5) if top else r.bottom(), c, c*.5); text(num, str(i), font(c*.24, True), '#e9dcc0')
    def neon_ring(e):   # pul boyunda kırmızı neon halka
        for w_, a_ in ((12, 40), (7, 90), (3.5, 255)):
            q = QColor(TAVLA_NEON); q.setAlpha(a_); p.setPen(QPen(q, w_)); p.setBrush(Qt.NoBrush); p.drawEllipse(e)
    def slot(i):   # bir haneye yeni gelecek pulun yeri
        r = pts[i]; v = abs(st['pts'][i]) if (st['pts'][i] > 0) == (st['turn'] == 'w') else 0; k = min(v, 4); rad = c*.45
        y = (r.top() + rad + k*2*rad) if i >= 13 else (r.bottom() - rad - k*2*rad)
        return QRectF(r.center().x() - rad, y - rad, 2*rad, 2*rad)
    def checkers(x, y0, dy, n, color, sel=False):
        rad = c*.45
        for k in range(min(n, 5)):
            y = y0 + dy*(k*2*rad + rad); e = QRectF(x - rad, y - rad, 2*rad, 2*rad)
            p.setPen(QPen(QColor('#1a1a1a' if color == 'w' else '#d8d8d8'), 2)); p.setBrush(QColor('#f4efe6' if color == 'w' else '#262626')); p.drawEllipse(e)
            p.setPen(QPen(QColor('#b9b2a4' if color == 'w' else '#555555'), 1.5)); p.setBrush(Qt.NoBrush); p.drawEllipse(e.adjusted(rad*.35, rad*.35, -rad*.35, -rad*.35))
            if sel and k == min(n, 5) - 1: neon_ring(e)
            if k == 4 and n > 5: text(e, str(n), font(c*.32, True), '#1a1a1a' if color == 'w' else '#ffffff')
    for i, r in pts.items():
        v = st['pts'][i]
        if v: checkers(r.center().x(), r.top() if i >= 13 else r.bottom(), 1 if i >= 13 else -1, abs(v), 'w' if v > 0 else 'b', g.sel == i)
    if st['bar']['b']: checkers(bar.center().x(), bar.top() + c*.2, 1, st['bar']['b'], 'b', g.sel == 'bar' and st['turn'] == 'b')
    if st['bar']['w']: checkers(bar.center().x(), bar.bottom() - c*.2, -1, st['bar']['w'], 'w', g.sel == 'bar' and st['turn'] == 'w')
    for colr, y0, dy in (('b', tray.top() + 6, 1), ('w', tray.bottom() - 6, -1)):   # toplananlar: ince dilimler
        for k in range(st['off'][colr]):
            y = y0 + dy*(k*c*.17); p.setPen(Qt.NoPen); p.setBrush(QColor('#f4efe6' if colr == 'w' else '#262626')); p.drawRoundedRect(QRectF(tray.x() + 4, min(y, y + dy*c*.14), tray.width() - 8, c*.14), 3, 3)
    for t_ in targets:   # gidebileceği yerler: pul boyunda kırmızı neon
        if t_ == 'off':
            for w_, a_ in ((12, 40), (7, 90), (3.5, 255)):
                q = QColor(TAVLA_NEON); q.setAlpha(a_); p.setPen(QPen(q, w_)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(tray, c*.2, c*.2)
        else: neon_ring(slot(t_))
    # zarlar
    def die(r, v, dim=False):
        p.setPen(QPen(QColor('#1a1a1a'), 2)); p.setBrush(QColor('#fffdf5' if not dim else '#a9a59a')); p.drawRoundedRect(r, r.width()*.18, r.width()*.18)
        pip = {1: [(1, 1)], 2: [(0, 0), (2, 2)], 3: [(0, 0), (1, 1), (2, 2)], 4: [(0, 0), (0, 2), (2, 0), (2, 2)], 5: [(0, 0), (0, 2), (1, 1), (2, 0), (2, 2)], 6: [(0, 0), (0, 2), (1, 0), (1, 2), (2, 0), (2, 2)]}[v]
        p.setPen(Qt.NoPen); p.setBrush(QColor('#1a1a1a')); q = r.width()/4; pr = r.width()*.09
        for a_, b_ in pip: p.drawEllipse(QPointF(r.x() + q*(b_ + 1), r.y() + q*(a_ + 1)), pr, pr)
    ds = c*.9
    if st['turn'] is None and st.get('first'):
        a_, b_ = st['first']
        for k_, (v, lab) in enumerate(((a_, 'Beyaz'), (b_, 'Siyah'))):
            r_ = QRectF(mid.center().x() - ds*1.6 + k_*ds*2.2, mid.center().y() - ds/2, ds, ds); die(r_, v); text(QRectF(r_.x() - c*.3, r_.bottom() + 2, ds + c*.6, c*.35), lab, font(c*.22, True), '#e9dcc0')
    rolling = time.monotonic() - getattr(g, 'roll_t0', -9) < TAVLA_ZAR_SURE
    if rolling:   # zarlar dönüyor
        import random as _r
        for k_ in range(2):
            r_ = QRectF(mid.center().x() - ds*1.2 + k_*ds*1.4 + _r.uniform(-6, 6), mid.center().y() - ds/2 + _r.uniform(-8, 8), ds, ds); die(r_, _r.randint(1, 6))
    elif st['turn'] is None and st.get('first'): pass
    elif st['dice']:
        vals = st['dice']; full = list(st.get('rolled') or vals[:2]); shown = full if len(set(full)) == 2 else [full[0]]*4
        rem = list(vals); xs = mid.center().x() - (len(shown)*ds*1.15)/2
        for k_, v in enumerate(shown):
            used = v not in rem
            if not used: rem.remove(v)
            die(QRectF(xs + k_*ds*1.15, mid.center().y() - ds/2, ds, ds), v, used)
    elif not st.get('bitti'):   # zar atma çağrısı: ortada neon yazı (yarım tahtaya sığar)
        f_ = font(c*.34, True); lab = 'Zar atmak için dokun'
        fm = QFontMetrics(f_); tw = fm.horizontalAdvance(lab) + c*.6; pill = QRectF(mid.center().x() - tw/2, mid.center().y() - c*.36, tw, c*.72)
        draw_neon(p, pill, lab, f_, '#22e8ff', c/80)
    fx = getattr(g, 'fx', None)
    if fx and time.monotonic() - fx[1] < .45:   # dokunma efekti
        a_ = (time.monotonic() - fx[1])/.45; rr = c*(.3 + .9*a_); q = QColor('#22e8ff'); q.setAlpha(int(200*(1 - a_)))
        p.setPen(QPen(q, 4)); p.setBrush(Qt.NoBrush); p.drawEllipse(fx[0], rr, rr)

def draw_game(p, W, H, font, g):
    """Oyun ekranını çizer (Qt ile ya da testte sahte çizici ile)."""
    def text(r, s_, f, c, al=Qt.AlignCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    R, cell, n = g.board_rect(); game = g.game
    turn_t, turn_c, sub, done = g.info()
    # yan paneller: solda sıra ve durum, sağda skor
    L = QRectF(30, R.y(), R.x() - 60, 260); p.setPen(Qt.NoPen); p.setBrush(QColor('#13233a')); p.drawRoundedRect(L, 20, 20)
    text(QRectF(L.x(), L.y() + 20, L.width(), 70), turn_t, font(40, True), turn_c)
    if sub: text(QRectF(L.x() + 10, L.y() + 100, L.width() - 20, 60), sub, font(26, True), '#ff5d6c' if sub == 'Şah!' else '#ffb020')
    if g.msg and not done: text(QRectF(L.x() + 10, L.y() + 170, L.width() - 20, 70), g.msg, font(18), '#ffd78a', Qt.AlignCenter | Qt.TextWordWrap)
    sc = g.score[game]; names = ('X', 'O') if game == 'xox' else (('Alt', 'Üst') if game == 'mangala' else ('Beyaz', 'Siyah'))
    S = QRectF(R.right() + 30, R.y(), W - R.right() - 60, 260); p.setPen(Qt.NoPen); p.setBrush(QColor('#13233a')); p.drawRoundedRect(S, 20, 20)
    text(QRectF(S.x(), S.y() + 16, S.width(), 40), 'Skor', font(22, True), '#9fb3cc')
    for i, (nm, v) in enumerate(zip(names + ('Berabere',), sc)):
        y = S.y() + 66 + i*62
        text(QRectF(S.x() + 24, y, S.width() - 48, 54), nm, font(26, True), '#ffffff', Qt.AlignLeft | Qt.AlignVCenter)
        text(QRectF(S.x() + 24, y, S.width() - 48, 54), str(v), font(34, True), '#ffe14d', Qt.AlignRight | Qt.AlignVCenter)
    # tahta
    if game == 'mangala': draw_mangala(p, g, font, text); return
    if game == 'tavla': draw_tavla(p, g, font, text); return
    if game == 'xox':
        st = g.states['xox']; w, line = xox_winner(st['cells'])
        p.setPen(Qt.NoPen); p.setBrush(QColor('#13233a')); p.drawRoundedRect(R.adjusted(-14, -14, 14, 14), 24, 24)
        p.setPen(QPen(QColor('#2f6fd6'), 6))
        for i in (1, 2):
            p.drawLine(QPointF(R.x() + i*cell, R.y() + 20), QPointF(R.x() + i*cell, R.bottom() - 20)); p.drawLine(QPointF(R.x() + 20, R.y() + i*cell), QPointF(R.right() - 20, R.y() + i*cell))
        for i, v in enumerate(st['cells']):
            if not v: continue
            r, c = divmod(i, 3); cr = QRectF(R.x() + c*cell, R.y() + r*cell, cell, cell); col = '#22e8ff' if v == 'X' else '#ff8fa3'
            win = line and i in line; f = font(cell*.62, True)
            if win:
                p.setPen(Qt.NoPen); q = QColor(col); q.setAlpha(50); p.setBrush(q); p.drawRoundedRect(cr.adjusted(14, 14, -14, -14), 20, 20)
            text(cr, v, f, col)
        return
    st = g.states[game]; b = st['b']
    for r in range(8):
        for c in range(8):
            sq = QRectF(R.x() + c*cell, R.y() + r*cell, cell, cell)
            if game == 'satranc': col = '#e9dcc0' if (r + c) % 2 == 0 else '#6d8fb3'
            else: col = '#e9dcc0' if (r + c) % 2 == 0 else '#d8c59f'   # Türk daması: bütün kareler kullanılır
            p.setPen(Qt.NoPen); p.setBrush(QColor(col)); p.drawRect(sq)
    if game == 'dama':
        p.setPen(QPen(QColor(120, 90, 50, 120), 1.5))
        for i in range(9): p.drawLine(QPointF(R.x() + i*cell, R.y()), QPointF(R.x() + i*cell, R.bottom())); p.drawLine(QPointF(R.x(), R.y() + i*cell), QPointF(R.right(), R.y() + i*cell))
    last = st.get('last')
    if last:
        for sq_ in last:
            p.setPen(Qt.NoPen); p.setBrush(QColor(255, 225, 77, 90)); p.drawRect(QRectF(R.x() + sq_[1]*cell, R.y() + sq_[0]*cell, cell, cell))
    targets = []
    if g.sel is not None:
        p.setPen(Qt.NoPen); p.setBrush(QColor(34, 232, 255, 110)); p.drawRect(QRectF(R.x() + g.sel[1]*cell, R.y() + g.sel[0]*cell, cell, cell))
        if game == 'satranc': targets = [m[1] for m in chess_legal(st) if m[0] == g.sel]
        else: targets = [m[1][-1] for m in dama_legal(st) if m[0] == g.sel]
    if game == 'satranc':
        stt = chess_status(st)
        if stt in ('sah', 'mat'):
            k = chess_king(b, st['turn'])
            if k: p.setPen(Qt.NoPen); p.setBrush(QColor(229, 50, 63, 150)); p.drawRect(QRectF(R.x() + k[1]*cell, R.y() + k[0]*cell, cell, cell))
        for (r, c), pc in b.items():
            cr = QRectF(R.x() + c*cell, R.y() + r*cell, cell, cell); f = font(cell*.78); f.setFamily('DejaVu Sans')   # satranç taşları (Poppins'te yok)
            fill, edge = ('#ffffff', '#1a1a1a') if pc[0] == 'w' else ('#1a1a1a', '#f0f0f0')
            for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (-1.5, -1.5), (1.5, 1.5), (-1.5, 1.5), (1.5, -1.5)): text(cr.translated(dx, dy + cell*.02), CHESS_GLYPH[pc[1]], f, edge)
            text(cr.translated(0, cell*.02), CHESS_GLYPH[pc[1]], f, fill)
    else:
        for (r, c), pc in b.items():
            cr = QRectF(R.x() + c*cell, R.y() + r*cell, cell, cell).adjusted(cell*.12, cell*.12, -cell*.12, -cell*.12)
            fill, edge = ('#fbfbf7', '#8a8a80') if pc.lower() == 'w' else ('#2b2b2b', '#000000')
            p.setPen(QPen(QColor(edge), 3)); p.setBrush(QColor(fill)); p.drawEllipse(cr)
            p.setPen(QPen(QColor('#b0b0a8' if pc.lower() == 'w' else '#555555'), 2)); p.setBrush(Qt.NoBrush); p.drawEllipse(cr.adjusted(cell*.12, cell*.12, -cell*.12, -cell*.12))
            if pc.isupper(): fk = font(cell*.42); fk.setFamily('DejaVu Sans'); text(cr, '♛', fk, '#d4a017')   # dama (kral)
    for t in targets:   # gidilebilecek kareler
        cr = QRectF(R.x() + t[1]*cell, R.y() + t[0]*cell, cell, cell); occ = t in b
        p.setPen(QPen(QColor(34, 232, 255, 220), 5) if occ else Qt.NoPen); p.setBrush(Qt.NoBrush if occ else QColor(34, 232, 255, 170))
        if occ: p.drawRoundedRect(cr.adjusted(5, 5, -5, -5), 10, 10)
        else: p.drawEllipse(QRectF(cr.center().x() - cell*.15, cr.center().y() - cell*.15, cell*.3, cell*.3))
    if g.promo is not None:
        p.setPen(Qt.NoPen); p.setBrush(QColor(5, 9, 18, 200)); p.drawRect(R)
        col = st['b'][g.promo[0]][0]
        for k_, r_ in g.promo_rects():
            p.setPen(QPen(QColor('#22e8ff'), 3)); p.setBrush(QColor('#13233a')); p.drawRoundedRect(r_, 14, 14)
            fill = '#ffffff' if col == 'w' else '#1a1a1a'; f = font(r_.width()*.7); f.setFamily('DejaVu Sans')
            if col != 'w':
                for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)): text(r_.translated(dx, dy), CHESS_GLYPH[k_], f, '#f0f0f0')
            text(r_, CHESS_GLYPH[k_], f, fill)
        text(QRectF(R.x(), g.promo_rects()[0][1].y() - 70, R.width(), 50), 'Piyon ne olsun?', font(28, True), '#ffffff')

# ---------------- Anket modu (sınıf tahtasından öğrenci anketi; sonuçlar Drive'a sınıf sınıf rapor) ----------------
# Anket tanımı kelebek paketinde gelir (plan.bin → 'anketler'): yalnız listelenen sınıfların tahtasında görünür.
# {id, ad, baslangic, bitis, isimli, sorular:[{tur: puan|begeni|secim|yazi, metin, secenekler, coklu, zorunlu}],
#  siniflar:{'12-A': [{no, ad, katilir}]}}
ANKET_BEGENI = ('Beğendim', 'Beğenmedim')
def anket_for_board(defs, sinif, today_iso, kontrol=None):
    """Bu tahtada açık anketler (tarih aralığında ya da Öğretmenler odasından açılmış, kapatılmamış; bu sınıf listede)."""
    out = []
    for a in defs or []:
        if not isinstance(a, dict) or not a.get('id') or not a.get('sorular'): continue
        if not anket_durum_acik(a, (kontrol or {}).get(a['id']), today_iso): continue
        if sinif in (a.get('siniflar') or {}): out.append(a)
    return out
def anket_roster(a, sinif):
    """[(no, ad, katılabilir mi)] — katılımcı listesinde olmayanlar katılamaz."""
    return [(str(r.get('no', '')), tr_name(r.get('ad', '')), r.get('katilir', True) is not False) for r in (a.get('siniflar') or {}).get(sinif, [])
            if str(r.get('no', '')) not in AYRILAN]
def anket_missing(a, ans):
    """Cevaplanmamış zorunlu soruların numaraları (1'den)."""
    miss = []
    for i, q in enumerate(a.get('sorular', [])):
        v = ans[i] if i < len(ans) else None; req = q.get('zorunlu', q.get('tur') != 'yazi')
        ks = q.get('kosul')   # {'soru': 1'den numara, 'deger': 'Evet'}: yalnız o cevap verildiyse sorulur/zorunlu
        if ks:
            j = int(ks.get('soru', 0)) - 1; kv = ans[j] if 0 <= j < len(ans) else None
            if kv != ks.get('deger') and not (isinstance(kv, list) and ks.get('deger') in kv): req = False
        empty = v in (None, '', []) or (isinstance(v, str) and not v.strip()) or anket_diger_bos(v)
        if q.get('tur') == 'sira' and isinstance(v, list):
            need = min(int(q.get('ilk') or len(q.get('secenekler') or [])), len(q.get('secenekler') or []))
            if len(v) < need: empty = True
        if req and empty: miss.append(i + 1)
    return miss
ANKET_DIGER = 'Diğer'
def anket_diger_bos(v):
    """'Diğer' seçilmiş ama yazılmamış."""
    if isinstance(v, list): return any(anket_diger_bos(x) for x in v)
    return isinstance(v, str) and v.strip().rstrip(':').strip() == ANKET_DIGER
def anket_secenek_adi(x):
    """'Diğer: robot yapımı' → 'Diğer' (sayımda)."""
    return ANKET_DIGER if isinstance(x, str) and x.startswith(ANKET_DIGER + ':') else x
def anket_ders_uygun(a, now):
    """Tanımda 'dersler' [1, 5] varsa anket yalnız o derslerde ve ardından gelen teneffüste açık."""
    dl = a.get('dersler')
    if not dl: return True
    try: dl = {int(x) for x in dl}
    except (TypeError, ValueError): return True
    t = now.hour*3600 + now.minute*60 + now.second; last = None
    for name, s_, e_, kind in bell_periods(now.weekday()):
        n = None
        if kind == 'lesson':
            try: n = int(str(name).split('.')[0])
            except ValueError: n = None
        if s_ <= t < e_: return (n in dl) if kind == 'lesson' else (last in dl)
        if n is not None: last = n
    return False
def anket_tamam(a, sinif, answers):
    """Sınıfta katılacak herkes cevapladı mı."""
    exp = [r for r in anket_roster(a, sinif) if r[2]]; cev = (answers or {}).get('cevaplar') or {}
    return bool(exp) and all(no in cev for no, _, _ in exp)
def _sinif_norm(s_): return str(s_ or '').upper().replace(' ', '').replace('İ', 'I')
def anket_kontenjan(a, qi, sayim, sinif, answers, haric_no=None):
    """Kontenjanlı seçeneklerde kalan yer {seçenek: kalan}: diğer sınıflar sunucudan (dakikada bir), bu sınıf yerel cevaplardan.
    haric_no: cevabını değiştiren öğrencinin eski seçimi sayılmaz."""
    qs = a.get('sorular') or []
    if not (0 <= qi < len(qs)): return {}
    q = qs[qi]; kl = q.get('kontenjanlar') or []; secs = list(q.get('secenekler') or [])
    if not any(kl): return {}
    diger, yerel, me = {}, {}, _sinif_norm(sinif)
    for r in sayim or []:
        if not isinstance(r, dict) or r.get('anket') != a.get('id') or _sinif_norm(r.get('sinif')) == me: continue
        try:
            if int(r.get('soru', -1)) != qi: continue
            diger[r.get('secenek')] = diger.get(r.get('secenek'), 0) + int(r.get('sayi') or 0)
        except (TypeError, ValueError): continue
    for no, c in ((answers or {}).get('cevaplar') or {}).items():
        if haric_no is not None and str(no) == str(haric_no): continue
        v = (c or {}).get('c') or []; v = v[qi] if qi < len(v) else None
        for x in (v if isinstance(v, list) else [v]):
            if isinstance(x, str): yerel[x] = yerel.get(x, 0) + 1
    out = {}
    for i, o in enumerate(secs):
        try: k = int((kl[i] if i < len(kl) else 0) or 0)
        except (TypeError, ValueError): k = 0
        if k > 0: out[o] = max(0, k - diger.get(o, 0) - yerel.get(o, 0))
    return out
def anket_summary(a, files):
    """files: {sınıf: cevap dosyası}. Döner: {'siniflar': {s: dict(beklenen, katilan, eksik, sorular)}, 'genel': sorular}.
    Soru özeti: puan → dağılım + ortalama; begeni/secim → sayılar; yazi → [(ad, metin)]."""
    qs = a.get('sorular', []); named = a.get('isimli', True)
    def empty_q(q):
        t = q.get('tur')
        if t == 'puan': return dict(tur=t, dag=[0]*5, top=0, n=0)
        if t == 'begeni': return dict(tur=t, say={k: 0 for k in ANKET_BEGENI}, n=0)
        if t == 'secim':
            d_ = dict(tur=t, say={k: 0 for k in q.get('secenekler', [])}, n=0, diger=[])
            if q.get('diger'): d_['say'][ANKET_DIGER] = 0
            return d_
        if t == 'sira': return dict(tur=t, top={k: 0 for k in q.get('secenekler', [])}, say={k: 0 for k in q.get('secenekler', [])}, n=0)
        if t == 'sayi': return dict(tur=t, vals=[])
        return dict(tur='yazi', liste=[])
    def add(sq, q, v, who):
        t = sq['tur']
        if v in (None, '', []): return
        if t == 'puan':
            try: x = int(v)
            except (TypeError, ValueError): return
            if 1 <= x <= 5: sq['dag'][x-1] += 1; sq['top'] += x; sq['n'] += 1
        elif t in ('begeni', 'secim'):
            for x in (v if isinstance(v, list) else [v]):
                k_ = anket_secenek_adi(x); sq['say'][k_] = sq['say'].get(k_, 0) + 1
                if k_ != x and 'diger' in sq: sq['diger'].append((who if named else '', str(x)[len(ANKET_DIGER) + 1:].strip()))
            sq['n'] += 1
        elif t == 'sira':
            for r_, x in enumerate(v if isinstance(v, list) else [v]):
                sq['top'][x] = sq['top'].get(x, 0) + r_ + 1; sq['say'][x] = sq['say'].get(x, 0) + 1
            sq['n'] += 1
        elif t == 'sayi':
            try: sq['vals'].append(float(v))
            except (TypeError, ValueError): pass
        else: sq['liste'].append((who if named else '', str(v).strip()))
    genel = [empty_q(q) for q in qs]; out = {}
    for s_ in (a.get('siniflar') or {}):
        ros = anket_roster(a, s_); exp = [r for r in ros if r[2]]; cev = ((files or {}).get(s_) or {}).get('cevaplar', {})
        sq = [empty_q(q) for q in qs]
        for no, ad, ok in exp:
            c = cev.get(no)
            if not c: continue
            for i, q in enumerate(qs):
                v = (c.get('c') or [None]*len(qs))[i] if i < len(c.get('c') or []) else None
                add(sq[i], q, v, ad); add(genel[i], q, v, ad + ' (%s)' % s_)
        out[s_] = dict(beklenen=len(exp), katilan=sum(1 for r in exp if r[0] in cev), eksik=[(no, ad) for no, ad, ok in exp if no not in cev], sorular=sq)
    return dict(siniflar=out, genel=genel)
def anket_report(a, files, folder, font_dir):
    """PDF (okul geneli özet + her sınıfa bir sayfa) ve CSV. [(yerel yol, Drive'daki ad)]"""
    import datetime, csv
    sm = anket_summary(a, files); qs = a.get('sorular', []); named = a.get('isimli', True)
    reg = os.path.join(font_dir, 'Poppins-Regular.ttf'); bold = os.path.join(font_dir, 'Poppins-Bold.ttf')
    if not os.path.isfile(reg): reg = bold = None
    doc = fitz.open(); W, H = 595, 842
    def page():
        pg = doc.new_page(width=W, height=H)
        if reg: pg.insert_font(fontname='pr', fontfile=reg); pg.insert_font(fontname='pb', fontfile=bold)
        return pg
    def T(pg, x, y, s_, size=11, b=False, col=(0.11, 0.15, 0.2), w=None):
        fn = ('pb' if b else 'pr') if reg else 'helv'
        if w:   # sığmazsa kısalt
            while s_ and fitz.get_text_length(s_, fontname='helv', fontsize=size)*1.08 > w: s_ = s_[:-2] + '…' if len(s_) > 2 else ''
        pg.insert_text((x, y), s_, fontname=fn, fontsize=size, color=col)
    def avg(q): return (q['top']/q['n']) if q.get('n') else 0
    def num(x): return ('%.1f' % x).replace('.', ',')
    def wrap(txt, n=95):
        lines, cur = [], ''
        for w_ in txt.split():
            if cur and len(cur) + 1 + len(w_) > n: lines.append(cur); cur = w_
            else: cur = (cur + ' ' + w_).strip()
        return lines + ([cur] if cur else [])
    def qblock(pg, y, i, q, s_q):
        y += 12; T(pg, 48, y, '%d. %s' % (i + 1, q.get('metin', '')), 12, True, w=W - 96); y += 16
        if s_q['tur'] == 'puan':
            mx = max(s_q['dag']) or 1
            for k in range(5, 0, -1):
                v = s_q['dag'][k-1]; T(pg, 56, y + 9, '%d puan' % k, 10)
                pg.draw_rect(fitz.Rect(110, y, 110 + 330*v/mx, y + 11), color=None, fill=(0.18, 0.44, 0.84)); T(pg, 450, y + 9, str(v), 10); y += 15
            T(pg, 56, y + 12, 'Ortalama: %s  (%d kişi)' % (num(avg(s_q)), s_q['n']), 10, True); y += 24
        elif s_q['tur'] == 'sira':
            sira_ = sorted(((s_q['top'][k_]/s_q['say'][k_], k_) for k_ in s_q['say'] if s_q['say'][k_]), key=lambda x: x[0])
            for j_, (o_, k_) in enumerate(sira_):
                T(pg, 56, y + 9, '%d. %s' % (j_ + 1, k_), 10, w=260); T(pg, 330, y + 9, 'ortalama sıra %s · %d kişi' % (num(o_), s_q['say'][k_]), 10); y += 15
            if not sira_: T(pg, 56, y + 9, '(cevap yok)', 10, col=(0.4, 0.45, 0.5)); y += 15
            y += 8
        elif s_q['tur'] == 'sayi':
            vs = s_q['vals']
            T(pg, 56, y + 9, ('Ortalama %s · en az %s · en çok %s · %d kişi' % (num(sum(vs)/len(vs)), num(min(vs)), num(max(vs)), len(vs))) if vs else '(cevap yok)', 10); y += 22
        elif s_q['tur'] in ('begeni', 'secim'):
            tot = max(1, s_q['n']); mx = max(s_q['say'].values() or [1]) or 1
            for k_, v in sorted(s_q['say'].items(), key=lambda kv: -kv[1]):
                T(pg, 56, y + 9, k_, 10, w=110)
                pg.draw_rect(fitz.Rect(170, y, 170 + 270*v/mx, y + 11), color=None, fill=(0.13, 0.72, 0.84)); T(pg, 450, y + 9, '%d  (%%%d)' % (v, round(100*v/tot)), 10); y += 15
            for who, txt in s_q.get('diger') or []:
                if y > H - 60: return y
                T(pg, 64, y + 9, ('Diğer · %s: %s' % (who, txt)) if who else 'Diğer · ' + txt, 9, col=(0.36, 0.42, 0.5), w=W - 120); y += 13
            y += 8
        else:
            for who, txt in s_q['liste']:
                line = ('%s: %s' % (who, txt)) if who else '• ' + txt
                for part in wrap(line):
                    if y > H - 60: return y
                    T(pg, 56, y + 9, part, 10); y += 14
            if not s_q['liste']: T(pg, 56, y + 9, '(yazılı görüş yok)', 10, col=(0.4, 0.45, 0.5)); y += 14
            y += 8
        return y
    today = datetime.date.today()
    # 1. sayfa: okul geneli
    pg = page(); T(pg, 48, 60, a.get('ad', 'Anket'), 20, True, w=W - 96)
    tb = sum(v['beklenen'] for v in sm['siniflar'].values()); tk = sum(v['katilan'] for v in sm['siniflar'].values())
    T(pg, 48, 80, 'Okul geneli · %s · %s · katılım %d / %d' % (TR_DAYS[today.weekday()] + ' ' + tr_date(today), 'isimli' if named else 'isimsiz', tk, tb), 10, col=(0.36, 0.42, 0.5))
    y = 104; T(pg, 48, y, 'Sınıf', 10, True); T(pg, 130, y, 'Katılım', 10, True)
    pi = next((i for i, q in enumerate(qs) if q.get('tur') == 'puan'), None)
    if pi is not None: T(pg, 220, y, 'Ortalama: ' + qs[pi].get('metin', ''), 10, True, w=320)
    y += 14
    for s_, v in sorted(sm['siniflar'].items(), key=lambda kv: _salon_key(kv[0])):
        T(pg, 48, y + 9, s_, 10); T(pg, 130, y + 9, '%d / %d' % (v['katilan'], v['beklenen']), 10)
        if pi is not None:
            av = avg(v['sorular'][pi]); pg.draw_rect(fitz.Rect(220, y, 220 + 60*av, y + 10), color=None, fill=(0.18, 0.44, 0.84)); T(pg, 530, y + 9, num(av) if v['sorular'][pi]['n'] else '—', 10)
        y += 14
        if y > H - 80: pg = page(); y = 60
    y += 14
    for i, q in enumerate(qs):
        if q.get('tur') == 'yazi': continue
        if y > H - 160: pg = page(); y = 60
        y = qblock(pg, y, i, q, sm['genel'][i])
    # sınıf sayfaları
    for s_, v in sorted(sm['siniflar'].items(), key=lambda kv: _salon_key(kv[0])):
        pg = page(); T(pg, 48, 60, a.get('ad', 'Anket'), 18, True, w=W - 96)
        T(pg, 48, 80, '%s · katılım %d / %d%s' % (s_, v['katilan'], v['beklenen'], '' if named else ' · isimsiz'), 11, col=(0.36, 0.42, 0.5)); y = 104
        for i, q in enumerate(qs):
            if y > H - 150: pg = page(); y = 60
            y = qblock(pg, y, i, q, v['sorular'][i])
        if v['eksik']:
            if y > H - 60: pg = page(); y = 60
            txt = 'Katılmayan: ' + ', '.join('%s (%s)' % (ad, no) for no, ad in v['eksik'])
            y += 10
            for part in wrap(txt, 100): T(pg, 48, y + 9, part, 10, col=(0.64, 0.2, 0.2)); y += 14
    base = 'Anket - %s - %s' % (''.join(c for c in a.get('ad', 'Anket') if c not in '/\\:*?"<>|').strip(), today.isoformat())
    os.makedirs(folder, exist_ok=True); pdf = os.path.join(folder, base + '.pdf'); doc.save(pdf); doc.close()
    cpath = os.path.join(folder, base + '.csv')
    with open(cpath, 'w', encoding='utf-8-sig', newline='') as f:
        w_ = csv.writer(f, delimiter=';'); w_.writerow(['Sınıf', 'No', 'Ad'] + ['%d. %s' % (i + 1, q.get('metin', '')) for i, q in enumerate(qs)])
        for s_ in sorted((a.get('siniflar') or {}), key=_salon_key):
            cev = ((files or {}).get(s_) or {}).get('cevaplar', {})
            for no, ad, ok in anket_roster(a, s_):
                if not ok or no not in cev: continue
                vals = cev[no].get('c') or []
                w_.writerow([s_, no if named else '', ad if named else ''] + [(', '.join(x) if isinstance(x, list) else ('' if x is None else str(x))) for x in vals])
    return [(pdf, base + '.pdf'), (cpath, base + '.csv')]

ANKET_GIZLI_DESEN = r'kimlik|\bt\.?\s?c\.?\b|\btckn\b|telefon|\bcep\b|\bgsm\b|\biban\b'
def anket_gizli(q):
    """Yazı sorusu kişisel veri mi (KVKK): soruda 'gizli' işareti ya da T.C. kimlik / telefon / IBAN geçiyorsa."""
    if q.get('tur') != 'yazi': return False
    if 'gizli' in q: return bool(q.get('gizli'))
    import re as _r
    return bool(_r.search(ANKET_GIZLI_DESEN, q.get('metin', '').replace('İ', 'i').replace('I', 'ı'), _r.I))

class AnketForm(QDialog):
    """Öğrencinin cevap penceresi: sorular alt alta, büyük dokunmatik seçenekler; yazı için ekran klavyesi."""
    def __init__(self, main, a, no, ad, on_done, kalan=None):
        super().__init__(main); self.a = a; self.on_done = on_done; self.vals = [None]*len(a.get('sorular', [])); self.diger = {}
        self.setWindowTitle(a.get('ad', 'Anket')); self.setModal(True); self.setStyleSheet(
            'QDialog{background:#0d1726;} QLabel{color:white;} QPushButton{font-size:22px;font-weight:700;color:white;background:#0b1422;border:2px solid #24364f;border-radius:14px;padding:12px 24px;}'
            'QPushButton:checked{background:#0f3a4a;border:2px solid #22e8ff;color:#7ff6ff;} QLineEdit{font-size:24px;color:#e8eefc;background:#0b1422;border:2px solid #24364f;border-radius:12px;padding:10px 14px;}'
            'QScrollArea{border:none;background:transparent;} QFrame#q{background:#13233a;border-radius:16px;}')
        v = QVBoxLayout(self); v.setContentsMargins(40, 24, 40, 20); v.setSpacing(12)
        top = QHBoxLayout(); t = QLabel('<span style="font-size:32px;font-weight:800">%s</span><br><span style="font-size:20px;color:#9fb3cc">%s</span>' % (ad.replace('<', ''), a.get('ad', '').replace('<', '')))
        top.addWidget(t, 1); back = QPushButton('Ben değilim, geri dön'); back.setFocusPolicy(Qt.NoFocus); back.clicked.connect(self.reject); top.addWidget(back); v.addLayout(top)
        sc = QScrollArea(); sc.setWidgetResizable(True); inner = QWidget(); inner.setStyleSheet('background:transparent;'); iv = QVBoxLayout(inner); iv.setSpacing(12); iv.setContentsMargins(0, 0, 0, 0)
        n = len(a.get('sorular', [])); self.edit = None; self.edits = []
        for i, q in enumerate(a.get('sorular', [])):
            fr = QFrame(); fr.setObjectName('q'); fv = QVBoxLayout(fr); fv.setContentsMargins(20, 12, 20, 14)
            opt = '' if q.get('zorunlu', q.get('tur') != 'yazi') else '  <span style="font-size:17px;color:#9fb3cc">(isteğe bağlı)</span>'
            fv.addWidget(QLabel('<span style="font-size:18px;color:#9fb3cc">%d/%d</span>&nbsp; <span style="font-size:25px;font-weight:700">%s</span>%s' % (i + 1, n, q.get('metin', '').replace('<', ''), opt)))
            tur = q.get('tur')
            if tur == 'yazi':
                e = QLineEdit(); e.setMaxLength(int(q.get('uzunluk') or 300)); e.setPlaceholderText(q.get('ornek') or 'Buraya yaz…'); e.textChanged.connect(lambda s_, i_=i: self.setv(i_, s_))
                if anket_gizli(q):   # KVKK: T.C. kimlik, cep telefonu tahtada *** görünür; "Göster" basılı tutulunca açılır
                    e.setEchoMode(QLineEdit.Password); e.setStyleSheet('lineedit-password-character: 42; letter-spacing: 3px;')
                    hr = QHBoxLayout(); hr.setSpacing(10); hr.addWidget(e, 1)
                    gb = QPushButton('Göster'); gb.setFocusPolicy(Qt.NoFocus); gb.setStyleSheet('QPushButton{font-size:18px;padding:8px 16px;}')
                    gb.pressed.connect(lambda e_=e: e_.setEchoMode(QLineEdit.Normal)); gb.released.connect(lambda e_=e: e_.setEchoMode(QLineEdit.Password))
                    hr.addWidget(gb); fv.addLayout(hr)
                else: fv.addWidget(e)
                self.edits.append(e)
                if self.edit is None: self.edit = e
            elif tur == 'sayi':   # K-330: sayı (− / + ya da klavyeyle)
                row = QHBoxLayout(); row.setSpacing(12); lo, hi = q.get('enaz'), q.get('encok'); birim = str(q.get('birim') or '')
                e = QLineEdit(); e.setMaxLength(6); e.setFixedWidth(170); e.setAlignment(Qt.AlignCenter); e.setPlaceholderText('sayı')
                def _sv(t_, i_=i, lo_=lo, hi_=hi):
                    try: x_ = int(str(t_).strip())
                    except ValueError: self.vals[i_] = None; return
                    if lo_ is not None: x_ = max(int(lo_), x_)
                    if hi_ is not None: x_ = min(int(hi_), x_)
                    self.vals[i_] = x_
                e.textChanged.connect(_sv)
                def _ad(d_, e_=e, lo_=lo, hi_=hi):
                    try: x_ = int(e_.text() or (lo_ if lo_ is not None else 0)) + d_
                    except ValueError: x_ = 0
                    if lo_ is not None: x_ = max(int(lo_), x_)
                    if hi_ is not None: x_ = min(int(hi_), x_)
                    e_.setText(str(x_))
                for d_, t_ in ((-1, '−'), (1, '+')):
                    b = QPushButton(t_); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(64); b.setMinimumWidth(80); b.clicked.connect(lambda c, d__=d_: _ad(d__))
                    if d_ < 0: row.addWidget(b); row.addWidget(e)
                    else: row.addWidget(b)
                if birim: row.addWidget(QLabel('<span style="font-size:22px;color:#9fb3cc">%s</span>' % birim.replace('<', '')))
                row.addStretch(1); fv.addLayout(row); self.edits.append(e)
                if self.edit is None: self.edit = e
            elif tur == 'sira':   # K-330: sıralama — sırayla dokun, yeniden dokununca çıkar
                row = QHBoxLayout(); row.setSpacing(12); opts = list(q.get('secenekler', [])); grp = []; self.vals[i] = []
                ilk = min(int(q.get('ilk') or len(opts)), len(opts))
                fv.addWidget(QLabel('<span style="font-size:17px;color:#9fb3cc">Tercih sırana göre dokun%s · yeniden dokunursan çıkar</span>' % ((' (ilk %d)' % ilk) if ilk < len(opts) else '')))
                for o in opts:
                    b = QPushButton(o); b.setCheckable(True); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(64)
                    b.clicked.connect(lambda c, i_=i, o_=o, g_=grp, os_=opts, n_=ilk: self.sira(i_, o_, g_, os_, n_)); grp.append(b); row.addWidget(b)
                row.addStretch(1); fv.addLayout(row)
            else:
                row = QHBoxLayout(); row.setSpacing(12)
                opts = [str(x) for x in range(1, 6)] if tur == 'puan' else (list(ANKET_BEGENI) if tur == 'begeni' else list(q.get('secenekler', [])))
                if tur == 'secim' and q.get('diger') and ANKET_DIGER not in opts: opts.append(ANKET_DIGER)
                kl = (kalan or {}).get(i) or {}
                grp = []
                for o in opts:
                    b = QPushButton(o + '…' if (o == ANKET_DIGER and q.get('diger')) else o); b.setCheckable(True); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(64)
                    if tur == 'puan': b.setMinimumWidth(96)
                    if o in kl:   # kontenjan: kalan yer (dolan kapanır)
                        b.setText('%s\n%s' % (o, 'doldu' if kl[o] <= 0 else '%d yer kaldı' % kl[o]))
                        if kl[o] <= 0: b.setEnabled(False)
                    b.clicked.connect(lambda c, i_=i, o_=o, g_=grp, b_=b, m_=bool(q.get('coklu')), os_=opts: self.pick(i_, o_, g_, b_, m_, os_)); grp.append(b); row.addWidget(b)
                row.addStretch(1); fv.addLayout(row)
                if tur == 'secim' and q.get('diger'):
                    de = QLineEdit(); de.setMaxLength(120); de.setPlaceholderText('Diğer: buraya yaz…'); de.hide(); fv.addWidget(de); self.edits.append(de)
                    if self.edit is None: self.edit = de
                    self.diger[i] = de; de.textChanged.connect(lambda t_, i_=i: self.diger_yaz(i_))
            iv.addWidget(fr)
        iv.addStretch(1); sc.setWidget(inner); v.addWidget(sc, 1)
        bot = QHBoxLayout(); self.err = QLabel(''); self.err.setStyleSheet('color:#ffb020;font-size:21px;font-weight:700;'); bot.addWidget(self.err, 1)
        self.send = QPushButton('Gönder'); self.send.setFocusPolicy(Qt.NoFocus); self.send.setMinimumHeight(68)
        self.send.setStyleSheet('QPushButton{background:#2fbf71;color:#06240f;border:none;font-size:28px;padding:12px 48px;}'); self.send.clicked.connect(self.submit); bot.addWidget(self.send); v.addLayout(bot)
        if self.edit is not None:
            kb = attach_touch_keyboard(self, self.edit, v)
            from PyQt5.QtCore import QObject
            class _F(QObject):   # birden çok yazı alanı: dokunulan alana yazar
                def eventFilter(self_, o, e_):
                    if e_.type() == QEvent.MouseButtonPress and o in self.edits and o is not self.edit:
                        kb.attach(o); kb.show()
                    return False
            self._kbf2 = _F(self)
            for e_ in self.edits[1:]: e_.installEventFilter(self._kbf2)
        fit_screen(self, main)
    def setv(self, i, val): self.vals[i] = val
    def pick(self, i, o, grp, b, multi, opts=None):
        opts = opts or [g.text() for g in grp]
        if multi: self.vals[i] = [opts[j] for j, g in enumerate(grp) if g.isChecked()]
        else:
            for g in grp: g.setChecked(g is b and b.isChecked())
            self.vals[i] = o if b.isChecked() else None
        de = self.diger.get(i)
        if de is not None:
            sec = ANKET_DIGER in (self.vals[i] if isinstance(self.vals[i], list) else [self.vals[i]])
            de.setVisible(sec)
            if sec: self.diger_yaz(i)
    def diger_yaz(self, i):
        """'Diğer' seçiliyse yazılanla birlikte kaydedilir: 'Diğer: …'."""
        de = self.diger.get(i); t_ = de.text().strip() if de is not None else ''; dv = (ANKET_DIGER + ': ' + t_) if t_ else ANKET_DIGER
        v = self.vals[i]
        if isinstance(v, list): self.vals[i] = [dv if anket_secenek_adi(x) == ANKET_DIGER else x for x in v]
        elif v is not None and anket_secenek_adi(v) == ANKET_DIGER: self.vals[i] = dv
    def sira(self, i, o, grp, opts, ilk):
        cur = list(self.vals[i] or [])
        if o in cur: cur.remove(o)
        elif len(cur) < ilk: cur.append(o)
        self.vals[i] = cur
        for j, g in enumerate(grp):
            n = cur.index(opts[j]) + 1 if opts[j] in cur else 0
            g.setChecked(bool(n)); g.setText(('%d · %s' % (n, opts[j])) if n else opts[j])
    def submit(self):
        miss = anket_missing(self.a, self.vals)
        if miss: self.err.setText('Lütfen cevapla: ' + ', '.join('%d. soru' % m for m in miss)); return
        self.on_done(list(self.vals)); self.send.setEnabled(False); self.send.setText('Teşekkürler!')
        QTimer.singleShot(900, self.accept)

class AnketScreen(QWidget):
    """Sınıf tahtasında tam ekran anket: fotoğraflı sınıf listesi; dokunan öğrenci cevaplar, üstüne yeşil tik düşer."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.idx = 0; self.cards = {}; self.bolum = 'anket'   # 'rehberlik': Rehberlik bölümünün formları
        self.kilit_id = None   # K-339: kilitli anket (Kapat yok; öğretmen 3 sn basılı tutar)
        self.kilit_b = QPushButton('Öğretmen: 3 sn basılı tut', self); self.kilit_b.setFocusPolicy(Qt.NoFocus); self.kilit_b.setMinimumHeight(56); self.kilit_b.hide()
        self.kilit_b.setStyleSheet('QPushButton{background:#281404;color:#ff9a3a;border:2px solid #ff9a3a;border-radius:14px;padding:0 26px;font-size:20px;font-weight:700;}')
        self.kilit_sure = QTimer(self); self.kilit_sure.setInterval(100); self.kilit_sure.timeout.connect(self.kilit_say); self._kilit_bas = None
        self.kilit_b.pressed.connect(self.kilit_basla); self.kilit_b.released.connect(self.kilit_birak)
        self.close_b = QPushButton('Kapat', self); self.close_b.setFocusPolicy(Qt.NoFocus); self.close_b.setMinimumHeight(56); self.close_b.clicked.connect(self.hide)
        self.close_b.setStyleSheet('QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:14px;padding:0 28px;font-size:22px;font-weight:700;}')
        self.next_b = QPushButton('Diğer anket', self); self.next_b.setFocusPolicy(Qt.NoFocus); self.next_b.setMinimumHeight(56); self.next_b.setStyleSheet(self.close_b.styleSheet()); self.next_b.clicked.connect(self.other)
        self.canli_b = QPushButton('Canlı katılım', self); self.canli_b.setFocusPolicy(Qt.NoFocus); self.canli_b.setMinimumHeight(56); self.canli_b.setStyleSheet(self.close_b.styleSheet())
        self.canli_b.clicked.connect(lambda: (self.hide(), self.main.open_anket('anket', canli=True)))   # Öğretmenler odası: öğretmen anketi açıkken
    def fit(self, rect): self.setGeometry(rect); self.layout_btns(); self.update()
    def resizeEvent(self, e): self.layout_btns()
    def kilit_basla(self): self._kilit_bas = time.time(); self.kilit_sure.start(); self.kilit_say()
    def kilit_birak(self):
        self.kilit_sure.stop(); self._kilit_bas = None; self.kilit_b.setText('Öğretmen: 3 sn basılı tut'); self.layout_btns()
    def kilit_say(self):
        if self._kilit_bas is None: return
        kalan = 3 - (time.time() - self._kilit_bas)
        if kalan <= 0: self.kilit_sure.stop(); self._kilit_bas = None; self.kilit_b.setText('Öğretmen: 3 sn basılı tut'); self.main.anket_kilit_ac(); return
        self.kilit_b.setText('Bırakmayın… %d' % (int(kalan) + 1)); self.layout_btns()
    def hideEvent(self, e):
        self.kilit_sure.stop(); self._kilit_bas = None; super().hideEvent(e)
    def layout_btns(self):
        kl = bool(self.kilit_id)
        self.close_b.adjustSize(); self.close_b.move(self.width() - self.close_b.width() - 30, self.height() - self.close_b.height() - 24)
        self.close_b.setVisible(not kl); self.kilit_b.setVisible(kl)
        if kl: self.kilit_b.adjustSize(); self.kilit_b.move(self.width() - self.kilit_b.width() - 30, self.height() - self.kilit_b.height() - 24)
        self.next_b.adjustSize(); self.next_b.move(self.close_b.x() - self.next_b.width() - 14, self.close_b.y())
        self.next_b.setVisible(not kl and len(self.main.anket_active(self.bolum)) > 1)
        oda = self.main.board_info().get('sinif') in CLASS_PLACES; self.canli_b.setVisible(oda and not kl)
        if oda: self.canli_b.adjustSize(); self.canli_b.move((self.next_b.x() if self.next_b.isVisible() else self.close_b.x()) - self.canli_b.width() - 14, self.close_b.y())
    def other(self): self.idx += 1; self.update()
    def cur(self):
        act = self.main.anket_active(self.bolum)
        if self.kilit_id:
            k_ = next((x for x in act if x.get('id') == self.kilit_id), None)
            if k_ is not None: return k_
        return act[self.idx % len(act)] if act else None
    def mousePressEvent(self, e):
        a = self.cur(); pos = QPointF(e.pos())
        if a is None: return
        hit = next((k_ for k_, r in self.cards.items() if r.contains(pos)), None)
        if hit is None: return
        no, ad, ok = hit
        if not ok: return
        if no in self.main.anket_answers(a).get('cevaplar', {}):   # fikrini değiştiren yeniden doldurabilir (son cevap geçerli)
            if QMessageBox.question(self, a.get('ad', 'Anket'), '%s anketi doldurmuş. Cevaplar değiştirilsin mi?' % ad) != QMessageBox.Yes: return
        sinif = self.main.board_info().get('sinif', ''); cev = self.main.anket_answers(a); sayim = self.main.anket_sayim()
        kalan = {i: anket_kontenjan(a, i, sayim, sinif, cev, haric_no=no) for i, q in enumerate(a.get('sorular', [])) if q.get('kontenjanlar')}
        AnketForm(self.main, a, no, ad, lambda vals: self.main.anket_save(a, no, vals), kalan=kalan).exec_(); self.update()
        if self.kilit_id == a.get('id') and anket_tamam(a, sinif, self.main.anket_answers(a)):   # K-339: herkes doldurdu, kilit kalkar
            self.kilit_id = None; self.hide(); self.layout_btns()
            if a.get('sonuc_goster'): self.main.open_anket_sonuc(a)
            else: self.main.show_toast('Herkes doldurdu, tahta açıldı. Teşekkürler!')
            return
        if a.get('id') not in {x.get('id') for x in self.main.anket_active(self.bolum)}:   # son öğrenci de doldurdu (ya da süre bitti)
            self.hide()
            if a.get('sonuc_goster'): self.main.open_anket_sonuc(a)
            else: self.main.show_toast('Anket bu sınıfta tamamlandı. Teşekkürler!')
            self.layout_btns()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); return f
        p.fillRect(self.rect(), QColor('#0d1726'))
        a = self.cur(); sinif = self.main.board_info().get('sinif', '')
        alt = self.kilit_b.y() if self.kilit_id else (self.close_b.y() if self.close_b.isVisible() else H - 70*k)
        self.cards = draw_anket_list(p, W, H, k, font, a, sinif, self.main.anket_answers(a) if a else {}, alt)
        if self.kilit_id:   # K-339: turuncu neon çerçeve + alt yazı
            p.setPen(QPen(QColor('#ff9a3a'), max(3, 4*k))); p.setBrush(Qt.NoBrush); p.drawRoundedRect(QRectF(3, 3, W - 6, H - 6), 14*k, 14*k)
            p.setFont(font(20, True)); p.setPen(QColor('#ff9a3a'))
            p.drawText(QRectF(30*k, self.kilit_b.y(), self.kilit_b.x() - 50*k, self.kilit_b.height()), Qt.AlignVCenter | Qt.AlignLeft, 'TAHTA KİLİTLİ · Herkes doldurunca kendiliğinden açılır.')
        p.end()

class AnketSonucEkrani(QWidget):
    """K-330: anket bu sınıfta kapanınca (isteğe bağlı) sınıfın sonucu — isim yok, yazı ve kişisel veri cevapları yok."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.a = None
        self.close_b = QPushButton('Kapat', self); self.close_b.setFocusPolicy(Qt.NoFocus); self.close_b.setMinimumHeight(56); self.close_b.clicked.connect(self.hide)
        self.close_b.setStyleSheet('QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:14px;padding:0 28px;font-size:22px;font-weight:700;}')
    def fit(self, rect): self.setGeometry(rect); self.close_b.adjustSize(); self.close_b.move(rect.width() - self.close_b.width() - 30, rect.height() - self.close_b.height() - 24); self.update()
    def resizeEvent(self, e): self.close_b.adjustSize(); self.close_b.move(self.width() - self.close_b.width() - 30, self.height() - self.close_b.height() - 24)
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); return f
        p.fillRect(self.rect(), QColor('#0d1726'))
        if self.a: draw_anket_sonuc(p, W, H, k, font, self.a, self.main.board_info().get('sinif', ''), self.main.anket_answers(self.a))
        p.end()
def anket_sonuc_kartlari(a, sinif, answers):
    """Sonuç ekranı için [(soru metni, tür, [(etiket, değer, oran 0–1, yazı)])]; yazı ve gizli sorular yok."""
    sm = anket_summary(a, {sinif: answers or {}}); v = sm['siniflar'].get(sinif)
    if not v: return [], 0, 0
    out = []
    for i, q in enumerate(a.get('sorular', [])):
        sq = v['sorular'][i]; t = sq['tur']
        if t == 'puan':
            n = max(1, sq['n']); out.append((q.get('metin', ''), t, [('%d' % (j + 1), sq['dag'][j], sq['dag'][j]/n, '%d · %%%d' % (sq['dag'][j], round(100*sq['dag'][j]/n))) for j in range(4, -1, -1)]))
        elif t in ('begeni', 'secim'):
            n = max(1, sq['n']); out.append((q.get('metin', ''), t, [(k_, x, x/n, '%d · %%%d' % (x, round(100*x/n))) for k_, x in sorted(sq['say'].items(), key=lambda kv: -kv[1])]))
        elif t == 'sira':
            r = sorted(((sq['top'][k_]/sq['say'][k_], k_) for k_ in sq['say'] if sq['say'][k_]), key=lambda x: x[0])
            out.append((q.get('metin', ''), t, [('%d. %s' % (j + 1, k_), 0, 0, 'ort. %s' % ('%.1f' % o_).replace('.', ',')) for j, (o_, k_) in enumerate(r)]))
        elif t == 'sayi' and sq['vals']:
            vs = sq['vals']; f_ = lambda x: ('%.1f' % x).replace('.', ',').replace(',0', '')
            out.append((q.get('metin', ''), t, [('Ortalama', 0, 0, f_(sum(vs)/len(vs))), ('En az', 0, 0, f_(min(vs))), ('En çok', 0, 0, f_(max(vs)))]))
    return out, v['katilan'], v['beklenen']
def draw_anket_sonuc(p, W, H, k, font, a, sinif, answers):
    def text(r, s_, f, c, al=Qt.AlignLeft | Qt.AlignVCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    kartlar, kat, bek = anket_sonuc_kartlari(a, sinif, answers)
    fT = font(34, True); text(QRectF(30*k, 18*k, W - 60*k, 56*k), QFontMetrics(fT).elidedText('%s · %s sonucu' % (sinif, a.get('ad', 'Anket')), Qt.ElideRight, int(W - 60*k)), fT, '#ffffff')
    text(QRectF(30*k, 70*k, W - 60*k, 30*k), 'Anket kapandı · %d / %d katıldı · isimler gösterilmez' % (kat, bek), font(18), '#9fb3cc')
    if not kartlar: text(QRectF(0, 0, W, H), 'Gösterilecek sonuç yok.', font(26), '#9fb3cc', Qt.AlignCenter); return
    cols = 1 if len(kartlar) == 1 else 2; rows = (len(kartlar) + cols - 1)//cols
    top = 116*k; bot = H - 100*k; gap = 16*k; cw = (W - 60*k - (cols - 1)*gap)/cols; ch = (bot - top - (rows - 1)*gap)/rows
    for n_, (metin, t, satir) in enumerate(kartlar):
        r = QRectF(30*k + (n_ % cols)*(cw + gap), top + (n_//cols)*(ch + gap), cw, ch)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#13233a')); p.drawRoundedRect(r, 16*k, 16*k)
        fq = font(20, True); text(QRectF(r.x() + 18*k, r.y() + 8*k, r.width() - 36*k, 34*k), QFontMetrics(fq).elidedText(metin, Qt.ElideRight, int(r.width() - 36*k)), fq, '#7ff6ff')
        lh = min(36*k, (r.height() - 54*k)/max(1, len(satir))); y = r.y() + 48*k; fl = font(min(18, lh/k*0.55))
        for et, x, oran, yazi in satir:
            text(QRectF(r.x() + 18*k, y, 200*k, lh), QFontMetrics(fl).elidedText(et, Qt.ElideRight, int(200*k)), fl, '#ffffff')
            if t in ('puan', 'begeni', 'secim'):
                bar = QRectF(r.x() + 228*k, y + lh*0.3, r.width() - 228*k - 140*k, lh*0.4)
                p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 26)); p.drawRoundedRect(bar, bar.height()/2, bar.height()/2)
                neg = (t == 'puan' and et in ('1', '2')) or str(et).lower().startswith('hayır') or et == 'Beğenmedim'
                p.setBrush(QColor('#ff3b4e' if neg else '#2fbf71')); p.drawRoundedRect(QRectF(bar.x(), bar.y(), bar.width()*oran, bar.height()), bar.height()/2, bar.height()/2)
                text(QRectF(r.right() - 132*k, y, 116*k, lh), yazi, fl, '#c9d6ea', Qt.AlignRight | Qt.AlignVCenter)
            else: text(QRectF(r.x() + 228*k, y, r.width() - 246*k, lh), yazi, fl, '#c9d6ea')
            y += lh

def draw_anket_list(p, W, H, k, font, a, sinif, answers, bottom):
    """Sınıf listesi ekranı; dönen: {(no, ad, katılır): QRectF} dokunma alanları."""
    from PyQt5.QtGui import QFontMetrics
    def text(r, s_, f, c, al=Qt.AlignLeft | Qt.AlignVCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    if a is None:
        text(QRectF(0, 0, W, H), 'Bu sınıf için açık anket yok', font(36, True), '#9fb3cc', Qt.AlignCenter); return {}
    fT = font(40, True); tw = QFontMetrics(fT).horizontalAdvance(sinif); pill = QRectF(30*k, 18*k, tw + 48*k, 62*k)
    draw_neon(p, pill, sinif, fT, '#22e8ff', k)
    ros = anket_roster(a, sinif); ros = [r for r in ros if r[2]] + [r for r in ros if not r[2]]   # katılmayanlar sona
    exp = [r for r in ros if r[2]]; cev = answers.get('cevaplar', {}); done = sum(1 for r in exp if r[0] in cev)
    meta = '%d soru  ·  %d/%d tamamladı' % (len(a.get('sorular', [])), done, len(exp)) + ('  ·  %d kişi katılamaz' % (len(ros) - len(exp)) if len(ros) > len(exp) else '')
    fm = font(22, True); mw = QFontMetrics(fm).horizontalAdvance(meta)
    text(QRectF(W - 30*k - mw - 4, 18*k, mw + 4, 62*k), meta, fm, '#ffe14d', Qt.AlignRight | Qt.AlignVCenter)
    fA = font(30, True); ax = pill.right() + 24*k
    text(QRectF(ax, 18*k, W - 30*k - mw - 30*k - ax, 62*k), QFontMetrics(fA).elidedText(a.get('ad', ''), Qt.ElideRight, int(W - 30*k - mw - 30*k - ax)), fA, '#ffffff')
    n = max(1, len(ros)); cols = 9 if n > 32 else 8; rows = (n + cols - 1)//cols
    top = 100*k; bot = bottom - 70*k; gap = 12*k; cw = (W - 60*k - (cols - 1)*gap)/cols; ch = min(cw*1.35, (bot - top - (rows - 1)*gap)/max(1, rows))
    rects = {}; fN = font(15, True)
    for i, (no, ad, ok) in enumerate(ros):
        r = QRectF(30*k + (i % cols)*(cw + gap), top + (i//cols)*(ch + gap), cw, ch); dn = no in cev
        p.setPen(QPen(QColor('#2fbf71'), 3*k) if dn else Qt.NoPen); p.setBrush(QColor(255, 255, 255, 16)); p.drawRoundedRect(r, 12*k, 12*k)
        ph = QRectF(r.x() + 7*k, r.y() + 7*k, r.width() - 14*k, r.height() - 46*k)
        draw_photo(p, ph, no, ad, k)
        if dn or not ok:
            p.setPen(Qt.NoPen); p.setBrush(QColor(13, 23, 38, 150 if dn else 200)); p.drawRoundedRect(ph, 6*k, 6*k)
        text(QRectF(r.x() + 4*k, r.bottom() - 38*k, r.width() - 8*k, 34*k), QFontMetrics(fN).elidedText(ad, Qt.ElideRight, int(r.width() - 10*k)), fN, '#ffffff' if ok else '#6f8099', Qt.AlignCenter)
        if dn:
            c_ = QRectF(r.right() - 46*k, r.y() + 8*k, 38*k, 38*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#2fbf71')); p.drawEllipse(c_)
            p.setPen(QPen(QColor('#06240f'), 4.5*k)); x0, y0 = c_.x(), c_.y()   # tik (yazı tipinden bağımsız)
            p.drawLine(QPointF(x0 + 10*k, y0 + 20*k), QPointF(x0 + 17*k, y0 + 27*k)); p.drawLine(QPointF(x0 + 17*k, y0 + 27*k), QPointF(x0 + 29*k, y0 + 12*k))
        if not ok:
            b = QRectF(ph.x() + 6*k, ph.center().y() - 14*k, ph.width() - 12*k, 28*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#0b1422')); p.drawRoundedRect(b, 7*k, 7*k)
            text(b, 'Katılmıyor', font(14, True), '#c9d6ea', Qt.AlignCenter)
        rects[(no, ad, ok)] = r
    # alt şerit: ilerleme
    by = bottom - 50*k; text(QRectF(30*k, by - 8*k, 520*k, 48*k), 'Fotoğrafına dokun, soruları cevapla', font(22), '#c9d6ea')
    bar = QRectF(560*k, by + 10*k, W - 560*k - 360*k, 14*k); p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 26)); p.drawRoundedRect(bar, 7*k, 7*k)
    if exp: p.setBrush(QColor('#2fbf71')); p.drawRoundedRect(QRectF(bar.x(), bar.y(), bar.width()*done/len(exp), bar.height()), 7*k, 7*k)
    return rects

# ---- Proje seçimi (sınıf tahtası): öğrenci 3 tercih yapar; öğretmen her ders için kontenjanı belirler, kura ile dağıtır ----
PROJE_DONEM = '2026-2027-1'   # dönem anahtarı: yeni dönemde yeni seçim
PROJE_HARIC = {'Rehberlik'}
PROJE_DEMO = 'DEMO'; PROJE_DEMO_DERS = '10-A'   # Öğretmenler odasındaki tanıtım sınıfı: 10-A'nın dersleri, uydurma öğrenciler
PROJE_DEMO_LISTE = [('%d' % (90001 + i), n_) for i, n_ in enumerate((
    'Ada Yıldız', 'Arda Kaya', 'Defne Aydın', 'Eren Şahin', 'Elif Demir', 'Kerem Çelik', 'Zeynep Arslan', 'Mert Doğan',
    'Ela Koç', 'Yusuf Kurt', 'Nehir Özdemir', 'Emir Aksoy', 'Asya Polat', 'Ali Erdem', 'Duru Kılıç', 'Kaan Yalçın'))]
def proje_dersleri(sinif):
    """Şubenin ders programındaki dersler (Rehberlik hariç), haftalık saati çok olandan aza."""
    if sinif == PROJE_DEMO: sinif = PROJE_DEMO_DERS
    lesson_cell(sinif, 0, 1)   # ders programı yüklensin
    cnt = {}
    for cell in _LESSON_TABLE.get(str(sinif or ''), {}).values():
        d = (cell or {}).get('ders', '')
        if d and d not in PROJE_HARIC: cnt[d] = cnt.get(d, 0) + 1
    return [d for d, n in sorted(cnt.items(), key=lambda kv: (-kv[1], kv[0]))]
def proje_gun_yazisi(iso):
    """'2026-11-14' → '14 Kas'."""
    try:
        y, m, g = (int(x) for x in str(iso).split('-'))
        return '%d %s' % (g, ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'][m - 1])
    except (ValueError, IndexError): return str(iso)
def proje_suresi_doldu(d):
    """Sınıfın son günü geçti mi (son gün dahil tercih yapılır)."""
    import datetime
    sg = str((d or {}).get('son_gun') or '')
    return bool(sg) and datetime.date.today().isoformat() > sg
def proje_dagit(tercihler, kont, seed=None):
    """tercihler {no: [1., 2., 3. ders]}, kont {ders: en çok kişi}. Önce 1. tercihler; bir derse kontenjandan çok
    öğrenci isterse kura (tamamen şans) çekilir, açıkta kalanlar 2. sonra 3. tercihlerine geçer. Döner {no: ders}."""
    import random
    rnd = random.Random(seed); sonuc = {}; kalan = {d: max(0, int(n or 0)) for d, n in (kont or {}).items()}
    for r in range(3):
        by = {}
        for no, t in sorted(tercihler.items()):
            if no in sonuc or len(t or []) <= r: continue
            by.setdefault(t[r], []).append(no)
        for d in sorted(by):
            cap = kalan.get(d, 0)
            if cap <= 0: continue
            lst = by[d]; pick = lst if len(lst) <= cap else rnd.sample(lst, cap)
            for no in pick: sonuc[no] = d
            kalan[d] = cap - len(pick)
    return sonuc
def proje_report(sinif, roster, d, folder, font_dir):
    """Kura sonucu: tek sayfa A4 PDF (okul logosu, öğrenci öğrenci liste, ders özeti) ve CSV. [(yerel yol, Drive'daki ad)]"""
    import datetime, csv
    reg = os.path.join(font_dir, 'Poppins-Regular.ttf'); med = os.path.join(font_dir, 'Poppins-Medium.ttf'); bold = os.path.join(font_dir, 'Poppins-Bold.ttf')
    if not os.path.isfile(reg): reg = None
    if not os.path.isfile(med): med = reg
    doc = fitz.open(); W, H = 595, 842; pg = doc.new_page(width=W, height=H)
    if reg: pg.insert_font(fontname='pr', fontfile=reg); pg.insert_font(fontname='pm', fontfile=med); pg.insert_font(fontname='pb', fontfile=bold)
    NAVY, CY, INK, MUT, RED = (0.075, 0.137, 0.227), (0.13, 0.62, 0.72), (0.11, 0.15, 0.2), (0.40, 0.45, 0.52), (0.72, 0.16, 0.16)
    def fn(b):
        if not reg: return 'helv'
        return {'b': 'pb', 'm': 'pm'}.get(b, 'pr')
    def L(s_, size, b=''): return fitz.get_text_length(s_, fontname='helv', fontsize=size)*1.12   # Poppins ≈ Helvetica'dan geniş
    def T(x, y, s_, size=10, b='', col=INK, w=None, right=False, center=False):
        s_ = str(s_)
        if w:
            while s_ and L(s_, size) > w: s_ = s_[:-2] + '…' if len(s_) > 2 else ''
        if right: x -= L(s_, size)
        if center: x -= L(s_, size)/2
        pg.insert_text((x, y), s_, fontname=fn(b), fontsize=size, color=col)
    ad = dict(roster); sonuc = d.get('sonuc', {}); ter = d.get('tercihler', {}); kont = d.get('kont', {}); today = datetime.date.today()
    M = 36
    # başlık: lacivert şerit, solda okulun resmi logosu
    pg.draw_rect(fitz.Rect(0, 0, W, 92), color=None, fill=NAVY)
    pg.draw_rect(fitz.Rect(0, 92, W, 95), color=None, fill=CY)
    if os.path.isfile(LOGO_RESMI):
        pg.draw_circle(fitz.Point(M + 32, 46), 33, color=None, fill=(1, 1, 1))
        pg.insert_image(fitz.Rect(M + 2, 16, M + 62, 76), filename=LOGO_RESMI, keep_proportion=True)
    tx = M + 80
    T(tx, 36, 'ÜMRANİYE MERKEZ ANADOLU LİSESİ', 15, 'b', (1, 1, 1))
    T(tx, 56, 'Proje Ödevi Dağılım Listesi', 12, 'm', (0.50, 0.96, 1.0))
    T(tx, 74, '2026-2027 Eğitim-Öğretim Yılı · 1. Dönem', 9, '', (0.80, 0.86, 0.94))
    # sağda sınıf rozeti
    bx = W - M - 92; pg.draw_rect(fitz.Rect(bx, 22, W - M, 70), color=(0.13, 0.91, 1.0), fill=None, width=1.6, radius=0.2)
    T(bx + 46, 54, sinif, 22, 'b', (1, 1, 1), center=True)
    # özet satırı
    n = len(roster); yer = sum(1 for no in ad if no in sonuc); tk = sum(1 for no in ad if no in ter)
    y = 118
    chips = [('Sınıf mevcudu', n), ('Tercih yapan', tk), ('Yerleşen', yer), ('Yerleşmeyen', n - yer)]
    cw = (W - 2*M - 3*10)/4
    for i, (k_, v) in enumerate(chips):
        x = M + i*(cw + 10); bad = (k_ == 'Yerleşmeyen' and v)
        pg.draw_rect(fitz.Rect(x, y - 14, x + cw, y + 16), color=None, fill=(0.99, 0.93, 0.93) if bad else (0.93, 0.96, 0.99), radius=0.25)
        T(x + 10, y + 5, k_, 8.5, '', MUT); T(x + cw - 10, y + 6, v, 13, 'b', RED if bad else NAVY, right=True)
    kz = d.get('kura_zaman') or tr_date(today)
    T(M, y + 34, 'Kura: %s  ·  Önce 1. tercihler; kontenjanı aşan derslerde kura çekildi, açıkta kalanlar 2. ve 3. tercihlerine geçti.' % kz, 7.5, '', MUT, w=W - 2*M)
    # ders özeti (altta) için yer ayır
    ders = [x for x in proje_dersleri(sinif) if int(kont.get(x) or 0) > 0 or any(v == x for v in sonuc.values())]
    ozet_rows = (len(ders) + 2)//3; ozet_h = 26 + 13*ozet_rows
    imza_h = 46
    top = y + 50; bottom = H - M - imza_h - ozet_h - 14
    rows = sorted(roster, key=lambda r: (int(r[0]) if str(r[0]).isdigit() else 10**9, r[1]))
    rh = min(17.0, (bottom - top - 18)/max(1, len(rows))); fs = max(6.5, min(9.5, rh*0.58))
    cols = [(M, 'Sıra'), (M + 30, 'No'), (M + 72, 'Adı Soyadı'), (M + 262, 'Proje dersi'), (W - M - 6, 'Tercih')]
    pg.draw_rect(fitz.Rect(M, top, W - M, top + 18), color=None, fill=NAVY)
    for x, h_ in cols: T(x + 5 if h_ != 'Tercih' else x, top + 12.5, h_, 8, 'b', (1, 1, 1), right=(h_ == 'Tercih'))
    yy = top + 18
    for i, (no, a_) in enumerate(rows):
        if i % 2: pg.draw_rect(fitz.Rect(M, yy, W - M, yy + rh), color=None, fill=(0.955, 0.965, 0.98))
        base = yy + rh*0.5 + fs*0.36; der = sonuc.get(no, ''); t = ter.get(no, [])
        rk = ('%d. tercih' % (t.index(der) + 1)) if der and der in t else ('öğretmen' if der else ('tercih yok' if not t else '—'))
        T(M + 5, base, i + 1, fs, '', MUT); T(M + 35, base, no, fs, '', MUT); T(M + 77, base, a_, fs, 'm', INK, w=180)
        T(M + 267, base, der or 'Yerleşmedi', fs, 'b' if der else 'm', NAVY if der else RED, w=W - M - 6 - (M + 267) - 60)
        T(W - M - 6, base, rk, fs*0.92, '', MUT, right=True)
        yy += rh
    pg.draw_line(fitz.Point(M, yy), fitz.Point(W - M, yy), color=(0.80, 0.84, 0.89), width=0.6)
    # ders özeti: ders · yerleşen / kontenjan
    oy = bottom + 14; T(M, oy, 'Derslere göre', 9, 'b', NAVY); oy += 6
    cw3 = (W - 2*M)/3
    for i, x_ in enumerate(ders):
        cx = M + (i % 3)*cw3; cy = oy + (i//3)*13 + 10; k_ = int(kont.get(x_) or 0); v = sum(1 for s_ in sonuc.values() if s_ == x_)
        T(cx, cy, x_, 7.8, '', INK, w=cw3 - 48); T(cx + cw3 - 10, cy, '%d / %d' % (v, k_), 7.8, 'b', RED if v > k_ else NAVY, right=True)
    # imza
    iy = H - M - 8
    for i, lab in enumerate(('Sınıf Rehber Öğretmeni', 'Okul Müdürü')):
        x0 = M + i*(W - 2*M)/2 + 30; x1 = x0 + (W - 2*M)/2 - 60
        pg.draw_line(fitz.Point(x0, iy - 12), fitz.Point(x1, iy - 12), color=(0.70, 0.74, 0.80), width=0.6)
        T((x0 + x1)/2, iy, lab, 8, '', MUT, center=True)
    T(W/2, H - 12, 'UMAL Atlas · %s' % tr_date(today), 6.5, '', (0.62, 0.66, 0.72), center=True)
    base_ = 'Proje seçimi - %s - %s' % (sinif, today.isoformat())
    os.makedirs(folder, exist_ok=True); pdf = os.path.join(folder, base_ + '.pdf'); doc.save(pdf); doc.close()
    cpath = os.path.join(folder, base_ + '.csv')
    with open(cpath, 'w', encoding='utf-8-sig', newline='') as f:
        w_ = csv.writer(f, delimiter=';'); w_.writerow(['Sınıf', 'No', 'Ad', '1. tercih', '2. tercih', '3. tercih', 'Proje dersi'])
        for no, a_ in rows:
            t = list(ter.get(no, [])) + ['', '', '']; w_.writerow([sinif, no, a_, t[0], t[1], t[2], sonuc.get(no, '')])
    return [(pdf, base_ + '.pdf'), (cpath, base_ + '.csv')]

def fit_screen(dlg, main):
    """Tam ekran pencere: çerçevesiz, tahtanın kullanılabilir alanı boyunda. (Çerçeveli pencereye ekran boyu verilince başlık çubuğu
    kadar aşağı itiliyor, alttaki Kaydet/Gönder düğmesi ekranın dışında kalıyordu.)"""
    try:
        scr = (main.windowHandle().screen() if main.windowHandle() else QApplication.primaryScreen()).geometry()   # bütün ekran (görev çubuğu payı yok)
    except Exception: scr = QApplication.primaryScreen().geometry()
    if not int(dlg.windowFlags() & Qt.FramelessWindowHint):
        vis = dlg.isVisible(); dlg.setWindowFlags(dlg.windowFlags() | Qt.FramelessWindowHint)
        if vis: dlg.show()
    dlg._fit_main = main   # çözünürlük değişince refit_screen yeniden oturtur
    lay = dlg.layout()   # tahtanın çerçevesi ekranın kenarını örtüyor: alt düğmeler kenardan yukarıda dursun
    if lay is not None:
        try: k = min(1.0, scr.height() / 1080.0)   # küçük çözünürlükte kenar payı da küçülür
        except Exception: k = 1.0
        try: lay.setContentsMargins(int(48*k), int(30*k), int(64*k), int(64*k))
        except Exception: pass
    dlg.setMinimumSize(0, 0); dlg.setMaximumSize(scr.width(), scr.height()); dlg.setGeometry(scr)
def fit_w(n):
    """Geniş pencere en az n piksel olsun ama küçük çözünürlükte ekrandan taşmasın."""
    try: return max(480, min(n, QApplication.primaryScreen().geometry().width() - 40))
    except Exception: return n

class ProjePin(QDialog):
    """Öğretmen şifresi (yalnız bu tahtada, özeti saklanır): ilk açılışta öğretmen belirler; öğrenciler ayarlara giremez."""
    def __init__(self, main, setup=False):
        super().__init__(main); self.main = main; self.setup = setup; self.setWindowTitle('Öğretmen'); self.setMinimumWidth(fit_w(1100))   # klavye geniş olsun (arama ekranındaki gibi)
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:21px;} QLineEdit{font-size:30px;padding:10px 14px;border:2px solid #2f6fd6;border-radius:12px;color:white;background:#0b1422;}'
                           'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:12px;padding:12px 22px;font-size:20px;font-weight:700;}')
        v = QVBoxLayout(self); v.setContentsMargins(28, 22, 28, 22); v.setSpacing(12)
        v.addWidget(QLabel('Bu tahta için öğretmen şifresi belirleyin (en az 4 karakter).\nSınıfın öğretmenleriyle paylaşın; öğrencilere söylemeyin.' if setup else 'Öğretmen şifresi'))
        self.edit = QLineEdit(); self.edit.setEchoMode(QLineEdit.Password); v.addWidget(self.edit)
        self.edit2 = None
        if setup: self.edit2 = QLineEdit(); self.edit2.setEchoMode(QLineEdit.Password); self.edit2.setPlaceholderText('Şifre (tekrar)'); v.addWidget(self.edit2)
        self.err = QLabel(''); self.err.setStyleSheet('color:#ffb020;'); v.addWidget(self.err)
        h = QHBoxLayout(); c = QPushButton('Vazgeç'); c.clicked.connect(self.reject); h.addWidget(c); h.addStretch(1)
        ok = QPushButton('Tamam'); ok.setStyleSheet('QPushButton{background:#2f6fd6;}'); ok.clicked.connect(self.check); h.addWidget(ok); v.addLayout(h)
        kb = attach_touch_keyboard(self, self.edit, v); kb.attach(self.edit); kb.show()
        if self.edit2 is not None:
            from PyQt5.QtCore import QObject
            class _F(QObject):
                def eventFilter(self_, o, e):
                    if e.type() == QEvent.MouseButtonPress and o in (self.edit, self.edit2): kb.attach(o)
                    return False
            self._f2 = _F(self); self.edit2.installEventFilter(self._f2)
        QTimer.singleShot(0, self.edit.setFocus)
    def check(self):
        s_ = self.edit.text()
        if self.setup:
            if len(s_) < 4: self.err.setText('En az 4 karakter.'); return
            if s_ != self.edit2.text(): self.err.setText('İki şifre aynı değil.'); return
            self.main.proje_pin_set(s_); self.accept(); return
        if self.main.proje_pin_ok(s_): self.accept()
        else: self.err.setText('Şifre yanlış.'); self.edit.clear()

class ProjeForm(QDialog):
    """Öğrencinin tercih penceresi: derslere sırayla dokunur (1., 2., 3. tercih); tekrar dokununca geri alır."""
    def __init__(self, main, no, ad, dersler, kont, eski, on_done, adet=3):
        super().__init__(main); self.on_done = on_done; self.need = max(1, min(int(adet or 3), 3, len(dersler))); self.sec = list(eski or [])[:self.need]; self.btns = {}
        self.setWindowTitle('Proje seçimi'); self.setModal(True); self.setStyleSheet(
            'QDialog{background:#0d1726;} QLabel{color:white;} QPushButton{font-size:22px;font-weight:700;color:white;background:#0b1422;border:2px solid #24364f;border-radius:14px;padding:12px 18px;text-align:left;}'
            'QPushButton:checked{background:#0f3a4a;border:2px solid #22e8ff;color:#7ff6ff;}')
        v = QVBoxLayout(self); v.setContentsMargins(40, 24, 40, 20); v.setSpacing(14)
        top = QHBoxLayout(); t = QLabel('<span style="font-size:32px;font-weight:800">%s</span><br><span style="font-size:20px;color:#9fb3cc">Projeni yapmak istediğin dersleri sırayla seç: önce en çok istediğin (%d tercih)</span>' % (ad.replace('<', ''), self.need))
        top.addWidget(t, 1); back = QPushButton('Ben değilim, geri dön'); back.setFocusPolicy(Qt.NoFocus); back.clicked.connect(self.reject); top.addWidget(back); v.addLayout(top)
        sc = QScrollArea(); sc.setWidgetResizable(True); sc.setStyleSheet('QScrollArea{border:none;background:transparent;}')   # ders çoksa kayar; Kaydet hep görünür
        inner = QWidget(); inner.setStyleSheet('background:transparent;'); g = QGridLayout(inner); g.setSpacing(12); g.setContentsMargins(0, 0, 0, 0)
        for i, d in enumerate(dersler):
            b = QPushButton(); b.setCheckable(True); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(64); b.clicked.connect(lambda c, d_=d: self.pick(d_))
            self.btns[d] = (b, int(kont.get(d) or 0)); g.addWidget(b, i//3, i % 3)
        g.setRowStretch((len(dersler) + 2)//3, 1); sc.setWidget(inner); v.addWidget(sc, 1)
        bot = QHBoxLayout(); self.err = QLabel(''); self.err.setStyleSheet('color:#ffb020;font-size:21px;font-weight:700;'); bot.addWidget(self.err, 1)
        self.send = QPushButton('Kaydet'); self.send.setFocusPolicy(Qt.NoFocus); self.send.setMinimumHeight(68)
        self.send.setStyleSheet('QPushButton{background:#2fbf71;color:#06240f;border:none;font-size:28px;padding:12px 48px;text-align:center;}'); self.send.clicked.connect(self.submit); bot.addWidget(self.send); v.addLayout(bot)
        self.refresh(); fit_screen(self, main)
    def pick(self, d):
        if d in self.sec: self.sec.remove(d)
        elif len(self.sec) < self.need: self.sec.append(d)
        self.refresh()
    def refresh(self):
        for d, (b, n) in self.btns.items():
            rk = (self.sec.index(d) + 1) if d in self.sec else 0
            b.setChecked(bool(rk)); b.setText(('%d.  ' % rk if rk else '') + '%s   (en çok %d kişi)' % (d, n))
        self.err.setText('' if len(self.sec) >= self.need else '%d tercih daha seç' % (self.need - len(self.sec)))
    def submit(self):
        if len(self.sec) < self.need: self.err.setText('%d tercih daha seç' % (self.need - len(self.sec))); return
        self.on_done(list(self.sec)); self.send.setEnabled(False); self.send.setText('Kaydedildi')
        QTimer.singleShot(800, self.accept)

class ProjeOgretmen(QDialog):
    """Öğretmen: her dersten en çok kaç öğrenci (kontenjan), seçimi aç/kapat, kura ile dağıt, sonucu düzelt, rapor."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Proje seçimi · öğretmen')
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:19px;} QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:10px;padding:10px 16px;font-size:19px;font-weight:700;}'
                           'QPushButton:disabled{color:#6f819c;} QComboBox{font-size:18px;padding:6px 10px;color:white;background:#0b1422;border:1px solid #2a4468;border-radius:8px;}')
        self.sinif = main.proje_sinif(); self.d = main.proje_data(); self.ros = main.proje_roster(); self.ders = proje_dersleri(self.sinif)
        v = QVBoxLayout(self); v.setContentsMargins(26, 20, 26, 20); v.setSpacing(10)
        t = QLabel('%s · Proje ödevi tercihi · öğretmen' % self.sinif); t.setStyleSheet('font-size:28px;font-weight:800;color:#7ff6ff;'); v.addWidget(t)
        alt = QLabel('Bu sınıfın ayarları; diğer sınıflar kendi ayarlarıyla çalışır.'); alt.setStyleSheet('color:#9fb3cc;font-size:17px;'); v.addWidget(alt)
        # sınıfa özel: tercih sayısı ve son gün
        ay = QHBoxLayout(); ay.setSpacing(8)
        ay.addWidget(QLabel('Kaç tercih:')); self.adet_b = {}
        for n_ in (1, 2, 3):
            b_ = QPushButton(str(n_)); b_.setFixedSize(56, 46); b_.setFocusPolicy(Qt.NoFocus); b_.clicked.connect(lambda c=False, n__=n_: self.adet(n__)); ay.addWidget(b_); self.adet_b[n_] = b_
        ay.addSpacing(30); ay.addWidget(QLabel('Son gün:'))
        sg_y = QPushButton('Yok'); sg_y.setFocusPolicy(Qt.NoFocus); sg_y.clicked.connect(lambda: self.son_gun(None)); ay.addWidget(sg_y); self.sg_yok = sg_y
        sg_m = QPushButton('−'); sg_m.setFixedSize(52, 46); sg_m.setFocusPolicy(Qt.NoFocus); sg_m.clicked.connect(lambda: self.son_gun(-1)); ay.addWidget(sg_m)
        self.sg_l = QLabel(''); self.sg_l.setMinimumWidth(170); self.sg_l.setAlignment(Qt.AlignCenter); self.sg_l.setStyleSheet('font-size:21px;font-weight:800;color:#ffe14d;'); ay.addWidget(self.sg_l)
        sg_p = QPushButton('+'); sg_p.setFixedSize(52, 46); sg_p.setFocusPolicy(Qt.NoFocus); sg_p.clicked.connect(lambda: self.son_gun(1)); ay.addWidget(sg_p)
        ay.addStretch(1); v.addLayout(ay)
        v.addWidget(QLabel('Dersler ve kontenjan: ders adına dokunup çıkarın ya da geri ekleyin (çıkarılan derste proje yok).'))
        gsc = QScrollArea(); gsc.setWidgetResizable(True); gsc.setStyleSheet('QScrollArea{border:none;background:transparent;}')
        gw = QWidget(); gw.setStyleSheet('background:transparent;'); g = QGridLayout(gw); g.setHorizontalSpacing(10); g.setVerticalSpacing(6); self.lab = {}; self.adlar = {}
        n0 = max(1, -(-len(self.ros)//max(1, len(self.ders))))   # ilk öneri: sınıf mevcudu / ders sayısı (yukarı)
        kont = self.d.setdefault('kont', {})
        for d in self.ders: kont.setdefault(d, n0)
        for i, d in enumerate(self.ders):
            r_, c_ = i % ((len(self.ders) + 1)//2), (i // ((len(self.ders) + 1)//2))*4
            nb = QPushButton(d); nb.setFocusPolicy(Qt.NoFocus); nb.setStyleSheet('QPushButton{text-align:left;background:transparent;border:none;padding:4px 2px;}')
            nb.clicked.connect(lambda c=False, d_=d: self.cikar(d_)); g.addWidget(nb, r_, c_); self.adlar[d] = nb
            m = QPushButton('−'); p_ = QPushButton('+'); l_ = QLabel(); l_.setMinimumWidth(44); l_.setAlignment(Qt.AlignCenter); l_.setStyleSheet('font-size:24px;font-weight:800;color:#ffe14d;')
            for b in (m, p_): b.setFixedSize(52, 46); b.setFocusPolicy(Qt.NoFocus)
            m.clicked.connect(lambda c=False, d_=d: self.step(d_, -1)); p_.clicked.connect(lambda c=False, d_=d: self.step(d_, 1))
            g.addWidget(m, r_, c_ + 1); g.addWidget(l_, r_, c_ + 2); g.addWidget(p_, r_, c_ + 3); self.lab[d] = l_
        gsc.setWidget(gw); gsc.setMinimumHeight(min(440, 52*((len(self.ders) + 1)//2) + 10)); v.addWidget(gsc, 1)
        self.info = QLabel(''); self.info.setWordWrap(True); self.info.setStyleSheet('color:#9fb3cc;font-size:18px;'); v.addWidget(self.info)
        h = QHBoxLayout(); h.setSpacing(10)
        self.ac = QPushButton(); self.ac.clicked.connect(self.toggle); h.addWidget(self.ac)
        self.kura = QPushButton('Kurayı çek ve dağıt'); self.kura.clicked.connect(self.dagit); h.addWidget(self.kura)
        self.duz = QPushButton('Sonucu düzelt'); self.duz.clicked.connect(self.duzelt); h.addWidget(self.duz)
        self.rap = QPushButton('Listeyi Drive\'a gönder'); self.rap.clicked.connect(self.rapor); h.addWidget(self.rap)
        v.addLayout(h)
        h2 = QHBoxLayout()
        if main.proje_demo():
            rs = QPushButton('Tanıtımı sıfırla'); rs.clicked.connect(self.sifirla); h2.addWidget(rs)
        h2.addStretch(1)
        cl = QPushButton('Kapat'); cl.clicked.connect(self.accept); h2.addWidget(cl); v.addLayout(h2)
        self.refresh()
        try:
            scr = QApplication.primaryScreen().availableGeometry(); self.setMaximumHeight(scr.height())
        except Exception: pass
    def save(self, push=True): self.main.proje_save(self.d, push); self.refresh()
    def adet(self, n):
        self.d['tercih_sayisi'] = n; self.save(False); self._kirli = True
    def son_gun(self, adim):
        """Son gün: None → yok; ±1 gün (yoksa bugünden 3 gün sonrası)."""
        import datetime
        if adim is None: self.d.pop('son_gun', None)
        else:
            try: g = datetime.date.fromisoformat(self.d.get('son_gun') or '')
            except ValueError: g = datetime.date.today() + datetime.timedelta(days=3 - adim)
            g = max(datetime.date.today(), g + datetime.timedelta(days=adim)); self.d['son_gun'] = g.isoformat()
        self.save(False); self._kirli = True
    def cikar(self, d):
        """Dersi çıkar (kontenjan 0) ya da önceki kontenjanıyla geri ekle."""
        k_ = self.d.setdefault('kont', {}); onc = self.d.setdefault('kont_onceki', {})
        if int(k_.get(d) or 0) > 0: onc[d] = int(k_[d]); k_[d] = 0
        else: k_[d] = int(onc.get(d) or max(1, -(-len(self.ros)//max(1, len(self.ders)))))
        self.save(False); self._kirli = True
    def step(self, d, s_):
        k_ = self.d['kont']; k_[d] = max(0, min(60, int(k_.get(d) or 0) + s_)); self.save(False); self._kirli = True
    def done(self, r):
        if getattr(self, '_kirli', False): self.main.proje_save(self.d)   # kontenjanlar kapatınca Drive'a
        super().done(r)
    def refresh(self):
        k_ = self.d.get('kont', {}); top = sum(int(k_.get(d) or 0) for d in self.ders); n = len(self.ros); dur = self.d.get('durum', 'kapali')
        for d, l_ in self.lab.items(): l_.setText(str(int(k_.get(d) or 0)))
        for d, nb in self.adlar.items():
            yok = int(k_.get(d) or 0) <= 0
            nb.setText(d + ('  · çıkarıldı (dokun: geri ekle)' if yok else '')); nb.setStyleSheet('QPushButton{text-align:left;background:transparent;border:none;padding:4px 2px;color:%s;}' % ('#6f819c' if yok else '#ffffff'))
        n_ad = int(self.d.get('tercih_sayisi') or 3)
        for n_, b_ in self.adet_b.items():
            b_.setStyleSheet('QPushButton{background:%s;color:%s;border:1px solid %s;}' % (('#22e8ff', '#0d1726', '#22e8ff') if n_ == n_ad else ('#1d3150', 'white', '#2a4468')))
        sg = self.d.get('son_gun')
        self.sg_l.setText(proje_gun_yazisi(sg) + (' (geçti)' if proje_suresi_doldu(self.d) else '') if sg else '—')
        self.sg_yok.setStyleSheet('QPushButton{background:%s;color:%s;}' % (('#22e8ff', '#0d1726') if not sg else ('#1d3150', 'white')))
        msg = 'Sınıf mevcudu %d · toplam kontenjan %d · %d öğrenci tercih yaptı' % (n, top, len(self.d.get('tercihler', {})))
        if top < n: msg += '  —  <span style="color:#ffb020">kontenjan sınıf mevcudundan az: bazı öğrenciler yerleşemez</span>'
        msg += '<br>Durum: <b>%s</b>' % {'kapali': 'seçim kapalı', 'acik': 'seçim açık — öğrenciler tahtada tercih yapıyor', 'dagitildi': 'dağıtım yapıldı (%s)' % self.d.get('kura_zaman', '')}.get(dur, dur)
        if dur == 'dagitildi': msg += ' · %d yerleşti, %d açıkta' % (len(self.d.get('sonuc', {})), n - len(self.d.get('sonuc', {})))
        self.info.setText(msg)
        self.ac.setText('Seçimi kapat' if dur == 'acik' else ('Seçimi yeniden aç' if dur == 'dagitildi' else 'Seçimi aç'))
        self.kura.setEnabled(bool(self.d.get('tercihler'))); self.duz.setEnabled(dur == 'dagitildi'); self.rap.setEnabled(bool(self.ros))
    def toggle(self):
        dur = self.d.get('durum', 'kapali')
        if dur == 'dagitildi' and QMessageBox.question(self, 'Proje seçimi', 'Dağıtım silinir, öğrenciler tercihlerini yeniden düzenleyebilir. Devam edilsin mi?') != QMessageBox.Yes: return
        self.d['durum'] = 'kapali' if dur == 'acik' else 'acik'
        if dur == 'dagitildi': self.d['sonuc'] = {}
        self.save(); self.main.proje_refresh()
    def dagit(self):
        if self.d.get('durum') == 'dagitildi' and QMessageBox.question(self, 'Proje seçimi', 'Kura yeniden çekilsin mi? Elle yapılan düzeltmeler silinir.') != QMessageBox.Yes: return
        import datetime
        self.d['sonuc'] = proje_dagit(self.d.get('tercihler', {}), self.d.get('kont', {})); self.d['durum'] = 'dagitildi'
        self.d['kura_zaman'] = datetime.datetime.now().strftime('%d.%m.%Y %H.%M'); self.save(); self.main.proje_refresh()
    def duzelt(self):
        """Sonucu düzelt: tam ekran liste; her öğrencinin satırına dokununca dersler büyük düğmelerle çıkar (açılır liste yok)."""
        dl = QDialog(self); dl.setWindowTitle('Sonucu düzelt')
        dl.setStyleSheet('QDialog{background:#0d1726;} QLabel{color:white;background:transparent;} QScrollArea{border:none;background:transparent;}'
                         'QPushButton{color:white;background:#13233a;border:1px solid #2a4468;border-radius:12px;padding:8px 16px;font-size:20px;font-weight:700;text-align:left;}'
                         'QPushButton:pressed{background:#1d3150;} QPushButton#ok{background:#2fbf71;color:#06240f;border:none;text-align:center;font-size:24px;padding:10px 40px;}'
                         'QPushButton#vz{text-align:center;}')
        v = QVBoxLayout(dl); v.setSpacing(10)
        t = QLabel('%s · Sonucu düzelt' % self.sinif); t.setStyleSheet('font-size:28px;font-weight:800;color:#7ff6ff;'); v.addWidget(t)
        sub = QLabel('Öğrencinin satırına dokunun, yerleşeceği dersi seçin.'); sub.setStyleSheet('font-size:18px;color:#9fb3cc;'); v.addWidget(sub)
        yeni = dict(self.d.get('sonuc', {})); ter = self.d.get('tercihler', {}); btns = {}
        sc = QScrollArea(); sc.setWidgetResizable(True); inner = QWidget(); inner.setStyleSheet('background:transparent;')
        g = QGridLayout(inner); g.setHorizontalSpacing(14); g.setVerticalSpacing(8); g.setContentsMargins(0, 0, 8, 0)
        half = (len(self.ros) + 1)//2
        def label(no):
            t_ = ter.get(no, []); d_ = yeni.get(no)
            rk = ('  · %d. tercih' % (t_.index(d_) + 1)) if d_ and d_ in t_ else ''
            return '%s   ·   %s%s' % (dict(self.ros)[no], d_ or 'Yerleşmedi', rk)
        def paint(no):
            b = btns[no]; b.setText(label(no))
            b.setStyleSheet('QPushButton{color:%s;}' % ('#ffffff' if yeni.get(no) else '#ff8a8a'))
        def pick(no):
            pk = QDialog(dl); pk.setWindowTitle('Ders seç'); pk.setStyleSheet(dl.styleSheet())
            pv = QVBoxLayout(pk); pv.setContentsMargins(26, 20, 26, 20); pv.setSpacing(12)
            t_ = ter.get(no, [])
            hd = QLabel('<span style="font-size:26px;font-weight:800">%s</span><br><span style="font-size:17px;color:#9fb3cc">Tercihleri: %s</span>' % (dict(self.ros)[no].replace('<', ''), ', '.join('%d. %s' % (k + 1, x) for k, x in enumerate(t_)) or 'yok'))
            pv.addWidget(hd); pg = QGridLayout(); pg.setSpacing(10)
            say = {}
            for x in yeni.values(): say[x] = say.get(x, 0) + 1
            for k, d_ in enumerate(self.ders + ['']):
                n_, cap = say.get(d_, 0), int(self.d.get('kont', {}).get(d_) or 0)
                b_ = QPushButton(('%s   (%d / %d)' % (d_, n_, cap)) if d_ else 'Yerleşmedi'); b_.setMinimumHeight(60); b_.setFocusPolicy(Qt.NoFocus)
                if d_ and d_ == yeni.get(no): b_.setStyleSheet('QPushButton{background:#0f3a4a;border:2px solid #22e8ff;color:#7ff6ff;}')
                elif d_ and n_ >= cap: b_.setStyleSheet('QPushButton{color:#9fb3cc;}')
                def sec(c=False, d_=d_):
                    if d_: yeni[no] = d_
                    else: yeni.pop(no, None)
                    paint(no); pk.accept()
                b_.clicked.connect(sec); pg.addWidget(b_, k//3, k % 3)
            pv.addLayout(pg); cl = QPushButton('Vazgeç'); cl.setObjectName('vz'); cl.setMinimumHeight(54); cl.clicked.connect(pk.reject); pv.addWidget(cl)
            pk.setMinimumWidth(fit_w(1100)); pk.exec_()
        for i_, (no, ad_) in enumerate(self.ros):
            b = QPushButton(); b.setMinimumHeight(52); b.setFocusPolicy(Qt.NoFocus); b.clicked.connect(lambda c=False, n_=no: pick(n_)); btns[no] = b; paint(no)
            g.addWidget(b, i_ % half, i_ // half)
        sc.setWidget(inner); v.addWidget(sc, 1)
        warn = QLabel(''); warn.setStyleSheet('color:#ffb020;font-size:19px;font-weight:700;'); v.addWidget(warn)
        h = QHBoxLayout(); c = QPushButton('Vazgeç'); c.setObjectName('vz'); c.setMinimumHeight(60); c.clicked.connect(dl.reject); h.addWidget(c); h.addStretch(1)
        ok = QPushButton('Kaydet'); ok.setObjectName('ok'); ok.setMinimumHeight(60); h.addWidget(ok); v.addLayout(h)
        def kaydet():
            say = {}
            for x in yeni.values(): say[x] = say.get(x, 0) + 1
            fazla = [x for x, n in say.items() if n > int(self.d['kont'].get(x) or 0)]
            if fazla and not getattr(dl, '_onay', False):
                warn.setText('Kontenjan aşılıyor: %s. Yine de kaydetmek için tekrar "Kaydet"e basın.' % ', '.join(fazla)); dl._onay = True; return
            self.d['sonuc'] = dict(yeni); self.save(); self.main.proje_refresh(); dl.accept()
        ok.clicked.connect(kaydet)
        fit_screen(dl, self.main); dl.exec_()
    def sifirla(self):
        if QMessageBox.question(self, 'Tanıtım', 'Tanıtım sınıfının tercihleri ve dağıtımı silinsin mi?') != QMessageBox.Yes: return
        self.d = dict(durum='kapali', kont={}, tercihler={}, sonuc={}); self.main.proje_save(self.d, False)
        self.accept(); self.main.proje_refresh()
    def rapor(self):
        if self.main.proje_demo():   # tanıtım: PDF tahtada açılır, Drive'a gitmez
            try:
                res = proje_report(self.sinif, self.ros, self.d, os.path.join(self.main.data_dir, 'proje-rapor'), UI_FONT_DIR)
                self.accept(); ps = getattr(self.main, 'proje_screen', None)
                if ps is not None: ps.hide()   # liste tahtada sekme olarak açılır
                tmp = res[0][0].replace('.pdf', time.strftime(' %H.%M.%S') + '.pdf'); shutil.copyfile(res[0][0], tmp)   # her basışta yeni sekme
                QTimer.singleShot(0, lambda: self.main.open_pdf_path(tmp))
                self.main.show_toast('Tanıtım listesi hazır (Drive\'a gönderilmedi).')
            except Exception as e: self.info.setText(self.info.text() + '<br><span style="color:#ffb020">Liste hazırlanamadı: %s</span>' % e)
            return
        try:
            for path, name in proje_report(self.sinif, self.ros, self.d, os.path.join(self.main.data_dir, 'proje-rapor'), UI_FONT_DIR): self.main.run_havuz('--yukle', path, name)
            self.info.setText(self.info.text() + '<br><span style="color:#2fbf71">Liste Drive\'daki "Sınav Yoklamaları" klasörüne gönderildi.</span>')
        except Exception as e: self.info.setText(self.info.text() + '<br><span style="color:#ffb020">Liste hazırlanamadı: %s</span>' % e)

class ProjeScreen(QWidget):
    """Sınıf tahtasında tam ekran proje seçimi: fotoğraflı sınıf listesi; dokunan öğrenci 3 tercihini yapar."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.cards = {}
        st_ = 'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:14px;padding:0 28px;font-size:22px;font-weight:700;}'
        self.close_b = QPushButton('Kapat', self); self.close_b.setFocusPolicy(Qt.NoFocus); self.close_b.setMinimumHeight(56); self.close_b.setStyleSheet(st_); self.close_b.clicked.connect(self.hide)
        self.ogr_b = QPushButton('Öğretmen', self); self.ogr_b.setFocusPolicy(Qt.NoFocus); self.ogr_b.setMinimumHeight(56); self.ogr_b.setStyleSheet(st_)
        self.ogr_b.pressed.connect(self.tut_bas); self.ogr_b.released.connect(self.tut_birak)   # şifre yok: 3 sn basılı tutunca açılır
        self._tut = QTimer(self); self._tut.setInterval(100); self._tut.timeout.connect(self.tut_say); self._tut_t = None
    def fit(self, rect): self.setGeometry(rect); self.layout_btns(); self.update()
    def resizeEvent(self, e): self.layout_btns()
    def layout_btns(self):
        self.close_b.adjustSize(); self.close_b.move(self.width() - self.close_b.width() - 30, self.height() - self.close_b.height() - 24)
        self.ogr_b.adjustSize(); self.ogr_b.move(self.close_b.x() - self.ogr_b.width() - 14, self.close_b.y())
    PROJE_TUT_SN = 3.0
    def tut_bas(self): self._tut_t = time.monotonic(); self._tut.start(); self.tut_say()
    def tut_birak(self):
        if self._tut_t is None: return
        kalan = self.PROJE_TUT_SN - (time.monotonic() - self._tut_t); self._tut.stop(); self._tut_t = None; self.ogr_b.setText('Öğretmen'); self.layout_btns()
        if kalan > 0: self.main.show_toast('Öğretmen ayarları için düğmeye 3 saniye basılı tutun')
    def tut_say(self):
        if self._tut_t is None: return
        gecen = time.monotonic() - self._tut_t
        if gecen >= self.PROJE_TUT_SN:
            self._tut.stop(); self._tut_t = None; self.ogr_b.setText('Öğretmen'); self.layout_btns(); self.ogretmen(); return
        self.ogr_b.setText('Basılı tutun… %d' % (int(self.PROJE_TUT_SN - gecen) + 1)); self.layout_btns()
    def ogretmen(self):
        ProjeOgretmen(self.main).exec_(); self.update()
    def mousePressEvent(self, e):
        pos = QPointF(e.pos()); hit = next((k_ for k_, r in self.cards.items() if r.contains(pos)), None)
        if hit is None: return
        d = self.main.proje_data(); no, ad = hit
        if d.get('durum') == 'acik' and proje_suresi_doldu(d):
            self.main.show_toast('Tercih süresi doldu (son gün %s); öğretmenine söyle.' % proje_gun_yazisi(d['son_gun'])); return
        if d.get('durum') != 'acik':
            self.main.show_toast('Seçim şu an kapalı.' if d.get('durum') != 'dagitildi' else 'Dağıtım yapıldı; değişiklik için öğretmenine söyle.'); return
        ders = [x for x in proje_dersleri(self.main.proje_sinif()) if int(d.get('kont', {}).get(x) or 0) > 0]
        if not ders: self.main.show_toast('Öğretmen henüz kontenjan belirlemedi.'); return
        ProjeForm(self.main, no, ad, ders, d.get('kont', {}), d.get('tercihler', {}).get(no), lambda t: self.main.proje_tercih(no, t), adet=int(d.get('tercih_sayisi') or 3)).exec_(); self.update()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); return f
        p.fillRect(self.rect(), QColor('#0d1726'))
        self.cards = draw_proje_list(p, W, H, k, font, self.main.proje_sinif(), self.main.proje_roster(), self.main.proje_data(), self.close_b.y())
        p.end()

def draw_proje_list(p, W, H, k, font, sinif, ros, d, bottom):
    """Proje seçimi sınıf listesi; dönen {(no, ad): QRectF} dokunma alanları."""
    def text(r, s_, f, c, al=Qt.AlignLeft | Qt.AlignVCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    fT = font(40, True); tw = QFontMetrics(fT).horizontalAdvance(sinif); pill = QRectF(30*k, 18*k, tw + 48*k, 62*k)
    draw_neon(p, pill, sinif, fT, '#22e8ff', k)
    dur = d.get('durum', 'kapali'); ter = d.get('tercihler', {}); sonuc = d.get('sonuc', {})
    meta = {'kapali': 'Seçim kapalı', 'acik': '%d/%d tercih yaptı' % (sum(1 for no, _ in ros if no in ter), len(ros)), 'dagitildi': 'Dağıtım yapıldı · %d/%d yerleşti' % (sum(1 for no, _ in ros if no in sonuc), len(ros))}.get(dur, '')
    if dur == 'acik' and d.get('son_gun'): meta += (' · süre doldu' if proje_suresi_doldu(d) else ' · son gün ' + proje_gun_yazisi(d['son_gun']))
    fm = font(22, True); mw = QFontMetrics(fm).horizontalAdvance(meta)
    text(QRectF(W - 30*k - mw - 4, 18*k, mw + 4, 62*k), meta, fm, '#ffe14d', Qt.AlignRight | Qt.AlignVCenter)
    fA = font(30, True); ax = pill.right() + 24*k; text(QRectF(ax, 18*k, W - 60*k - mw - ax, 62*k), 'Proje seçimi', fA, '#ffffff')
    if not ros:
        text(QRectF(0, 0, W, H), 'Bu sınıfın öğrenci listesi henüz gelmedi', font(32, True), '#9fb3cc', Qt.AlignCenter); return {}
    n = len(ros); top = 100*k; bot = bottom - 70*k; gap = 12*k; best = None
    for cols in range(8, 11):   # fotoğraf en büyük olacak sütun sayısı (adlar okunur kalsın: en çok 10 sütun)
        rows = (n + cols - 1)//cols; cw = (W - 60*k - (cols - 1)*gap)/cols; ch = min(cw*1.6, (bot - top - (rows - 1)*gap)/max(1, rows))
        phh = ch - (22 + 24*(2 if dur == 'dagitildi' else 1))*k; sz = min(cw - 14*k, phh*0.78)*phh
        if best is None or sz > best[0]: best = (sz, cols, cw, ch)
    _, cols, cw, ch = best
    rects = {}; fN = font(15, True); fS = font(13, True)
    for i, (no, ad) in enumerate(ros):
        r = QRectF(30*k + (i % cols)*(cw + gap), top + (i//cols)*(ch + gap), cw, ch)
        dn = (no in sonuc) if dur == 'dagitildi' else (no in ter)
        p.setPen(QPen(QColor('#2fbf71'), 3*k) if dn else Qt.NoPen); p.setBrush(QColor(255, 255, 255, 16)); p.drawRoundedRect(r, 12*k, 12*k)
        lines = 2 if dur == 'dagitildi' else 1
        ph_h = r.height() - (22 + 24*lines)*k; ph_w = min(r.width() - 14*k, ph_h*0.78)   # vesikalık oranı korunur (yüz kesilmez)
        ph = QRectF(r.center().x() - ph_w/2, r.y() + 7*k, ph_w, ph_h)
        draw_photo(p, ph, no, ad, k)
        text(QRectF(r.x() + 4*k, ph.bottom() + 2*k, r.width() - 8*k, 26*k), QFontMetrics(fN).elidedText(ad, Qt.ElideRight, int(r.width() - 10*k)), fN, '#ffffff', Qt.AlignCenter)
        if dur == 'dagitildi':
            s_ = sonuc.get(no) or 'Yerleşmedi'
            text(QRectF(r.x() + 4*k, ph.bottom() + 28*k, r.width() - 8*k, 22*k), QFontMetrics(fS).elidedText(s_, Qt.ElideRight, int(r.width() - 10*k)), fS, '#ffe14d' if no in sonuc else '#ff6b6b', Qt.AlignCenter)
        elif dn:
            c_ = QRectF(r.right() - 46*k, r.y() + 8*k, 38*k, 38*k); p.setPen(Qt.NoPen); p.setBrush(QColor('#2fbf71')); p.drawEllipse(c_)
            p.setPen(QPen(QColor('#06240f'), 4.5*k)); x0, y0 = c_.x(), c_.y()
            p.drawLine(QPointF(x0 + 10*k, y0 + 20*k), QPointF(x0 + 17*k, y0 + 27*k)); p.drawLine(QPointF(x0 + 17*k, y0 + 27*k), QPointF(x0 + 29*k, y0 + 12*k))
        rects[(no, ad)] = r
    hint = {'kapali': 'Öğretmen kontenjanları belirleyip seçimi açınca fotoğrafına dokun', 'acik': 'Fotoğrafına dokun, 3 tercihini yap (değiştirmek için yine dokun)', 'dagitildi': 'Proje derslerin belli oldu'}.get(dur, '')
    text(QRectF(30*k, bottom - 58*k, W - 520*k, 48*k), hint, font(22), '#c9d6ea')
    return rects

# ---- Rastgele öğrenci (sınıf tahtası): fotoğraflar hızla döner, birinde durur; tur bitmeden aynı öğrenci yeniden çıkmaz ----
RASTGELE_SURE = 3.2   # sn: dönme süresi
class RastgeleScreen(QWidget):
    """Tam ekran: 'Öğrenci seç' → fotoğraflar hızla döner, yavaşlar, bir öğrencide durur ('Tahtaya kalk!').
    Bu turda kalkanlar tahtanın hafızasında (data_dir/rastgele-<sınıf>.json); herkes kalkınca yeni tur başlar."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.spin = None; self.cur = None; self.toast = ''
        import random; self.rnd = random.Random()
        st_ = 'QPushButton{background:#1d3150;color:white;border:1px solid #2a4468;border-radius:14px;padding:0 28px;font-size:22px;font-weight:700;}QPushButton:pressed{background:#2a4468;}'
        self.go_b = neon_button(self, self.start, 30); self.go_b.setText('  Öğrenci seç  ')
        self.reset_b = QPushButton('Turu sıfırla', self); self.close_b = QPushButton('Kapat', self)
        for b in (self.reset_b, self.close_b): b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(58); b.setStyleSheet(st_)
        self.reset_b.clicked.connect(self.reset); self.close_b.clicked.connect(self.hide)
        self.timer = QTimer(self); self.timer.setInterval(30); self.timer.timeout.connect(self.tick)
    # hafıza
    def path(self): return os.path.join(self.main.data_dir, 'rastgele-%s.json' % ''.join(c for c in self.main.proje_sinif() if c.isalnum() or c in '-_'))
    def mem(self):
        try:
            with open(self.path(), encoding='utf-8') as f: d = json.load(f)
            if isinstance(d, dict): return d
        except (OSError, ValueError): pass
        return dict(tur=[], gecmis=[], tur_no=1)
    def save(self, d):
        try:
            with open(self.path() + '.tmp', 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)
            os.replace(self.path() + '.tmp', self.path())
        except OSError as e: print('rastgele:', e)
    def ros(self): return self.main.proje_roster()
    def pool(self):
        d = self.mem(); done = set(d.get('tur', [])); return [r for r in self.ros() if r[0] not in done]
    # düzen
    def fit(self, rect): self.setGeometry(rect); self.layout_btns(); self.update()
    def resizeEvent(self, e): self.layout_btns()
    def layout_btns(self):
        W, H = self.width(), self.height()
        self.close_b.adjustSize(); self.close_b.move(W - self.close_b.width() - 64, H - self.close_b.height() - 64)
        self.reset_b.adjustSize(); self.reset_b.move(self.close_b.x() - self.reset_b.width() - 14, self.close_b.y())
        self.go_b.adjustSize(); self.go_b.move((W - self.go_b.width())//2, H - self.go_b.height() - 64)
    # akış
    def start(self):
        if self.spin is not None: return
        ros = self.ros()
        if not ros: self.toast = 'Bu sınıfın öğrenci listesi henüz gelmedi'; self.update(); return
        d = self.mem(); pool = self.pool()
        if not pool:   # tur tamamlandı: yeni tur
            d['tur'] = []; d['tur_no'] = int(d.get('tur_no', 1)) + 1; self.save(d); pool = list(ros); self.toast = 'Herkes kalktı: %d. tur başladı' % d['tur_no']
        else: self.toast = ''
        win = self.rnd.choice(pool)
        # dönen sıra: önce herkesin fotoğrafı hızla, sonra yavaşlayarak kazanana
        n = 34; seq = [self.rnd.choice(ros) for _ in range(n - 1)] + [win]
        for i in range(1, len(seq)):
            if seq[i] == seq[i - 1] and len(ros) > 1: seq[i - 1] = self.rnd.choice([r for r in ros if r != seq[i]])
        t, times = 0.0, []
        for i in range(n): t += 0.03 + 0.42*(i/(n - 1))**3; times.append(t)   # yavaşlayarak
        k = RASTGELE_SURE/times[-1]; self.spin = dict(seq=seq, times=[x*k for x in times], t0=time.monotonic(), win=win)
        self.cur = seq[0]; self.go_b.setEnabled(False); self.timer.start()
    def tick(self):
        sp = self.spin
        if sp is None: self.timer.stop(); return
        el = time.monotonic() - sp['t0']; i = next((j for j, x in enumerate(sp['times']) if x >= el), len(sp['seq']) - 1)
        self.cur = sp['seq'][i]
        if el >= sp['times'][-1] + 0.05:   # durdu: tahtaya kalkar, hafızaya yazılır
            win = sp['win']; self.cur = win; d = self.mem(); d.setdefault('tur', []).append(win[0])
            d.setdefault('gecmis', []).append(dict(no=win[0], ad=win[1], zaman=time.strftime('%Y-%m-%d %H:%M'), tur=d.get('tur_no', 1)))
            d['gecmis'] = d['gecmis'][-500:]; self.save(d); self.spin = None; self.timer.stop(); self.go_b.setEnabled(True); self.go_b.setText('  Yeni öğrenci  ')
            self.layout_btns()
        self.update()
    def reset(self):
        if QMessageBox.question(self, 'Rastgele öğrenci', 'Bu turda kalkanlar sıfırlansın mı? Herkes yeniden seçilebilir.') != QMessageBox.Yes: return
        d = self.mem(); d['tur'] = []; d['tur_no'] = int(d.get('tur_no', 1)) + 1; self.save(d); self.cur = None; self.toast = 'Yeni tur başladı'; self.update()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); return f
        p.fillRect(self.rect(), QColor('#0d1726'))
        draw_rastgele(p, W, H, k, font, self.main.proje_sinif(), self.ros(), self.mem(), self.cur, self.spin is not None, self.toast, self.go_b.y())
        p.end()

def draw_rastgele(p, W, H, k, font, sinif, ros, mem, cur, spinning, toast, bottom):
    def text(r, s_, f, c, al=Qt.AlignCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    fT = font(40, True); tw = QFontMetrics(fT).horizontalAdvance(sinif); pill = QRectF(30*k, 18*k, tw + 48*k, 62*k)
    draw_neon(p, pill, sinif, fT, '#22e8ff', k)
    text(QRectF(pill.right() + 24*k, 18*k, 600*k, 62*k), 'Rastgele öğrenci', font(30, True), '#ffffff', Qt.AlignLeft | Qt.AlignVCenter)
    done = [n_ for n_ in mem.get('tur', []) if n_ in dict(ros)]
    meta = '%d. tur  ·  %d / %d kalktı' % (int(mem.get('tur_no', 1)), len(done), len(ros)); fm = font(22, True)
    text(QRectF(W - 630*k, 18*k, 600*k, 62*k), meta, fm, '#ffe14d', Qt.AlignRight | Qt.AlignVCenter)
    # ortada büyük fotoğraf
    ph_h = min(H*.44, 430*k); ph_w = ph_h*0.78; cx = W/2; top = 142*k
    ph = QRectF(cx - ph_w/2, top, ph_w, ph_h)
    p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 14)); p.drawRoundedRect(ph.adjusted(-18*k, -18*k, 18*k, 18*k), 24*k, 24*k)
    if cur:
        draw_photo(p, ph, cur[0], cur[1], k)
        if not spinning:
            for w_, a_ in ((22, 30), (12, 70), (5, 255)):   # durdu: neon çerçeve
                q = QColor('#22e8ff'); q.setAlpha(a_); p.setPen(QPen(q, w_*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(ph.adjusted(-6*k, -6*k, 6*k, 6*k), 14*k, 14*k)
        text(QRectF(0, ph.bottom() + 24*k, W, 66*k), cur[1], font(52, True), '#ffffff')
        if not spinning: text(QRectF(0, ph.bottom() + 92*k, W, 50*k), 'Tahtaya kalk!', font(34, True), '#ffe14d')
    else:
        text(ph, '?', font(160, True), '#2a4468')
        text(QRectF(0, ph.bottom() + 30*k, W, 60*k), '“Öğrenci seç”e dokunun', font(34, True), '#9fb3cc')
    if toast: text(QRectF(0, 84*k, W, 36*k), toast, font(22, True), '#7ff6ff')
    # bu turda kalkanlar: altta küçük fotoğraflar (son kalkan sağda)
    if done:
        n = len(done); sz = min(64*k, (W - 60*k)/max(1, n) - 6*k); y = bottom - sz*1.3 - 30*k
        text(QRectF(30*k, y - 34*k, 600*k, 30*k), 'Bu turda kalkanlar', font(18, True), '#9fb3cc', Qt.AlignLeft | Qt.AlignVCenter)
        names = dict(ros)
        for i, no in enumerate(done):
            r = QRectF(30*k + i*(sz + 6*k), y, sz, sz*1.28); draw_photo(p, r, no, names.get(no, ''), k)


# ---- K-344: "Atlas'a sor" — yapay zekâ yardımcısı (maskot + yan panel). İstek havuz üzerinden gider, kalem beklemez. ----
ATLAS_PNG = os.path.join(_APP_DIR, 'atlas-maskot.png')
# Maskot görselinde (768×780) gözlerin merkezi ve boyu
ATLAS_GOZ = ((248, 260), (384, 260)); ATLAS_GOZ_RX, ATLAS_GOZ_RY = 30, 40

def ders_bransi(ders):
    x = str(ders or '').replace('İ', 'i').replace('I', 'ı').lower()
    for anah, b in ((('matematik',), 'Matematik'), (('fizik',), 'Fizik'), (('kimya',), 'Kimya'), (('biyoloji',), 'Biyoloji'),
                    (('edebiyat', 'metin tahlil', 'türk dili'), 'Edebiyat'), (('tarih', 'inkılap'), 'Tarih'), (('coğrafya',), 'Coğrafya'),
                    (('felsefe', 'mantık', 'psikoloji', 'sosyoloji'), 'Felsefe'), (('din', "kur'an", 'peygamber', 'ahlak'), 'Din Kültürü'),
                    (('ingilizce', 'almanca', 'yabancı'), 'Yabancı Dil'), (('bilişim',), 'Bilişim')):
        if any(a in x for a in anah): return b
    return ''

ATLAS_SECENEK = {
    'Matematik': ['Çöz', 'Adım adım anlat', 'İpucu ver', 'Benzer 3 soru üret'],
    'Fizik': ['Çöz', 'Adım adım anlat', 'Kavramı açıkla', 'Benzer 3 soru üret'],
    'Kimya': ['Çöz', 'Adım adım anlat', 'Kavramı açıkla', 'Benzer 3 soru üret'],
    'Biyoloji': ['Açıkla', 'Kavram haritası çıkar', 'Kısa özet', '5 soru hazırla'],
    'Edebiyat': ['Şiiri / metni çözümle', 'Söz sanatları', 'Ana fikir ve tema', '5 soru hazırla'],
    'Tarih': ['Açıkla', 'Sebep ve sonuçlar', 'Kronoloji çıkar', '5 soru hazırla'],
    'Coğrafya': ['Açıkla', 'Örnekle anlat', 'Kısa özet', '5 soru hazırla'],
    'Felsefe': ['Kavramı açıkla', 'Filozofları karşılaştır', 'Tartışma soruları', 'Düşünce deneyi öner'],
    'Din Kültürü': ['Açıkla', 'Kısa özet', 'Örnekle anlat', '5 soru hazırla'],
    'Yabancı Dil': ['Türkçeye çevir', 'Dil bilgisini açıkla', 'Kelime listesi çıkar', '5 alıştırma hazırla'],
    'Bilişim': ['Açıkla', 'Adım adım anlat', 'Örnek ver', '5 soru hazırla'],
    '': ['Açıkla', 'Adım adım anlat', 'Kısa özet', '5 soru hazırla'],
}

class AtlasMaskot(QWidget):
    """Maskot: gövde tek resim (yeniden çizilmez); yalnız gözler QPainter ile canlanır.
    İfadeler: bekleme, dinleme, dusunme, konusma, mutluluk, sasirma (+ kendiliğinden göz kırpma)."""
    IFADE = {'bekleme': (15, 20, 0, 0, 0), 'dinleme': (17.5, 23.5, 0, 1, 0), 'dusunme': (13, 17, 12, -11, 0),
             'konusma': (15, 19, 0, 0, 0), 'mutluluk': (15, 20, 0, -2, 1), 'sasirma': (19, 19, 0, -3, 0)}
    def __init__(self, parent=None):
        super().__init__(parent); self.setAttribute(Qt.WA_TranslucentBackground)
        self.govde = QPixmap(ATLAS_PNG); self._olcekli = None
        self.ad = 'bekleme'; self.su = list(self.IFADE['bekleme']); self.t0 = time.monotonic()
        self.kirp_t = -9; self.sonraki = 3.0
        self.zaman = QTimer(self); self.zaman.setInterval(40); self.zaman.timeout.connect(self.tik)
    def ifade(self, ad):
        if ad in self.IFADE: self.ad = ad
    def showEvent(self, e): self.zaman.start(); super().showEvent(e)
    def hideEvent(self, e): self.zaman.stop(); super().hideEvent(e)
    def tik(self):
        h = self.IFADE[self.ad]; self.su = [a + (b - a)*0.18 for a, b in zip(self.su, h)]; self.update()
    def paintEvent(self, e):
        if self.govde.isNull(): return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
        t = time.monotonic() - self.t0
        k = min(self.width()/768, self.height()/780)
        w, h = int(768*k), int(780*k)
        if self._olcekli is None or self._olcekli.width() != w: self._olcekli = self.govde.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        ox = (self.width() - w)/2; oy = (self.height() - h)/2 + math.sin(t*1.6)*3*k*4
        p.drawPixmap(int(ox), int(oy), self._olcekli)
        rx, ry, dx, dy, yay = self.su
        kap = 1.0
        if self.ad in ('bekleme', 'dinleme', 'konusma'):
            if t > self.sonraki: self.kirp_t = t; self.sonraki = t + 3 + (hash(int(t)) % 300)/100
            g = t - self.kirp_t
            if g < 0.16: kap = max(0.08, abs(1 - g/0.08))
        if self.ad == 'konusma': ry *= 1 + 0.1*math.sin(t*9); dx += math.sin(t*1.4)*1.5
        if self.ad == 'dusunme': dx += math.sin(t*1.1)*3
        renk = QColor('#7ff0ff')
        for cx, cy in ATLAS_GOZ:
            x = ox + (cx + dx*2)*k; y = oy + (cy + dy*2)*k
            if yay < 0.5:
                for kal, op in ((10, 0.18), (5, 0.3), (0, 1.0)):
                    c = QColor(renk); c.setAlphaF(op); p.setPen(Qt.NoPen); p.setBrush(c)
                    p.drawEllipse(QPointF(x, y), (rx*2 + kal)*k, max(1.5, (ry*2*kap + kal))*k)
            else:
                yol = QPolygonF([QPointF(x + (-40 + 80*i/16)*k, y + (12 - 28*(1 - ((i - 8)/8)**2))*k) for i in range(17)])
                for kal, op in ((14, 0.18), (0, 1.0)):
                    c = QColor(renk); c.setAlphaF(op); p.setPen(QPen(c, (24 + kal)*k, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.setBrush(Qt.NoBrush)
                    p.drawPolyline(yol)
        p.end()

# K-348: Atlas cevabındaki düz yazı matematiği tahtada okunur yapılır (x^2 → x², -> → ⇒, 2*a → 2·a, a - b → a − b).
_UST = str.maketrans('0123456789-+()n', '⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺⁽⁾ⁿ')
def atlas_guzel(t):
    import re
    t = re.sub(r'\^\((-?\d+|n)\)', lambda m: m.group(1).translate(_UST), t)
    t = re.sub(r'\^(-?\d+|n)', lambda m: m.group(1).translate(_UST), t)
    t = t.replace('->', '⇒').replace('=>', '⇒').replace('>=', '≥').replace('<=', '≤').replace('!=', '≠')
    t = t.replace('sqrt(', '√(')
    t = re.sub(r'(?<=[\w)²³¹⁰-⁹])\s*\*\s*(?=[\w(√])', '·', t)
    t = re.sub(r'(?<=[\w)²³⁰-⁹]) - (?=[\w(√])', ' − ', t)
    t = re.sub(r'(?<=[=(,\s])-(?=[\d(√]|[a-z](?![a-zçğıöşü]))', '−', t)
    t = re.sub(r'(?<=[a-z0-9)])-(?=\d)', '−', t)
    return t

# K-349: Atlas cevaplarını matematik kitabı gibi dizer: $...$ içindeki LaTeX (kesir üst üste, üs yukarıda, kök işareti),
# düz yazı el yazısıyla, satırlar kelime kelime kırılır. Çizim arka uçtan bağımsız: olc(metin, boy) → genişlik;
# sonuç [('t', x, y_taban, metin, boy), ('l', x1, y1, x2, y2, kalınlık)] listesi. Atlas'ta QPainter çizer.
FORMUL_KOMUT = {'cdot': '·', 'times': '×', 'div': '÷', 'pm': '±', 'mp': '∓', 'le': '≤', 'leq': '≤', 'ge': '≥', 'geq': '≥', 'neq': '≠', 'ne': '≠',
    'Rightarrow': '⇒', 'implies': '⇒', 'rightarrow': '→', 'to': '→', 'Leftrightarrow': '⇔', 'iff': '⇔', 'approx': '≈', 'infty': '∞', 'pi': 'π',
    'alpha': 'α', 'beta': 'β', 'gamma': 'γ', 'delta': 'δ', 'Delta': 'Δ', 'theta': 'θ', 'lambda': 'λ', 'mu': 'μ', 'sigma': 'σ', 'Sigma': 'Σ',
    'omega': 'ω', 'Omega': 'Ω', 'phi': 'φ', 'varphi': 'φ', 'epsilon': 'ε', 'varepsilon': 'ε', 'rho': 'ρ', 'tau': 'τ', 'circ': '°', 'degree': '°',
    'in': '∈', 'notin': '∉', 'cup': '∪', 'cap': '∩', 'subset': '⊂', 'emptyset': '∅', 'varnothing': '∅', 'mathbb': '', 'angle': '∠', 'perp': '⊥',
    'parallel': '∥', 'cdots': '⋯', 'ldots': '…', 'dots': '…', '%': '%', '{': '{', '}': '}', ',': ' ', ';': ' ', ':': ' ', '!': '', ' ': ' ',
    'quad': '  ', 'qquad': '    ', 'left': '', 'right': '', 'displaystyle': '', 'limits': '', 'sin': 'sin', 'cos': 'cos', 'tan': 'tan', 'cot': 'cot',
    'log': 'log', 'ln': 'ln', 'lim': 'lim', 'max': 'max', 'min': 'min', 'R': 'ℝ', 'N': 'ℕ', 'Z': 'ℤ', 'Q': 'ℚ', 'mid': '|', 'vert': '|', '|': '‖'}
_BAGLAC = set('=<>≤≥≠⇒→⇔≈∈∉⊂')   # iki yanına boşluk
_ISLEM = set('+−±∓×÷·∪∩')

def formul_coz(s):
    """LaTeX alt kümesini ağaca çevirir: ('m', metin) | ('kesir', a, b) | ('kok', a) | ('us', taban, us) | ('alt', taban, alt) | ('g', [..])."""
    i = 0; n = len(s)
    def grup():
        nonlocal i
        oge = []
        while i < n:
            c = s[i]
            if c == '}': i += 1; return oge
            if c == '{': i += 1; oge.append(('g', grup())); continue
            if c in '^_':
                i += 1; arg = tek()
                taban = oge.pop() if oge else ('m', '')
                if taban[0] == 'm' and len(taban[1]) > 1 and c == '^':   # "x2^3" gibi: üs yalnız son karaktere
                    oge.append(('m', taban[1][:-1])); taban = ('m', taban[1][-1])
                oge.append(('us' if c == '^' else 'alt', taban, arg)); continue
            if c == '\\':
                i += 1; j = i
                if i < n and not s[i].isalpha(): i += 1
                else:
                    while i < n and s[i].isalpha(): i += 1
                k = s[j:i]
                if k in ('frac', 'dfrac', 'tfrac'): a = tek(); b = tek(); oge.append(('kesir', a, b)); continue
                if k == 'sqrt':
                    if i < n and s[i] == '[':   # \sqrt[3]{x}
                        e = s.find(']', i); kok_derece = s[i+1:e] if e > 0 else ''; i = e + 1 if e > 0 else i
                    else: kok_derece = ''
                    oge.append(('kok', tek(), kok_derece)); continue
                if k in ('text', 'mathrm', 'textbf', 'mathbf', 'operatorname', 'mbox'): oge.append(('yazi', metin_al())); continue
                if k == 'mathbb': a = metin_al(); oge.append(('m', ''.join(FORMUL_KOMUT.get(ch, ch) for ch in a))); continue
                oge.append(('m', FORMUL_KOMUT.get(k, k))); continue
            if c == ' ': i += 1; continue
            j = i
            while i < n and s[i] not in '{}^_\\ ': i += 1
            oge.append(('m', s[j:i].replace('-', '−').replace('*', '·')))
        return oge
    def tek():
        nonlocal i
        while i < n and s[i] == ' ': i += 1
        if i >= n: return ('m', '')
        if s[i] == '{': i += 1; return ('g', grup())
        if s[i] == '\\':
            j = i; i += 1
            while i < n and s[i].isalpha(): i += 1
            k = s[j+1:i]; return ('m', FORMUL_KOMUT.get(k, k))
        i += 1; return ('m', s[i-1].replace('-', '−'))
    def metin_al():
        nonlocal i
        while i < n and s[i] == ' ': i += 1
        if i < n and s[i] == '{':
            d = 1; j = i + 1; i += 1
            while i < n and d:
                d += {'{': 1, '}': -1}.get(s[i], 0); i += 1
            return s[j:i-1]
        return tek()[1]
    return ('g', grup())

class _Kutu:
    __slots__ = ('w', 'a', 'd', 'op')
    def __init__(self, w=0.0, a=0.0, d=0.0, op=None): self.w, self.a, self.d, self.op = w, a, d, op or []
    def ekle(self, k, x, y):
        for o in k.op:
            if o[0] == 't': self.op.append(('t', o[1] + x, o[2] + y, o[3], o[4]))
            else: self.op.append(('l', o[1] + x, o[2] + y, o[3] + x, o[4] + y, o[5]))

def formul_diz(agac, boy, olc):
    """Ağacı kutuya dizer (taban çizgisi y=0, yukarısı eksi)."""
    son = ['']   # son yazılan işaret: tekli eksi / artı (= −b, (−4)) boşluksuz yazılır
    def metin(t, s):
        k = _Kutu(); x = 0.0
        for ch_grup in _parcala(t):
            pay = 0.0
            if ch_grup in _BAGLAC: pay = 0.28*s
            elif ch_grup in _ISLEM and not (ch_grup in '−+±' and (son[0] == '' or son[0] in _BAGLAC or son[0] in '(,[')): pay = 0.18*s
            x += pay
            if ch_grup.strip(): k.op.append(('t', x, 0.0, ch_grup, s)); son[0] = ch_grup.strip()[-1]
            x += olc(ch_grup, s) + pay
            if ch_grup.endswith((',', ';')): x += 0.22*s   # (0, 3)
        k.w = x; k.a = 0.74*s; k.d = 0.24*s; return k
    def us_kur(t, ust, s, tur):
        es = max(13.0, s*0.64); sk = son[0]; son[0] = ''; u = diz(ust, es); son[0] = sk; k = _Kutu(); k.ekle(t, 0, 0)
        if tur == 'us':
            yuk = max(0.42*s, t.a - 0.45*es) if t.a > 0.8*s else 0.42*s   # kesir / büyük parantez üstünde daha yukarı
            k.ekle(u, t.w + 0.04*s, -yuk); k.a = max(t.a, yuk + u.a); k.d = t.d
        else:
            k.ekle(u, t.w + 0.02*s, 0.22*s); k.a = t.a; k.d = max(t.d, 0.22*s + u.d)
        k.w = t.w + 0.06*s + u.w; return k
    def parantez_kutu(ch, A, D, s):
        ps = (A + D)*1.02; orta = (D - A)/2; y = orta + 0.26*ps   # yazı ortası taban çizgisinin ~0.26 boy üstünde
        k = _Kutu(olc(ch, ps), A + 0.04*s, D + 0.04*s); k.op.append(('t', 0.0, y, ch, ps)); return k
    def diz(d, s):
        tur = d[0]
        if tur == 'm': return metin(d[1], s)
        if tur == 'yazi':
            k = _Kutu(olc(d[1], s), 0.74*s, 0.24*s); k.op.append(('t', 0.0, 0.0, d[1], s)); return k
        if tur == 'g':
            kutular = [diz(e, s) for e in d[1]]
            # kesir gibi uzun ifadeleri saran parantezler büyür (matematik kitabındaki gibi)
            ici = [c for e, c in zip(d[1], kutular) if not _parantez(e)]
            A = max([c.a for c in ici] or [0.74*s]); D = max([c.d for c in ici] or [0.24*s])
            if A + D > 1.3*s:
                for j, e in enumerate(d[1]):
                    if _parantez(e) == 'm': kutular[j] = parantez_kutu(e[1], A, D, s)
                    elif _parantez(e) == 'us': kutular[j] = us_kur(parantez_kutu(e[1][1], A, D, s), e[2], s, 'us')
            k = _Kutu(); x = 0.0
            for c in kutular: k.ekle(c, x, 0.0); x += c.w; k.a = max(k.a, c.a); k.d = max(k.d, c.d)
            k.w = x
            if not d[1]: k.a, k.d = 0.74*s, 0.24*s
            return k
        if tur in ('us', 'alt'):
            return us_kur(diz(d[1], s), d[2], s, tur)
        if tur == 'kesir':
            es = max(15.0, s*0.9)
            son[0] = ''; a = diz(d[1], es); son[0] = ''; b = diz(d[2], es); son[0] = 'x'; eks = -0.30*s; bos = 0.14*s; kal = max(1.6, s*0.06)
            gen = max(a.w, b.w) + 0.24*s; k = _Kutu(gen + 0.24*s)
            ya = eks - bos - a.d; yb = eks + bos + b.a
            k.ekle(a, 0.12*s + (gen - a.w)/2, ya); k.ekle(b, 0.12*s + (gen - b.w)/2, yb)
            k.op.append(('l', 0.12*s, eks, 0.12*s + gen, eks, kal))
            k.a = -ya + a.a; k.d = yb + b.d; return k
        if tur == 'kok':
            son[0] = ''; g = diz(d[1], s); son[0] = 'x'; kal = max(1.6, s*0.06); ust = g.a + 0.14*s; alt = g.d
            sol = 0.62*s; k = _Kutu()
            if d[2]:
                dr = diz(('m', d[2]), max(12.0, s*0.5)); k.ekle(dr, 0.02*s, -0.42*s)
            pts = [(0.04*s, -0.30*s), (0.18*s, -0.38*s), (0.36*s, alt), (0.56*s, -ust), (sol + g.w + 0.08*s, -ust)]
            for (x1, y1), (x2, y2) in zip(pts, pts[1:]): k.op.append(('l', x1, y1, x2, y2, kal))
            k.ekle(g, sol, 0); k.w = sol + g.w + 0.14*s; k.a = ust + kal; k.d = max(g.d, alt + kal); return k
        return _Kutu()
    return diz(agac, boy)

def _parantez(e):
    if e[0] == 'm' and e[1] in ('(', ')', '[', ']', '|'): return 'm'
    if e[0] == 'us' and e[1][0] == 'm' and e[1][1] in (')', ']', '|'): return 'us'
    return ''

def _parcala(t):
    """Metni bağlaç / işlem işaretleri ve geri kalan parçalar olarak böler."""
    out = []; tam = ''
    for ch in t:
        if ch in _BAGLAC or ch in _ISLEM or ch in ',;':
            if tam: out.append(tam); tam = ''
            out.append(ch)
        else: tam += ch
    if tam: out.append(tam)
    return out

def cevap_diz(cevap, genislik, boy, olc, duzelt=lambda t: t, stil=None):
    """Bütün cevabı dizer: paragraflar, kelime kelime satır kırma, $...$ formülleri kutu olarak.
    stil (isteğe bağlı): baslik / madde / cevap renkleri, satir / paragraf aralık çarpanları.
    Döner: (yükseklik, op listesi) — ('t', x, y, metin, boy, renk|None), ('l', ...), ('k', x0, y0, x1, y1, renk) çerçeve."""
    import re
    st = dict(baslik=None, madde=None, cevap=None, satir=1.0, paragraf=1.0, par_ara=0.0); st.update(stil or {})
    op = []; y = 0.0; ara = boy*0.42*st['satir']
    bosluk = olc(' ', boy)
    for par in cevap.replace('**', '').replace('$$', '$').split('\n'):
        duz = par.strip()
        if not duz: y += boy*0.55*st['paragraf']; continue
        cevap_mi = bool(re.match(r'^(Cevap|Sonuç)\s*:', duz)) and st['cevap'] is not None
        baslik_mi = duz.endswith(':') and len(duz) < 80 and st['baslik'] is not None
        if op: y += boy*st['par_ara']   # dolu paragraflar arası (madde madde ferah)
        if baslik_mi and op: y += boy*0.35*st['paragraf']
        if cevap_mi: y += boy*0.3*st['paragraf']
        ic = boy*0.55 if cevap_mi else 0.0   # cevap kutusunun iç boşluğu
        gen = genislik - 2*ic
        ogeler = []   # (kutu, öncesinde boşluk var mı)
        parca = par.split('$'); ilk_kelime = True
        for i, p in enumerate(parca):
            if i % 2 == 1 and i < len(parca) - 1:   # formül
                kt = formul_diz(formul_coz(p), boy, olc)
                if kt.w > gen:   # sığmazsa küçült
                    kt = formul_diz(formul_coz(p), max(14.0, boy*gen/kt.w*0.98), olc)
                ogeler.append((kt, True)); ilk_kelime = False
            else:
                if i % 2 == 1: p = '$' + p
                p = duzelt(p)
                ilk = True
                for kel in p.split(' '):
                    if not kel: ilk = False; continue
                    renk = None
                    if baslik_mi: renk = st['baslik']
                    elif ilk_kelime and kel in ('•', '-', '·') and st['madde']: renk = st['madde']; kel = '•'
                    elif ilk_kelime and re.match(r'^\d+[.)]$', kel) and st['baslik']: renk = st['baslik']
                    elif ilk_kelime and cevap_mi: renk = st['cevap']
                    k = _Kutu(olc(kel, boy), 0.74*boy, 0.24*boy); k.op.append(('t', 0.0, 0.0, kel, boy, renk))
                    ogeler.append((k, not ilk or p.startswith(' '))); ilk = False; ilk_kelime = False
        girinti = 0.0
        if duz[:1] in '•-·' or re.match(r'^\d+[.)]\s', duz): girinti = olc(duz.split(' ')[0] + ' ', boy)
        y0 = y; satir = []; x = 0.0
        def bitir(satir):
            nonlocal y
            if not satir: return
            a = max(k.a for _, k in satir); d = max(k.d for _, k in satir)
            yb = y + a
            for xx, k in satir:
                for o in k.op:
                    if o[0] == 't': op.append(('t', o[1] + xx + ic, o[2] + yb, o[3], o[4], o[5] if len(o) > 5 else None))
                    else: op.append(('l', o[1] + xx + ic, o[2] + yb, o[3] + xx + ic, o[4] + yb, o[5]))
            y = yb + d + ara*0.5
        if cevap_mi: y += ic*0.6
        for k, bsl in ogeler:
            once = bosluk if (satir and bsl) else 0.0
            if satir and x + once + k.w > gen:
                bitir(satir); satir = []; x = girinti; once = 0.0
            satir.append((x + once, k)); x += once + k.w
        bitir(satir)
        if cevap_mi:
            y += ic*0.4; op.append(('k', 0.0, y0, genislik, y, st['cevap'])); y += boy*0.3
    return y, op

# K-350: "Tahtaya yaz": Atlas'ın cevabı tek çizgili el yazısı fontuyla (Relief SingleLine, OFL) gerçek kalem çizgilerine çevrilir;
# tahtada silinir, taşınır, Geri al ile kalkar, PDF'e aynen geçer.
_TEK_CIZGI = {}
def tek_cizgi_font(yol):
    """SVG fonttan karakter → (ilerleme, [çoklu çizgi]) (font birimi, y yukarı)."""
    if _TEK_CIZGI.get('_yol') == yol: return _TEK_CIZGI
    import re, html
    _TEK_CIZGI.clear(); _TEK_CIZGI['_yol'] = yol
    try: s = open(yol, encoding='utf-8').read()
    except OSError: return _TEK_CIZGI
    v = re.search(r'<font\b[^>]*horiz-adv-x="([^"]*)"', s); varsayilan = float(v.group(1)) if v else 500.0
    for g in re.finditer(r'<glyph\b([^>]*)/?>', s):
        a = g.group(1); u = re.search(r'unicode="([^"]*)"', a); d = re.search(r'\sd="([^"]*)"', a); w = re.search(r'horiz-adv-x="([^"]*)"', a)
        if not u: continue
        ch = html.unescape(u.group(1))
        if len(ch) != 1: continue
        _TEK_CIZGI[ch] = (float(w.group(1)) if w else varsayilan, _yol_coz(d.group(1)) if d else [])
    # fontta olmayan: ⇒ (iki çizgi + ok başı)
    _TEK_CIZGI['⇒'] = (760.0, [[(90, 330), (560, 330)], [(90, 170), (560, 170)], [(470, 470), (670, 250), (470, 30)]])
    # fontta olmayan öteki işaretler (Δ…): Hershey çizgi yazısından (büyük harf 21 birim, taban y=9) ölçeklenir
    hs = globals().get('HERSHEY') or {}
    k = 680/21.0
    for ch, (adv, polys) in hs.items():
        if ch not in _TEK_CIZGI and len(ch) == 1:
            _TEK_CIZGI[ch] = (adv*k, [[(gx*k, (9 - gy)*k) for gx, gy in poly] for poly in polys])
    return _TEK_CIZGI

def _yol_coz(d):
    import re
    t = re.findall(r'[MmLlHhVvCcSsQqTtZz]|-?\d*\.?\d+(?:[eE][-+]?\d+)?', d)
    out = []; cur = []; x = y = 0.0; sx = sy = 0.0; komut = None; i = 0; onc = None
    def sayi():
        nonlocal i
        v = float(t[i]); i += 1; return v
    def kubik(p0, p1, p2, p3, n=10):
        return [((1-u)**3*p0[0] + 3*(1-u)**2*u*p1[0] + 3*(1-u)*u*u*p2[0] + u**3*p3[0], (1-u)**3*p0[1] + 3*(1-u)**2*u*p1[1] + 3*(1-u)*u*u*p2[1] + u**3*p3[1]) for u in (k/n for k in range(1, n+1))]
    while i < len(t):
        if t[i].isalpha(): komut = t[i]; i += 1
        rel = komut.islower(); c = komut.upper()
        if c == 'Z':
            if cur: cur.append((sx, sy))
            x, y = sx, sy; continue
        bx, by = (x, y) if rel else (0.0, 0.0)
        if c == 'M':
            if len(cur) > 1: out.append(cur)
            x, y = bx + sayi(), by + sayi(); sx, sy = x, y; cur = [(x, y)]; komut = 'l' if rel else 'L'; onc = None; continue
        if c == 'L': x, y = bx + sayi(), by + sayi(); cur.append((x, y)); onc = None
        elif c == 'H': x = bx + sayi(); cur.append((x, y)); onc = None
        elif c == 'V': y = (y if rel else 0.0) + sayi(); cur.append((x, y)); onc = None
        elif c == 'C':
            p1 = (bx + sayi(), by + sayi()); p2 = (bx + sayi(), by + sayi()); p3 = (bx + sayi(), by + sayi())
            cur += kubik((x, y), p1, p2, p3); onc = p2; x, y = p3
        elif c == 'S':
            p1 = (2*x - onc[0], 2*y - onc[1]) if onc else (x, y); p2 = (bx + sayi(), by + sayi()); p3 = (bx + sayi(), by + sayi())
            cur += kubik((x, y), p1, p2, p3); onc = p2; x, y = p3
        elif c == 'Q':
            q = (bx + sayi(), by + sayi()); p3 = (bx + sayi(), by + sayi())
            cur += kubik((x, y), (x + 2/3*(q[0]-x), y + 2/3*(q[1]-y)), (p3[0] + 2/3*(q[0]-p3[0]), p3[1] + 2/3*(q[1]-p3[1])), p3); onc = None; x, y = p3
        elif c == 'T':
            p3 = (bx + sayi(), by + sayi()); cur.append(p3); x, y = p3; onc = None
        else: i += 1
    if len(cur) > 1: out.append(cur)
    return out

def tek_cizgi_olcer(yol):
    f = tek_cizgi_font(yol)
    def olc(t, boy): return sum(f.get(ch, f.get('?', (500.0, [])))[0] for ch in t)*boy/1000.0
    return olc

def murekkep_cizgileri(cevap, genislik, boy, renk, kalinlik, yol, duzelt=lambda t: t):
    """Cevabı kalem çizgilerine çevirir: [{'tool': 'pen', 'color', 'width', 'points'}], sol üst (0, 0)."""
    f = tek_cizgi_font(yol); olc = tek_cizgi_olcer(yol)
    h, op = cevap_diz(cevap, genislik, boy, olc, duzelt, dict(satir=2.3, paragraf=1.5, par_ara=0.45))   # tahtada ferah: satırlar iç içe girmesin
    out = []
    for o in op:
        if o[0] == 't':
            x = o[1]; k = o[4]/1000.0
            for ch in o[3]:
                adv, cizgiler = f.get(ch, f.get('?', (500.0, [])))
                for c in cizgiler:
                    out.append(dict(tool='pen', color=renk, width=kalinlik*(o[4]/boy)**0.5, points=[[round(x + gx*k, 2), round(o[2] - gy*k, 2)] for gx, gy in c]))
                x += adv*k
        elif o[0] == 'l':
            out.append(dict(tool='pen', color=renk, width=kalinlik, points=[[o[1], o[2]], [o[3], o[4]]]))
    return out, h

_ATLAS_FONT = {}
def _atlas_font(boy, yedek=False):
    from PyQt5.QtGui import QFont
    k = (yedek, int(round(boy)))
    if k not in _ATLAS_FONT:
        f = QFont('DejaVu Sans' if yedek else (ui_fonts().get('PatrickHand-Regular') or 'DejaVu Sans')); f.setPixelSize(max(8, k[1])); _ATLAS_FONT[k] = f
    return _ATLAS_FONT[k]
def _atlas_kos(t, boy):
    """Metni (parça, font) kümelerine böler: el yazısı fontunda olmayan işaretler (⇒, ∞…) DejaVu Sans ile."""
    from PyQt5.QtGui import QFontMetricsF
    ana = _atlas_font(boy); fm = QFontMetricsF(ana); out = []
    for ch in t:
        f = ana if fm.inFontUcs4(ord(ch)) else _atlas_font(boy, True)
        if out and out[-1][1] is f: out[-1][0] += ch
        else: out.append([ch, f])
    return out
def _atlas_olc(t, boy):
    from PyQt5.QtGui import QFontMetricsF
    return sum(QFontMetricsF(f).width(c) for c, f in _atlas_kos(t, boy))
ATLAS_STIL = dict(baslik='#7ff6ff', madde='#22e8ff', cevap='#3ef08a', satir=1.15, paragraf=1.1)
ATLAS_STIL_TAM = dict(ATLAS_STIL, satir=1.6, paragraf=1.7, par_ara=0.3)   # tam ekran: kitap gibi ferah
def atlas_cevap_resmi(cevap, genislik, boy=27, renk='#eef6ff', formul=True, stil=None):
    """K-349: cevabı matematik kitabı düzeninde (kesir üst üste, üs yukarıda, kök işareti) el yazısıyla çizer; saydam QImage.
    K-350: başlıklar camgöbeği, madde işaretleri, "Cevap:" yeşil çerçevede."""
    metin = cevap if formul else cevap.replace('$', '＄')
    h, op = cevap_diz(metin, genislik - 12, boy, _atlas_olc, atlas_guzel, stil)
    im = QImage(int(genislik) + 2, max(1, int(h + boy*0.4)), QImage.Format_ARGB32_Premultiplied); im.fill(Qt.transparent)
    p = QPainter(im); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
    c = QColor(renk); p.translate(6, 0)
    for o in op:
        if o[0] == 't':
            x = o[1]; p.setPen(QColor(o[5]) if len(o) > 5 and o[5] else c)
            for parca, f in _atlas_kos(o[3], o[4]):
                p.setFont(f); p.drawText(QPointF(x, o[2]), parca); x += _atlas_olc(parca, o[4])
        elif o[0] == 'k':
            kc = QColor(o[5]); dolgu = QColor(kc); dolgu.setAlpha(28)
            p.setPen(QPen(kc, max(2.0, boy*0.08))); p.setBrush(dolgu); p.drawRoundedRect(QRectF(o[1] - 4, o[2], o[3] - o[1] + 8, o[4] - o[2]), boy*0.5, boy*0.5); p.setBrush(Qt.NoBrush)
        else:
            p.setPen(QPen(c, o[5], Qt.SolidLine, Qt.RoundCap)); p.drawLine(QPointF(o[1], o[2]), QPointF(o[3], o[4]))
    p.end(); return im

class AtlasCevap(QFrame):
    """Cevap kutusu: QTextBrowser yerine; formüller çizilir, parmakla kaydırılır. setPlainText ile aynı kullanım.
    Tam ekranda yazı büyür, satır araları açılır, metin ortada kitap sayfası genişliğinde durur."""
    def __init__(self, parent=None):
        super().__init__(parent)
        from PyQt5.QtWidgets import QScrollArea, QScroller
        self.setObjectName('atlasCevap'); self.setStyleSheet('#atlasCevap{background:#0a1628;border:1px solid #2a4468;border-radius:14px;}')
        v = QVBoxLayout(self); v.setContentsMargins(12, 10, 6, 10)
        self.alan = QScrollArea(); self.alan.setWidgetResizable(False); self.alan.setFrameShape(QFrame.NoFrame)
        self.alan.setStyleSheet('QScrollArea{background:transparent;} QScrollArea > QWidget > QWidget{background:transparent;}'
                                'QScrollBar:vertical{background:transparent;width:10px;margin:4px 0;} QScrollBar::handle:vertical{background:#2a6f8a;border-radius:5px;min-height:40px;}'
                                'QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;} QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical{background:none;}')
        self.alan.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.resim = QLabel(); self.resim.setStyleSheet('background:transparent;'); self.alan.setWidget(self.resim); v.addWidget(self.alan)
        QScroller.grabGesture(self.alan.viewport(), QScroller.LeftMouseButtonGesture)
        self.metin = ''; self.formul = False; self._gen = 0; self.tam = False
    def tam_ekran(self, tam):
        self.tam = tam; self.setStyleSheet('#atlasCevap{background:%s;border:1px solid #2a4468;border-radius:22px;}' % ('#0b1a30' if tam else '#0a1628'))
        self.layout().setContentsMargins(*((40, 30, 20, 30) if tam else (12, 10, 6, 10))); QTimer.singleShot(0, self._ciz)
    def setPlainText(self, t, formul=False):
        self.metin = t or ''; self.formul = formul; self._ciz(); self.alan.verticalScrollBar().setValue(0)
    def toPlainText(self): return self.metin
    def _ciz(self):
        g = max(200, self.alan.width() - 22); self._gen = g   # kaydırma çubuğu çıksa da kesilmesin
        if self.tam:
            sayfa = min(g, 1250)   # kitap sayfası genişliği; ortada
            im = atlas_cevap_resmi(self.metin, sayfa, 38, '#eef6ff', self.formul, ATLAS_STIL_TAM)
            self.resim.setPixmap(QPixmap.fromImage(im)); self.resim.setFixedSize(g, im.height()); self.resim.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        else:
            im = atlas_cevap_resmi(self.metin, g, 27, '#eef6ff', self.formul, ATLAS_STIL)
            self.resim.setPixmap(QPixmap.fromImage(im)); self.resim.setFixedSize(im.width(), im.height()); self.resim.setAlignment(Qt.AlignLeft | Qt.AlignTop)
    def resizeEvent(self, e):
        super().resizeEvent(e)
        if abs(self.alan.width() - 22 - self._gen) > 4: QTimer.singleShot(0, self._ciz)

class AtlasPanel(QFrame):
    """Sağdan açılan 'Atlas'a sor' paneli. Tahtanın geri kalanı yazmaya açık kalır."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.resim = None; self.bekleyen = None; self.son_istek = None; self.cevap = ''; self.grafik = []; self.son_derin = False
        self.setObjectName('atlasPanel')
        self.setStyleSheet('#atlasPanel{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #112540,stop:1 #0b182b);border-left:3px solid #22e8ff;}'
                           'QLabel{color:#eef6ff;} QPushButton{color:#eef6ff;background:#0e2038;border:1.5px solid #2a4468;border-radius:14px;padding:9px 14px;font-size:19px;font-weight:700;}'
                           'QPushButton:pressed{background:#1d3150;} QPushButton#birincil{background:#22e8ff;color:#04202a;border-color:#22e8ff;}'
                           'QPushButton#secenek{border-color:#22e8ff;color:#7ff6ff;border-radius:18px;padding:8px 14px;font-size:18px;}'
                           'QLineEdit{background:#0a1628;color:#eef6ff;border:1.5px solid #2a4468;border-radius:12px;padding:10px;font-size:20px;}'
                           'QTextBrowser{background:#0a1628;color:#eef6ff;border:1px solid #2a4468;border-radius:14px;padding:10px;font-size:22px;}')
        from PyQt5.QtWidgets import QTextBrowser
        v = QVBoxLayout(self); v.setContentsMargins(18, 14, 18, 14); v.setSpacing(10)
        ust = QHBoxLayout(); ust.setSpacing(10)
        self.maskot = AtlasMaskot(self); self.maskot.setFixedSize(150, 152); ust.addWidget(self.maskot)
        bas = QVBoxLayout(); bas.setSpacing(2)
        t = QLabel('Atlas'); t.setStyleSheet('font-size:30px;font-weight:800;color:#7ff6ff;'); bas.addWidget(t); self.baslik = t
        self.ders = QLabel(''); self.ders.setStyleSheet('font-size:17px;color:#9fb3cc;'); bas.addWidget(self.ders)
        self.durum = QLabel(''); self.durum.setWordWrap(True); self.durum.setStyleSheet('font-size:17px;color:#ffb867;'); bas.addWidget(self.durum)
        bas.addStretch(1); ust.addLayout(bas, 1)
        self.tam = False   # K-350: tam ekran (öğrencilere kitap gibi ferah anlatım)
        self.tam_b = QPushButton('⤢ Tam ekran'); self.tam_b.setFixedHeight(52); self.tam_b.setFocusPolicy(Qt.NoFocus); self.tam_b.setStyleSheet('QPushButton{border-color:#22e8ff;color:#7ff6ff;}')
        self.tam_b.clicked.connect(lambda: self.tam_ekran(not self.tam)); ust.addWidget(self.tam_b, 0, Qt.AlignTop)
        kapat = QPushButton('✕'); kapat.setFixedSize(52, 52); kapat.setFocusPolicy(Qt.NoFocus); kapat.clicked.connect(self.kapat); ust.addWidget(kapat, 0, Qt.AlignTop)
        v.addLayout(ust)
        self.onizleme = QLabel(); self.onizleme.setAlignment(Qt.AlignCenter); self.onizleme.setStyleSheet('background:#ffffff;border-radius:10px;padding:4px;'); self.onizleme.hide(); v.addWidget(self.onizleme)
        self.secenekler = QGridLayout(); self.secenekler.setSpacing(8); v.addLayout(self.secenekler)
        sat = QHBoxLayout(); sat.setSpacing(8)
        self.giris = QLineEdit(); self.giris.setPlaceholderText("Atlas'a yazarak sor…"); self.giris.returnPressed.connect(lambda: self.sor(self.giris.text()))
        sat.addWidget(self.giris, 1)
        b = QPushButton('Sor'); b.setObjectName('birincil'); b.setFocusPolicy(Qt.NoFocus); b.clicked.connect(lambda: self.sor(self.giris.text())); sat.addWidget(b)
        v.addLayout(sat)
        # K-350: ikinci yol: tahtadaki soruyu çerçeveye al, Atlas hemen çözsün
        self.sec_b = QPushButton('▢  Tahtadan soru seç'); self.sec_b.setFocusPolicy(Qt.NoFocus); self.sec_b.setMinimumHeight(50)
        self.sec_b.setStyleSheet('QPushButton{border:1.5px dashed #22e8ff;color:#7ff6ff;border-radius:14px;font-size:19px;}')
        self.sec_b.clicked.connect(self.soru_sec); v.addWidget(self.sec_b)
        self.metin = AtlasCevap(self); v.addWidget(self.metin, 1)   # K-348/349: el yazısı, formüller kitap düzeninde
        # K-346: iki satır düğme (dar panelde yazılar sığsın): Tahtaya yaz · Grafiği çiz / Yeniden sor · Daha ayrıntılı
        alt = QGridLayout(); alt.setHorizontalSpacing(8); alt.setVerticalSpacing(8)
        self.yaz_b = QPushButton('Tahtaya yaz'); self.yaz_b.setObjectName('birincil'); self.yaz_b.setFocusPolicy(Qt.NoFocus); self.yaz_b.clicked.connect(self.tahtaya_yaz); self.yaz_b.setEnabled(False); alt.addWidget(self.yaz_b, 0, 0)
        self.grafik_b = QPushButton('Grafiği çiz'); self.grafik_b.setObjectName('birincil'); self.grafik_b.setFocusPolicy(Qt.NoFocus); self.grafik_b.clicked.connect(self.grafik_ciz); self.grafik_b.hide(); alt.addWidget(self.grafik_b, 0, 1)
        self.tekrar_b = QPushButton('Yeniden sor'); self.tekrar_b.setFocusPolicy(Qt.NoFocus); self.tekrar_b.clicked.connect(lambda: self.son_istek and self.sor(self.son_istek, self.son_derin)); self.tekrar_b.setEnabled(False); alt.addWidget(self.tekrar_b, 1, 0)
        self.derin_b = QPushButton('✦ Daha ayrıntılı'); self.derin_b.setFocusPolicy(Qt.NoFocus); self.derin_b.setStyleSheet('QPushButton{border-color:#22e8ff;color:#7ff6ff;}'); self.derin_b.clicked.connect(lambda: self.son_istek and self.sor(self.son_istek, True)); self.derin_b.setEnabled(False); alt.addWidget(self.derin_b, 1, 1)
        alt.setColumnStretch(0, 1); alt.setColumnStretch(1, 1); v.addLayout(alt); self.alt = alt; self.secenek_dug = []
        not_ = QLabel('Öğrenci adı ve fotoğrafı gönderilmez · yalnız seçilen ders içeriği gider'); not_.setStyleSheet('font-size:14px;color:#6f86a6;'); v.addWidget(not_)
        self.bek = QTimer(self); self.bek.setInterval(400); self.bek.timeout.connect(self.bekle)
        self.hide()
    def ders_bilgisi(self):
        try: d = lesson_now(self.main.board_info().get('sinif'), self.main.exam_clock())
        except Exception: d = {}
        return (d.get('ders') or '') if d.get('durum') == 'ders' else ''
    def ac(self, resim=None):
        self.resim = resim; ders = self.ders_bilgisi(); self.brans = ders_bransi(ders)
        self.ders.setText((ders or 'Ders dışı') + (' · ' + self.brans if self.brans and self.brans not in ders else ''))
        for b in self.secenek_dug: b.deleteLater()
        self.secenek_dug = []
        for ad in ATLAS_SECENEK.get(self.brans, ATLAS_SECENEK['']):
            b = QPushButton(ad); b.setObjectName('secenek'); b.setFocusPolicy(Qt.NoFocus); b.clicked.connect(lambda c=False, a=ad: self.sor(a)); self.secenek_dug.append(b)
        if resim is not None and not resim.isNull():
            self.metin.setPlainText('Tahtadan seçtiğiniz bölüm hazır. Yukarıdan ne yapılacağını seçin ya da yazarak sorun.')
            self.maskot.ifade('dinleme')
        else:
            self.metin.setPlainText("Merhaba! Sorunuzu yukarıya yazın ya da \"Tahtadan soru seç\" ile tahtadaki soruyu çerçeveye alın; Atlas hemen çözsün.")
            self.maskot.ifade('bekleme')
        self.onizleme.setVisible(resim is not None and not resim.isNull()); self._duzen()
        self.durum.setText(''); self.cevap = ''; self.grafik = []; self.yaz_b.setEnabled(False); self.derin_b.setEnabled(False); self.tekrar_b.setEnabled(False); self.grafik_b.hide()
        self.yerlestir(); self.show(); self.raise_()
    def yerlestir(self):
        m = self.main.rect()
        if self.tam: self.setGeometry(m); return
        w = max(440, min(620, int(m.width()*0.36)))
        self.setGeometry(m.width() - w, 0, w, m.height())
    def tam_ekran(self, tam):
        """K-350: Atlas tam ekran: büyük maskot, seçenekler tek satır, cevap ortada kitap gibi ferah."""
        self.tam = bool(tam); self.tam_b.setText('⤡ Küçült' if self.tam else '⤢ Tam ekran')
        self._duzen(); self.metin.tam_ekran(self.tam); self.yerlestir(); self.raise_()
    def _duzen(self):
        t = self.tam
        self.maskot.setFixedSize(*((210, 213) if t else (150, 152)))
        self.baslik.setStyleSheet('font-size:%dpx;font-weight:800;color:#7ff6ff;' % (44 if t else 30))
        self.ders.setStyleSheet('font-size:%dpx;color:#9fb3cc;' % (22 if t else 17))
        sutun = 4 if t else 2
        for b in self.secenek_dug + [self.yaz_b, self.grafik_b, self.tekrar_b, self.derin_b]: (self.secenekler if b in self.secenek_dug else self.alt).removeWidget(b)
        for i, b in enumerate(self.secenek_dug): self.secenekler.addWidget(b, i//sutun, i % sutun)
        for i, b in enumerate((self.yaz_b, self.grafik_b, self.tekrar_b, self.derin_b)): self.alt.addWidget(b, 0 if t else i//2, i if t else i % 2)
        for c in range(4): self.alt.setColumnStretch(c, 1 if (t or c < 2) else 0)
        if self.resim is not None and not self.resim.isNull():
            self.onizleme.setPixmap(self.resim.scaled(*((900, 230) if t else (420, 150)), Qt.KeepAspectRatio, Qt.SmoothTransformation))
    def soru_sec(self):
        """Panel geçici gizlenir; öğretmen soruyu çerçeveye alınca görüntüsüyle geri gelir ve hemen çözülür."""
        if self.bekleyen: return
        if self.tam: self.tam_ekran(False)
        self.hide(); self.main.set_tool('atlas')
    def kapat(self):
        self.bek.stop(); self.bekleyen = None; self.hide()
        if self.tam: self.tam_ekran(False)
    def sor(self, istek, derin=False):
        istek = (istek or '').strip()
        if not istek and self.resim is None: return
        if getattr(self.main, '_sinav_su_an', False):
            self.durum.setText("Sınav saatinde Atlas'a sor kapalı."); self.maskot.ifade('sasirma'); return
        if self.bekleyen: return
        self.son_istek = istek or 'Açıkla'; self.son_derin = bool(derin)
        klasor = os.path.join(self.main.data_dir, 'atlas'); os.makedirs(klasor, exist_ok=True)
        kimlik = uuid.uuid4().hex[:10]; giris = os.path.join(klasor, 'istek-%s.json' % kimlik); cikis = os.path.join(klasor, 'cevap-%s.json' % kimlik)
        veri = dict(sinif=self.main.board_info().get('sinif') or '-', brans=self.brans, istek=self.son_istek)
        if derin: veri['derin'] = True   # güçlü model: daha doğru, 30–60 sn sürebilir
        veri['formul'] = True   # K-349: bu tahta $...$ formülleri kitap düzeninde çizebiliyor
        if self.resim is not None and not self.resim.isNull():
            from PyQt5.QtCore import QBuffer, QByteArray, QIODevice
            im = self.resim
            if max(im.width(), im.height()) > 1024: im = im.scaled(1024, 1024, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            ba = QByteArray(); bu = QBuffer(ba); bu.open(QIODevice.WriteOnly); im.save(bu, 'JPG', 82); bu.close()
            veri['resim'] = bytes(ba.toBase64()).decode('ascii')
        try:
            with open(giris, 'w', encoding='utf-8') as f: json.dump(veri, f, ensure_ascii=False)
        except OSError:
            self.durum.setText('İstek hazırlanamadı.'); return
        self.bekleyen = (cikis, time.monotonic()); self.main.run_havuz('--atlas-sor', giris, cikis)
        self.metin.setPlainText('Atlas derin düşünüyor…\nAyrıntılı cevap 30–60 saniye sürebilir; bu sırada tahtada yazmaya devam edebilirsiniz.' if derin else 'Atlas düşünüyor…')
        self.durum.setText(''); self.maskot.ifade('dusunme'); self.yaz_b.setEnabled(False); self.tekrar_b.setEnabled(False); self.derin_b.setEnabled(False); self.grafik_b.hide()
        self.giris.clear(); self.bek.start()
    def bekle(self):
        if not self.bekleyen: self.bek.stop(); return
        cikis, t0 = self.bekleyen
        if os.path.exists(cikis):
            try:
                with open(cikis, encoding='utf-8') as f: d = json.load(f)
            except (OSError, ValueError): return   # yazılması sürüyor
            self.bek.stop(); self.bekleyen = None
            for yol in (cikis, cikis.replace('cevap-', 'istek-')):
                try: os.remove(yol)
                except OSError: pass
            self.tekrar_b.setEnabled(True); self.derin_b.setEnabled(not self.son_derin)
            if d.get('cevap'):
                self.cevap = d['cevap']; self.metin.setPlainText(self.cevap, True); self.yaz_b.setEnabled(True)
                self.grafik = [f for f in (d.get('grafik') or [])[:2] if isinstance(f, str) and graph_compile(f)[0]]
                self.grafik_b.setVisible(bool(self.grafik))
                if d.get('sayi') and d.get('sinir'): self.durum.setText('Bugün %s / %s' % (d['sayi'], d['sinir']))
                self.maskot.ifade('konusma'); QTimer.singleShot(1800, lambda: self.maskot.ifade('mutluluk')); QTimer.singleShot(4200, lambda: self.isVisible() and self.maskot.ifade('bekleme'))
            else:
                self.metin.setPlainText(d.get('hata') or 'Atlas şu an cevap veremedi.'); self.maskot.ifade('sasirma')
            return
        if time.monotonic() - t0 > (160 if self.son_derin else 80):
            self.bek.stop(); self.bekleyen = None; self.tekrar_b.setEnabled(True); self.derin_b.setEnabled(not self.son_derin)
            self.metin.setPlainText('Cevap gelmedi. İnternet bağlantısını kontrol edip yeniden deneyin.'); self.maskot.ifade('sasirma')
    def grafik_ciz(self):
        """K-346: Atlas'ın verdiği fonksiyon(lar)ı tahtanın kendi Grafik çizicisinde açar; çizimi yapay zekâ değil Atlas yapar."""
        if not self.grafik: return
        import re
        def guzel(f):   # alana öğretmenin yazacağı gibi: x^2 → x², 4*x → 4x, * → ·, - → −
            f = f.replace('^2', '²').replace('^3', '³'); f = re.sub(r'(\d)\*(?=[a-z(])', r'\1', f)
            return f.replace('*', '·').replace(' - ', ' − ').replace('-', '−')
        g = [guzel(f) if graph_compile(guzel(f))[0] else f for f in self.grafik]; m = self.main
        m.graph_cfg = dict(getattr(m, 'graph_cfg', {}) or {}, f0=g[0], f1=g[1] if len(g) > 1 else '')
        m.board.finish(); GraphDialog(m).exec_()
    def tahtaya_yaz(self):
        """K-350: Cevap tek çizgili el yazısıyla gerçek kalem çizgilerine çevrilir ve sorunun altındaki boş yere yazılır
        (tahtadaki yazıların üstüne binmez). Silinir, Akıllı seçimle taşınır, Geri al ile kalkar, PDF'e aynen geçer."""
        if not self.cevap: return
        m = self.main; b = m.board
        try:
            vis = b.visibleRegion().boundingRect(); k = b.scale or 1
            sayfa = m.doc[m.page].rect
            boy = 36.0/k   # ekranda ~36 px el yazısı
            renk = m.color if m.color != '#ffffff' or m.background in DARK_BACKGROUNDS else PEN_DEFAULT
            kal = max(1.2, min(2.6, m.width.value()*0.75))
            # Başlangıç: çerçevelenen sorunun hemen altı; yoksa görünen alanın sol üstü
            cer = getattr(m, 'atlas_son_cerceve', None)
            if cer and cer[0] == m.page: x0, y0 = max(16.0, cer[1].left()), cer[1].bottom() + boy*0.8
            else: x0, y0 = max(16.0, vis.left()/k + 24), vis.top()/k + 24
            gen = max(260.0, min(sayfa.width - x0 - 24, vis.width()/k*0.9))
            cizgiler, h = murekkep_cizgileri(self.cevap, gen, boy, renk, kal, os.path.join(UI_FONT_DIR, 'ReliefSingleLineSVG-Regular.svg'), atlas_guzel)
        except Exception as e:
            print('atlas tahtaya yaz:', e); m.show_toast('Cevap tahtaya yazılamadı.'); return
        if not cizgiler: m.show_toast('Cevap tahtaya yazılamadı.'); return
        xs = [q[0] for c in cizgiler for q in c['points']]; ys = [q[1] for c in cizgiler for q in c['points']]
        bw, bh = max(xs) + 4, max(ys) + 4
        # Tahtadaki yazıların üstüne binmesin: çakışan yazının altına kaydır
        kutular = []
        for s_ in m.marks.get(m.page, []):
            p_ = s_.get('points') or []
            if s_.get('tool') not in ('whiteout', 'geo', 'compass') and p_:
                kutular.append((min(q[0] for q in p_), min(q[1] for q in p_), max(q[0] for q in p_), max(q[1] for q in p_)))
        pay = boy*0.5
        for _ in range(60):
            carp = [kt for kt in kutular if kt[0] < x0 + bw + pay and kt[2] > x0 - pay and kt[1] < y0 + bh + pay and kt[3] > y0 - pay]
            if not carp: break
            y0 = max(kt[3] for kt in carp) + pay
        if y0 + bh > sayfa.height - 8:   # sayfada yer yok: öğretmen yerini seçsin
            m.pending_triangle = cizgiler; m.pending_label = "Atlas'ın cevabı yazıldı · Akıllı seçimle taşıyabilir, Geri al ile kaldırabilirsiniz"
            ipucu = "Sayfada boş yer kalmadı: cevabın başlayacağı yere dokunun."; m.pending_hint = ipucu
            self.kapat(); m.set_tool('place_tri'); m.show_toast(ipucu); return
        m.checkpoint(); ms = m.marks.setdefault(m.page, [])
        for c in cizgiler: ms.append(dict(c, points=[[x0 + q[0], y0 + q[1]] for q in c['points']]))
        m.changed(); b.update(); self.kapat()
        m.show_toast("Atlas'ın cevabı sorunun altına yazıldı · Akıllı seçimle taşıyabilir, Geri al ile kaldırabilirsiniz")

class OkulAraclari(QDialog):
    """Panelde tek 'Okul araçları' düğmesi: Anket, Oyunlar, Rehberlik, Proje seçimi (saatin yeri bozulmasın diye bir arada)."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Okul araçları')
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;} QPushButton{font-size:24px;font-weight:700;color:white;background:#13233a;border:2px solid #2a4468;border-radius:18px;padding:14px 20px;text-align:left;} QPushButton:pressed{background:#1d3150;} QPushButton:disabled{color:#6f819c;border-color:#1d2c44;}')
        v = QVBoxLayout(self); v.setContentsMargins(30, 24, 30, 24); v.setSpacing(16)
        t = QLabel('Okul araçları'); t.setStyleSheet('font-size:28px;font-weight:800;color:#7ff6ff;'); v.addWidget(t)
        room = main.board_info().get('sinif') in CLASS_PLACES
        try: an = bool(main.anket_defs()) if room else bool(main.anket_active('anket'))
        except Exception: an = False
        try: rh = (not room) and bool(main.anket_active('rehberlik'))   # Rehberlik: sınıfa açılmış bilgi formu
        except Exception: rh = False
        pj = True   # proje seçimi: sınıf tahtalarında; Öğretmenler odasında tanıtım sınıfı (DEMO)
        g = QGridLayout(); g.setSpacing(16)
        items = (('Anket', 'Anket' + ('' if an else '\nAçık anket yok'), an, self.anket),
                 ('Oyunlar', 'Oyunlar\nSatranç · Dama · Tavla · Mangala · XOX', True, self.oyun),
                 ('Okul araçları', 'Rastgele öğrenci\nTahtaya kim kalkacak?', True, self.rastgele),
                 ('Rehberlik', 'Rehberlik\nProje tercihi' + (' · Bilgi formu' if rh else ''), pj, self.rehberlik))   # proje seçimi Rehberlik'te; Atlas panelde (K-350)
        for i, (ic, txt, on, fn) in enumerate(items):
            b = QPushButton('  ' + txt); b.setFocusPolicy(Qt.NoFocus); b.setMinimumSize(340, 110)
            b.setIcon(QIcon(ATLAS_PNG) if ic == 'Atlas' else tool_icon(ic)); b.setIconSize(QSize(56, 56)); b.setEnabled(on)
            if ic == 'Atlas': b.setStyleSheet('QPushButton{border-color:#22e8ff;color:#7ff6ff;}')
            if fn: b.clicked.connect(fn)
            g.addWidget(b, i//2, i % 2)
        v.addLayout(g)
        cl = QPushButton('Kapat'); cl.setStyleSheet('text-align:center;font-size:20px;'); cl.clicked.connect(self.reject); v.addWidget(cl)
    def anket(self): self.accept(); QTimer.singleShot(0, self.main.open_anket)
    def rehberlik(self): self.accept(); QTimer.singleShot(0, lambda: RehberlikMenu(self.main).exec_())
    def oyun(self): self.accept(); QTimer.singleShot(0, self.main.open_games)
    def proje(self): self.accept(); QTimer.singleShot(0, self.main.open_proje)
    def rastgele(self): self.accept(); QTimer.singleShot(0, self.main.open_rastgele)
    def atlas(self): self.accept(); QTimer.singleShot(0, lambda: self.main.atlas_sor_ac())

class RehberlikMenu(QDialog):
    """Okul araçları → Rehberlik: Proje ödevi tercihi ve (açıksa) Öğrenci bilgi formu."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Rehberlik')
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;} QPushButton{font-size:24px;font-weight:700;color:white;background:#13233a;border:2px solid #2a4468;border-radius:18px;padding:18px 22px;text-align:left;}'
                           'QPushButton:pressed{background:#1d3150;} QPushButton:disabled{color:#6f819c;border-color:#1d2c44;}')
        v = QVBoxLayout(self); v.setContentsMargins(30, 24, 30, 24); v.setSpacing(16)
        t = QLabel('Rehberlik  <span style="font-size:20px;color:#9fb3cc;font-weight:400">%s</span>' % main.proje_sinif().replace('<', ''))
        t.setStyleSheet('font-size:28px;font-weight:800;color:#7ff6ff;'); v.addWidget(t)
        room = main.board_info().get('sinif') in CLASS_PLACES
        try: rh = (not room) and bool(main.anket_active('rehberlik'))
        except Exception: rh = False
        d = main.proje_data(); ros = main.proje_roster(); ter = d.get('tercihler', {})
        dur = {'kapali': 'seçim kapalı', 'acik': '%d/%d tercih yaptı' % (sum(1 for no, _ in ros if no in ter), len(ros)), 'dagitildi': 'dağıtım yapıldı'}.get(d.get('durum', 'kapali'), '')
        if d.get('son_gun') and d.get('durum') == 'acik': dur += ' · son gün ' + proje_gun_yazisi(d['son_gun'])
        h = QHBoxLayout(); h.setSpacing(16)
        b1 = QPushButton('  Proje ödevi tercihi\n  ' + (dur if ros else 'öğrenci listesi bekleniyor') + ('  (tanıtım)' if main.proje_demo() else ''))
        b1.setIcon(tool_icon('Proje seçimi')); b1.setIconSize(QSize(56, 56)); b1.setMinimumSize(430, 140); b1.setFocusPolicy(Qt.NoFocus)
        b1.setStyleSheet('QPushButton{border-color:#22e8ff;}'); b1.clicked.connect(self.proje); h.addWidget(b1)
        b2 = QPushButton('  Öğrenci bilgi formu\n  ' + ('formu doldurun' if rh else 'Açık form yok'))
        b2.setIcon(tool_icon('Rehberlik')); b2.setIconSize(QSize(56, 56)); b2.setMinimumSize(430, 140); b2.setFocusPolicy(Qt.NoFocus); b2.setEnabled(rh)
        b2.clicked.connect(self.form); h.addWidget(b2); v.addLayout(h)
        cl = QPushButton('Kapat'); cl.setStyleSheet('text-align:center;font-size:20px;padding:12px;'); cl.clicked.connect(self.reject); v.addWidget(cl)
    def proje(self): self.accept(); QTimer.singleShot(0, self.main.open_proje)
    def form(self): self.accept(); QTimer.singleShot(0, lambda: self.main.open_anket('rehberlik'))

class AnketSonucDialog(QDialog):
    """Öğretmenler odası: açık anketlerin katılımı ve 'Raporu Drive'a gönder'."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Anketler')
        self.setStyleSheet('QDialog{background:#0f1c2e;} QLabel{color:white;font-size:20px;} QPushButton{font-size:20px;font-weight:700;color:white;background:#1d3150;border:1px solid #2a4468;border-radius:12px;padding:12px 22px;}')
        v = QVBoxLayout(self); v.setContentsMargins(30, 24, 30, 24); v.setSpacing(12)
        defs = [a for a in main.anket_defs() if str(a.get('bitis') or '9999') >= (datetime_today() - 30)]
        if not defs: v.addWidget(QLabel('Henüz anket yok.'))
        self.info = QLabel(''); self.info.setStyleSheet('color:#ffe14d;font-size:19px;')
        for a in defs:
            row = QHBoxLayout(); n = sum(1 for s_ in a.get('siniflar', {}) for r in anket_roster(a, s_) if r[2])
            row.addWidget(QLabel('<b>%s</b><br><span style="color:#9fb3cc;font-size:17px">%d sınıf · %d öğrenci · %s – %s</span>' % (a.get('ad', '').replace('<', ''), len(a.get('siniflar', {})), n, a.get('baslangic', ''), a.get('bitis', ''))), 1)
            b = QPushButton('Raporu Drive\'a gönder'); b.clicked.connect(lambda c=False, a_=a: self.report(a_)); row.addWidget(b); v.addLayout(row)
        v.addWidget(self.info); cl = QPushButton('Kapat'); cl.clicked.connect(self.accept); v.addWidget(cl)
        self.resize(900, 200 + 90*len(defs))
    def report(self, a):
        out = os.path.join(self.main.data_dir, 'anket-%s-tum.json' % a['id'])
        try: t0 = os.path.getmtime(out)
        except OSError: t0 = 0
        self.main.run_havuz('--yoklama-oku', 'anket_%s_' % a['id'], out); self.info.setText('Cevaplar Drive\'dan alınıyor…'); self.tries = 0
        def wait():
            self.tries += 1
            try: m = os.path.getmtime(out)
            except OSError: m = 0
            if m > t0 or self.tries > 60:
                try:
                    with open(out, encoding='utf-8') as f: raw = json.load(f)
                except (OSError, ValueError): raw = {}
                files = {(v_ or {}).get('salon'): v_ for v_ in raw.values() if isinstance(v_, dict)}
                try:
                    res = anket_report(a, files, os.path.join(self.main.data_dir, 'anket-rapor'), UI_FONT_DIR)
                    for path, name in res: self.main.run_havuz('--yukle', path, name)
                    sm = anket_summary(a, files); tk = sum(x['katilan'] for x in sm['siniflar'].values()); tb = sum(x['beklenen'] for x in sm['siniflar'].values())
                    self.info.setText('Rapor Drive\'daki "Sınav Yoklamaları" klasörüne gönderildi · katılım %d / %d' % (tk, tb))
                except Exception as e: self.info.setText('Rapor hazırlanamadı: %s' % e)
                return
            QTimer.singleShot(1000, wait)
        QTimer.singleShot(1000, wait)
class AnketCanli(QWidget):
    """Öğretmenler odası: anketin canlı katılım ekranı. Cevap verenler geldikçe ekrana düşer, bekleyenler sağda sınıf sınıf;
    'Anketi kapat / aç' bütün sınıf tahtalarına (1–2 dk içinde), 'Raporu Drive'a gönder'."""
    OKU_SN = 15
    def __init__(self, main):
        super().__init__(main); self.main = main; self.a = None; self.defs = []; self.files = {}; self.geldi = {}; self.first = True
        self.sec = None; self.hits = {}; self.toast = ''; self.out_m = 0; self.wait_report = None
        st_ = 'QPushButton{background:#1d3150;color:white;border:2px solid %s;border-radius:14px;padding:0 28px;font-size:22px;font-weight:700;}QPushButton:pressed{background:#2a4468;}'
        self.toggle_b = QPushButton('', self); self.rapor_b = QPushButton("Raporu Drive'a gönder", self); self.next_b = QPushButton('Diğer anket', self); self.close_b = QPushButton('Kapat', self)
        for b, c in ((self.toggle_b, '#ff3b4e'), (self.rapor_b, '#22e8ff'), (self.next_b, '#2a4468'), (self.close_b, '#2a4468')):
            b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(58); b.setStyleSheet(st_ % c)
        self.toggle_b.clicked.connect(self.toggle); self.rapor_b.clicked.connect(self.report); self.next_b.clicked.connect(self.other); self.close_b.clicked.connect(self.close_)
        self.poll = QTimer(self); self.poll.timeout.connect(self.fetch)
        self.tick_t = QTimer(self); self.tick_t.setInterval(40); self.tick_t.timeout.connect(self.tick)
        self.load_t = QTimer(self); self.load_t.setInterval(1000); self.load_t.timeout.connect(self.load)
    def out_path(self): return os.path.join(self.main.data_dir, 'anket-%s-tum.json' % self.a['id'])
    def open_(self, a, defs):
        if self.a is None or self.a['id'] != a['id']: self.files = {}; self.geldi = {}; self.first = True; self.sec = None; self.out_m = 0
        self.a = a; self.defs = defs; self.toast = ''
        self.fit(self.main.rect()); self.show(); self.raise_(); self.load(); self.fetch()
        self.poll.start(self.OKU_SN*1000); self.load_t.start(); self.tick_t.start()
    def close_(self): self.poll.stop(); self.load_t.stop(); self.tick_t.stop(); self.hide()
    def other(self):
        if len(self.defs) < 2: return
        i = next((j for j, d in enumerate(self.defs) if d['id'] == self.a['id']), 0); self.open_(self.defs[(i + 1) % len(self.defs)], self.defs)
    def fit(self, rect): self.setGeometry(rect); self.layout_btns(); self.update()
    def resizeEvent(self, e): self.layout_btns()
    def layout_btns(self):
        W, H = self.width(), self.height(); m = int(64*min(1.0, H/1080.0)) if H else 64
        self.close_b.adjustSize(); self.close_b.move(W - self.close_b.width() - m, H - self.close_b.height() - m)
        self.next_b.adjustSize(); self.next_b.move(self.close_b.x() - self.next_b.width() - 14, self.close_b.y()); self.next_b.setVisible(len(self.defs) > 1)
        self.toggle_b.setText('Anketi aç' if self.a is not None and not self.acik() else 'Anketi kapat')
        self.toggle_b.setStyleSheet(self.toggle_b.styleSheet().replace('#2fbf71', '#ff3b4e') if self.acik() else self.toggle_b.styleSheet().replace('#ff3b4e', '#2fbf71'))
        self.toggle_b.adjustSize(); self.toggle_b.move(m, self.close_b.y())
        self.rapor_b.adjustSize(); self.rapor_b.move(self.toggle_b.x() + self.toggle_b.width() + 14, self.close_b.y())
    def acik(self):
        if self.a is None: return False
        return anket_durum_acik(self.a, self.main.anket_kontrol().get(self.a['id']), datetime_today())
    # veri
    def fetch(self):
        if self.a is None: return
        self.main.run_havuz('--yoklama-oku', 'anket_%s_' % self.a['id'], self.out_path())
        self.main.run_havuz('--yoklama-oku', 'anketdurum_', os.path.join(self.main.data_dir, 'anketdurum-gelen.json'))
    def load(self):
        if self.a is None: return
        try: m = os.path.getmtime(self.out_path())
        except OSError: m = 0
        if m and m != self.out_m:
            self.out_m = m
            try:
                with open(self.out_path(), encoding='utf-8') as f: raw = json.load(f)
            except (OSError, ValueError): raw = {}
            self.files = {(v_ or {}).get('salon'): v_ for v_ in raw.values() if isinstance(v_, dict)}
        cevl, bek, say = anket_canli_veri(self.a, self.files); now = time.monotonic()
        for d in cevl:   # yeni gelen (ya da cevabını değiştiren) yukarıdan düşer; açılıştaki liste düşmez
            key = (d['sinif'], d['no'])
            if self.geldi.get(key, (None,))[0] != d['zaman']: self.geldi[key] = (d['zaman'], -1e9 if self.first else now)
            d['geldi'] = self.geldi[key][1]
        if self.first and self.files: self.first = False
        elif self.first and m: self.first = False
        self.data = (cevl, bek, say)
        if self.sec not in say: self.sec = max(say, key=lambda s_: len(bek.get(s_, []))) if say else None
        self.layout_btns(); self.update()
    def tick(self):
        cevl = getattr(self, 'data', ([], {}, {}))[0]; now = time.monotonic()
        if any(now - d.get('geldi', -1e9) < ANKET_YENI_SURE + 0.2 for d in cevl[:60]): self.update()
    # eylemler
    def mousePressEvent(self, e):
        pos = QPointF(e.pos())
        for r, s_ in self.hits.get('sinif', []):
            if r.contains(pos): self.sec = s_; self.update(); return
    def toggle(self):
        if self.a is None: return
        kapat = self.acik(); soru = ('“%s” bütün sınıf tahtalarında kapatılsın mı?' if kapat else '“%s” sınıf tahtalarında yeniden açılsın mı? (bugün için)') % self.a.get('ad', 'Anket')
        if QMessageBox.question(self, 'Anket', soru) != QMessageBox.Yes: return
        if self.main.anket_kontrol_yaz(self.a, 'kapali' if kapat else 'acik'):
            self.toast = ('Anket kapatıldı: 1–2 dakika içinde bütün tahtalarda kapanır.' if kapat else 'Anket açıldı: 1–2 dakika içinde sınıf tahtalarında görünür.')
        else: self.toast = 'Kaydedilemedi.'
        self.layout_btns(); self.update()
    def report(self):
        if self.a is None: return
        try:
            res = anket_report(self.a, self.files, os.path.join(self.main.data_dir, 'anket-rapor'), UI_FONT_DIR)
            for path, name in res: self.main.run_havuz('--yukle', path, name)
            cevl, bek, say = self.data; self.toast = 'Rapor Drive\'daki "Sınav Yoklamaları" klasörüne gönderildi · katılım %d / %d' % (sum(x[0] for x in say.values()), sum(x[1] for x in say.values()))
        except Exception as e: self.toast = 'Rapor hazırlanamadı: %s' % e
        self.update()
    def paintEvent(self, e):
        from PyQt5.QtGui import QFont
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900)
        def font(px, b=False): f = QFont(famb if b else fam); f.setPixelSize(max(10, int(px*k))); return f
        p.fillRect(self.rect(), QColor('#0d1726'))
        if self.a is not None:
            cevl, bek, say = getattr(self, 'data', ([], {}, {}))
            self.hits = draw_anket_canli(p, W, H, k, font, self.a, cevl, bek, say, self.sec, self.acik(), time.monotonic(), self.close_b.y(), self.toast)
        p.end()

ANKET_YENI_SURE = 10.0   # yeni gelen cevap bu kadar saniye neon çerçeveli durur
def anket_canli_veri(a, files):
    """Öğretmenler odası canlı ekranı: (cevaplayanlar [dict(no, ad, sinif, cevap, zaman)] en yeni önce,
    bekleyenler {sınıf: [(no, ad)]}, sayılar {sınıf: (katılan, beklenen)})."""
    cev_l, bek, say = [], {}, {}
    for s_ in sorted((a.get('siniflar') or {}), key=lambda x: (class_grade(x) or 0, x)):
        exp = [r for r in anket_roster(a, s_) if r[2]]; cev = ((files or {}).get(s_) or {}).get('cevaplar', {}) or {}
        for no, ad, ok in exp:
            c = cev.get(no)
            if c: v = (c.get('c') or [None])[0]; cev_l.append(dict(no=no, ad=ad, sinif=s_, cevap=(', '.join(v) if isinstance(v, list) else (v or '')), zaman=float(c.get('zaman') or 0)))
        bek[s_] = [(no, ad) for no, ad, ok in exp if no not in cev]; say[s_] = (len(exp) - len(bek[s_]), len(exp))
    cev_l.sort(key=lambda d: -d['zaman'])
    return cev_l, bek, say
def anket_durum_acik(a, kontrol, today_iso):
    """Anket bu tahtada açık mı: Öğretmenler odasının 'Anketi aç / kapat' kaydı (anketdurum) tarih aralığından önce gelir.
    Kapatma kalıcıdır (yeniden açılana kadar); 'aç' yalnız verildiği gün geçerli."""
    k = kontrol if isinstance(kontrol, dict) else {}
    if k.get('durum') == 'kapali': return False
    if k.get('durum') == 'acik' and k.get('gun') == today_iso: return True
    return str(a.get('baslangic') or '0000') <= today_iso <= str(a.get('bitis') or '9999')
def draw_anket_canli(p, W, H, k, font, a, cevl, bek, say, sec, acik, now, bottom, toast=''):
    """Canlı katılım ekranı: solda cevap verenler (yeni gelen yukarıdan düşer), sağda sınıf sınıf bekleyenler.
    Döner: {'sinif': [(QRectF, sınıf)]} dokunma alanları."""
    def text(r, s_, f, c, al=Qt.AlignCenter): p.setFont(f); p.setPen(QColor(c)); p.drawText(r, al, s_)
    def elide(s_, f, w): return QFontMetrics(f).elidedText(s_, Qt.ElideRight, int(w))
    hits = {'sinif': []}
    fT = font(34, True); lbl = 'ANKET'; tw = QFontMetrics(fT).horizontalAdvance(lbl); pill = QRectF(30*k, 20*k, tw + 48*k, 58*k)
    draw_neon(p, pill, lbl, fT, '#22e8ff', k)
    fS = font(26, True); st_ = 'AÇIK' if acik else 'KAPALI'; sw = QFontMetrics(fS).horizontalAdvance(st_) + 56*k
    spill = QRectF(W - 30*k - sw, 22*k, sw, 54*k); draw_neon(p, spill, st_, fS, '#2fbf71' if acik else '#ff3b4e', k)
    fA = font(28, True); tx = pill.right() + 24*k
    text(QRectF(tx, 16*k, spill.left() - tx - 24*k, 40*k), elide(a.get('ad', ''), fA, spill.left() - tx - 24*k), fA, '#ffffff', Qt.AlignLeft | Qt.AlignVCenter)
    tk_ = sum(x[0] for x in say.values()); tb_ = sum(x[1] for x in say.values())
    dag = {}
    for d in cevl: dag[d['cevap']] = dag.get(d['cevap'], 0) + 1
    ops = list((a.get('sorular') or [{}])[0].get('secenekler') or [])
    parts = ['Cevap veren %d / %d' % (tk_, tb_)] + ['%s %d' % (o, dag.get(o, 0)) for o in ops]
    text(QRectF(tx, 56*k, spill.left() - tx - 24*k, 32*k), '   ·   '.join(parts), font(20, True), '#ffe14d', Qt.AlignLeft | Qt.AlignVCenter)
    # sağ: bekleyenler
    side = QRectF(W - 540*k, 104*k, 510*k, bottom - 164*k)   # altta bilgi satırına yer
    p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 10)); p.drawRoundedRect(side, 18*k, 18*k)
    nb = sum(len(v) for v in bek.values())
    text(QRectF(side.x() + 22*k, side.y() + 12*k, side.width() - 44*k, 40*k), 'Cevap bekleyenler · %d' % nb, font(22, True), '#7ff6ff', Qt.AlignLeft | Qt.AlignVCenter)
    y = side.y() + 60*k; fC = font(20, True); fN = font(17)
    nc = 3; gw = (side.width() - 28*k - (nc - 1)*8*k)/nc; gh = 64*k   # sınıflar: 3 sütunlu kutucuklar (adlara yer kalsın)
    for i, s_ in enumerate(say):
        r = QRectF(side.x() + 14*k + (i % nc)*(gw + 8*k), y + (i // nc)*(gh + 8*k), gw, gh); kat, bek_n = say[s_]
        if s_ == sec: p.setPen(QPen(QColor('#22e8ff'), 2.5*k)); p.setBrush(QColor(34, 232, 255, 26))
        else: p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 12))
        p.drawRoundedRect(r, 10*k, 10*k); kal = bek_n - kat
        text(QRectF(r.x() + 12*k, r.y() + 6*k, r.width() - 24*k, 32*k), s_, fC, '#ffffff', Qt.AlignLeft | Qt.AlignVCenter)
        text(QRectF(r.x() + 12*k, r.y() + 6*k, r.width() - 24*k, 32*k), ('%d kaldı' % kal) if kal else 'tamam', font(16, True), '#ffe14d' if kal else '#2fbf71', Qt.AlignRight | Qt.AlignVCenter)
        bar = QRectF(r.x() + 12*k, r.bottom() - 18*k, r.width() - 24*k, 8*k)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#1d3150')); p.drawRoundedRect(bar, 4*k, 4*k)
        if bek_n and kat: p.setBrush(QColor('#2fbf71')); p.drawRoundedRect(QRectF(bar.x(), bar.y(), max(bar.height(), bar.width()*kat/bek_n), bar.height()), 4*k, 4*k)
        hits['sinif'].append((r, s_))
    y += ((len(say) + nc - 1)//nc)*(gh + 8*k)
    if sec in bek:
        y += 10*k; lst = bek[sec]
        text(QRectF(side.x() + 22*k, y, side.width() - 44*k, 32*k), ('%s · bekleyenler' % sec) if lst else ('%s · herkes cevap verdi' % sec), font(19, True), '#9fb3cc', Qt.AlignLeft | Qt.AlignVCenter)
        y += 38*k; colw = (side.width() - 44*k)/2; lh = 29*k; rows = max(1, int((side.bottom() - 14*k - y)//lh))
        cap = rows*2; show = lst if len(lst) <= cap else lst[:cap - 1]
        for i, (no, ad) in enumerate(show):
            cx = side.x() + 22*k + (i // rows)*colw; cy = y + (i % rows)*lh
            text(QRectF(cx, cy, colw - 10*k, lh), elide(ad, fN, colw - 10*k), fN, '#dbe6f5', Qt.AlignLeft | Qt.AlignVCenter)
        if len(show) < len(lst):
            i = len(show); cx = side.x() + 22*k + (i // rows)*colw; cy = y + (i % rows)*lh
            text(QRectF(cx, cy, colw - 10*k, lh), '+%d öğrenci daha' % (len(lst) - len(show)), font(16, True), '#ffe14d', Qt.AlignLeft | Qt.AlignVCenter)
    # sol: cevap verenler (en yeni sol üstte)
    area = QRectF(30*k, 104*k, side.left() - 54*k, bottom - 164*k)
    text(QRectF(area.x() + 4*k, area.y(), area.width(), 40*k), 'Cevap verenler · en yeni başta', font(22, True), '#7ff6ff', Qt.AlignLeft | Qt.AlignVCenter)
    gy = area.y() + 52*k; cw_min = 238*k; cols = max(1, int(area.width()//cw_min)); cw = area.width()/cols; ch = 104*k
    rows = max(1, int((area.bottom() - gy)//ch)); cap = rows*cols
    show = cevl if len(cevl) <= cap else cevl[:cap - 1]
    if not cevl: text(QRectF(area.x(), gy, area.width(), 200*k), 'Henüz cevap gelmedi.\nÖğrenciler sınıf tahtasından cevap verdikçe burada belirir.', font(24, True), '#6f819c')
    fName = font(17, True); fCls = font(15, True)
    for i, d in enumerate(show):
        cx = area.x() + (i % cols)*cw; cy = gy + (i // cols)*ch
        age = now - d.get('geldi', -1e9); t = min(1.0, max(0.0, age/0.6))
        dy = -(1 - t)**2*70*k   # yukarıdan düşer
        r = QRectF(cx + 4*k, cy + 4*k + dy, cw - 8*k, ch - 10*k)
        p.save(); p.setOpacity(0.25 + 0.75*t)
        yeni = age < ANKET_YENI_SURE
        if yeni:
            for w_, al in ((12, 26), (6, 70)):
                q = QColor('#22e8ff'); q.setAlpha(al); p.setPen(QPen(q, w_*k)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 12*k, 12*k)
        p.setPen(QPen(QColor('#22e8ff' if yeni else '#2a4468'), (2.5 if yeni else 1.2)*k)); p.setBrush(QColor('#13233a')); p.drawRoundedRect(r, 12*k, 12*k)
        ph = QRectF(r.x() + 8*k, r.y() + 8*k, (r.height() - 16*k)*0.78, r.height() - 16*k); draw_photo(p, ph, d['no'], d['ad'], k)
        tx_ = ph.right() + 10*k; tw_ = r.right() - tx_ - 8*k
        text(QRectF(tx_, r.y() + 8*k, tw_, 26*k), elide(d['ad'], fName, tw_), fName, '#ffffff', Qt.AlignLeft | Qt.AlignVCenter)
        text(QRectF(tx_, r.y() + 34*k, tw_, 22*k), d['sinif'], fCls, '#9fb3cc', Qt.AlignLeft | Qt.AlignVCenter)
        cv = d.get('cevap') or '—'; fc = font(16, True); cw_ = min(tw_, QFontMetrics(fc).horizontalAdvance(cv) + 26*k)
        chip = QRectF(tx_, r.bottom() - 36*k, cw_, 28*k)
        col = '#2fbf71' if cv == (ops[0] if ops else None) else ('#ff6b6b' if (len(ops) > 1 and cv == ops[1]) else '#7ff6ff')
        q = QColor(col); q.setAlpha(40); p.setPen(QPen(QColor(col), 1.5*k)); p.setBrush(q); p.drawRoundedRect(chip, 14*k, 14*k)
        text(chip, elide(cv, fc, cw_ - 16*k), fc, col)
        p.restore()
    if len(show) < len(cevl):
        i = len(show); cx = area.x() + (i % cols)*cw; cy = gy + (i // cols)*ch
        text(QRectF(cx, cy, cw, ch), '+%d cevap daha\n(rapor hepsini içerir)' % (len(cevl) - len(show)), font(17, True), '#ffe14d')
    if toast: text(QRectF(0, bottom - 50*k, W, 38*k), toast, font(21, True), '#7ff6ff')
    return hits

def datetime_today():
    import datetime
    class _D(str):
        def __sub__(self, days): return (datetime.date.fromisoformat(self) - datetime.timedelta(days=days)).isoformat()
    return _D(datetime.date.today().isoformat())

class Curtain(QWidget):
    """Perde: covers the solution; drag the handle to reveal it step by step.
    Screen-only (never saved). Below the line by default; ⇅ flips it to cover the top."""
    GRIP = 46
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.ratio = .45; self.top_side = False
        self.drag = None; self.vp = QRect(); self.setCursor(Qt.SizeVerCursor)
    def fit(self, vp):
        self.vp = QRect(vp); line = int(vp.height()*self.ratio)
        if self.top_side: self.setGeometry(vp.x(), vp.y(), vp.width(), max(self.GRIP, line))
        else: self.setGeometry(vp.x(), vp.y()+min(line, vp.height()-self.GRIP), vp.width(), max(self.GRIP, vp.height()-line))
    def strip(self):   # the handle strip faces the open part
        return QRectF(0, self.height()-self.GRIP, self.width(), self.GRIP) if self.top_side else QRectF(0, 0, self.width(), self.GRIP)
    def buttons(self):
        s = self.strip(); y = s.center().y()
        return QRectF(self.width()-58, y-19, 38, 38), QRectF(self.width()-106, y-19, 38, 38)   # ×, ⇅
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(11, 22, 38))   # opaque: nothing of the answer shows through
        p.setPen(QPen(QColor(255, 255, 255, 14), 1))
        for y in range(0, self.height(), 18): p.drawLine(0, y, self.width(), y)   # cloth folds
        s = self.strip(); p.fillRect(s, QColor('#1d3150'))
        edge = s.top() if not self.top_side else s.bottom()-1
        p.setPen(QPen(QColor('#ffc526'), 3)); p.drawLine(QPointF(0, edge), QPointF(self.width(), edge))
        grip = QRectF(s.center().x()-90, s.center().y()-15, 180, 30)
        p.setPen(Qt.NoPen); p.setBrush(QColor('#ffc526')); p.drawRoundedRect(grip, 15, 15)
        p.setPen(QColor('#122034')); p.setFont(BellClock.font(15, True))
        p.drawText(grip, Qt.AlignCenter, ('▲ Perdeyi çek' if self.top_side else '▼ Perdeyi çek'))
        x, flip = self.buttons()
        for r, t in ((x, '×'), (flip, '⇅')):
            p.setPen(Qt.NoPen); p.setBrush(QColor('#30496d')); p.drawEllipse(r)
            p.setPen(Qt.white); p.setFont(BellClock.font(22, True)); p.drawText(r, Qt.AlignCenter, t)
        p.end()
    def mousePressEvent(self, e):
        x, flip = self.buttons(); pos = QPointF(e.pos())
        if x.adjusted(-6, -6, 6, 6).contains(pos): self.main.toggle_curtain(False); return
        if flip.adjusted(-6, -6, 6, 6).contains(pos):
            self.top_side = not self.top_side; self.ratio = 1-self.ratio; self.fit(self.vp); self.update(); return
        self.drag = e.globalPos().y()
    def mouseMoveEvent(self, e):
        if self.drag is None or not self.vp.height(): return
        dy = e.globalPos().y()-self.drag; self.drag = e.globalPos().y()
        self.ratio = max(.0, min(1.0, self.ratio + dy/self.vp.height())); self.fit(self.vp); self.update()
    def mouseReleaseEvent(self, e):
        self.drag = None
        if (not self.top_side and self.ratio >= .97) or (self.top_side and self.ratio <= .03): self.main.toggle_curtain(False)   # pulled all the way: gone

class Spotlight(QWidget):
    """Spot ışığı: the board darkens; the framed part stays lit. The lit part is
    left out of this widget's mask, so the pen keeps writing there."""
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.hole = None; self.round = False
        self.mode = None; self.start = None; self.corner = None
    def fit(self, vp):
        self.setGeometry(vp); self.remask()
    def remask(self):
        if self.hole is None or self.hole.width() < 4: self.clearMask(); return
        h = self.hole.toAlignedRect().adjusted(2, 2, -2, -2)
        self.setMask(QRegion(self.rect()).subtracted(QRegion(h, QRegion.Ellipse if self.round else QRegion.Rectangle)))
    def corners(self):
        h = self.hole; return [h.topLeft(), h.topRight(), h.bottomLeft(), h.bottomRight()]
    def controls(self):
        h = self.hole; y = h.top()-46 if h.top() > 56 else h.bottom()+8
        return QRectF(h.center().x()-55, y, 110, 38), QRectF(h.right()-38, y, 38, 38), QRectF(h.right()-84, y, 38, 38)   # taşı, ×, şekil
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(3, 8, 18, 205))
        if self.hole is None:
            p.setPen(Qt.white); p.setFont(BellClock.font(22, True))
            p.drawText(self.rect(), Qt.AlignCenter, 'Aydınlık kalacak yeri kalemle çerçeveleyin'); return
        h = self.hole
        p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor(255, 225, 77, 200), 4))
        (p.drawEllipse if self.round else p.drawRect)(h.adjusted(-2, -2, 2, 2))
        if self.mode == 'draw': return
        p.setPen(Qt.NoPen); p.setBrush(QColor('#ffe14d'))
        for c in self.corners(): p.drawEllipse(c, 12, 12)
        move, x, shape = self.controls()
        p.setBrush(QColor('#ffe14d')); p.drawRoundedRect(move, 19, 19)
        p.setPen(QColor('#122034')); p.setFont(BellClock.font(16, True)); p.drawText(move, Qt.AlignCenter, '✥ Taşı')
        for r, t in ((x, '×'), (shape, '▢' if self.round else '◯')):
            p.setPen(Qt.NoPen); p.setBrush(QColor('#30496d')); p.drawEllipse(r)
            p.setPen(Qt.white); p.setFont(BellClock.font(20, True)); p.drawText(r, Qt.AlignCenter, t)
        p.end()
    def mousePressEvent(self, e):
        pos = QPointF(e.pos()); self.start = pos; self.corner = None
        if self.hole is not None:
            move, x, shape = self.controls()
            if x.adjusted(-6, -6, 6, 6).contains(pos): self.main.toggle_spot(False); return
            if shape.adjusted(-6, -6, 6, 6).contains(pos): self.round = not self.round; self.remask(); self.update(); return
            if move.adjusted(-6, -6, 6, 6).contains(pos): self.mode = 'move'; return
            for i, c in enumerate(self.corners()):
                if math.hypot(pos.x()-c.x(), pos.y()-c.y()) <= 30: self.mode = 'resize'; self.corner = i; return
        self.mode = 'draw'; self.hole = QRectF(pos, pos); self.remask(); self.update()   # frame a new lit part
    def mouseMoveEvent(self, e):
        pos = QPointF(e.pos())
        if self.mode == 'draw': self.hole = QRectF(self.start, pos).normalized(); self.remask()
        elif self.mode == 'move': d = pos-self.start; self.start = pos; self.hole.translate(d); self.remask()
        elif self.mode == 'resize':
            h = self.hole
            if self.corner in (0, 2): h.setLeft(min(pos.x(), h.right()-60))
            else: h.setRight(max(pos.x(), h.left()+60))
            if self.corner in (0, 1): h.setTop(min(pos.y(), h.bottom()-40))
            else: h.setBottom(max(pos.y(), h.top()+40))
            self.remask()
        else: return
        self.update()
    def mouseReleaseEvent(self, e):
        if self.mode == 'draw' and (self.hole.width() < 40 or self.hole.height() < 30): self.hole = None
        self.mode = None; self.remask(); self.update()

class PanelClock(QWidget):
    """Büyük saat ve tarih: sol panelin altındaki boşlukta."""
    def __init__(self, parent=None):
        super().__init__(parent); self.setMinimumHeight(110); self.now = None
        self.timer = QTimer(self); self.timer.timeout.connect(self.update); self.timer.start(1000)
    def paintEvent(self, e):
        import datetime
        now = self.now or datetime.datetime.now(); p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = self.rect(); cy = r.height()/2
        p.setPen(QPen(QColor('#364a63'), 1)); p.drawLine(QPointF(12, 2), QPointF(r.width()-12, 2))
        tr_ = QRectF(0, cy-60, r.width(), 64); hm = now.strftime('%H:%M'); p.setFont(BellClock.font(52, True))
        for w_, a in ((4, 45), (2, 90)):   # "Nerede sınava gireceğim?" ile aynı neon camgöbeği
            q = QColor('#22e8ff'); q.setAlpha(a); p.setPen(q)
            for dx, dy in ((-w_, 0), (w_, 0), (0, -w_), (0, w_)): p.drawText(tr_.translated(dx, dy), Qt.AlignCenter, hm)
        p.setPen(QColor('#7ff6ff')); p.drawText(tr_, Qt.AlignCenter, hm)
        p.setPen(QColor('#a9b9cf')); p.setFont(BellClock.font(16))
        p.drawText(QRectF(0, cy+6, r.width(), 22), Qt.AlignCenter, '%d %s %d' % (now.day, TR_MONTHS[now.month-1], now.year))
        p.drawText(QRectF(0, cy+28, r.width(), 22), Qt.AlignCenter, TR_DAYS[now.weekday()])
        p.end()

# ---- Ağdaki yazıcıları bulma (yalnızca yönetim panelinden "Yazıcıları bul" komutuyla) ----
PRINTER_PORTS = (9100, 631, 515)   # ham baskı (JetDirect), IPP, LPD
def _snmp_get_sysdescr(ip, timeout=.8):
    """SNMP v1 'public' ile sysDescr (1.3.6.1.2.1.1.1.0): yazıcılar marka/modelini burada söyler."""
    import socket
    oid = bytes([0x06, 0x08, 0x2b, 6, 1, 2, 1, 1, 1, 0])
    vb = bytes([0x30, len(oid) + 2]) + oid + b'\x05\x00'; vbl = bytes([0x30, len(vb)]) + vb
    pdu_body = b'\x02\x01\x01' + b'\x02\x01\x00' + b'\x02\x01\x00' + vbl
    pdu = bytes([0xa0, len(pdu_body)]) + pdu_body
    msg_body = b'\x02\x01\x00' + b'\x04\x06public' + pdu
    msg = bytes([0x30, len(msg_body)]) + msg_body
    sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sk.settimeout(timeout)
    try:
        sk.sendto(msg, (ip, 161)); data, _ = sk.recvfrom(2048)
    except OSError: return ''
    finally: sk.close()
    i = data.rfind(b'\x04')   # son OCTET STRING = değer
    while i > 0:
        n = data[i+1]
        if n < 0x80 and i + 2 + n == len(data): return data[i+2:i+2+n].decode('utf-8', 'replace').strip()
        if n == 0x81 and i + 3 + data[i+2] == len(data): return data[i+3:i+3+data[i+2]].decode('utf-8', 'replace').strip()
        i = data.rfind(b'\x04', 0, i)
    return ''
def _http_title(ip, port=80, timeout=1.5):
    import urllib.request, re as re_
    try:
        with urllib.request.urlopen('http://%s:%d/' % (ip, port), timeout=timeout) as r: body = r.read(20000).decode('utf-8', 'replace')
    except Exception: return ''
    m = re_.search(r'<title[^>]*>(.*?)</title>', body, re_.I | re_.S)
    return ' '.join(m.group(1).split())[:120] if m else ''
def scan_printers(hosts=None):
    """Bu tahtanın bulunduğu ağı (/24) yazıcı bağlantı noktaları için kısaca yoklar; model bilgisini toplar."""
    import socket, concurrent.futures as cf, subprocess
    try:
        u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); u.connect(('8.8.8.8', 80)); my = u.getsockname()[0]; u.close()   # paket gönderilmez
    except OSError: my = ''
    if hosts is None:
        if not my: return dict(zaman=time.time(), hata='Ağ adresi bulunamadı', bulunan=[])
        pre = my.rsplit('.', 1)[0]; hosts = ['%s.%d' % (pre, i) for i in range(1, 255) if '%s.%d' % (pre, i) != my]
    def probe(h):
        open_ = []
        for port in PRINTER_PORTS + (80,):
            sk = socket.socket(); sk.settimeout(.35)
            try:
                if sk.connect_ex((h, port)) == 0: open_.append(port)
            except OSError: pass
            finally: sk.close()
        return h, open_
    found = []
    with cf.ThreadPoolExecutor(64) as ex:
        for h, ports in ex.map(probe, hosts):
            if any(p_ in ports for p_ in PRINTER_PORTS): found.append(dict(ip=h, portlar=ports))
    for f in found:
        f['model'] = _snmp_get_sysdescr(f['ip'])[:160]
        if 80 in f['portlar']: f['web'] = _http_title(f['ip'])
    cups = []
    try:
        out = subprocess.run(['lpstat', '-v'], capture_output=True, text=True, timeout=5).stdout
        cups = [l.strip() for l in out.splitlines() if l.strip()][:20]
    except Exception: pass
    return dict(zaman=time.time(), ag=(my.rsplit('.', 1)[0] + '.0/24') if my else '', bu_tahta=my, bulunan=found, cups=cups)

class LiveMeter:
    """Derste gerçek kullanımda kalem akıcılığı: gün boyu tutulur, durum bildirimiyle sunucuya gider.
    Takılma: bir nokta 60 ms'den uzun sırada bekledi / işlendi ya da çizgiyi bitirmek 100 ms'yi geçti."""
    KEEP = 3000
    def __init__(self, main):
        import collections
        self.main = main; self.path = os.path.join(main.data_dir, 'kalem-canli.json')
        self.proc = collections.deque(maxlen=self.KEEP); self.lag = collections.deque(maxlen=self.KEEP); self.fin = collections.deque(maxlen=self.KEEP)
        self.day = time.strftime('%Y-%m-%d'); self.strokes = 0; self.points = 0; self.stalls = 0; self.worst = []; self.base = None; self.last_t = 0
        try:
            with open(self.path, encoding='utf-8') as f: d = json.load(f)
            if d.get('gun') == self.day:
                self.strokes, self.points, self.stalls = d.get('cizgi', 0), d.get('nokta', 0), d.get('takilma', 0); self.worst = d.get('en_kotu', [])[:5]
                self.proc.extend(d.get('_isleme', [])); self.lag.extend(d.get('_bekleme', [])); self.fin.extend(d.get('_bitis', []))
        except (OSError, ValueError, AttributeError): pass
    def roll(self):
        today = time.strftime('%Y-%m-%d')
        if today != self.day:
            self.day = today; self.strokes = self.points = self.stalls = 0; self.worst = []
            self.proc.clear(); self.lag.clear(); self.fin.clear()
    def context(self, b):
        o = self.main
        return dict(saat=time.strftime('%H:%M'), cozum=bool(o.in_solution()) if hasattr(o, 'in_solution') else False,
                    cizgi_sayfada=len(o.marks.get(o.page, [])), yakinlik=round(getattr(o, 'zoom', 1), 2))
    def note(self, kind, ms, b):
        self.stalls += 1
        self.worst.append(dict(self.context(b), tur=kind, ms=round(ms)))
        self.worst = sorted(self.worst, key=lambda x: -x['ms'])[:5]
    def point(self, ms, ts, b):
        self.roll(); now = time.monotonic()
        if now - self.last_t > .2: self.base = None   # yeni çizgi
        self.last_t = now; self.points += 1; self.proc.append(round(ms, 2))
        if ms > 60: self.note('isleme', ms, b)
        if ts:
            d = now*1000 - ts
            if self.base is None or d < self.base: self.base = d
            lag = d - self.base; self.lag.append(round(lag, 1))
            if lag > 60: self.note('bekleme', lag, b)
    def stroke_end(self, ms, b):
        self.roll(); self.strokes += 1; self.fin.append(round(ms, 1)); self.base = None
        if ms > 100: self.note('bitis', ms, b)
    @staticmethod
    def pct(v, q):
        v = sorted(v); return v[min(len(v)-1, int(len(v)*q))] if v else 0
    def summary(self):
        self.roll()
        return dict(gun=self.day, cizgi=self.strokes, nokta=self.points, takilma=self.stalls,
                    isleme_95=self.pct(self.proc, .95), isleme_max=max(self.proc) if self.proc else 0,
                    bekleme_95=self.pct(self.lag, .95), bekleme_max=max(self.lag) if self.lag else 0,
                    bitis_95=self.pct(self.fin, .95), bitis_max=max(self.fin) if self.fin else 0, en_kotu=self.worst, surum=installed_version())
    def save(self):
        d = self.summary(); d.update(_isleme=list(self.proc)[-500:], _bekleme=list(self.lag)[-500:], _bitis=list(self.fin)[-500:])
        try:
            with open(self.path, 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)
        except OSError: pass

class PenMeter:
    """Kalem ölçümü: 10 saniye yazılır; tahtanın nokta sıklığı, işleme ve çizim süresi,
    sırada bekleme ölçülür, sonuç ekranda gösterilir (Terminal gerekmez)."""
    SECONDS = 10
    def __init__(self, main):
        self.main = main; self.b = main.board; self.events = []; self.paints = []; self.kinds = {}; self.t0 = None
    def start(self):
        m = self.main; m.new_board()
        m.set_tool('pen'); b = self.b
        self.orig = (b.event, b.paintEvent)
        def event(e):
            t = e.type()
            if t in (QEvent.TouchUpdate, QEvent.MouseMove, QEvent.TabletMove):
                st = time.perf_counter(); r = self.orig[0](e); dur = (time.perf_counter() - st)*1000
                if self.t0 is None: self.t0 = time.monotonic()
                try: ts = e.timestamp()
                except Exception: ts = 0
                self.events.append((time.monotonic(), ts, dur, b.active is not None))
                k = {QEvent.TouchUpdate: 'dokunma', QEvent.MouseMove: 'fare', QEvent.TabletMove: 'kalem'}[t]; self.kinds[k] = self.kinds.get(k, 0) + 1
                return r
            return self.orig[0](e)
        def paint(e):
            st = time.perf_counter(); self.orig[1](e); self.paints.append((time.perf_counter() - st)*1000)
        b.event = event; b.paintEvent = paint
        self.banner = QLabel(m.scroll); self.banner.setAlignment(Qt.AlignCenter)
        self.banner.setStyleSheet('background:rgba(14,28,50,230);color:white;border:2px solid #3d8bff;border-radius:16px;padding:14px 26px;font-size:22px;')
        self.timer = QTimer(); self.timer.timeout.connect(self.tick); self.timer.start(200); self.tick()
    def tick(self):
        left = self.SECONDS if self.t0 is None else max(0, self.SECONDS - (time.monotonic() - self.t0))
        self.banner.setText('Kalem ölçümü · ' + ('normal hızda yazmaya başlayın' if self.t0 is None else 'yazmaya devam edin · %d sn' % math.ceil(left)))
        self.banner.adjustSize(); vp = self.main.scroll.viewport().geometry()
        self.banner.move(vp.x() + (vp.width() - self.banner.width())//2, vp.y() + 16); self.banner.show(); self.banner.raise_()
        if self.t0 is not None and left <= 0: self.stop()
    def stop(self):
        self.timer.stop(); self.banner.hide(); b = self.b
        del b.event; del b.paintEvent   # özgün yöntemlere dön
        self.main.pen_meter = None; self.show(self.result())
    @staticmethod
    def pct(v, q):
        if not v: return 0.0
        v = sorted(v); return v[min(len(v)-1, int(len(v)*q))]
    def result(self):
        ev = [e for e in self.events if e[3]]   # yalnızca yazarken
        gaps = [(b_[1]-a_[1]) for a_, b_ in zip(ev, ev[1:]) if 0 < b_[1]-a_[1] < 200]
        hz = 1000/self.pct(gaps, .5) if gaps else 0
        lag = []   # sırada bekleme: her çizginin içinde, en hızlı işlenen noktaya göre gecikme
        if ev and ev[0][1]:
            stroke = [ev[0]]
            for prev, cur in list(zip(ev, ev[1:])) + [(ev[-1], None)]:
                if cur is None or cur[0] - prev[0] > .2:
                    base = [e[0]*1000 - e[1] for e in stroke]; lo = min(base); lag += [x - lo for x in base]
                    stroke = [cur] if cur is not None else []
                else: stroke.append(cur)
        proc = [e[2] for e in ev]
        r = dict(nokta=len(ev), hz=round(hz), isleme_ort=round(sum(proc)/len(proc), 2) if proc else 0, isleme_95=round(self.pct(proc, .95), 2),
                 cizim_ort=round(sum(self.paints)/len(self.paints), 2) if self.paints else 0, cizim_95=round(self.pct(self.paints, .95), 2),
                 bekleme_95=round(self.pct(lag, .95), 1), bekleme_max=round(max(lag), 1) if lag else 0, giris=self.kinds, surum=installed_version())
        try:
            with open(os.path.join(self.main.data_dir, 'kalem-olcum.json'), 'w', encoding='utf-8') as f: json.dump(r, f, ensure_ascii=False)
        except OSError: pass
        return r
    def show(self, r):
        if r['nokta'] < 20: verdict = 'Yeterli yazı alınamadı. Ölçümü yeniden başlatıp 10 saniye boyunca sürekli yazın.'
        elif r['isleme_95'] > 8 or r['cizim_95'] > 16: verdict = 'Uygulama yavaş kalıyor: işleme ya da çizim süresi uzun. Kodda iyileştirilecek yer var.'
        elif r['bekleme_95'] > 25: verdict = 'Noktalar sırada bekliyor: tahta meşgul. Kodda iyileştirilecek yer var.'
        elif r['hz'] and r['hz'] < 80: verdict = 'Uygulama tarafı hızlı. Dokunmatik panel saniyede %d nokta gönderiyor; bu panelin kendi sınırı.' % r['hz']
        else: verdict = 'Uygulama tarafı hızlı. Kalan küçük gecikme dokunmatik panel ve ekrandan geliyor.'
        giris = ', '.join('%s %d' % kv for kv in r['giris'].items()) or '-'
        rows = [('Tahtanın gönderdiği nokta', '%d / saniye' % r['hz']), ('Noktayı işleme (ort / %95)', '%.2f / %.2f ms' % (r['isleme_ort'], r['isleme_95'])),
                ('Ekrana çizme (ort / %95)', '%.2f / %.2f ms' % (r['cizim_ort'], r['cizim_95'])), ('Sırada bekleme (%95 / en çok)', '%.1f / %.1f ms' % (r['bekleme_95'], r['bekleme_max'])),
                ('Ölçülen nokta', str(r['nokta'])), ('Giriş türü', giris), ('Uç tahmini', 'açık (normal ve Akıcı kalem)' if Board.PRED_ON else 'kapalı'), ('Sürüm', r['surum'])]
        d = QDialog(self.main); d.setWindowTitle('Kalem ölçümü'); lay = QVBoxLayout(d); lay.setContentsMargins(26, 22, 26, 22); lay.setSpacing(12)
        t = QLabel('Kalem ölçümü sonucu'); t.setStyleSheet('font-size:24px;font-weight:600;'); lay.addWidget(t)
        g = QGridLayout(); g.setHorizontalSpacing(30); g.setVerticalSpacing(10); lay.addLayout(g)
        for i, (a, v) in enumerate(rows):
            la = QLabel(a); la.setStyleSheet('font-size:19px;color:#a9b9cf;'); lv = QLabel(v); lv.setStyleSheet('font-size:21px;font-weight:600;')
            g.addWidget(la, i, 0); g.addWidget(lv, i, 1)
        v = QLabel(verdict); v.setWordWrap(True); v.setStyleSheet('font-size:18px;padding:12px;border-radius:12px;background:rgba(61,139,255,0.18);'); lay.addWidget(v)
        n = QLabel('Bu ekranın fotoğrafını gönderebilirsiniz.'); n.setStyleSheet('color:#a9b9cf;font-size:15px;'); lay.addWidget(n)
        ok = QPushButton('Kapat'); ok.setObjectName('primary'); ok.setMinimumHeight(48); ok.clicked.connect(d.accept); lay.addWidget(ok)
        d.resize(720, 560); d.exec_()


# ---------------------------------------------------------------------------
# Ölçülü üçgen: kenar/açıdan üçgeni hesaplar; tahtaya normal çizgilerle konur.
TRI_MODES = [('sss', '3 kenar', ('|AB|', '|BC|', '|CA|')), ('sas', '2 kenar + aradaki açı', ('|AB|', '|AC|', 'A açısı')),
             ('asa', '1 kenar + 2 açı', ('|AB|', 'A açısı', 'B açısı')), ('aaa', 'Yalnız açılar', ('A açısı', 'B açısı'))]

def triangle_solve(mode, vals):
    """Döner: (a=|BC|, b=|CA|, c=|AB|, A, B, C derece) ya da hata metni."""
    d = math.degrees; r_ = math.radians
    try:
        if mode == 'sss':
            c, a, b = vals
            if min(a, b, c) <= 0: return 'Kenarlar sıfırdan büyük olmalı.'
            for x, y, z in ((a, b, c), (b, c, a), (c, a, b)):
                if x + y <= z: return 'Bu kenarlarla üçgen olmaz (%s + %s ≤ %s).' % (fmt_num(x), fmt_num(y), fmt_num(z))
            A = d(math.acos((b*b + c*c - a*a)/(2*b*c))); B = d(math.acos((a*a + c*c - b*b)/(2*a*c)))
        elif mode == 'sas':
            c, b, A = vals
            if min(b, c) <= 0: return 'Kenarlar sıfırdan büyük olmalı.'
            if not 0 < A < 180: return 'Açı 0° ile 180° arasında olmalı.'
            a = math.sqrt(b*b + c*c - 2*b*c*math.cos(r_(A))); B = d(math.acos(max(-1, min(1, (a*a + c*c - b*b)/(2*a*c)))))
        elif mode == 'asa':
            c, A, B = vals
            if c <= 0: return 'Kenar sıfırdan büyük olmalı.'
            if A <= 0 or B <= 0 or A + B >= 180: return 'Açıların toplamı 180°\'den küçük olmalı.'
            C = 180 - A - B; a = c*math.sin(r_(A))/math.sin(r_(C)); b = c*math.sin(r_(B))/math.sin(r_(C))
        else:
            A, B = vals
            if A <= 0 or B <= 0 or A + B >= 180: return 'Açıların toplamı 180° olmalı (iki açının toplamı 180°\'den küçük).'
            C = 180 - A - B; c = 6.0; a = c*math.sin(r_(A))/math.sin(r_(C)); b = c*math.sin(r_(B))/math.sin(r_(C))
        C = 180 - A - B
        return (a, b, c, A, B, C)
    except (ValueError, ZeroDivisionError):
        return 'Bu değerlerle üçgen çizilemiyor.'

def label_half(text, h):
    """text_strokes yazısının yarı genişlik/yükseklik kutusu."""
    xs = [q[0] for m in text_strokes(text, 0, 0, h, '#000', 1) for q in m['points']]
    ys = [q[1] for m in text_strokes(text, 0, 0, h, '#000', 1) for q in m['points']]
    if not xs: return h*.3, h*.5
    return max(abs(min(xs)), abs(max(xs))), max(abs(min(ys)), abs(max(ys)))

def triangle_marks(sol, mode, opts, size, color, width):
    """Üçgeni (ağırlık merkezi 0,0) çizgi listesi olarak üretir; size: en uzun kenar (sayfa birimi)."""
    a, b, c, A, B, C = sol; k = size/max(a, b, c)
    P = {'A': (0.0, 0.0), 'B': (c*k, 0.0), 'C': (b*k*math.cos(math.radians(A)), -b*k*math.sin(math.radians(A)))}
    gx = sum(v[0] for v in P.values())/3; gy = sum(v[1] for v in P.values())/3
    P = {n: (x - gx, y - gy) for n, (x, y) in P.items()}
    h = max(9.0, size*.075); blue, red, grey = '#0057ff', '#e8132b', '#64748b'
    out = [dict(tool='pen', color=color, width=width, points=[list(P['A']), list(P['B']), list(P['C']), list(P['A'])])]
    def unit(x, y): n = math.hypot(x, y) or 1; return x/n, y/n
    edges = [(P['A'], P['B']), (P['B'], P['C']), (P['C'], P['A'])]; boxes = []
    Ax, Ay = P['A']; Bx, By = P['B']; Cx, Cy = P['C']
    if opts.get('height'):   # yardımcı çizgiler de etiketlerin kaçınacağı yerler
        t_ = ((Cx - Ax)*(Bx - Ax) + (Cy - Ay)*(By - Ay))/((Bx - Ax)**2 + (By - Ay)**2); edges.append(((Cx, Cy), (Ax + t_*(Bx - Ax), Ay + t_*(By - Ay))))
    if opts.get('bisector'): t_ = c/(b + c); edges.append(((Ax, Ay), (Bx + (Cx - Bx)*t_, By + (Cy - By)*t_)))
    if opts.get('median'): edges.append(((Ax, Ay), ((Bx + Cx)/2, (By + Cy)/2)))
    def seg_hits(box, p0, p1):   # doğru parçası kutuya giriyor mu (Liang–Barsky)
        x0, y0, x1, y1 = box; t0, t1 = 0.0, 1.0; dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        for pp, qq in ((-dx, p0[0] - x0), (dx, x1 - p0[0]), (-dy, p0[1] - y0), (dy, y1 - p0[1])):
            if pp == 0:
                if qq < 0: return False
            else:
                r_ = qq/pp
                if pp < 0: t0 = max(t0, r_)
                else: t1 = min(t1, r_)
                if t0 > t1: return False
        return True
    def free(box):
        g = h*.18; bb = (box[0] - g, box[1] - g, box[2] + g, box[3] + g)
        if any(seg_hits(bb, p0, p1) for p0, p1 in edges): return False
        return not any(bb[0] < q[2] and q[0] < bb[2] and bb[1] < q[3] and q[1] < bb[3] for q in boxes)
    def place(txt, hs, col, wid, tries):
        """tries: [(px, py, ux, uy, t0, t1)] sırayla denenir; çizgiye/etikete değmeyen ilk yer."""
        hw, hh = label_half(txt, hs); last = None
        for px, py, ux, uy, t0, t1 in tries:
            t = t0
            while t <= t1:
                cx, cy = px + ux*t, py + uy*t; box = (cx - hw, cy - hh, cx + hw, cy + hh)
                if free(box):
                    boxes.append(box); return text_strokes(txt, cx, cy, hs, col, wid)
                last = last or (cx, cy, box); t += h*.2
        cx, cy, box = last; boxes.append(box); return text_strokes(txt, cx, cy, hs, col, wid)
    angs = {'A': A, 'B': B, 'C': C}; bis = {}
    for n_ in 'ABC':
        others = [m for m in 'ABC' if m != n_]; vx, vy = P[n_]
        d1 = unit(P[others[0]][0] - vx, P[others[0]][1] - vy); d2 = unit(P[others[1]][0] - vx, P[others[1]][1] - vy)
        bis[n_] = (d1, d2, unit(d1[0] + d2[0], d1[1] + d2[1]))
    if opts.get('names', True):
        for n_ in 'ABC':   # köşe adı: açının tam dışına
            bx, by = bis[n_][2]; out += place(n_, h, color, max(1.2, width*.7), [(P[n_][0], P[n_][1], -bx, -by, h*.7, h*4)])
    given_s = {'sss': ('c', 'a', 'b'), 'sas': ('c', 'b'), 'asa': ('c',), 'aaa': ()}[mode]
    given_a = {'sss': (), 'sas': ('A',), 'asa': ('A', 'B'), 'aaa': ('A', 'B')}[mode]
    sides = {'c': ('A', 'B', c), 'a': ('B', 'C', a), 'b': ('C', 'A', b)}
    rr = size*.09; jobs = []
    for n_, val in angs.items():
        show = n_ in given_a and opts.get('angles', True); calc = n_ not in given_a and opts.get('calc', False)
        right = abs(val - 90) < 1e-6
        if not (show or calc or right): continue
        d1, d2, (bx, by) = bis[n_]; vx, vy = P[n_]; col = red if show else grey
        if right:   # dik açı: küçük kare
            q = rr*.6; out.append(dict(tool='pen', color=red, width=max(1.2, width*.7), points=[[vx + d1[0]*q, vy + d1[1]*q], [vx + (d1[0] + d2[0])*q, vy + (d1[1] + d2[1])*q], [vx + d2[0]*q, vy + d2[1]*q]]))
        else:
            a0 = math.atan2(d1[1], d1[0]); a1 = math.atan2(d2[1], d2[0]); da = (a1 - a0 + math.pi) % (2*math.pi) - math.pi
            out.append(dict(tool='pen', color=col, width=max(1.2, width*.7), points=[[vx + rr*math.cos(a0 + da*i/16), vy + rr*math.sin(a0 + da*i/16)] for i in range(17)]))
        if show or calc:
            txt = ('≈ ' if calc and not show else '') + fmt_num(val, 1) + '°'
            # önce açının içinde (yayın ötesinde), sığmazsa köşenin dışında
            o1, o2 = (P[m] for m in 'ABC' if m != n_)   # karşı kenara kadar olan iç mesafe
            ex_, ey_ = o2[0] - o1[0], o2[1] - o1[1]; den = bx*ey_ - by*ex_
            reach = ((o1[0] - vx)*ey_ - (o1[1] - vy)*ex_)/den if abs(den) > 1e-9 else size
            tries = [(vx, vy, bx, by, rr*1.1, min(size*.45, reach*.85))] if val >= 30 else []   # çok dar açı: doğrudan dışarı
            tries.append((vx, vy, -bx, -by, h*.8, h*6))
            jobs.append((0 if show else 1, txt, h*(.75 if show else .64), col, max(1.1, width*.55), tries))
    for key, (u, v, val) in sides.items():
        show = key in given_s and mode != 'aaa' and opts.get('sides', True)
        calc = key not in given_s and mode != 'aaa' and opts.get('calc', False)
        if not (show or calc): continue
        mx, my = (P[u][0] + P[v][0])/2, (P[u][1] + P[v][1])/2
        ex, ey = unit(P[v][0] - P[u][0], P[v][1] - P[u][1]); nx, ny = -ey, ex
        if nx*mx + ny*my < 0: nx, ny = -nx, -ny   # kenarın dış normali
        L = math.hypot(P[v][0] - P[u][0], P[v][1] - P[u][1])
        tries = [(mx + ex*o, my + ey*o, nx, ny, h*.3, h*3) for o in (0, L*.15, -L*.15, L*.28, -L*.28)]
        jobs.append((0 if show else 1, ('≈ ' if calc else '') + fmt_num(val), h*(.9 if show else .78), blue if show else grey, max(1.2, width*.6), tries))
    for _, txt, hs, col, wid, tries in sorted(jobs, key=lambda j: j[0]):   # verilenler önce yerini alır
        out += place(txt, hs, col, wid, tries)
    Ax, Ay = P['A']; Bx, By = P['B']; Cx, Cy = P['C']
    if opts.get('height'):   # C'den AB'ye yükseklik (kesikli), ayağında dik açı
        t = ((Cx - Ax)*(Bx - Ax) + (Cy - Ay)*(By - Ay))/((Bx - Ax)**2 + (By - Ay)**2); Hx, Hy = Ax + t*(Bx - Ax), Ay + t*(By - Ay)
        out.append(dict(tool='pen', color=grey, width=max(1.2, width*.7), dash=True, points=[[Cx, Cy], [Hx, Hy]]))
        if not 0 <= t <= 1: out.append(dict(tool='pen', color=grey, width=max(1.0, width*.5), dash=True, points=[[Ax, Ay] if t < 0 else [Bx, By], [Hx, Hy]]))
        q = size*.04; out.append(dict(tool='pen', color=grey, width=max(1.0, width*.5), points=[[Hx + q, Hy], [Hx + q, Hy - q], [Hx, Hy - q]]))
    if opts.get('bisector'):   # A'dan açıortay
        t = c/(b + c); Dx, Dy = Bx + (Cx - Bx)*t, By + (Cy - By)*t
        out.append(dict(tool='pen', color='#16a34a', width=max(1.2, width*.7), dash=True, points=[[Ax, Ay], [Dx, Dy]]))
    if opts.get('median'):   # A'dan kenarortay
        out.append(dict(tool='pen', color='#d946ef', width=max(1.2, width*.7), dash=True, points=[[Ax, Ay], [(Bx + Cx)/2, (By + Cy)/2]]))
    return out

class NumPad(QWidget):
    """Sayı tuş takımı (ölçü girişleri için): rakamlar, virgül, sil."""
    def __init__(self, parent, on_key):
        super().__init__(parent); g = QGridLayout(self); g.setSpacing(6); g.setContentsMargins(0, 0, 0, 0)
        for i, k in enumerate(['7', '8', '9', '⌫', '4', '5', '6', 'Temizle', '1', '2', '3', ',', '0', '00', '.', '°']):
            if k in ('.', '°'): continue
            b = QPushButton(k); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(52); b.setStyleSheet('font-size:21px;')
            b.clicked.connect(lambda checked=False, k_=k: on_key(k_)); g.addWidget(b, i//4, i % 4)

# ---- Canlı koordinat düzlemi: noktalar, doğrular, sonuçlar (kesir + ondalık) ----
from fractions import Fraction as _Fr
from PyQt5.QtGui import QFont, QFontMetricsF, QPainterPath
from PyQt5.QtWidgets import QFrame
from html import escape as html_escape
GEO_U = 24   # make_template('koordinat') birimi
GEO_COL = {'line': '#16a34a', 'par': '#0d9488', 'perp': '#ea580c', 'dist': '#0057ff', 'slope': '#c026d3', 'mid': '#b45309', 'cut': '#7c3aed'}
GEO_LINES = ('line', 'par', 'perp')
GEO_LETTERS = 'ABCDEFGHLNPRSTUVYZ'
def gq(v): return _Fr(str(v)).limit_denominator(100000)
def _minus(t): return t.replace('-', '−')
def gexact(q):   # sonlu ondalık mı (paydada yalnız 2 ve 5)
    d = q.denominator
    for f in (2, 5):
        while d % f == 0: d //= f
    return d == 1
def gdec(q, nd=2):
    t = ('%.*f' % (nd, float(q))).rstrip('0').rstrip('.')
    return _minus(t.replace('.', ',')) if t not in ('-0', '') else '0'
def gnum(q):   # koordinat yazımı: tam, sonlu ondalık ya da kesir
    if q.denominator == 1: return _minus(str(q.numerator))
    if gexact(q) and q.denominator <= 1000: return gdec(q, 4)
    return gfrac(q)
def gfrac(q): return _minus(str(q.numerator)) if q.denominator == 1 else _minus('%d/%d' % (q.numerator, q.denominator))
def gboth(q):   # 4/5 = 0,8  ·  1/3 ≈ 0,33  ·  2
    if q.denominator == 1: return gfrac(q)
    return gfrac(q) + (' = ' if gexact(q) and q.denominator <= 100 else ' ≈ ') + gdec(q)
def gpt(x, y):
    sep = ', ' if x.denominator == 1 and y.denominator == 1 else ' ; '
    return '(' + gnum(x) + sep + gnum(y) + ')'
def gpt_both(x, y):
    t = gpt(x, y)
    if all(q.denominator == 1 or (gexact(q) and q.denominator <= 1000) for q in (x, y)): return t
    return t + ' ≈ (' + gdec(x) + ' ; ' + gdec(y) + ')'
def _isqrt_q(q):
    import math as _m
    a, b = _m.isqrt(q.numerator), _m.isqrt(q.denominator)
    return _Fr(a, b) if a*a == q.numerator and b*b == q.denominator else None
def gdist(d2):
    import math as _m
    r = _isqrt_q(d2)
    if r is not None: return gnum(r)
    approx = ' ≈ ' + gdec(_Fr(_m.sqrt(d2)))
    if d2.denominator == 1:
        n = d2.numerator; k = 1; i = 2
        while i*i <= n:
            while n % (i*i) == 0: n //= i*i; k *= i
            i += 1
        return ('' if k == 1 else str(k)) + '√' + str(n) + approx
    return approx.strip()
def geq(L, dec=False):
    A, B, C = L; f = gdec if dec else gfrac
    if B == 0: return 'x = ' + f(C/A)
    m, c = -A/B, C/B; t = 'y = '
    if m != 0: t += ('' if m == 1 else '−' if m == -1 else f(m)) + 'x'
    if m == 0: t += f(c)
    elif c != 0: t += (' − ' if c < 0 else ' + ') + f(abs(c))
    return t
def geq_both(L):
    A, B, C = L; e = geq(L)
    if B == 0: frac_ = (C/A).denominator != 1
    else: frac_ = (A/B).denominator != 1 or (C/B).denominator != 1
    return e + ('   (' + geq(L, True) + ')' if frac_ else '')
def geo_find(marks):
    for m in marks:
        if m.get('tool') == 'geo': return m
    return None
def geo_eval(m):
    """Her nesnenin değeri: doğrular (A, B, C: Ax + By = C), noktalar, adlar."""
    P = [(gq(x), gq(y)) for x, y, _ in m['P']]; lines = {}; names = {}; nd = nm = nk = 0; out = []
    sub = '₀₁₂₃₄₅₆₇₈₉'
    def nm_(base, n): return base + ('' if n == 1 and base in 'MK' else ''.join(sub[int(c)] for c in str(n)))
    for k, o in enumerate(m['O']):
        t = o['t']; v = dict(t=t)
        try:
            if t in ('dist', 'line', 'slope', 'mid'):
                (ax, ay), (bx, by) = P[o['a']], P[o['b']]; v['ab'] = m['P'][o['a']][2] + m['P'][o['b']][2]
                if t == 'line':
                    A, B = by - ay, ax - bx
                    if A == 0 and B == 0: raise ValueError
                    lines[k] = (A, B, A*ax + B*ay)
                elif t == 'mid': nm += 1; v['pt'] = ((ax + bx)/2, (ay + by)/2); v['name'] = nm_('M', nm)
                elif t == 'dist': v['d2'] = (bx - ax)**2 + (by - ay)**2; v['seg'] = ((ax, ay), (bx, by))
                else: v['seg'] = ((ax, ay), (bx, by)); v['m'] = None if bx == ax else (by - ay)/(bx - ax); v['dx'] = bx - ax; v['dy'] = by - ay
            elif t in ('par', 'perp'):
                A, B, _ = lines[o['l']]; rx, ry = P[o['p']]
                if t == 'perp': A, B = -B, A
                lines[k] = (A, B, A*rx + B*ry); v['of'] = names[o['l']]; v['p'] = m['P'][o['p']][2]
                if t == 'perp':
                    A1, B1, C1 = lines[o['l']]; A2, B2, C2 = lines[k]; det = A1*B2 - A2*B1
                    v['foot'] = ((C1*B2 - C2*B1)/det, (A1*C2 - A2*C1)/det); v['dir'] = (-B1, A1)
            elif t == 'cut':
                (A1, B1, C1), (A2, B2, C2) = lines[o['l']], lines[o['m']]; v['of'] = (names[o['l']], names[o['m']])
                det = A1*B2 - A2*B1
                if det == 0: v['pt'] = None; v['same'] = A1*C2 == A2*C1 and B1*C2 == B2*C1
                else: nk += 1; v['pt'] = ((C1*B2 - C2*B1)/det, (A1*C2 - A2*C1)/det); v['name'] = nm_('K', nk)
            if k in lines: nd += 1; names[k] = 'd' + ''.join(sub[int(c)] for c in str(nd)); v['name'] = names[k]; v['L'] = lines[k]
        except (KeyError, IndexError, ZeroDivisionError, ValueError):
            v['bad'] = True
        out.append(v)
    return P, out
def geo_rows(m, vals):
    """Sonuç panosu satırları: (nesne no, renk, başlık, değer)."""
    rows = []
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        t = o['t']; c = GEO_COL[t]
        if t == 'dist': rows.append((k, c, '|%s| = ' % v['ab'], gdist(v['d2'])))
        elif t == 'slope': rows.append((k, c, 'm(%s) = Δy/Δx = ' % v['ab'], 'tanımsız (dikey doğru)' if v['m'] is None else gboth(v['m'])))
        elif t == 'mid': rows.append((k, c, '%s, %s’nin orta noktası: ' % (v['name'], v['ab']), v['name'] + gpt_both(*v['pt'])))
        elif t == 'line':
            L = v['L']; extra = []
            if L[1] != 0: extra.append(gpt(_Fr(0), L[2]/L[1]))
            if L[0] != 0 and not (L[1] != 0 and L[2] == 0): extra.append(gpt(L[2]/L[0], _Fr(0)))
            rows.append((k, c, '%s (%s): ' % (v['name'], v['ab']), geq_both(L) + ('   · eksenleri keser: ' + ' ve '.join(extra) if extra else '')))
        elif t in ('par', 'perp'):
            rows.append((k, c, '%s %s %s, %s’den: ' % (v['name'], '∥' if t == 'par' else '⊥', v['of'], v['p']), geq_both(v['L'])))
        elif t == 'cut':
            a, b = v['of']
            if v['pt'] is None: rows.append((k, c, '%s ∩ %s: ' % (a, b), 'çakışık (aynı doğru)' if v['same'] else 'kesişmez (paralel)'))
            else: rows.append((k, c, '%s ∩ %s = ' % (a, b), v['name'] + gpt_both(*v['pt'])))
    return rows
def halo_text(p, x, y, text, px, color, bold=False, align='l'):
    """Izgara üstünde okunaklı yazı: beyaz kenarlı."""
    f = QFont(p.font()); f.setPixelSize(max(1, int(px))); f.setBold(bold); fm = QFontMetricsF(f)
    w = fm.horizontalAdvance(text); x0 = x - w/2 if align == 'c' else x - w if align == 'r' else x
    path = QPainterPath(); path.addText(QPointF(x0, y), f, text)
    p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor(255, 255, 255, 235), px*.28, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.drawPath(path)
    p.setPen(Qt.NoPen); p.setBrush(QColor(color)); p.drawPath(path); p.setBrush(Qt.NoBrush)
    return QRectF(x0, y - fm.ascent(), w, fm.height())
def geo_layout(m, vals, W):
    """Panonun satır kutuları (sayfa birimi): [(nesne no, kutu, gizli mi)]."""
    rows = geo_rows(m, vals); f = QFont(); f.setPixelSize(13); fm = QFontMetricsF(f); fb = QFont(f); fb.setBold(True); fmb = QFontMetricsF(fb)
    out = []; y = 12
    for k, c, head, val in rows:
        hid = m['O'][k].get('h'); vtxt = '?' if hid else val
        w = 26 + fm.horizontalAdvance(head) + (34 if hid else fmb.horizontalAdvance(vtxt)) + 12
        out.append((k, QRectF(12, y, min(w, W*.62), 24), hid, c, head, vtxt)); y += 28
    return out
def geo_strokes(m, W, H):
    """PDF'ye: aynı çizim kalem çizgileri olarak (gizli cevaplar gizli kalır)."""
    P, vals = geo_eval(m); cx, cy, U = W/2, H/2, GEO_U; out = []
    X = lambda x: cx + float(x)*U; Y = lambda y: cy - float(y)*U
    def ln(a, b, col, w): out.append(dict(tool='pen', color=col, width=w, points=[list(a), list(b)]))
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        col = GEO_COL[o['t']]
        if 'L' in v:
            A, B, C = (float(t) for t in v['L'])
            if B == 0: ln((X(C/A), 0), (X(C/A), H), col, 2.2)
            else:
                xa, xb = -cx/U, cx/U; ya, yb = (C - A*xa)/B, (C - A*xb)/B
                pts = []
                for xx, yy in ((xa, ya), (xb, yb)):
                    if abs(yy) > cy/U: yy = math.copysign(cy/U, yy); xx = (C - B*yy)/A if A else xx
                    pts.append((X(xx), Y(yy)))
                ln(pts[0], pts[1], col, 2.2)
        elif o['t'] == 'dist': (ax, ay), (bx, by) = v['seg']; ln((X(ax), Y(ay)), (X(bx), Y(by)), col, 3)
        elif o['t'] == 'slope' and v['m'] is not None:
            (ax, ay), (bx, by) = v['seg']
            for (x0, y0), (x1, y1) in (((X(ax), Y(ay)), (X(bx), Y(ay))), ((X(bx), Y(ay)), (X(bx), Y(by)))):   # kesikli Δx, Δy
                L_ = math.hypot(x1 - x0, y1 - y0); n_ = max(1, int(L_/7))
                for j in range(0, n_, 2): ln((x0 + (x1 - x0)*j/n_, y0 + (y1 - y0)*j/n_), (x0 + (x1 - x0)*(j + 1)/n_, y0 + (y1 - y0)*(j + 1)/n_), col, 1.6)
            if not o.get('h'):
                if v['dx']: out += text_strokes('Δx = ' + gnum(v['dx']), (X(ax) + X(bx))/2, Y(ay) + (12 if by > ay else -8), 8, col, 1.1)
                if v['dy']: out += text_strokes('Δy = ' + gnum(v['dy']), X(bx) + 6, (Y(ay) + Y(by))/2, 8, col, 1.1, 'l')
        elif o['t'] in ('mid', 'cut') and v.get('pt') is not None:
            x, y = v['pt']; out += text_strokes(v['name'] + ('' if o.get('h') else gpt_canvas(x, y)), X(x) + 8, Y(y) + 12, 9, col, 1.2, 'l')
            out.append(dict(tool='pen', color=col, width=8, points=[[X(x), Y(y)]]))
    for i, (x, y) in enumerate(P):
        out.append(dict(tool='pen', color='#e8132b', width=9, points=[[X(x), Y(y)]]))
        out += text_strokes(m['P'][i][2] + gpt(x, y), X(x) + 8, Y(y) - 12, 10, '#111827', 1.3, 'l')
    y0 = 18
    for k, c, head, val in geo_rows(m, vals):
        for part in (head + ('?' if m['O'][k].get('h') else val)).split('   · '):
            out += text_strokes(part, 14, y0, 9, c, 1.1, 'l'); y0 += 16
    return out

def gpt_canvas(x, y):   # tahtadaki kısa yazım: tam/sonlu ondalık, değilse ≈ iki basamak
    if all(q.denominator == 1 or (gexact(q) and q.denominator <= 1000) for q in (x, y)): return gpt(x, y)
    return '≈(' + gdec(x) + ' ; ' + gdec(y) + ')'
def draw_geo(p, m, W, H, sel=()):
    P, vals = geo_eval(m); cx, cy, U = W/2, H/2, GEO_U
    X = lambda x: cx + float(x)*U; Y = lambda y: cy - float(y)*U
    p.save(); p.setClipRect(QRectF(0, 0, W, H)); p.setOpacity(1)
    placed = [QRectF(X(x) - 7, Y(y) - 7, 14, 14) for x, y in P]   # noktaların kendisi de dolu sayılır
    def label(ax, ay, text, px, color, bold=True, offs=None):
        """Yazıyı çevresindeki ilk boş yere koyar (öteki yazılara/noktalara binmez)."""
        f = QFont(p.font()); f.setPixelSize(max(1, int(px))); f.setBold(bold); fm = QFontMetricsF(f); w = fm.horizontalAdvance(text)
        offs = offs or [(9, -9, 'l'), (9, 19, 'l'), (-9, -9, 'r'), (-9, 19, 'l2'), (0, -14, 'c'), (0, 26, 'c'), (14, -24, 'l'), (14, 32, 'l'), (-14, -24, 'r'), (-14, 32, 'r')]
        first = None
        for dx, dy, al in offs:
            x0 = ax + dx - (w if al in ('r', 'l2') else w/2 if al == 'c' else 0); y0 = ay + dy
            box = QRectF(x0 - 2, y0 - fm.ascent() - 1, w + 4, fm.height() + 2)
            if first is None: first = (x0, y0, box)
            if 0 <= box.left() and box.right() <= W and 0 <= box.top() and box.bottom() <= H and not any(box.intersects(q) for q in placed):
                placed.append(box); halo_text(p, x0, y0, text, px, color, bold); return
        placed.append(first[2]); halo_text(p, first[0], first[1], text, px, color, bold)
    def line_seg(L):
        A, B, C = (float(v) for v in L)
        if B == 0: x = C/A; return (QPointF(X(x), 0), QPointF(X(x), H))
        xa, xb = -cx/U - 1, cx/U + 1
        return (QPointF(X(xa), Y((C - A*xa)/B)), QPointF(X(xb), Y((C - A*xb)/B)))
    hidden = lambda k: m['O'][k].get('h')
    names = []
    for k, (o, v) in enumerate(zip(m['O'], vals)):   # doğrular en altta
        if v.get('bad') or 'L' not in v: continue
        col = QColor(GEO_COL[o['t']]); a, b = line_seg(v['L'])
        if ('o', k) in sel: p.setPen(QPen(QColor(47, 124, 246, 70), 10, Qt.SolidLine, Qt.RoundCap)); p.drawLine(a, b)
        p.setPen(QPen(col, 2.4, Qt.SolidLine, Qt.RoundCap)); p.drawLine(a, b)
        names.append((a, b, v['name'], col.name()))
        if o['t'] == 'perp' and v.get('foot'):
            fx, fy = (float(t_) for t_ in v['foot']); A1, B1 = (float(t_) for t_ in v['dir'])
            n1 = math.hypot(A1, B1) or 1; u1 = (A1/n1, -B1/n1); A2, B2, _ = (float(t_) for t_ in v['L']); n2 = math.hypot(A2, B2) or 1; u2 = (-B2/n2, -A2/n2)
            e = 9; o_ = QPointF(X(fx), Y(fy)); a1 = QPointF(u1[0]*e, u1[1]*e); a2 = QPointF(u2[0]*e, u2[1]*e)
            p.setPen(QPen(col, 1.6)); p.drawPolyline(QPolygonF([o_ + a1, o_ + a1 + a2, o_ + a2]))
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        t = o['t']; col = QColor(GEO_COL[t])
        if t == 'dist':
            (ax, ay), (bx, by) = v['seg']; p.setPen(QPen(col, 3.4, Qt.SolidLine, Qt.RoundCap)); p.drawLine(QPointF(X(ax), Y(ay)), QPointF(X(bx), Y(by)))
        elif t == 'slope' and v['m'] is not None:
            (ax, ay), (bx, by) = v['seg']; pen = QPen(col, 2, Qt.DashLine); pen.setDashPattern([4, 3]); p.setPen(pen)
            p.drawPolyline(QPolygonF([QPointF(X(ax), Y(ay)), QPointF(X(bx), Y(ay)), QPointF(X(bx), Y(by))]))
    # noktalar
    for i, (x, y) in enumerate(P):
        c = QPointF(X(x), Y(y))
        if ('p', i) in sel: p.setPen(QPen(QColor('#2f7cf6'), 2.6)); p.setBrush(QColor(47, 124, 246, 40)); p.drawEllipse(c, 12, 12)
        p.setPen(QPen(Qt.white, 1.6)); p.setBrush(QColor('#e8132b')); p.drawEllipse(c, 5.5, 5.5); p.setBrush(Qt.NoBrush)
    for k, (o, v) in enumerate(zip(m['O'], vals)):   # türetilen noktalar
        if v.get('bad') or o['t'] not in ('mid', 'cut') or v.get('pt') is None: continue
        x, y = v['pt']; col = QColor(GEO_COL[o['t']]); p.setPen(QPen(Qt.white, 1.4)); p.setBrush(col); p.drawEllipse(QPointF(X(x), Y(y)), 5, 5); p.setBrush(Qt.NoBrush)
        placed.append(QRectF(X(x) - 6, Y(y) - 6, 12, 12))
    icpts = []   # doğruların eksenleri kestiği yerler
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad') or o['t'] != 'line': continue
        A, B, C = v['L']; col = GEO_COL['line']
        for ix, iy in ([(_Fr(0), C/B)] if B != 0 else []) + ([(C/A, _Fr(0))] if A != 0 and C != 0 else []):
            if abs(float(ix)) > cx/U or abs(float(iy)) > cy/U: continue
            p.setPen(QPen(QColor(col), 2)); p.setBrush(Qt.white); p.drawEllipse(QPointF(X(ix), Y(iy)), 4, 4); p.setBrush(Qt.NoBrush)
            placed.append(QRectF(X(ix) - 5, Y(iy) - 5, 10, 10)); icpts.append((ix, iy, col, not hidden(k)))
    # yazılar: önce asıl noktalar, sonra türetilenler, en son eksen kesimleri ve doğru adları
    for i, (x, y) in enumerate(P): label(X(x), Y(y), m['P'][i][2] + gpt(x, y), 15, '#111827')
    for k, (o, v) in enumerate(zip(m['O'], vals)):
        if v.get('bad'): continue
        col = GEO_COL[o['t']]
        if o['t'] in ('mid', 'cut') and v.get('pt') is not None:
            x, y = v['pt']; label(X(x), Y(y), v['name'] + ('' if hidden(k) else gpt_canvas(x, y)), 14, col)
        elif o['t'] == 'slope' and v['m'] is not None:
            (ax, ay), (bx, by) = v['seg']; h = hidden(k)
            if v['dx']: label((X(ax) + X(bx))/2, Y(ay), 'Δx = ' + ('?' if h else gnum(v['dx'])), 13, col, offs=[(0, 17 if by > ay else -8, 'c'), (0, -8 if by > ay else 17, 'c'), (0, 32, 'c')])
            if v['dy']: label(X(bx), (Y(ay) + Y(by))/2 + 5, 'Δy = ' + ('?' if h else gnum(v['dy'])), 13, col, offs=[(8, 0, 'l') if bx > ax else (-8, 0, 'r'), (-8, 0, 'r') if bx > ax else (8, 0, 'l'), (8, 18, 'l')])
    for ix, iy, col, show in icpts:
        if show: label(X(ix), Y(iy), gpt_canvas(ix, iy), 12, col, False)
    for a, b, name, col in names:   # doğru adı: sayfanın içinde, uca yakın boş yer
        d = b - a; n = math.hypot(d.x(), d.y()) or 1; nx, ny = -d.y()/n, d.x()/n
        if ny > 0: nx, ny = -nx, -ny
        for i in range(60):
            q = a + d*(.95 - i*.015)
            if 30 < q.x() < W - 30 and 30 < q.y() < H - 30: break
        label(q.x(), q.y(), name, 15, col, True, [(nx*16, ny*16 + 5, 'c'), (-nx*16, -ny*16 + 5, 'c'), (nx*30, ny*30 + 5, 'c')])
    p.restore()

class GeoPanel(QWidget):
    """Sonuçlar: ekranın sağında, katlanır, başlığından sürüklenir; “?” dokununca açılır."""
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.setObjectName('geopanel'); self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet('#geopanel{background:rgba(15,26,46,238);border:1px solid #2b3b5a;border-radius:16px;}'
                           '#geopanel QLabel{color:#dbe5f7;font-size:17px;background:transparent;}'
                           '#geopanel QPushButton{background:#22314d;color:#e8eefc;border:1px solid #33456a;border-radius:10px;font-size:17px;padding:2px 10px;}'
                           '#geopanel QPushButton#soru{background:#fef3c7;color:#92400e;border:1.5px solid #d97706;font-weight:700;min-width:46px;}')
        from PyQt5.QtWidgets import QLayout
        self.box = QVBoxLayout(self); self.box.setContentsMargins(14, 10, 14, 12); self.box.setSpacing(6); self.box.setSizeConstraint(QLayout.SetFixedSize)
        head = QHBoxLayout(); self.title = QLabel('Sonuçlar'); self.title.setStyleSheet('font-size:18px;font-weight:600;color:#ffffff;'); head.addWidget(self.title); head.addStretch(1)
        self.fold = QPushButton('–'); self.fold.setFocusPolicy(Qt.NoFocus); self.fold.setFixedSize(40, 34); self.fold.clicked.connect(self.toggle); head.addWidget(self.fold)
        self.box.addLayout(head); self.body = QWidget(); self.rows = QVBoxLayout(self.body); self.rows.setContentsMargins(0, 0, 0, 0); self.rows.setSpacing(6); self.box.addWidget(self.body)
        self.offset = None; self.drag = None; self.folded = False; self.hide()
    def toggle(self):
        self.folded = not self.folded; self.body.setVisible(not self.folded); self.fold.setText('+' if self.folded else '–'); self.adjustSize(); self.place()
    def fill(self, m):
        old = self.body; self.body = QWidget(); self.rows = QVBoxLayout(self.body); self.rows.setContentsMargins(0, 0, 0, 0); self.rows.setSpacing(6)
        self.box.replaceWidget(old, self.body); old.deleteLater(); self.body.setVisible(not self.folded)
        P, vals = geo_eval(m); rows = geo_rows(m, vals); n = 0
        for k, c, head, val in rows:
            line = QHBoxLayout(); line.setSpacing(8); hid = m['O'][k].get('h')
            dot = QLabel('●'); dot.setStyleSheet('color:%s;font-size:16px;' % c); line.addWidget(dot, 0, Qt.AlignTop)
            if hid:
                h_ = QLabel(head.strip()); line.addWidget(h_); q = QPushButton('?'); q.setObjectName('soru'); q.setFocusPolicy(Qt.NoFocus)
                q.clicked.connect(lambda checked=False, k_=k: self.main.geo_reveal(k_)); line.addWidget(q); line.addStretch(1)
            else:
                v_ = html_escape(val).replace('   · ', '<br>').replace('   (', '&nbsp;&nbsp;(')
                lab = QLabel('%s<b style="color:%s">%s</b>' % (html_escape(head), QColor(c).lighter(135).name(), v_)); lab.setTextFormat(Qt.RichText); line.addWidget(lab, 1)
            self.rows.addLayout(line); n += 1
        self.title.setText('Sonuçlar (%d)' % n if n else 'Sonuçlar'); self.body.adjustSize(); self.adjustSize()
        return n
    def place(self):
        vp = self.main.scroll.viewport().geometry(); self.adjustSize()
        if self.offset is None: x, y = vp.right() - self.width() - 12, vp.y() + 74
        else: x, y = vp.x() + self.offset.x(), vp.y() + self.offset.y()
        x = max(vp.x() + 4, min(x, vp.right() - self.width() - 4)); y = max(vp.y() + 4, min(y, vp.bottom() - min(self.height(), 60)))
        self.move(x, y); self.raise_()
    def resizeEvent(self, e):
        if self.isVisible(): QTimer.singleShot(0, self.place)
    def mousePressEvent(self, e): self.drag = e.globalPos() - self.pos()
    def mouseMoveEvent(self, e):
        if self.drag is not None:
            vp = self.main.scroll.viewport().geometry(); np_ = e.globalPos() - self.drag; self.offset = np_ - vp.topLeft(); self.place()
    def mouseReleaseEvent(self, e): self.drag = None

class GeoBar(QWidget):
    """Koordinat düzlemi araç çubuğu: yalnızca koordinat şablonunda görünür."""
    BTN = [('nokta', 'Nokta koy'), ('gir', 'Koordinat gir'), None, ('dist', 'Mesafe'), ('line', 'Doğru'), ('slope', 'Eğim'), ('mid', 'Orta nokta'),
           ('par', 'Paralel'), ('perp', 'Dik'), ('cut', 'Kesişim'), None, ('gizle', 'Cevabı gizle'), ('sil', 'Sil'), ('temizle', 'Temizle')]
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.setObjectName('geobar'); self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet('#geobar{background:rgba(15,26,46,236);border:1px solid #2b3b5a;border-radius:16px;}'
                           '#geobar QPushButton{background:#22314d;color:#e8eefc;border:1px solid #33456a;border-radius:11px;padding:8px 13px;font-size:15px;min-height:26px;}'
                           '#geobar QPushButton:checked{background:#2f7cf6;border-color:#2f7cf6;color:white;}'
                           '#geobar QPushButton[pasif="true"]{color:#6b7c99;background:#1a2640;border-color:#24324d;}'
                           '#geobar QFrame{background:#33456a;}')
        row = QHBoxLayout(self); row.setContentsMargins(8, 7, 8, 7); row.setSpacing(6); self.b = {}
        for it in self.BTN:
            if it is None:
                sep = QFrame(); sep.setFixedSize(1, 30); row.addWidget(sep); continue
            k, t = it; b = QPushButton(t); b.setFocusPolicy(Qt.NoFocus); b.setCheckable(k in ('nokta', 'gizle'))
            b.clicked.connect(lambda checked=False, k_=k: self.main.geo_action(k_)); row.addWidget(b); self.b[k] = b
        self.hide()
    def sync(self):
        o = self.main; sel = getattr(o.board, 'geo_sel', []); np_ = sum(1 for t, _ in sel if t == 'p'); nl = len(sel) - np_
        self.b['nokta'].setChecked(o.tool == 'geo'); self.b['gizle'].setChecked(getattr(o, 'geo_hide', False))
        ok = {'dist': np_ == 2, 'line': np_ == 2, 'slope': np_ == 2, 'mid': np_ == 2, 'par': np_ == 1 and nl == 1, 'perp': np_ == 1 and nl == 1, 'cut': nl == 2, 'sil': bool(sel)}
        for k, v in ok.items():
            b = self.b[k]
            if b.property('pasif') != (not v): b.setProperty('pasif', not v); b.style().unpolish(b); b.style().polish(b)
    def place(self):
        vp = self.main.scroll.viewport().geometry(); self.adjustSize()
        self.move(vp.x() + max(10, (vp.width() - self.width())//2), vp.y() + 10); self.raise_()

class GeoInput(QDialog):
    """Koordinat gir: x ve y, tahtanın kendi tuş takımıyla."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Koordinat gir'); self.setModal(True)
        from PyQt5.QtWidgets import QLineEdit
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(10)
        t = QLabel('Nokta koordinatı'); t.setStyleSheet('font-size:21px;font-weight:600;'); box.addWidget(t)
        row = QHBoxLayout(); row.setSpacing(8); box.addLayout(row); self.fields = []
        for i, name in enumerate(('x', 'y')):
            l = QLabel(('( ' if i == 0 else ' ;  ') + name + ' ='); l.setStyleSheet('font-size:20px;'); row.addWidget(l)
            e = QLineEdit(); e.setMinimumHeight(52); e.setFixedWidth(130); e.setAlignment(Qt.AlignCenter); e.setStyleSheet('font-size:22px;'); e.installEventFilter(self); row.addWidget(e); self.fields.append(e)
        r_ = QLabel(' )'); r_.setStyleSheet('font-size:20px;'); row.addWidget(r_); row.addStretch(1)
        self.cur = self.fields[0]; self.err = QLabel(''); self.err.setStyleSheet('color:#ff8a95;font-size:15px;'); box.addWidget(self.err)
        pad = QHBoxLayout(); box.addLayout(pad); pad.addWidget(NumPad(self, self.key), 1)
        sign = QPushButton('±'); sign.setFocusPolicy(Qt.NoFocus); sign.setMinimumSize(70, 52); sign.setStyleSheet('font-size:24px;'); sign.clicked.connect(lambda: self.key('±')); pad.addWidget(sign, 0, Qt.AlignTop)
        bt = QHBoxLayout(); box.addLayout(bt)
        c = QPushButton('Vazgeç'); c.setMinimumHeight(48); c.clicked.connect(self.reject); bt.addWidget(c)
        ok = QPushButton('Noktayı koy'); ok.setMinimumHeight(48); ok.setObjectName('primary'); ok.clicked.connect(self.put); bt.addWidget(ok)
        self.fields[0].setFocus()
    def eventFilter(self, o, e):
        if e.type() == QEvent.FocusIn and o in self.fields: self.cur = o
        return False
    def key(self, k):
        e = self.cur; t = e.text()
        if k == '⌫': e.setText(t[:-1])
        elif k == 'Temizle': e.setText('')
        elif k == '±': e.setText(t[1:] if t.startswith('−') else '−' + t)
        elif k == ',':
            if ',' not in t: e.setText((t or '0') + ',')
        else: e.setText(t + k)
        e.setFocus()
    def put(self):
        try:
            x, y = (gq(float(f.text().replace('−', '-').replace(',', '.'))) for f in self.fields)
        except ValueError:
            self.err.setText('İki sayıyı da girin (ör. 2,5 ve −3).'); return
        page = self.main.doc[self.main.page].rect
        if abs(float(x)) > page.width/2/GEO_U or abs(float(y)) > page.height/2/GEO_U:
            self.err.setText('Bu nokta düzlemin dışında kalıyor (x: ±%d, y: ±%d).' % (page.width/2/GEO_U, page.height/2/GEO_U)); return
        self.main.board.geo_point(x, y); self.accept()

# ---- Yönetim: tahtanın sınıfı ve durum bildirimi (kişisel veri yok) ----
CLASS_GRADES = ['9', '10', '11', '12']
CLASS_BY_GRADE = {'9': 'ABCD', '10': 'ABCDEFGH', '11': 'ABCDEFGHI', '12': 'ABCDEFGHI'}   # okulun şubeleri (12-J'de tahta yok)
CLASS_SECTIONS = list('ABCDEFGHI')
CLASS_PLACES = ['Öğretmenler odası']   # sınıf dışında tahta olan tek yer
class ClassDialog(QDialog):
    """Bu tahta hangi sınıfta? Bir kez sorulur; Ayarlar'dan değiştirilebilir."""
    def __init__(self, main, current=''):
        super().__init__(main); self.setWindowTitle('Tahtanın sınıfı'); self.setModal(True); self.value = current or ''
        box = QVBoxLayout(self); box.setContentsMargins(24, 20, 24, 20); box.setSpacing(12)
        t = QLabel('Bu tahta hangi sınıfta?'); t.setStyleSheet('font-size:22px;font-weight:600;'); box.addWidget(t)
        n = QLabel('Yalnızca bir kez sorulur. Okul yönetimi tahtayı bu adla görür. Ayarlar’dan değiştirilebilir.'); n.setWordWrap(True); box.addWidget(n)
        self.grade = None; self.section = None; self.buttons = {}
        def row(label, items, kind):
            box.addWidget(QLabel(label)); r = QHBoxLayout(); r.setSpacing(8); box.addLayout(r)
            for it in items:
                b = QPushButton(it); b.setCheckable(True); b.setMinimumSize(64 if kind != 'place' else 120, 54); b.setStyleSheet('font-size:19px;')
                b.clicked.connect(lambda checked=False, v=it, k=kind: self.pick(k, v)); r.addWidget(b); self.buttons[(kind, it)] = b
            r.addStretch(1)
        row('Sınıf', CLASS_GRADES, 'grade'); row('Şube', CLASS_SECTIONS, 'section')
        box.addWidget(QLabel('Sınıf dışında bir yerse'))
        g = QGridLayout(); g.setSpacing(8); box.addLayout(g)
        for i, it in enumerate(CLASS_PLACES):
            b = QPushButton(it); b.setCheckable(True); b.setMinimumHeight(50); b.setStyleSheet('font-size:17px;')
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed); b.setMinimumWidth(200)
            b.clicked.connect(lambda checked=False, v=it: self.pick('place', v)); g.addWidget(b, i//3, i % 3, 1, 3 if len(CLASS_PLACES) == 1 else 1); self.buttons[('place', it)] = b
        for c in range(3): g.setColumnStretch(c, 1)   # eşit genişlik
        box.addSpacing(4); self.shown = QLabel(); self.shown.setStyleSheet('font-size:20px;'); box.addWidget(self.shown)
        bt = QHBoxLayout(); box.addLayout(bt)
        later = QPushButton('Sonra'); later.setMinimumHeight(50); later.clicked.connect(self.reject); bt.addWidget(later)
        self.ok = QPushButton('Kaydet'); self.ok.setObjectName('primary'); self.ok.setMinimumHeight(50); self.ok.clicked.connect(self.accept); bt.addWidget(self.ok)
        if '-' in self.value and self.value.split('-')[0] in CLASS_GRADES:
            self.grade, self.section = self.value.split('-', 1)
        self.refresh()
    def pick(self, kind, v):
        if kind == 'place': self.grade = self.section = None; self.value = v
        else:
            if self.value in CLASS_PLACES: self.value = ''
            if kind == 'grade':
                self.grade = v
                if self.section and self.section not in CLASS_BY_GRADE.get(v, ''): self.section = None   # o seviyede olmayan şube
            else: self.section = v
            self.value = '%s-%s' % (self.grade, self.section) if self.grade and self.section else ''
        self.refresh()
    def refresh(self):
        valid = CLASS_BY_GRADE.get(self.grade, '')
        for (k, it), b in self.buttons.items():
            if k == 'section': b.setVisible(bool(valid) and it in valid)   # yalnız o seviyedeki şubeler
            b.setChecked((k == 'grade' and it == self.grade) or (k == 'section' and it == self.section) or (k == 'place' and it == self.value))
        self.shown.setText('Seçilen: <b>%s</b>' % (self.value or '—')); self.ok.setEnabled(bool(self.value))

class AcilMesaj(QWidget):
    """K-341: tahtayı kaplayan yönetim mesajı. Başlık ve metin kendi alanlarına sığacak boyda yazılır (üst üste binmez)."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.m = {}; self.mid = None
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.ok = QPushButton('Okudum', self); self.ok.setFocusPolicy(Qt.NoFocus); self.ok.clicked.connect(lambda: self.main.acil_okudum(self.mid))
        self.hide()
    def goster(self, m):
        self.m = dict(m); self.mid = m.get('id'); self.yerlestir(); self.update()
    def resizeEvent(self, e): self.yerlestir()
    def yerlestir(self):
        k = min(self.width()/1600, self.height()/900) or 1
        self.ok.setStyleSheet('QPushButton{background:#281404;color:#ff9a3a;border:2px solid #ff9a3a;border-radius:%dpx;padding:0 %dpx;font-size:%dpx;font-weight:800;}' % (int(16*k), int(48*k), max(16, int(30*k))))
        self.ok.setFixedHeight(max(52, int(76*k))); self.ok.adjustSize()
        self.ok.move((self.width() - self.ok.width())//2, self.height() - self.ok.height() - int(46*k))
    @staticmethod
    def sigdir(p, rect, text, fam, bold, px_max, px_min, flags):
        from PyQt5.QtGui import QFont, QFontMetrics
        px = px_max
        while True:
            f = QFont(fam); f.setPixelSize(int(px)); f.setBold(bold)
            br = QFontMetrics(f).boundingRect(rect.toRect(), flags, text)
            if (br.height() <= rect.height() and br.width() <= rect.width()) or px <= px_min: return f
            px = max(px_min, px * 0.92)
    def paintEvent(self, e):
        from PyQt5.QtGui import QLinearGradient, QRadialGradient
        fams = ui_fonts(); fam = fams.get('Poppins-Medium') or 'Sans'; famb = fams.get('Poppins-Bold') or fam
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); k = min(W/1600, H/900) or 1
        g = QRadialGradient(W/2, H/2, max(W, H)*0.7); g.setColorAt(0, QColor('#2a1406')); g.setColorAt(1, QColor('#0b0705')); p.fillRect(self.rect(), g)
        p.setPen(QPen(QColor('#ff9a3a'), max(4, 6*k))); p.setBrush(Qt.NoBrush); p.drawRoundedRect(QRectF(6*k, 6*k, W - 12*k, H - 12*k), 22*k, 22*k)
        from PyQt5.QtGui import QFont
        f = QFont(famb); f.setPixelSize(max(14, int(26*k))); f.setLetterSpacing(QFont.AbsoluteSpacing, 6*k); p.setFont(f); p.setPen(QColor('#ff9a3a'))
        p.drawText(QRectF(0, 34*k, W, 50*k), Qt.AlignCenter, 'OKUL YÖNETİMİ')
        f2 = QFont(fam); f2.setPixelSize(max(12, int(22*k))); p.setFont(f2); p.setPen(QColor('#9fb3cc'))
        p.drawText(QRectF(0, 34*k, W - 50*k, 50*k), Qt.AlignVCenter | Qt.AlignRight, time.strftime('%H.%M'))
        bas = str(self.m.get('baslik') or '').strip(); met = str(self.m.get('metin') or '').strip()
        ust = 110*k; alt = self.ok.y() - 30*k; x0 = W*0.08; gen = W*0.84
        fl = int(Qt.AlignHCenter | Qt.AlignVCenter | Qt.TextWordWrap)
        if bas:
            r1 = QRectF(x0, ust, gen, (alt - ust)*0.34); r2 = QRectF(x0, r1.bottom() + 20*k, gen, alt - r1.bottom() - 20*k)
            fb = self.sigdir(p, r1, bas, famb, True, 96*k, 22*k, fl)
            p.setFont(fb); p.setPen(QColor('#ffffff')); p.drawText(r1, fl, bas)
        else: r2 = QRectF(x0, ust, gen, alt - ust)
        if met:
            fm = self.sigdir(p, r2, met, fam, False, 60*k, 14*k, fl)
            p.setFont(fm); p.setPen(QColor('#ffe3c6')); p.drawText(r2, fl, met)
        p.end()
    def mousePressEvent(self, e): e.accept()   # arkadaki tahtaya dokunma gitmez

class MessageBar(QFrame):
    """Panelden gelen mesaj: tahtanın üstünde şerit (yazıyı kapatmaz)."""
    KIND = {'bilgi': ('#1f3c73', '#eaf2ff', 'Okul yönetimi', 'Tamam'), 'not': ('#5a4610', '#fff3d1', 'Not', 'Tamam'),
            'pdf': ('#0f4a43', '#e2f6ef', 'Belge', 'Kapat'), 'hata': ('#6e1c1c', '#ffecec', 'Hatalı soru', 'Sınıfa okudum'),
            'surum': ('#3a2d72', '#efeaff', 'Yeni sürüm yüklendi', 'Yeniden başlat')}
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setObjectName('msgbar'); self.setMaximumHeight(280)
        row = QHBoxLayout(self); row.setContentsMargins(16, 10, 10, 10); row.setSpacing(10)
        self.text = QLabel(); self.text.setWordWrap(True); self.text.setTextFormat(Qt.RichText); row.addWidget(self.text, 1)
        self.count = QLabel(); row.addWidget(self.count)
        self.next = QPushButton('Sonraki'); self.next.clicked.connect(main.next_message); row.addWidget(self.next)
        self.open = QPushButton('Aç'); self.open.setObjectName('primary'); self.open.clicked.connect(main.open_message_pdf); row.addWidget(self.open)
        self.ok = QPushButton(); self.ok.clicked.connect(main.ack_message); row.addWidget(self.ok)
        for b in (self.next, self.open, self.ok): b.setMinimumHeight(46); b.setFocusPolicy(Qt.NoFocus)
    def show_msg(self, m, i, n):
        bg, fg, title, ok = self.KIND.get(m.get('tur'), self.KIND['bilgi'])
        self.setStyleSheet('QFrame#msgbar{background:%s;border-radius:12px;} QFrame#msgbar QLabel{color:%s;background:transparent;font-size:19px;}' % (bg, fg))
        esc = lambda t: html_escape(str(t or '')).replace('\n', '<br>')
        head = title
        if m.get('tur') == 'pdf': head = 'Belge: ' + str((m.get('pdf') or {}).get('ad') or 'PDF')
        if m.get('baslik'): head += ' · ' + str(m['baslik'])
        body = esc(m.get('metin'))
        self.text.setText('<b>%s</b>%s' % (esc(head), ('<br>' + body) if body else ''))
        self.count.setText('%d/%d' % (i + 1, n) if n > 1 else ''); self.count.setVisible(n > 1); self.next.setVisible(n > 1)
        self.open.setText('Sonra' if m.get('tur') == 'surum' else 'Aç'); self.open.setObjectName('' if m.get('tur') == 'surum' else 'primary')
        self.ok.setObjectName('primary' if m.get('tur') == 'surum' else '')
        for b in (self.open, self.ok): b.style().unpolish(b); b.style().polish(b)
        self.open.setVisible(m.get('tur') == 'surum' or (m.get('tur') == 'pdf' and bool(m.get('pdf_yol')))); self.ok.setText(ok); self.show()

class TriangleDialog(QDialog):
    """Ölçülü üçgen: ne bilindiğini seç, değerleri gir, tahtaya koy."""
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Ölçülü üçgen'); self.setModal(True)
        from PyQt5.QtWidgets import QLineEdit, QCheckBox
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(860, scr.width()-60), min(760, scr.height()-60))
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(10)
        t = QLabel('Ölçülü üçgen'); t.setStyleSheet('font-size:21px;font-weight:600;'); box.addWidget(t)
        box.addWidget(QLabel('Ne biliniyor?'))
        row = QHBoxLayout(); row.setSpacing(6); box.addLayout(row); self.mode_buttons = {}
        for key, name, _ in TRI_MODES:
            b = QPushButton(name); b.setCheckable(True); b.setMinimumHeight(46); b.clicked.connect(lambda checked=False, k=key: self.set_mode(k)); row.addWidget(b); self.mode_buttons[key] = b
        body = QHBoxLayout(); body.setSpacing(18); box.addLayout(body)
        left = QVBoxLayout(); left.setSpacing(8); body.addLayout(left, 3)
        self.grid = QGridLayout(); self.grid.setVerticalSpacing(8); self.grid.setHorizontalSpacing(12); left.addLayout(self.grid)
        self.labels = []; self.fields = []
        for i in range(3):
            l = QLabel(); e = QLineEdit(); e.setMinimumHeight(50); e.setStyleSheet('font-size:21px;'); e.installEventFilter(self); e.textChanged.connect(self.check)
            self.grid.addWidget(l, i, 0); self.grid.addWidget(e, i, 1); self.labels.append(l); self.fields.append(e)
        self.result = QLabel(); self.result.setWordWrap(True); self.result.setStyleSheet('font-size:16px;'); left.addWidget(self.result)
        cfg = main.tri_cfg if hasattr(main, 'tri_cfg') else {}
        self.opts = {}
        for key, name, on in (('names', 'Köşe adları (A, B, C)', True), ('sides', 'Verilen kenarlar', True), ('angles', 'Verilen açılar', True),
                              ('calc', 'Hesaplanan değerler', False), ('height', 'Yükseklik (C’den)', False), ('bisector', 'Açıortay (A’dan)', False), ('median', 'Kenarortay (A’dan)', False)):
            c = QCheckBox(name); c.setChecked(cfg.get(key, on)); left.addWidget(c); self.opts[key] = c
        left.addStretch(1)
        right = QVBoxLayout(); body.addLayout(right, 2)
        self.pad = NumPad(self, self.key); right.addWidget(self.pad); right.addStretch(1)
        btns = QHBoxLayout(); box.addLayout(btns)
        no = QPushButton('Vazgeç'); no.setMinimumHeight(50); no.clicked.connect(self.reject); btns.addWidget(no)
        self.ok = QPushButton('Tahtaya koy'); self.ok.setObjectName('primary'); self.ok.setMinimumHeight(50); self.ok.clicked.connect(self.place); btns.addWidget(self.ok)
        self.target = None; self.set_mode(cfg.get('mode', 'sas'))
    def eventFilter(self, o, e):
        if e.type() in (QEvent.FocusIn, QEvent.MouseButtonPress) and o in self.fields: self.target = o
        return False
    def key(self, k):
        t = self.target or next((f for f in self.fields if f.isVisible()), None)
        if t is None: return
        if k == '⌫': t.backspace()
        elif k == 'Temizle': t.clear()
        else: t.insert(k)
    def set_mode(self, key):
        self.mode = key
        for k, b in self.mode_buttons.items(): b.setChecked(k == key)
        names = dict((k, f) for k, _, f in TRI_MODES)[key]
        for i in range(3):
            vis = i < len(names); self.labels[i].setVisible(vis); self.fields[i].setVisible(vis)
            if vis: self.labels[i].setText(names[i] + ('  (derece)' if 'açı' in names[i] else '')); self.labels[i].setStyleSheet('font-size:18px;')
        self.target = self.fields[0]; self.fields[0].setFocus(); self.check()
    def values(self):
        n = len(dict((k, f) for k, _, f in TRI_MODES)[self.mode]); out = []
        for f in self.fields[:n]:
            t = f.text().strip().replace(',', '.').replace('°', '')
            try: out.append(float(t))
            except ValueError: return None
        return out
    def check(self):
        v = self.values()
        if v is None: self.result.setText('Değerleri girin.'); self.result.setStyleSheet('font-size:16px;color:#a9b9cf;'); self.ok.setEnabled(False); return None
        sol = triangle_solve(self.mode, v)
        if isinstance(sol, str): self.result.setText(sol); self.result.setStyleSheet('font-size:16px;color:#ff8a95;'); self.ok.setEnabled(False); return None
        a, b, c, A, B, C = sol
        txt = 'Geçerli üçgen · ' + ('|AB| ≈ %s · |BC| ≈ %s · |CA| ≈ %s · ' % (fmt_num(c), fmt_num(a), fmt_num(b)) if self.mode != 'aaa' else '') + 'A ≈ %s° · B ≈ %s° · C ≈ %s°' % (fmt_num(A, 1), fmt_num(B, 1), fmt_num(C, 1))
        self.result.setText('✓ ' + txt); self.result.setStyleSheet('font-size:16px;color:#4ade80;'); self.ok.setEnabled(True); return sol
    def place(self):
        sol = self.check()
        if sol is None: return
        opts = {k: c.isChecked() for k, c in self.opts.items()}; self.main.tri_cfg = dict(opts, mode=self.mode)
        b = self.main.board; vis = b.visibleRegion().boundingRect(); size = min(vis.width(), vis.height())/b.scale*.42
        self.main.pending_triangle = triangle_marks(sol, self.mode, opts, size, self.main.color if self.main.color != '#ffffff' or self.main.background in DARK_BACKGROUNDS else PEN_DEFAULT, max(2, self.main.width.value()))
        self.main.pending_label = None; self.accept(); self.main.set_tool('place_tri')


# ---------------------------------------------------------------------------
# Şablonlar: koordinat düzlemi, sayı doğrusu, izometrik, milimetrik (yeni boş tahta)
TEMPLATES = [('koordinat', 'Koordinat düzlemi'), ('sayi', 'Sayı doğrusu'), ('izometrik', 'İzometrik'), ('milimetrik', 'Milimetrik')]

def make_template(key, width=960, height=540):
    doc = fitz.open(); page = doc.new_page(width=width, height=height); sh = page.new_shape()
    dark = (.2, .25, .33); light = (.84, .88, .94)
    def label(x, y, t, size=8):
        page.insert_text((x - fitz.get_text_length(t, fontsize=size)/2, y), t, fontsize=size, color=dark)
    if key == 'koordinat':
        u = 24; cx, cy = width/2, height/2
        for i in range(-int(cx//u), int(cx//u) + 1): sh.draw_line((cx + i*u, 0), (cx + i*u, height))
        for j in range(-int(cy//u), int(cy//u) + 1): sh.draw_line((0, cy + j*u), (width, cy + j*u))
        sh.finish(color=light, width=.6)
        sh.draw_line((8, cy), (width - 8, cy)); sh.draw_line((cx, height - 8), (cx, 8))
        sh.draw_polyline([(width - 18, cy - 5), (width - 8, cy), (width - 18, cy + 5)]); sh.draw_polyline([(cx - 5, 18), (cx, 8), (cx + 5, 18)])
        sh.finish(color=dark, width=1.4)
        for i in range(-int(cx//u) + 1, int(cx//u)):
            if i: sh.draw_line((cx + i*u, cy - 3), (cx + i*u, cy + 3)); label(cx + i*u, cy + 13, str(i))
        for j in range(-int(cy//u) + 1, int(cy//u)):
            if j: sh.draw_line((cx - 3, cy - j*u), (cx + 3, cy - j*u)); page.insert_text((cx - 6 - fitz.get_text_length(str(j), fontsize=8), cy - j*u + 3), str(j), fontsize=8, color=dark)
        sh.finish(color=dark, width=1); label(cx - 7, cy + 13, '0'); label(width - 14, cy - 8, 'x', 11); label(cx + 12, 16, 'y', 11)
    elif key == 'sayi':
        for yy, n in ((height*.25, 10), (height*.5, 10), (height*.75, 10)):
            x0, x1 = 40, width - 40; step = (x1 - x0)/(2*n + 2)
            sh.draw_line((x0 - 10, yy), (x1 + 10, yy)); sh.draw_polyline([(x1, yy - 5), (x1 + 10, yy), (x1, yy + 5)]); sh.draw_polyline([(x0, yy - 5), (x0 - 10, yy), (x0, yy + 5)])
            for i in range(-n, n + 1):
                x = width/2 + i*step; big = i == 0
                sh.draw_line((x, yy - (8 if big else 5)), (x, yy + (8 if big else 5))); label(x, yy + 20, str(i), 9)
        sh.finish(color=dark, width=1.3)
    elif key == 'izometrik':
        u = 24; hrow = u*math.sqrt(3)/2; j = 0; y = 0.0
        while y <= height + 1:
            off = (u/2) if j % 2 else 0; x = off
            while x <= width + 1: sh.draw_circle((x, y), 1.3); x += u
            y += hrow; j += 1
        sh.finish(color=None, fill=(.45, .53, .66))
    elif key == 'milimetrik':
        mm = 72/25.4
        for i in range(int(width/mm) + 1):
            x = i*mm; w_ = .9 if i % 10 == 0 else .55 if i % 5 == 0 else .25
            sh.draw_line((x, 0), (x, height)); sh.finish(color=(.93, .55, .45) if i % 10 == 0 else (.96, .78, .72), width=w_)
        for i in range(int(height/mm) + 1):
            y = i*mm; w_ = .9 if i % 10 == 0 else .55 if i % 5 == 0 else .25
            sh.draw_line((0, y), (width, y)); sh.finish(color=(.93, .55, .45) if i % 10 == 0 else (.96, .78, .72), width=w_)
    sh.commit(); doc.set_metadata({'title': APP_NAME, 'keywords': 'UMAL-template:' + key}); return doc

class TemplateDialog(QDialog):
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Şablonlar'); self.setModal(True)
        box = QVBoxLayout(self); box.setContentsMargins(22, 18, 22, 18); box.setSpacing(12)
        t = QLabel('Şablonlar · seçilen zeminle yeni boş tahta açılır'); t.setStyleSheet('font-size:19px;font-weight:600;'); box.addWidget(t)
        g = QGridLayout(); g.setSpacing(14); box.addLayout(g)
        for i, (key, name) in enumerate(TEMPLATES):
            d = make_template(key); pix = d[0].get_pixmap(matrix=fitz.Matrix(.36, .36), alpha=False); d.close()
            b = QPushButton(name); b.setIcon(QIcon(QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy())))
            b.setIconSize(QSize(pix.width, pix.height)); b.setStyleSheet('QPushButton{padding:10px;font-size:17px;}'); b.setMinimumHeight(pix.height + 24)
            b.clicked.connect(lambda checked=False, k=key, n=name: self.pick(k, n)); g.addWidget(b, i//2, i % 2)
        c = QPushButton('Vazgeç'); c.setMinimumHeight(48); c.clicked.connect(self.reject); box.addWidget(c)
    def pick(self, key, name):
        m = self.main; self.accept(); m.start_tab(name); m.replace(make_template(key)); m.tabs_changed(); m.set_tool('pen')

# ---------------------------------------------------------------------------
# Grafik çizici: y = f(x) (log, ln, üstel, sin/cos/tan, mutlak değer, kök…) → yeni tahta sekmesinde vektör grafik
import re as _re
_SUB = str.maketrans('₀₁₂₃₄₅₆₇₈₉', '0123456789')
def graph_compile(expr):
    """Öğretmenin yazdığını güvenli Python ifadesine çevirir. Döner: (işlev, hata)."""
    s0 = expr.strip()
    s = s0.lower().replace(' ', '').replace('−', '-').replace('·', '*').replace('×', '*').replace('÷', '/')
    s = _re.sub(r'^(y|f\(x\))=', '', s)
    if not s: return None, 'Fonksiyonu yazın.'
    s = _re.sub(r'(\d),(\d)', r'\1.\2', s)
    s = s.replace('²', '**2').replace('³', '**3').replace('π', 'pi').replace('^', '**')
    s = _re.sub(r'log([₀-₉]+)\(', lambda m: 'logb(%s,' % m.group(1).translate(_SUB), s)
    s = _re.sub(r'log_(\d+(?:\.\d+)?)\(', r'logb(\1,', s)
    s = _re.sub(r'(?<![a-z])log\(', 'lg(', s)
    s = s.replace('√(', 'sqrt(')
    s = _re.sub(r'√(\d+(?:\.\d+)?|x)', r'sqrt(\1)', s)
    for _ in range(3): s = _re.sub(r'\|([^|]+)\|', r'abs(\1)', s)
    s = _re.sub(r'(\d|\))(?=[a-z(])', r'\1*', s)
    s = _re.sub(r'(?<![a-z])x(?=[\d(a-z])', 'x*', s)
    s = _re.sub(r'(?<![a-z])pi(?=[\dx(a-z])', 'pi*', s)
    s = _re.sub(r'(?<![a-z])e(?=[\dx(])', 'e*', s)
    if _re.search(r'[^0-9a-z+\-*/().,]', s): return None, 'Anlaşılmayan işaret var.'
    names = set(_re.findall(r'[a-z]+', s)) - {'x', 'sin', 'cos', 'tan', 'sqrt', 'lg', 'ln', 'logb', 'abs', 'pi', 'e', 'cot'}
    if names: return None, 'Tanınmayan: ' + ', '.join(sorted(names))
    ns = dict(sin=math.sin, cos=math.cos, tan=math.tan, cot=lambda v: 1/math.tan(v), sqrt=math.sqrt, lg=math.log10, ln=math.log,
              logb=lambda b_, v: math.log(v, b_), abs=abs, pi=math.pi, e=math.e)
    try: code = compile(s, '<f>', 'eval')
    except SyntaxError: return None, 'Yazım hatası (parantezleri denetleyin).'
    def f(x):
        try:
            v = eval(code, {'__builtins__': {}}, dict(ns, x=x))
            if isinstance(v, complex) or v != v or abs(v) > 1e12: return None
            return float(v)
        except (ValueError, ZeroDivisionError, OverflowError, TypeError): return None
        except Exception: return None
    try: eval(code, {'__builtins__': {}}, dict(ns, x=1.37))
    except (NameError, SyntaxError, TypeError): return None, 'Yazım hatası.'
    except Exception: pass
    return f, None

def grafik_latex(ifade):
    """K-350: Grafik çizicide öğretmenin yazdığı fonksiyonu kitap yazımına çevirir (x^2 → x², 1/(x-2) → kesir, √(x) → kök)."""
    import re
    s = ifade.strip().replace('**', '^').replace('−', '-').replace('×', '*').replace('÷', '/')
    s = re.sub(r'^(y|f\(x\))\s*=\s*', '', s)
    s = s.replace('²', '^2').replace('³', '^3').replace('ˣ', '^x').replace('π', 'pi')
    s = re.sub(r'log([₀-₉]+)', lambda m: 'log_' + m.group(1).translate(str.maketrans('₀₁₂₃₄₅₆₇₈₉', '0123456789')), s)
    def grup(t, i):   # t[i] == '(' → eşleşen ')' konumu
        d = 0
        for j in range(i, len(t)):
            d += {'(': 1, ')': -1}.get(t[j], 0)
            if d == 0: return j
        return len(t) - 1
    def islenen_sag(t, i):   # i'den başlayan işlenen: (…), sayı, harf dizisi(+(…)), √…
        if i < len(t) and t[i] == '(':
            j = grup(t, i); return t[i+1:j], j + 1, True
        m = re.match(r'(sqrt|√|log_\d+|log|ln|sin|cos|tan|cot|abs)?\s*', t[i:])
        if m and m.group(1) and i + m.end() < len(t) and t[i + m.end()] == '(':
            j = grup(t, i + m.end()); return t[i:j+1], j + 1, False
        m = re.match(r'\d+(?:[.,]\d+)?|[a-z]', t[i:])
        if m: return m.group(0), i + m.end(), False
        return '', i, False
    def cevir(t):
        out = ''; i = 0
        while i < len(t):
            c = t[i]
            if t.startswith('sqrt(', i) or t.startswith('√(', i):
                k = t.index('(', i); j = grup(t, k); out += '\\sqrt{' + cevir(t[k+1:j]) + '}'; i = j + 1; continue
            if c == '√':
                a, i2, _ = islenen_sag(t, i + 1); out += '\\sqrt{' + cevir(a) + '}'; i = i2; continue
            if c == '^':
                a, i2, par = islenen_sag(t, i + 1); out += '^{' + cevir(a) + '}'; i = i2; continue
            if c == '/':
                # sol işlenen: son eklenen parça (…) ya da sayı/harf/üs
                sol = re.search(r'(\\left\(.*\\right\)|\([^()]*\)|\\sqrt\{[^{}]*\}|[0-9a-z.,]+(?:\^\{[^{}]*\})?)$', out)
                a, i2, _ = islenen_sag(t, i + 1)
                if sol:
                    pay = sol.group(1); out = out[:sol.start()]
                    if pay.startswith('(') and pay.endswith(')'): pay = pay[1:-1]
                    out += '\\frac{' + pay + '}{' + cevir(a) + '}'; i = i2; continue
            if t.startswith('log_', i):
                m = re.match(r'log_(\d+)', t[i:]); out += '\\log_{' + m.group(1) + '}'; i += m.end(); continue
            m = re.match(r'(sin|cos|tan|cot|ln|log|abs|pi)', t[i:])
            if m:
                out += {'pi': '\\pi ', 'abs': ''}.get(m.group(1), '\\' + m.group(1) + ' '); i += m.end(); continue
            if c == '*':
                prev = out.rstrip()[-1:] ; nxt = t[i+1:i+2]
                out += '' if (prev.isdigit() and (nxt.isalpha() or nxt == '(')) else '\\cdot '; i += 1; continue
            out += c; i += 1
        return out
    return cevir(s.replace(' ', ''))

def graph_build(funcs, opts, W=960, H=600):
    """funcs: [(yazı, işlev, renk)] · opts: roots, extrema, cross, yx. Döner: fitz belge."""
    xs_try = [i/25 for i in range(-250, 251)]
    pos_only = all(all(fn(x) is None for x in xs_try if x <= 0) and any(fn(x) is not None for x in xs_try if x > 0) for _, fn, _ in funcs)
    keys = []   # kökler, uç noktalar, kesişimler, tanım sınırları: görüntü bunlara göre seçilir
    for _, fn, _ in funcs:
        prev = None
        for x in xs_try:
            v = fn(x)
            if prev is not None:
                pv = prev[1]
                if (v is None) != (pv is None): keys.append(x)
                elif v is not None and pv is not None and abs(v - pv) < 5:
                    if pv*v <= 0: keys.append(x)
            prev = (x, v)
        vals = [(x, fn(x)) for x in xs_try]
        for (xa, a), (xb, b), (xc_, c) in zip(vals, vals[1:], vals[2:]):
            if None not in (a, b, c) and (b - a)*(c - b) < 0 and abs(c - a) < 5: keys.append(xb)
    if len(funcs) == 2:
        f_, g_ = funcs[0][1], funcs[1][1]; prev = None
        for x in xs_try:
            a, b = f_(x), g_(x); v = None if a is None or b is None else a - b
            if v is not None and prev is not None and prev*v <= 0 and abs(v - prev) < 5: keys.append(x)
            prev = v
    if keys and len(keys) <= 8:
        x0, x1 = min(keys) - 2.5, max(keys) + 2.5
        if x1 - x0 < 9: c_ = (x0 + x1)/2; x0, x1 = c_ - 4.5, c_ + 4.5
        if x1 - x0 > 22: x0, x1 = max(x0, -11), min(x1, 11)
    else: x0, x1 = (-2.0, 12.0) if pos_only else (-7.0, 7.0)
    if pos_only: x0 = max(x0, -1.5)
    ys = []
    for _, fn, _ in funcs:
        for i in range(401):
            v = fn(x0 + (x1 - x0)*i/400)
            if v is not None and abs(v) < 60: ys.append(v)
    ys.sort()
    lo, hi = (ys[int(len(ys)*.05)], ys[int(len(ys)*.95)]) if ys else (-5, 5)
    lo, hi = min(lo, 0), max(hi, 0); span = max(4.0, hi - lo); lo -= span*.15; hi += span*.15
    lo, hi = max(lo, -15), min(hi, 15)
    if opts.get('yx'):   # ters fonksiyonlar: iki eksende aynı aralık (simetri görünsün)
        a_, b_ = min(x0, -2.5), max(x1, 6.5); lo, hi = a_, b_; x0, x1 = a_, b_
    m = 46; pw, ph = W - 2*m, H - 2*m
    ux, uy = pw/(x1 - x0), ph/(hi - lo)
    if opts.get('yx') or .55 < ux/uy < 1.8:   # birimler yakınsa eşit al (y = x simetrisi doğru görünsün)
        unit = min(ux, uy); xc, yc = (x0 + x1)/2, (lo + hi)/2
        x0, x1 = xc - pw/unit/2, xc + pw/unit/2; lo, hi = yc - ph/unit/2, yc + ph/unit/2; ux = uy = unit
    unit = min(ux, uy)
    X = lambda x: m + (x - x0)*ux; Y = lambda y: m + (hi - y)*uy
    doc = fitz.open(); page = doc.new_page(width=W, height=H); sh = page.new_shape()
    fonts = pdf_fonts(); dark = (.2, .25, .33)
    dv = next((q for q in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans.ttf', os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'seguisym.ttf')) if os.path.isfile(q)), None)
    pop = fitz.Font(fontfile=fonts['m']) if fonts['m'] else None
    def text(x, y, t, size, color=dark, anchor='c'):
        f = fonts['m']
        if pop is not None and dv and any(not pop.has_glyph(ord(ch)) for ch in t): f = dv   # log₂, ˣ gibi işaretler
        wdt = fitz.Font(fontfile=f).text_length(t, fontsize=size) if f else fitz.get_text_length(t, fontsize=size)
        xx = x - wdt/2 if anchor == 'c' else x - wdt if anchor == 'r' else x
        if f: page.insert_text((xx, y), t, fontsize=size, fontname='umalm' if f == fonts['m'] else 'umaldv', fontfile=f, color=color)
        else: page.insert_text((xx, y), t, fontsize=size, color=color)
    step = next(k for k in (1, 2, 5, 10, 20) if k*ux >= 26); stepy = next(k for k in (1, 2, 5, 10, 20) if k*uy >= 22)
    for i in range(math.ceil(x0), math.floor(x1) + 1): sh.draw_line((X(i), m), (X(i), H - m))
    for j in range(math.ceil(lo), math.floor(hi) + 1): sh.draw_line((m, Y(j)), (W - m, Y(j)))
    sh.finish(color=(.87, .9, .95), width=.5)
    ax_y = Y(0) if lo < 0 < hi else (Y(lo) if lo >= 0 else Y(hi)); ax_x = X(0) if x0 < 0 < x1 else X(x0)
    sh.draw_line((m - 6, ax_y), (W - m + 10, ax_y)); sh.draw_line((ax_x, H - m + 6), (ax_x, m - 10))
    sh.draw_polyline([(W - m + 2, ax_y - 5), (W - m + 10, ax_y), (W - m + 2, ax_y + 5)]); sh.draw_polyline([(ax_x - 5, m - 2), (ax_x, m - 10), (ax_x + 5, m - 2)])
    sh.finish(color=dark, width=1.3)
    for i in range(math.ceil(x0/step)*step, math.floor(x1) + 1, step):
        if i: sh.draw_line((X(i), ax_y - 3), (X(i), ax_y + 3)); text(X(i), ax_y + 14, str(i).replace('-', '−') if fonts['m'] else str(i), 9)
    for j in range(math.ceil(lo/stepy)*stepy, math.floor(hi) + 1, stepy):
        if j: sh.draw_line((ax_x - 3, Y(j)), (ax_x + 3, Y(j))); text(ax_x - 7, Y(j) + 3, str(j).replace('-', '−') if fonts['m'] else str(j), 9, anchor='r')
    sh.finish(color=dark, width=1); text(W - m + 4, ax_y - 9, 'x', 12); text(ax_x + 11, m - 4, 'y', 12)
    if opts.get('yx'):
        a_, b_ = max(x0, lo), min(x1, hi); sh.draw_line((X(a_), Y(a_)), (X(b_), Y(b_))); sh.finish(color=(.6, .64, .7), width=1, dashes='[5 4] 0')
    N = 1600; marks = []
    def rgb(c): q = QColor(c); return (q.redF(), q.greenF(), q.blueF())
    sampled = []
    for label, fn, col in funcs:
        pts = [(x0 + (x1 - x0)*i/N, fn(x0 + (x1 - x0)*i/N)) for i in range(N + 1)]; sampled.append(pts)
        seg = []; asym = []
        def flush():
            if len(seg) > 1: sh.draw_polyline([(X(a), Y(b)) for a, b in seg]); sh.finish(color=rgb(col), width=2.4, closePath=False)
            seg.clear()
        yr = hi - lo
        for (xa, ya), (xb, yb) in zip(pts, pts[1:]):
            if ya is None or yb is None:
                if ya is not None and yb is None and abs(ya) > yr: asym.append(xb)   # tanım dışı sınırında sonsuza gidiyor
                if ya is None and yb is not None and abs(yb) > yr: asym.append(xa)
                flush(); continue
            if abs(yb - ya) > yr*1.5 and ya*yb < 0: asym.append((xa + xb)/2); flush(); continue   # tan gibi sıçrama
            ca, cb = min(max(ya, lo - yr), hi + yr), min(max(yb, lo - yr), hi + yr)
            inside_a, inside_b = lo <= ya <= hi, lo <= yb <= hi
            if inside_a and not seg: seg.append((xa, ya))
            if inside_a and inside_b: seg.append((xb, yb))
            elif inside_a and not inside_b:
                yy = hi if yb > hi else lo; xx = xa + (xb - xa)*(yy - ya)/(yb - ya); seg.append((xx, yy)); flush()
            elif not inside_a and inside_b:
                yy = hi if ya > hi else lo; xx = xa + (xb - xa)*(yy - ya)/(yb - ya); seg.extend([(xx, yy), (xb, yb)])
        flush()
        al = sorted(set(round(v, 2) for v in asym))
        for xa in al:
            xv = round(xa*2)/2 if abs(xa*2 - round(xa*2)) < .03 else xa
            sh.draw_line((X(xv), m), (X(xv), H - m)); sh.finish(color=rgb(col), width=1, dashes='[6 4] 0')
            if len(al) <= 3: text(X(xv) + 4, m + 12, 'x = ' + fmt_num(xv), 10, rgb(col), 'l')
    def refine(g, a, b):
        ga = g(a)
        for _ in range(48):
            c = (a + b)/2; gc = g(c)
            if gc is None: return None
            if (gc < 0) == (ga < 0): a, ga = c, gc
            else: b = c
        return (a + b)/2
    dots = []
    for (label, fn, col), pts in zip(funcs, sampled):
        yr = hi - lo
        if opts.get('roots', True):
            for (xa, ya), (xb, yb) in zip(pts, pts[1:]):
                if ya is None or yb is None or abs(yb - ya) > yr: continue
                if ya == 0 or ya*yb < 0:
                    r = xa if ya == 0 else refine(fn, xa, xb)
                    if r is not None and all(abs(r - d[0]) > (x1 - x0)/200 for d in dots if d[3] == 'kök'): dots.append((r, 0.0, col, 'kök'))
        if opts.get('extrema', True):
            for i in range(1, len(pts) - 1):
                (xa, ya), (xb, yb), (xc_, yc_) = pts[i-1], pts[i], pts[i+1]
                if None in (ya, yb, yc_) or abs(yc_ - ya) > yr*.5: continue
                if (yb - ya)*(yc_ - yb) < 0:
                    a_, b_ = xa, xc_   # altın oran araması
                    for _ in range(60):
                        c1 = b_ - (b_ - a_)*.618; c2 = a_ + (b_ - a_)*.618; f1, f2 = fn(c1), fn(c2)
                        if f1 is None or f2 is None: break
                        if (f1 < f2) == (yb < ya): b_ = c2
                        else: a_ = c1
                    xe = (a_ + b_)/2; ye = fn(xe)
                    if ye is not None and lo < ye < hi: dots.append((xe, ye, col, 'uç'))
    if opts.get('cross', True) and len(funcs) == 2:
        f, g = funcs[0][1], funcs[1][1]
        def d(x):
            a, b = f(x), g(x); return None if a is None or b is None else a - b
        prev = None
        for i in range(N + 1):
            x = x0 + (x1 - x0)*i/N; v = d(x)
            if v is not None and prev is not None and prev[1]*v < 0 and abs(v - prev[1]) < (hi - lo):
                r = refine(d, prev[0], x)
                if r is not None and f(r) is not None and lo < f(r) < hi: dots.append((r, f(r), '#111111', 'kesişim'))
            prev = (x, v) if v is not None else None
    n_ext = sum(1 for d in dots if d[3] == 'uç'); many = len(dots) > 8; placed = []
    def free(x, y, w, h):   # etiketler üst üste binmesin
        r = fitz.Rect(x - w/2, y - h, x + w/2, y + 2)
        return not any(r.intersects(q) for q in placed), r
    for x, y, col, kind in dots[:16]:
        page.draw_circle((X(x), Y(y)), 4.2, color=(1, 1, 1), fill=rgb('#e8132b' if kind == 'uç' else col), width=1)
        if many: continue
        if kind == 'kök': t = 'x = ' + fmt_num(x)
        elif kind == 'uç': t = ('T' if n_ext == 1 else '') + '(%s ; %s)' % (fmt_num(x), fmt_num(y))
        else: t = '(%s ; %s)' % (fmt_num(x), fmt_num(y))
        w_ = fitz.get_text_length(t, fontsize=10.5)*1.05 + 6
        lower = kind == 'kök' or (kind == 'uç' and y < (lo + hi)/2)
        for dy in (((30, 44, -12) if kind == 'kök' else (18, -10, 32, -24)) if lower else (-10, 18, -24, 32)):
            ok, r = free(X(x), Y(y) + dy, w_, 12)
            if ok: placed.append(r); text(X(x), Y(y) + dy, t, 10.5, rgb('#e8132b' if kind == 'uç' else col)); break
    yy = m + 8
    def olc_(t, size):
        f = fonts['m']
        if pop is not None and dv and any(not pop.has_glyph(ord(ch)) for ch in t): f = dv
        return fitz.Font(fontfile=f).text_length(t, fontsize=size) if f else fitz.get_text_length(t, fontsize=size)
    for label, fn, col in funcs:   # fonksiyon adları sol üstte, kitap yazımıyla (K-350: x², kesir, kök)
        try: kt = formul_diz(formul_coz('y = ' + grafik_latex(label)), 14, olc_)
        except Exception: kt = None
        if kt is None:
            page.draw_rect(fitz.Rect(m + 6, yy - 9, m + 16, yy + 1), color=None, fill=rgb(col)); text(m + 22, yy, 'y = ' + label, 13, rgb(col), 'l'); yy += 20; continue
        base = yy + max(0.0, kt.a - 10)
        page.draw_rect(fitz.Rect(m + 6, base - 9, m + 16, base + 1), color=None, fill=rgb(col))
        for o in kt.op:
            if o[0] == 't': text(m + 22 + o[1], base + o[2], o[3], o[4], rgb(col), 'l')
            else: page.draw_line((m + 22 + o[1], base + o[2]), (m + 22 + o[3], base + o[4]), color=rgb(col), width=max(.8, o[5]))
        yy = base + kt.d + 14
    sh.commit(); doc.set_metadata({'title': 'Grafik — ' + APP_NAME, 'keywords': 'UMAL-graph'}); return doc

class GraphDialog(QDialog):
    COLORS = ('#2f7cf6', '#e8132b')
    KEYS = [['x', '²', '³', '^', '√', '(', ')', '|x|'], ['sin', 'cos', 'tan', 'log', 'ln', 'log₂', 'π', 'e'],
            ['7', '8', '9', '/', '·', ',', '⌫', 'Temizle'], ['4', '5', '6', '+', '−', '1', '2', '3'], ['0', 'eˣ', '2ˣ', 'log₃', '√x']]
    INSERT = {'√': '√(', 'sin': 'sin(', 'cos': 'cos(', 'tan': 'tan(', 'log': 'log(', 'ln': 'ln(', 'log₂': 'log₂(', 'log₃': 'log₃(', 'eˣ': 'e^x', '2ˣ': '2^x', '√x': '√(x)'}
    def __init__(self, main):
        super().__init__(main); self.main = main; self.setWindowTitle('Grafik çizici'); self.setModal(True)
        from PyQt5.QtWidgets import QLineEdit, QCheckBox
        scr = QApplication.primaryScreen().availableGeometry(); self.resize(min(1500, scr.width()-40), min(860, scr.height()-40))
        box = QHBoxLayout(self); box.setContentsMargins(20, 16, 20, 16); box.setSpacing(18)
        left = QVBoxLayout(); left.setSpacing(8); box.addLayout(left, 5)
        t = QLabel('Grafik çizici'); t.setStyleSheet('font-size:21px;font-weight:600;'); left.addWidget(t)
        cfg = getattr(main, 'graph_cfg', {}); self.fields = []; self.errs = []
        for i, col in enumerate(self.COLORS):
            row = QHBoxLayout(); dot = QLabel('●'); dot.setStyleSheet('color:%s;font-size:22px;' % col); row.addWidget(dot)
            pre = QLabel('y ='); pre.setStyleSheet('font-size:20px;'); row.addWidget(pre)
            e = QLineEdit(cfg.get('f%d' % i, 'x² − 3x + 2' if i == 0 else '')); e.setMinimumHeight(52); e.setStyleSheet('font-size:22px;')
            e.setPlaceholderText('ikinci fonksiyon (isteğe bağlı)' if i else 'fonksiyon'); e.installEventFilter(self); e.textChanged.connect(self.later)
            row.addWidget(e, 1); left.addLayout(row); self.fields.append(e)
            er = QLabel(''); er.setStyleSheet('color:#ff8a95;font-size:14px;'); left.addWidget(er); self.errs.append(er)
        kb = QGridLayout(); kb.setSpacing(6); left.addLayout(kb)
        for r, keys in enumerate(self.KEYS):
            for c, k in enumerate(keys):
                b = QPushButton(k); b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(48); b.setStyleSheet('font-size:19px;padding:0;')
                b.clicked.connect(lambda checked=False, k_=k: self.key(k_)); kb.addWidget(b, r, c)
        self.opts = {}
        orow = QHBoxLayout(); left.addLayout(orow)
        for key, name in (('roots', 'Kökler'), ('extrema', 'Tepe / uç noktalar'), ('cross', 'Kesişimler'), ('yx', 'y = x doğrusu')):
            c = QCheckBox(name); c.setChecked(cfg.get(key, key != 'yx')); c.toggled.connect(self.later); orow.addWidget(c); self.opts[key] = c
        left.addStretch(1)
        btns = QHBoxLayout(); left.addLayout(btns)
        no = QPushButton('Vazgeç'); no.setMinimumHeight(52); no.clicked.connect(self.reject); btns.addWidget(no)
        self.ok = QPushButton('Tahtaya aç'); self.ok.setObjectName('primary'); self.ok.setMinimumHeight(52); self.ok.clicked.connect(self.open_board); btns.addWidget(self.ok)
        self.preview = QLabel(); self.preview.setAlignment(Qt.AlignCenter); self.preview.setStyleSheet('background:white;border-radius:12px;'); box.addWidget(self.preview, 6)
        self.target = self.fields[0]; self.timer = QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(250); self.timer.timeout.connect(self.redraw)
        QTimer.singleShot(0, self.redraw)
    def eventFilter(self, o, e):
        if e.type() in (QEvent.FocusIn, QEvent.MouseButtonPress) and o in self.fields: self.target = o
        return False
    def key(self, k):
        t = self.target
        if k == '⌫': t.backspace()
        elif k == 'Temizle': t.clear()
        else: t.insert(self.INSERT.get(k, k))
        t.setFocus()
    def later(self, *a): self.timer.start()
    def funcs(self):
        out = []; ok = True
        for i, e in enumerate(self.fields):
            txt = e.text().strip(); self.errs[i].setText('')
            if not txt: continue
            fn, err = graph_compile(txt)
            if err: self.errs[i].setText(err); ok = False; continue
            if not any(fn(k/10) is not None for k in range(-100, 101)): self.errs[i].setText('Bu aralıkta tanımlı değil.'); ok = False; continue
            out.append((txt, fn, self.COLORS[i]))   # etiket graph_build'de kitap yazımıyla çizilir (K-350)
        return out, ok
    def redraw(self):
        fs, ok = self.funcs(); self.ok.setEnabled(bool(fs) and ok)
        if not fs: self.preview.setText('Fonksiyonu yazın'); return
        doc = graph_build(fs, {k: c.isChecked() for k, c in self.opts.items()})
        w = max(300, self.preview.width() - 16); z = w/doc[0].rect.width; pix = doc[0].get_pixmap(matrix=fitz.Matrix(z, z), alpha=False); doc.close()
        self.preview.setPixmap(QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()))
    def open_board(self):
        fs, ok = self.funcs()
        if not fs or not ok: return
        opts = {k: c.isChecked() for k, c in self.opts.items()}
        self.main.graph_cfg = dict(opts, f0=self.fields[0].text(), f1=self.fields[1].text())
        doc = graph_build(fs, opts); m = self.main; self.accept()
        name = 'y = ' + atlas_guzel(fs[0][0]); m.start_tab(name if len(name) < 28 else name[:26] + '…'); m.replace(doc); m.tabs_changed(); m.set_tool('pen')

class Ruler(QWidget):
    """Cetvel: sayfanın üstünde yarı saydam; gövdeden sürüklenir, sağ uçtaki tutamakla
    döndürülür (15°'lere yapışır), sol uçtaki × ile kalkar. Çizgiler sayfanın gerçek
    santimetresiyle; kenarına yakın çizilen kalem çizgisi kenara yapışır."""
    L, W, KNOB = 760, 86, 22
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.angle = 0.0; self.drag = None
        vp = main.scroll.viewport().geometry(); self.c = QPointF(vp.center().x(), vp.y() + vp.height()*.62)
        self.setCursor(Qt.SizeAllCursor); self.hide()
    def corners(self):
        a = math.radians(self.angle); ca, sa = math.cos(a), math.sin(a); L, W = self.L/2, self.W/2
        return [QPointF(self.c.x() + ca*x - sa*y, self.c.y() + sa*x + ca*y) for x, y in ((-L, -W), (L, -W), (L, W), (-L, W))]
    def local(self, x, y):
        a = math.radians(self.angle); return QPointF(self.c.x() + math.cos(a)*x - math.sin(a)*y, self.c.y() + math.sin(a)*x + math.cos(a)*y)
    def place(self):
        pts = self.corners(); xs = [q.x() for q in pts]; ys = [q.y() for q in pts]
        r = QRect(int(min(xs))-4, int(min(ys))-4, int(max(xs)-min(xs))+9, int(max(ys)-min(ys))+9)
        self.setGeometry(r)
        poly = QPolygonF([q - QPointF(r.topLeft()) for q in pts]); self.setMask(QRegion(poly.toPolygon())); self.update()
    def edge_for(self, vp, off):
        """Kalem başlangıcı kenara yakınsa o kenarın çizgisi: ((ox,oy),(dx,dy),(t0,t1)), görüntü koordinatında."""
        a = math.radians(self.angle); dx, dy = math.cos(a), math.sin(a); nx, ny = -dy, dx
        for side in (-1, 1):   # üst kenar, alt kenar (dışa doğru kalem kalınlığı kadar)
            o = self.local(0, side*(self.W/2 + off))
            dist = (vp.x() - o.x())*nx + (vp.y() - o.y())*ny; along = (vp.x() - o.x())*dx + (vp.y() - o.y())*dy
            if abs(dist) <= 36 and abs(along) <= self.L/2 + 10 and side*dist >= -14:
                return ((o.x(), o.y()), (dx, dy), (-self.L/2, self.L/2))
        return None
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.translate(-QPointF(self.geometry().topLeft()))
        p.translate(self.c); p.rotate(self.angle); L, W = self.L/2, self.W/2
        p.setPen(QPen(QColor('#b78a00'), 1.6)); p.setBrush(QColor(234, 179, 8, 92)); p.drawRoundedRect(QRectF(-L, -W, 2*L, 2*W), 10, 10)
        cm = 28.3465*self.main.board.scale; mm = cm/10; n = int((2*L - 40)/mm)
        f = p.font(); f.setPixelSize(13); f.setBold(True); p.setFont(f)
        for i in range(n + 1):   # üst kenar: santimetre ve milimetre çizgileri
            x = -L + 20 + i*mm; big = i % 10 == 0; mid = i % 5 == 0
            if mm < 3.5 and not (big or mid): continue
            p.setPen(QPen(QColor('#5c4400'), 1.4 if big else 1)); p.drawLine(QPointF(x, -W), QPointF(x, -W + (20 if big else 13 if mid else 8)))
            if big: p.drawText(QRectF(x - 20, -W + 20, 40, 18), Qt.AlignCenter, str(i//10))
        for i in range(n + 1):   # alt kenar da ölçülü
            x = -L + 20 + i*mm; big = i % 10 == 0
            if mm < 3.5 and i % 5: continue
            p.setPen(QPen(QColor('#5c4400'), 1.4 if big else 1)); p.drawLine(QPointF(x, W), QPointF(x, W - (14 if big else 8)))
        k = QPointF(L - 30, 4)   # döndürme tutamağı
        p.setPen(QPen(QColor('#b78a00'), 2)); p.setBrush(QColor(255, 255, 255, 230)); p.drawEllipse(k, self.KNOB, self.KNOB)
        p.setPen(QPen(QColor('#7a5b00'), 2.4)); p.drawArc(QRectF(k.x()-10, k.y()-10, 20, 20), 40*16, 280*16)
        p.drawLine(k + QPointF(7, -9), k + QPointF(10, -3)); p.drawLine(k + QPointF(10, -3), k + QPointF(4, -2))
        x_ = QPointF(-L + 28, 6)   # kaldır
        p.setPen(QPen(QColor('#b42318'), 2.6)); p.setBrush(QColor(255, 255, 255, 220)); p.drawEllipse(x_, 15, 15)
        p.drawLine(x_ + QPointF(-6, -6), x_ + QPointF(6, 6)); p.drawLine(x_ + QPointF(-6, 6), x_ + QPointF(6, -6))
        if self.drag and self.drag[0] == 'rotate':
            p.setPen(QColor('#3d2a00')); f.setPixelSize(18); p.setFont(f); p.drawText(QRectF(-60, -12, 120, 30), Qt.AlignCenter, '%d°' % round((-self.angle) % 360))
    def to_local(self, q):
        a = math.radians(-self.angle); d = q - self.c
        return QPointF(math.cos(a)*d.x() - math.sin(a)*d.y(), math.sin(a)*d.x() + math.cos(a)*d.y())
    def mousePressEvent(self, e):
        q = QPointF(e.pos()) + QPointF(self.geometry().topLeft()); l = self.to_local(q)
        if math.hypot(l.x() - (-self.L/2 + 28), l.y() - 6) < 22: self.main.toggle_ruler(False); return
        if math.hypot(l.x() - (self.L/2 - 30), l.y() - 4) < self.KNOB + 10:
            self.drag = ('rotate', math.degrees(math.atan2(q.y() - self.c.y(), q.x() - self.c.x())) - self.angle)
        else: self.drag = ('move', q - self.c)
    def mouseMoveEvent(self, e):
        if not self.drag: return
        q = QPointF(e.pos()) + QPointF(self.geometry().topLeft())
        if self.drag[0] == 'move': self.c = q - self.drag[1]
        else:
            a = math.degrees(math.atan2(q.y() - self.c.y(), q.x() - self.c.x())) - self.drag[1]
            near = round(a/15)*15; self.angle = near if abs(a - near) < 2.5 else a   # 0°, 15°, 30°, 45°, 90°…
        self.place()
    def mouseReleaseEvent(self, e): self.drag = None; self.update()

class FloatingBell(QWidget):
    """Tahtanın üstünde yüzen zil saati: ders, kalan süre, saat aralığı, ilerleme.
    Ders boyunca sade; son 5 dakikada sarı, son 1 dakikada kırmızı ve nabız gibi atar
    (teneffüste altın tonları). Dokun: küçük hap ↔ büyük kutu; sürükle: taşı."""
    BIG = (236, 124); SMALL = (196, 46)
    def __init__(self, main):
        super().__init__(main.scroll); self.main = main; self.small = False; self.offset = None
        self.press = None; self.moved = False; self.now = None; self.state = None
        self.setCursor(Qt.PointingHandCursor)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(500); self.tick()
    def phase(self, st):
        if st['left'] is None: return None
        if st['left'] <= 60 and st['kind'] in ('lesson', 'break'): return 'son1'
        if st['left'] <= 300 and st['kind'] in ('lesson', 'break'): return 'son5'
        return 'normal'
    def tick(self):
        import datetime
        st = bell_state(self.now or datetime.datetime.now()); self.state = st; ph = self.phase(st)
        show = ph is not None and not getattr(self.main, 'overlay_mode', False) and getattr(self.main, 'exam_screen', None) is None   # sınav sayacı varken köşe saati yok
        big = ph in ('son5', 'son1') or not self.small
        w, h = self.BIG if big else self.SMALL
        if (self.width(), self.height()) != (w, h): self.setFixedSize(w, h); self.place()
        if show != self.isVisible(): self.setVisible(show); self.main.place_overlays()
        self.timer.setInterval(50 if ph == 'son1' else 500)
        if show: self.raise_(); self.update()
    def place(self):
        vp = self.main.scroll.viewport().geometry()
        if self.offset is None: x, y = vp.right() - self.width() - 14, vp.y() + 14
        else: x, y = vp.right() - self.offset[0] - self.width(), vp.y() + self.offset[1]
        self.move(max(vp.x(), min(x, vp.right() - self.width())), max(vp.y(), min(y, vp.bottom() - self.height())))
    def colors(self, st, ph):
        brk = st['kind'] == 'break'
        if ph == 'son1': return QColor('#ff6b7a'), QColor(255, 107, 122, 40), QColor('#bb1826')
        if ph == 'son5': return QColor('#ffc526'), QColor(255, 197, 38, 30), QColor('#8a6514')
        if brk: return QColor('#e7c46a'), QColor(201, 154, 46, 26), QColor('#8a6514')
        return QColor('#ffffff'), QColor(14, 28, 50, 205), QColor('#1d4f8f')
    def font(self, px, bold=False):
        from PyQt5.QtGui import QFont
        f = QFont(ui_fonts().get('Poppins-Regular') or 'DejaVu Sans'); f.setPixelSize(px); f.setBold(bold); return f
    def paintEvent(self, e):
        st = self.state
        if st is None or st['left'] is None: return
        ph = self.phase(st); fg, bg, tagc = self.colors(st, ph)
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        W, H = self.width(), self.height(); r = QRectF(1.5, 1.5, W-3, H-3)
        if ph == 'son1':   # nabız: çerçeve dışına yayılan hafif ışık
            k = (math.sin(time.monotonic()*5.2) + 1)/2
            for i in range(3): c = QColor(fg); c.setAlpha(int(70*k/(i+1))); p.setPen(QPen(c, 2)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r.adjusted(-i, -i, i, i).adjusted(2, 2, -2, -2), 16, 16)
        base = QColor(14, 28, 50, 215); p.setPen(Qt.NoPen); p.setBrush(base); p.drawRoundedRect(r, 16, 16)
        p.setBrush(bg); p.drawRoundedRect(r, 16, 16)
        border = QColor(fg) if ph in ('son5', 'son1') else QColor(255, 255, 255, 45)
        p.setPen(QPen(border, 2 if ph in ('son5', 'son1') else 1)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 16, 16)
        l = st['left']; cd = ('%d:%02d:%02d' % (l//3600, l%3600//60, l%60)) if l >= 3600 else ('%d:%02d' % (l//60, l%60))
        label = 'zile kalan' if st['kind'] in ('lesson', 'prep') else 'derse kalan' if st['kind'] == 'break' else 'okula kalan'
        p.setFont(self.font(12, True)); tw = p.fontMetrics().horizontalAdvance(st['tag']) + 16
        if H < 60:   # küçük hap: etiket + süre
            tr = QRectF(10, (H-22)/2, tw, 22); p.setPen(Qt.NoPen); p.setBrush(tagc); p.drawRoundedRect(tr, 11, 11)
            p.setPen(Qt.white); p.drawText(tr, Qt.AlignCenter, st['tag'])
            p.setPen(fg); p.setFont(self.font(20, True)); p.drawText(QRectF(tr.right()+8, 0, W-tr.right()-14, H), Qt.AlignVCenter|Qt.AlignLeft, cd); return
        tr = QRectF((W-tw)/2, 10, tw, 22); p.setPen(Qt.NoPen); p.setBrush(tagc); p.drawRoundedRect(tr, 11, 11)
        p.setPen(Qt.white); p.drawText(tr, Qt.AlignCenter, st['tag'])
        p.setPen(fg); p.setFont(self.font(40 if l < 3600 else 32, True)); p.drawText(QRectF(0, 32, W, 48), Qt.AlignCenter, cd)
        sub = QColor(fg) if ph else QColor('#9fb3cf'); sub.setAlpha(200 if ph in ('son5', 'son1') else 255)
        p.setPen(sub); p.setFont(self.font(12)); p.drawText(QRectF(0, 80, W, 18), Qt.AlignCenter, label + ('  ·  ' + st['span'].replace(' – ', '–') if st['span'] else ''))
        bar = QRectF(18, H-17, W-36, 5); p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 30)); p.drawRoundedRect(bar, 2.5, 2.5)
        fill = QColor('#ff6b7a') if ph == 'son1' else QColor('#ffc526') if ph == 'son5' or st['kind'] == 'break' else QColor('#3d8bff')
        if st['frac'] > 0: p.setBrush(fill); p.drawRoundedRect(QRectF(bar.x(), bar.y(), bar.width()*min(1, st['frac']), bar.height()), 2.5, 2.5)
    def mousePressEvent(self, e): self.press = (e.globalPos(), self.pos()); self.moved = False
    def mouseMoveEvent(self, e):
        if self.press is None: return
        d = e.globalPos() - self.press[0]
        if self.moved or abs(d.x()) + abs(d.y()) > 10:
            self.moved = True; vp = self.main.scroll.viewport().geometry(); q = self.press[1] + d
            self.offset = (vp.right() - q.x() - self.width(), q.y() - vp.y()); self.place(); self.main.place_overlays()
    def mouseReleaseEvent(self, e):
        if self.press is not None and not self.moved: self.small = not self.small; self.tick(); self.main.place_overlays()
        self.press = None

class BellClock(QWidget):
    """Saat ve zile kalan süre: üst şeritte, PDF sekmelerinin sağında, tek satır."""
    W, H = 700, 42
    def __init__(self, parent=None, show_time=True):
        super().__init__(parent); self.show_time = show_time
        if not show_time: self.W = 450   # saat/tarih sol paneldeki büyük saatte; "Sonra" satırı yok
        self.setFixedSize(self.W, self.H); self.setAttribute(Qt.WA_TranslucentBackground)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(500)
        self.now = None   # tests can pin a time
        self.chimed = None; self.sound_dir = None
        if not show_time: self.fit_width()
    WARN_S = 300   # dersin bitmesine 5 dk kala hoş bir ses
    def fit_width(self, st=None):
        """Kutu içeriği kadar: ders dışında yalnızca etiket (boş uzun kutu kalmaz)."""
        import datetime
        from PyQt5.QtGui import QFontMetrics
        st = st or bell_state(self.now or datetime.datetime.now())
        tw = QFontMetrics(self.font(12, True)).horizontalAdvance(st['tag']) + 14
        if st['left'] is None: w = int(tw + 28)
        else:
            l = st['left']; cd = ('%d:%02d:%02d' % (l//3600, l%3600//60, l%60)) if l >= 3600 else ('%d:%02d' % (l//60, l%60))
            label = 'zile kalan' if st['kind'] in ('lesson','prep') else 'derse kalan' if st['kind'] == 'break' else 'okula kalan'
            w = 12 + 190 + 12 + QFontMetrics(self.font(22, True)).horizontalAdvance('0:00:00' if l >= 3600 else '00:00') + 6 + QFontMetrics(self.font(12)).horizontalAdvance(label) + 14
        if w != self.width(): self.setFixedWidth(w)
    def tick(self):
        import datetime
        now = self.now or datetime.datetime.now(); st = bell_state(now)
        # Yalnızca 5. dakikaya girerken bir kez (uygulama ders sonuna yakın açılırsa çalmaz).
        if st['kind'] == 'lesson' and st['left'] is not None and self.WARN_S - 30 < st['left'] <= self.WARN_S:
            key = (now.date(), st['tag'])
            if key != self.chimed:
                self.chimed = key
                try: play_sound(warn_chime_file(self.sound_dir or tempfile.gettempdir()))
                except Exception: pass
        if not self.show_time: self.fit_width(st)
        self.update()
    @staticmethod
    def font(px, bold=False):
        from PyQt5.QtGui import QFont
        f = QFont(ui_fonts().get('Poppins-Regular') or 'DejaVu Sans'); f.setPixelSize(px); f.setBold(bold); return f
    def paintEvent(self, e):
        import datetime
        now = self.now or datetime.datetime.now(); st = bell_state(now)
        if not self.show_time and st['left'] is None:   # ders dışı: yalnızca etiket, ortada
            p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); W_ = self.width()
            p.setPen(QPen(QColor(255, 255, 255, 30), 1)); p.setBrush(QColor(255, 255, 255, 14)); p.drawRoundedRect(QRectF(.5, .5, W_-1, self.H-1), 14, 14)
            p.setFont(self.font(12, True)); tw = p.fontMetrics().horizontalAdvance(st['tag'])+14
            p.setPen(Qt.NoPen); p.setBrush(QColor('#3a5577')); r_ = QRectF((W_-tw)/2, (self.H-22)/2, tw, 22); p.drawRoundedRect(r_, 11, 11)
            p.setPen(Qt.white); p.drawText(r_, Qt.AlignCenter, st['tag']); p.end(); return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.TextAntialiasing)
        urgent = st['kind'] == 'lesson' and st['left'] is not None and st['left'] <= 120
        accent = QColor('#e23b4d') if urgent else QColor('#c99a2e') if st['kind'] == 'break' else QColor('#3a5577')
        p.setPen(QPen(accent, 1.5)); p.setBrush(QColor(255, 255, 255, 14)); p.drawRoundedRect(QRectF(.75, .75, self.width()-1.5, self.H-1.5), 14, 14)
        muted = QColor('#8fa3bd'); H = self.H; x = 12
        def text(s_, px, color, bold=False, top=0, h=H, align=Qt.AlignLeft|Qt.AlignVCenter, width=None):
            p.setPen(color); p.setFont(self.font(px, bold)); w = width or p.fontMetrics().horizontalAdvance(s_)
            p.drawText(QRectF(x, top, w, h), align, s_); return w
        # saat + saniye, altında tarih yok (yer kazanmak için tarih sağ uçta)
        if self.show_time:
            x += text(now.strftime('%H:%M'), 26, Qt.white, True); x += 2
            x += text(':%02d' % now.second, 13, muted, top=4) + 12
            p.setPen(QPen(QColor('#3a5577'), 1)); p.drawLine(QPointF(x, 8), QPointF(x, H-8)); x += 12
        # ders etiketi + saat aralığı (üstte), ilerleme çubuğu (altta)
        tagc = QColor('#8a6514') if st['kind'] == 'break' else QColor('#1d4f8f') if st['kind'] in ('lesson','prep','before') else QColor('#3a5577')
        p.setFont(self.font(12, True)); tw = p.fontMetrics().horizontalAdvance(st['tag'])+14
        p.setPen(Qt.NoPen); p.setBrush(tagc); p.drawRoundedRect(QRectF(x, 5, tw, 20), 10, 10)
        p.setPen(Qt.white); p.drawText(QRectF(x, 5, tw, 20), Qt.AlignCenter, st['tag'])
        block = 190
        p.setPen(muted); p.setFont(self.font(12)); p.drawText(QRectF(x+tw+6, 5, block-tw-6, 20), Qt.AlignLeft|Qt.AlignVCenter, st['span'])
        if st['left'] is not None:
            bar = QColor('#e23b4d') if urgent else QColor('#ffc526') if st['kind'] == 'break' else QColor('#3d8bff')
            p.setPen(Qt.NoPen); p.setBrush(QColor('#26405f')); p.drawRoundedRect(QRectF(x, 30, block, 5), 2.5, 2.5)
            if st['frac'] > 0: p.setBrush(bar); p.drawRoundedRect(QRectF(x, 30, block*min(1, st['frac']), 5), 2.5, 2.5)
        x += block + 12
        if st['left'] is not None:
            l = st['left']; cd = ('%d:%02d:%02d' % (l//3600, l%3600//60, l%60)) if l >= 3600 else ('%d:%02d' % (l//60, l%60))
            color = QColor('#ff6b7a') if urgent else QColor('#ffc526') if st['kind'] == 'break' else Qt.white
            x += text(cd, 22, color, True) + 6
            label = 'zile kalan' if st['kind'] in ('lesson','prep') else 'derse kalan' if st['kind'] == 'break' else 'okula kalan'
            x += text(label, 12, muted) + 12
        # sağda: tarih (üst) ve sıradaki ders (alt)
        rest = self.width() - x - 10
        p.setPen(muted); p.setFont(self.font(12))
        if self.show_time:
            date = '%s · %d %s' % (TR_DAYS[now.weekday()], now.day, TR_MONTHS[now.month-1])
            p.drawText(QRectF(x, 3, rest, 18), Qt.AlignRight|Qt.AlignVCenter, date)
            p.drawText(QRectF(x, 21, rest, 18), Qt.AlignRight|Qt.AlignVCenter, p.fontMetrics().elidedText(st['next'], Qt.ElideRight, int(rest)))

        p.end()

def warn_chime_file(folder):
    """Dersin bitmesine 5 dk kala: yumuşak, yükselen üç notalı çan (bir kez üretilir)."""
    import wave, struct
    path = os.path.join(folder, 'ders-uyari.wav')
    if os.path.isfile(path): return path
    os.makedirs(folder, exist_ok=True)
    rate = 44100; frames = []
    notes = [(0.0, 523.25), (0.32, 659.25), (0.64, 783.99)]   # C5 → E5 → G5
    for i in range(int(rate*2.8)):
        t = i/rate; v = 0.0
        for start, f in notes:
            dt = t-start
            if dt < 0: continue
            env = min(1, dt/.012)*math.exp(-dt*2.2)
            v += env*(math.sin(2*math.pi*f*dt) + .3*math.sin(2*math.pi*2*f*dt) + .1*math.sin(2*math.pi*3*f*dt))
        frames.append(struct.pack('<h', int(max(-1, min(1, v*.22))*32767)))
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b''.join(frames))
    return path

def rapt_sound_file(folder):
    """Short paper 'rapt' (slap + soft thump), generated once."""
    import wave, struct, random
    path = os.path.join(folder, 'rapt.wav')
    if os.path.isfile(path): return path
    os.makedirs(folder, exist_ok=True); rate = 44100; rng = random.Random(3); frames = []
    for i in range(int(rate*.16)):
        t = i/rate
        v = rng.uniform(-1, 1)*math.exp(-t*55)*.55 + math.sin(2*math.pi*140*t)*math.exp(-t*30)*.6
        frames.append(struct.pack('<h', int(max(-1, min(1, v*.5))*32767)))
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b''.join(frames))
    return path

def paint_postit(p, rect, pix, color, tilt=0, shadow=True):
    """A paper note: colour, tape strip, the captured picture inside."""
    p.save(); p.translate(rect.center()); p.rotate(tilt); r = QRectF(-rect.width()/2, -rect.height()/2, rect.width(), rect.height())
    if shadow: p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 70)); p.drawRect(r.translated(4, 5))
    p.setPen(Qt.NoPen); p.setBrush(QColor(color)); p.drawRect(r)
    m = max(6, r.width()*.05); top = max(10, r.height()*.1)
    inner = QRectF(r.left()+m, r.top()+top, r.width()-2*m, r.height()-top-m)
    if pix is not None and not pix.isNull():
        s = min(inner.width()/pix.width(), inner.height()/pix.height()); w, h = pix.width()*s, pix.height()*s
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawPixmap(QRectF(inner.center().x()-w/2, inner.center().y()-h/2, w, h), pix, QRectF(pix.rect()))
    p.setBrush(QColor(255, 255, 255, 140)); tw = r.width()*.32
    p.rotate(-2); p.drawRect(QRectF(-tw/2, r.top()-6, tw, 14)); p.restore()

class PostItCard(QWidget):
    W = 300   # wide enough that a question stays readable on the board
    def __init__(self, pano, pix, color, name, tilt):
        super().__init__(pano.holder); self.pano, self.pix, self.color, self.name, self.tilt = pano, pix, color, name, tilt
        # Height follows the picture, so the whole question shows (no tiny strip).
        paper = self.W-24; m = max(6, paper*.05); inner = paper-2*m
        ratio = pix.height()/max(1, pix.width()) if pix is not None and not pix.isNull() else .6
        self.H = int(max(140, min(420, inner*ratio + max(10, (inner*ratio+30)*.1) + m + 30)))
        self.pending = False; self.setFixedSize(self.W, self.H); self.setCursor(Qt.PointingHandCursor)
        self.setToolTip('Dokunun: büyür · sağ üstteki ×: kaldırır')
    def close_rect(self): return QRectF(self.W-36, 4, 30, 30)
    def paintEvent(self, e):
        if self.pending: return
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        paint_postit(p, QRectF(10, 12, self.W-24, self.H-26), self.pix, self.color, self.tilt)
        c = self.close_rect(); p.setPen(Qt.NoPen); p.setBrush(QColor(18, 32, 52, 200)); p.drawEllipse(c)
        p.setPen(QPen(Qt.white, 2.4, Qt.SolidLine, Qt.RoundCap)); d = 7
        p.drawLine(QPointF(c.center().x()-d, c.center().y()-d), QPointF(c.center().x()+d, c.center().y()+d))
        p.drawLine(QPointF(c.center().x()+d, c.center().y()-d), QPointF(c.center().x()-d, c.center().y()+d)); p.end()
    def mouseReleaseEvent(self, e):
        if self.pending: return
        if self.close_rect().adjusted(-8, -8, 8, 8).contains(QPointF(e.pos())): self.pano.main.remove_postit(self)
        else: self.pano.main.show_postit(self)

class PostItPano(QScrollArea):
    """Post-it panosu: a narrow column right of the board."""
    TILTS = (-3, 2, -1.5, 3)
    def __init__(self, main):
        super().__init__(); self.main = main; self.cards = []
        self.setFixedWidth(PostItCard.W+18); self.setWidgetResizable(True); self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.holder = QWidget(); self.box = QVBoxLayout(self.holder); self.box.setContentsMargins(4, 6, 4, 6); self.box.setSpacing(4)
        head = QHBoxLayout(); head.setContentsMargins(4, 0, 0, 0)
        title = QLabel('Post-it panosu'); title.setStyleSheet('color:#8fa3bd;font-size:13px;'); head.addWidget(title, 1)
        hide = QPushButton('Gizle  ›'); hide.setToolTip('Panoyu gizle (post-it\'ler silinmez)'); hide.setFixedHeight(38)
        hide.setStyleSheet('QPushButton{padding:0 12px;min-height:38px;max-height:38px;font-size:14px;}')
        hide.clicked.connect(lambda: self.main.set_pano_hidden(True)); head.addWidget(hide)
        self.box.addLayout(head); self.box.addStretch(); self.setWidget(self.holder)
    def add(self, pix, color, name, pending=False):
        card = PostItCard(self, pix, color, name, self.TILTS[len(self.cards) % len(self.TILTS)]); card.pending = pending
        self.box.insertWidget(self.box.count()-1, card); self.cards.append(card); return card
    def remove(self, card):
        if card in self.cards: self.cards.remove(card)
        card.hide(); card.deleteLater()
    def clear(self):
        for c in list(self.cards): self.remove(c)

class PostItFlight(QWidget):
    """Peel off (lift and tilt), shrink, fly to the board, land."""
    def __init__(self, parent, pix, color, start, end, tilt, done):
        super().__init__(parent); self.pix, self.color, self.start, self.end, self.tilt, self.done = pix, color, QRectF(start), QRectF(end), tilt, done
        self.setAttribute(Qt.WA_TransparentForMouseEvents); self.setGeometry(parent.rect()); self.t = 0; self.show(); self.raise_()
        self.anim = QVariantAnimation(self); self.anim.setStartValue(0.0); self.anim.setEndValue(1.0); self.anim.setDuration(720)
        self.anim.valueChanged.connect(self.step); self.anim.finished.connect(self.finish); self.anim.start()
    def step(self, v): self.t = v; self.update()
    def finish(self): self.hide(); self.deleteLater(); self.done()
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); t = self.t
        if t < .3:   # peel: lift a little, tilt, paper colour comes in
            u = t/.3; r = self.start; c = r.center(); k = 1+.05*u
            rect = QRectF(c.x()-r.width()*k/2, c.y()-r.height()*k/2-10*u, r.width()*k, r.height()*k); rot = -6*u
            col = QColor(self.color); col.setAlpha(int(255*u))
            p.save(); p.translate(rect.center()); p.rotate(rot); p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, int(60*u)))
            p.drawRect(QRectF(-rect.width()/2+6, -rect.height()/2+8, rect.width(), rect.height())); p.setBrush(Qt.white)
            p.drawRect(QRectF(-rect.width()/2, -rect.height()/2, rect.width(), rect.height())); p.restore()
            paint_postit(p, rect, self.pix, col.name() if u > .5 else '#ffffff', rot, shadow=False)
        else:        # fly with a small overshoot, then land
            u = QEasingCurve(QEasingCurve.OutBack).valueForProgress((t-.3)/.7)
            s0 = self.start; s0 = QRectF(s0.center().x()-s0.width()*.525, s0.center().y()-s0.height()*.525-10, s0.width()*1.05, s0.height()*1.05)
            e = QRectF(self.end.x()+10, self.end.y()+12, self.end.width()-24, self.end.height()-26)
            lerp = lambda a, b: a+(b-a)*u
            rect = QRectF(lerp(s0.x(), e.x()), lerp(s0.y(), e.y()), max(10, lerp(s0.width(), e.width())), max(10, lerp(s0.height(), e.height())))
            paint_postit(p, rect, self.pix, self.color, lerp(-6, self.tilt))
        p.end()

class PostItBig(QWidget):
    """Tap a post-it: it opens large over the board; tap again to put it back."""
    def __init__(self, scroll, pix, color):
        super().__init__(scroll); self.pix, self.color = pix, color; vp = scroll.viewport().geometry()
        # Card sized to the picture: as large as fits, small paper margins.
        mw, mh = vp.width()*.82, vp.height()*.8
        sc = min((mw-60)/max(1, pix.width()), (mh-90)/max(1, pix.height()), 3.0)
        w = int(pix.width()*sc+60); h = int(pix.height()*sc+90)
        self.setGeometry(vp.x()+(vp.width()-w)//2, vp.y()+(vp.height()-h)//2, w, h); self.setCursor(Qt.PointingHandCursor)
        self.setToolTip('Dokunun: küçülür'); self.show(); self.raise_()
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        paint_postit(p, QRectF(14, 18, self.width()-30, self.height()-36), self.pix, self.color, 0); p.end()
    def mouseReleaseEvent(self, e): self.hide(); self.deleteLater()

class ThemePicker(QWidget):
    """Touch-sized theme chooser with live colour + pattern previews."""
    def __init__(self, main):
        super().__init__(main, Qt.Popup|Qt.FramelessWindowHint)
        self.main = main; self.setAttribute(Qt.WA_TranslucentBackground)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        panel = QWidget(); panel.setObjectName('picker'); outer.addWidget(panel)
        panel.setStyleSheet('QWidget#picker{background:#0b1426;border:1px solid #2a3b57;border-radius:18px;} QLabel{background:transparent;color:#e8eefc;}')
        layout = QVBoxLayout(panel); layout.setContentsMargins(18, 14, 18, 18); layout.setSpacing(12)
        title = QLabel('Tema seçin'); title.setStyleSheet('font-size:19px;font-weight:bold;color:#9fb3d1;'); layout.addWidget(title)
        grid = QGridLayout(); grid.setSpacing(12); layout.addLayout(grid)
        for i, key in enumerate(THEME_ORDER):
            t = THEMES[key]; tile = main.theme_tile(key)
            b = QPushButton(); b.setFixedSize(176, 118); b.setCursor(Qt.PointingHandCursor); b.setToolTip(t['name'])
            current = key == main.theme
            b.setStyleSheet('''QPushButton{border:%s;border-radius:14px;background-color:%s;background-image:url("%s");text-align:left;min-height:118px;max-height:118px;min-width:176px;max-width:176px;padding:0;}
                QPushButton:hover{border:2px solid %s;}''' % ('3px solid %s' % t['selb'] if current else '1px solid %s' % t['border'], t['view'], tile.replace('\\\\','/'), t['selb']))
            inner = QVBoxLayout(b); inner.setContentsMargins(10, 8, 10, 8); inner.addStretch()
            chip = QLabel(('✓  ' if current else '')+t['name']); chip.setWordWrap(True)
            chip.setStyleSheet('QLabel{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 %s,stop:1 %s);color:white;font-size:%dpx;font-weight:bold;border-radius:10px;padding:6px 10px;}' % (t['sel2'], t['sel'], 14 if len(t['name']) > 14 else 17))
            inner.addWidget(chip)
            b.clicked.connect(lambda checked=False, k=key: (self.main.apply_theme(k), self.close()))
            grid.addWidget(b, i//4, i % 4)

class ScreenToolbar(QWidget):
    def __init__(self, session):
        # A normal independent window stays reachable from the taskbar when
        # the main window is hidden, unlike tool windows grouped by some WMs.
        super().__init__(None,Qt.Window|Qt.WindowStaysOnTopHint)
        self.session=session;self.drag_from=None
        self.setWindowTitle('Ekrana yaz • Ümraniye Merkez Anadolu Lisesi')
        self.setWindowIcon(QIcon(LOGO))
    # Frameless panel: drag from any empty area (buttons keep their clicks).
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton:self.drag_from=e.globalPos()-self.frameGeometry().topLeft()
    def mouseMoveEvent(self,e):
        if self.drag_from is not None:self.move(e.globalPos()-self.drag_from)
    def mouseReleaseEvent(self,e):self.drag_from=None
    def moveEvent(self,e):
        super().moveEvent(e)
        if self is self.session.toolbar:self.session.update_mask()
    def resizeEvent(self,e):
        super().resizeEvent(e)
        if self is self.session.toolbar:self.session.update_mask()
    def closeEvent(self,event):
        event.ignore(); self.session.leave()

class ScreenSession:
    """Independent screen-coordinate strokes and history, retained across mode switches."""
    overlay_mode=True
    @property
    def color(self): return self._color
    @color.setter
    def color(self, value):
        self._color = value
        if hasattr(self,'tools'): paint_tool_buttons(self.tools, self.tool_labels, self.tool, value)
    def __init__(self, main):
        self.main=main
        self.doc=fitz.open(); self.doc.new_page(width=1920,height=1080)
        self.page=0; self.tool='pen'; self.color='#e8132b'; self.backdrop=None
        self.marks={};self.undo_stack=[];self.redo_stack=[];self.dirty=False
        self.toolbar=ScreenToolbar(self)
        self.active=False
        self.floating=ScreenToolbar(self)
        self.floating.setWindowFlags(Qt.Window|Qt.WindowStaysOnTopHint|Qt.CustomizeWindowHint|Qt.WindowTitleHint)
        self.floating.setWindowTitle('Serbest kalem')
        self.floating.setWindowIcon(QIcon(LOGO))
        floating_layout=QHBoxLayout(self.floating)
        write=QPushButton('Kalem');write.setIcon(tool_icon('Kalem'));write.clicked.connect(self.resume)
        back=QPushButton('Tahta');back.clicked.connect(self.leave)
        floating_layout.addWidget(write);floating_layout.addWidget(back)
        self.board=Board(self)
        self.board.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.board.setAttribute(Qt.WA_TranslucentBackground)
        self.board.setAttribute(Qt.WA_QuitOnClose,False)
        self.board.setCursor(Qt.CrossCursor)
        self.toolbar.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.toolbar.setStyleSheet('''QWidget{background:#0a203e;color:white;font-family:"DejaVu Sans";font-size:13px;}
            QWidget#panel{border:1px solid #526780;border-radius:10px;}
            QPushButton#primary{background:#c61d2d;border:1px solid #e23b4d;font-weight:bold;font-size:14px;}
            QPushButton,QSpinBox{background:#203957;border:1px solid #526780;border-radius:8px;padding:0;}
            QPushButton:checked{background:#bc1b2b;border:2px solid #e23b4d;} QPushButton:hover{background:#365575;}''')
        self.floating.setStyleSheet('''QWidget{background:#0a203e;color:white;font-family:"DejaVu Sans";font-size:14px;}
            QPushButton{background:#203957;border:1px solid #526780;border-radius:7px;padding:9px;min-height:25px;}
            QPushButton:hover{background:#365575;}''')
        # Compact vertical panel on the left: icon-only buttons in two
        # columns; names are shown as tooltips. No full-width top band.
        outer=QHBoxLayout(self.toolbar);outer.setContentsMargins(0,0,0,0);outer.setSpacing(4);outer.setAlignment(Qt.AlignTop)
        panel=QWidget();panel.setObjectName('panel');outer.addWidget(panel)
        layout=QVBoxLayout(panel);layout.setContentsMargins(8,6,8,8);layout.setSpacing(6)
        grip=QLabel('⋮⋮');grip.setAlignment(Qt.AlignCenter);grip.setToolTip('Sürükleyerek taşıyın');grip.setStyleSheet('color:#8fa3bd;font-size:15px;')
        layout.addWidget(grip)
        grid=QGridLayout();grid.setSpacing(6);layout.addLayout(grid)
        def icon_button(label):
            b=QPushButton();b.setIcon(tool_icon(label));b.setIconSize(QSize(28,28));b.setFixedSize(54,54)
            b.setToolTip(label);b.setAccessibleName(label);return b
        # Only this panel stays on screen: "Masaüstünü kullan" keeps it
        # visible (no separate floating window); Kalem returns to writing.
        to_pdf=QPushButton("PDF'ye yaz");to_pdf.setIcon(tool_icon("PDF'ye yaz"));to_pdf.setIconSize(QSize(26,26))
        to_pdf.setObjectName('primary');to_pdf.setFixedHeight(54);to_pdf.setToolTip('Ekran modunu kapatıp PDF üzerine kalemle yazın')
        to_pdf.clicked.connect(self.write_on_pdf);grid.addWidget(to_pdf,0,0,1,2)
        self.tools={};self.tool_labels={}
        for i,(key,label) in enumerate([('pen','Kalem'),('highlight','Fosforlu'),('eraser','Silgi'),('smart','Akıllı seçim')]):
            b=icon_button(label);b.setCheckable(True);b.clicked.connect(lambda checked=False,k=key:self.set_tool(k))
            grid.addWidget(b,1+i//2,i%2);self.tools[key]=b;self.tool_labels[key]=label
        self.tools['pen'].setChecked(True)
        paint_tool_buttons(self.tools,self.tool_labels,self.tool,self.color)
        for i,(label,fn) in enumerate([('Geri al',self.undo),('İleri al',self.redo),('Tümünü sil',self.clear),('Notları PDF kaydet',self.save_notes)]):
            b=icon_button(label);b.clicked.connect(lambda checked=False,fn=fn:fn());grid.addWidget(b,3+i//2,i%2)
        self.mode=icon_button('Masaüstünü kullan');self.mode.setCheckable(True)
        self.mode.toggled.connect(self.set_passthrough)
        grid.addWidget(self.mode,5,0)
        dash=icon_button('Kesikli çizgi');dash.setCheckable(True);dash.clicked.connect(lambda checked=False:self.set_tool('dash'))
        grid.addWidget(dash,5,1);self.tools['dash']=dash;self.tool_labels['dash']='Kesikli çizgi'
        area=icon_button('Alan silgisi');area.setCheckable(True);area.clicked.connect(lambda checked=False:self.set_tool('area_eraser'))
        grid.addWidget(area,6,0);self.tools['area_eraser']=area;self.tool_labels['area_eraser']='Alan silgisi'
        # Kalem stili: the button shows the current style; tap opens the
        # five choices beside the panel (inside the same window, so the
        # input hole in the ink layer covers them too).
        self.pen_style='fluid'
        self.style_button=icon_button('Kalem stili');self.style_button.setIcon(tool_icon('Akıcı'));self.style_button.setToolTip('Kalem stili: Akıcı')
        self.style_button.clicked.connect(self.toggle_styles);grid.addWidget(self.style_button,6,1)
        self.style_panel=QWidget();self.style_panel.setObjectName('panel');outer.addWidget(self.style_panel,0,Qt.AlignTop)
        styles=QVBoxLayout(self.style_panel);styles.setContentsMargins(6,6,6,6);styles.setSpacing(6)
        self.style_buttons={}
        for key,label in PEN_STYLES:
            b=QPushButton(' '+label);b.setIcon(tool_icon({'fluid':'Akıcı','laser':'Neon'}.get(key)) if key in ('fluid','laser') else style_icon(key,28));b.setIconSize(QSize(28,28));b.setFixedSize(150,48);b.setCheckable(True)
            b.setAccessibleName('Kalem stili: '+label);b.setStyleSheet('QPushButton{text-align:left;padding-left:8px;font-size:14px;}')
            b.clicked.connect(lambda checked=False,k=key:self.set_pen_style(k));styles.addWidget(b);self.style_buttons[key]=b
        self.style_buttons['fluid'].setChecked(True);self.style_panel.hide()
        self.nib=QComboBox(self.toolbar);self.nib.addItem('Yuvarlak uç','round');self.nib.hide()
        self.colors=QComboBox(self.toolbar);self.colors.hide()
        palette=[('Kırmızı','#e8132b'),('Siyah','#111111'),('Mavi','#0057ff'),('Yeşil','#00a24a'),('Sarı','#ffe14d'),('Beyaz','#ffffff'),('Mor','#8a2be2'),('Pembe','#ff2d95')]   # 4 Sarı, 5 Beyaz: used below
        for label,c in palette:self.colors.addItem(label,c)
        dots=QGridLayout();dots.setSpacing(6);layout.addLayout(dots)
        self.color_buttons=[]
        for i,(label,c) in enumerate(palette):
            b=QPushButton();b.setFixedSize(54,54);b.setCheckable(True);b.setToolTip(label);b.setAccessibleName(label)
            b.setStyleSheet('QPushButton{background:'+c+';border:2px solid #8292a8;border-radius:27px;}QPushButton:checked{border:4px solid #ffffff;}')
            b.clicked.connect(lambda checked=False,n=i:self.colors.setCurrentIndex(n))
            dots.addWidget(b,i//2,i%2);self.color_buttons.append(b)
        self.color_buttons[0].setChecked(True)
        self.colors.currentIndexChanged.connect(lambda:self.set_color(self.colors.currentData()))
        self.colors.currentIndexChanged.connect(lambda n:[b.setChecked(k==n) for k,b in enumerate(self.color_buttons)])
        # Screen backdrop: transparent (desktop visible) or a full board.
        backdrops=QHBoxLayout();backdrops.setSpacing(6);layout.addLayout(backdrops)
        self.backdrop_buttons={}
        for label,c in [('Saydam (masaüstü görünür)',None),('Beyaz tahta','#ffffff'),('Yeşil tahta','#214d38'),('Kara tahta','#121214')]:
            b=QPushButton('∅' if c is None else '');b.setFixedSize(26,26);b.setCheckable(True);b.setToolTip(label);b.setAccessibleName(label)
            b.setStyleSheet('QPushButton{background:%s;border:2px solid #8292a8;border-radius:5px;color:#b9c6d8;font-size:14px;}QPushButton:checked{border:3px solid #ffffff;}' % (c or '#0a203e'))
            b.clicked.connect(lambda checked=False,c=c:self.set_backdrop(c));backdrops.addWidget(b);self.backdrop_buttons[c]=b
        self.backdrop_buttons[None].setChecked(True)
        size=QHBoxLayout();size.setSpacing(4);layout.addLayout(size)
        self.width=QSpinBox();self.width.setRange(1,16);self.width.setValue(3);self.width.setSuffix(' pt')
        self.width.setButtonSymbols(QSpinBox.NoButtons);self.width.setAlignment(Qt.AlignCenter);self.width.setReadOnly(True);self.width.setFixedSize(46,36)
        minus=QPushButton('−');minus.setFixedSize(34,36);minus.setAccessibleName('Kalemi incelt');minus.setToolTip('Kalemi incelt');minus.clicked.connect(self.width.stepDown);size.addWidget(minus)
        size.addWidget(self.width)
        plus=QPushButton('+');plus.setFixedSize(34,36);plus.setAccessibleName('Kalemi kalınlaştır');plus.setToolTip('Kalemi kalınlaştır');plus.clicked.connect(self.width.stepUp);size.addWidget(plus)
        self.hint=QLabel('Esc: tahtaya dön');self.hint.setWordWrap(True);self.hint.setAlignment(Qt.AlignCenter)
        self.hint.setStyleSheet('color:#b9c6d8;font-size:11px;');self.hint.setFixedWidth(114);layout.addWidget(self.hint)
        for parent in (self.board,self.toolbar):
            QShortcut(QKeySequence('Escape'),parent,activated=self.leave)
            QShortcut(QKeySequence('Ctrl+Z'),parent,activated=self.undo)
            QShortcut(QKeySequence('Ctrl+Shift+Z'),parent,activated=self.redo)

    def enter(self):
        self.board.finish()
        screen=self.main.windowHandle().screen() if self.main.windowHandle() else QApplication.primaryScreen()
        geometry=screen.geometry()
        old=self.doc;self.doc=fitz.open();self.doc.new_page(width=geometry.width(),height=geometry.height());old.close()
        self.board.setGeometry(geometry);self.board.scale=1
        self.mode.setChecked(False)
        self.toolbar.adjustSize()
        self.toolbar.move(geometry.x()+12,geometry.y()+max(0,(geometry.height()-self.toolbar.height())//2))
        if not self.floating.isVisible():self.floating.move(geometry.x()+20,geometry.y()+100)
        self.floating.hide()
        self.active=True
        self.main.hide()
        # Allow the window manager to process main-window hiding BEFORE
        # displaying the independent overlay and its control window.
        QTimer.singleShot(150,self.show_windows)
    def update_mask(self):
        # Cut the panel's rectangle out of the full-screen ink layer so taps
        # there always reach the panel buttons, even if the window manager
        # raises the ink layer above the panel after a touch.
        if not hasattr(self,'board'):return
        hole=self.toolbar.frameGeometry().adjusted(-4,-4,4,4)
        hole.translate(-self.board.geometry().topLeft())
        self.board.setMask(QRegion(self.board.rect())-QRegion(hole))
    def show_windows(self):
        if not self.active:return
        self.update_mask()
        self.board.show();self.board.raise_()
        self.toolbar.showNormal();self.toolbar.raise_();self.toolbar.activateWindow()
    def write_on_pdf(self):
        self.leave();self.main.set_tool('pen')
    def leave(self):
        self.active=False
        self.board.finish()
        if self.main.tabs is None: self.main.init_tabs()   # never return to an empty board without tabs
        self.main.show();self.main.raise_();self.main.activateWindow()
        self.board.hide();self.toolbar.hide();self.floating.hide()
    def park(self):
        if not self.active:return
        self.board.finish();self.mode.setChecked(True)
        self.toolbar.hide()
        self.floating.show();self.floating.raise_()
    def resume(self):
        if not self.active:return
        self.floating.hide()
        self.set_tool('pen')
        self.board.show();self.board.raise_()
        self.toolbar.showNormal();self.toolbar.raise_();self.toolbar.activateWindow()
    def set_backdrop(self,color):
        self.backdrop=color
        for c,b in self.backdrop_buttons.items():b.setChecked(c==color)
        if color in ('#214d38','#121214') and self.color in ('#172b4d','#000000',PEN_DEFAULT):self.colors.setCurrentIndex(5)
        elif color=='#ffffff' and self.color=='#ffffff':self.colors.setCurrentIndex(1)
        self.board.update()
    def set_passthrough(self,enabled):
        if enabled and self.backdrop:self.set_backdrop(None)
        self.board.finish()
        visible=self.board.isVisible()
        self.board.setWindowFlag(Qt.WindowTransparentForInput,enabled)
        if visible:self.board.show()
        self.mode.setToolTip('Yazmaya dön' if enabled else 'Masaüstünü kullan')
        self.hint.setText('Masaüstü açık' if enabled else 'Esc: tahtaya dön')
        if visible:self.toolbar.raise_()
    def set_tool(self,tool):
        self.board.finish();self.tool=tool;self.mode.setChecked(False)
        if tool!='smart':self.board.clear_selection()
        if tool=='highlight':self.colors.setCurrentIndex(4)
        for k,b in self.tools.items():b.setChecked(k==tool)
        paint_tool_buttons(self.tools,self.tool_labels,self.tool,self.color)
    def set_color(self,color):
        self.color=color
        if self.tool not in ('pen','highlight','dash','laser'):self.set_tool('pen')
    def toggle_styles(self):
        self.style_panel.setVisible(not self.style_panel.isVisible());self.toolbar.adjustSize()
    def set_pen_style(self,key):
        name=dict(PEN_STYLES)[key]
        for k,b in self.style_buttons.items():b.setChecked(k==key)
        self.style_button.setIcon(tool_icon({'fluid':'Akıcı','laser':'Neon'}.get(key)) if key in ('fluid','laser') else style_icon(key,28));self.style_button.setToolTip('Kalem ucu: '+name)
        self.style_panel.hide();self.toolbar.adjustSize()
        if key=='laser':self.set_tool('laser');self.hint.setText('Neon kalem: birkaç saniye sonra söner');return
        self.pen_style=key
        if self.tool!='pen':self.set_tool('pen')
        self.hint.setText('Kalem ucu: '+name)
    def checkpoint(self):
        self.undo_stack.append(snapshot_marks(self.marks,self.undo_stack[-1] if self.undo_stack else None));self.undo_stack=self.undo_stack[-80:];self.redo_stack.clear()
        self.main.undo_log.append(('screen',));self.main.redo_log.clear()
    def changed(self):self.dirty=True
    def move_log(self,source,target):
        for i in range(len(source)-1,-1,-1):
            if source[i]==('screen',):del source[i];break
        target.append(('screen',))
    def undo(self,record=True):
        self.board.finish()
        self.board.clear_selection()
        if self.undo_stack:
            if record:self.move_log(self.main.undo_log,self.main.redo_log)
            self.redo_stack.append(snapshot_marks(self.marks,self.redo_stack[-1] if self.redo_stack else None));self.marks=live_marks(self.undo_stack.pop());self.changed();self.board.update()
    def redo(self,record=True):
        self.board.finish()
        self.board.clear_selection()
        if self.redo_stack:
            if record:self.move_log(self.main.redo_log,self.main.undo_log)
            self.undo_stack.append(snapshot_marks(self.marks,self.undo_stack[-1] if self.undo_stack else None));self.marks=live_marks(self.redo_stack.pop());self.changed();self.board.update()
    def clear(self):
        if self.marks.get(0) and QMessageBox.question(self.toolbar,'Ekran notları','Ekran üzerindeki yazılar temizlensin mi?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)==QMessageBox.Yes:
            self.checkpoint();self.marks={};self.changed();self.board.update()
    def save_notes(self):
        self.board.finish()
        path,_=QFileDialog.getSaveFileName(self.toolbar,'Yalnızca ekran notlarını PDF kaydet','Ekran-notlari.pdf','PDF (*.pdf)')
        if not path:return False
        if not path.lower().endswith('.pdf'):path+='.pdf'
        try:
            export_document(self.doc,self.marks,path);self.dirty=False;self.hint.setText('Ekran notları kaydedildi');return True
        except Exception as e:QMessageBox.warning(self.toolbar,'Kaydedilemedi',str(e));return False
    def confirm_close(self):
        if not self.dirty:return True
        answer=QMessageBox.question(self.main,'Ekran notları','Ekran üzerine yazdığınız notlar kaydedilsin mi? Masaüstü görüntüsü kayda dahil değildir.',QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
        if answer==QMessageBox.Save:return self.save_notes()
        return answer==QMessageBox.Discard

def install_turkish(app):
    """Turkish dialog buttons (Evet/Hayır/Kaydet/İptal/Tamam) and file dialogs."""
    from PyQt5.QtCore import QTranslator, QLibraryInfo
    class Overrides(QTranslator):
        WORDS = {'Discard': 'Kaydetme', '&Yes': '&Evet', '&No': '&Hayır', 'Yes': 'Evet', 'No': 'Hayır'}
        def translate(self, context, source, disambiguation=None, n=-1):
            return self.WORDS.get(source) if context == 'QPlatformTheme' else None   # None = use qtbase_tr
    base = QTranslator(app)
    for folder in (os.path.dirname(os.path.abspath(__file__)), QLibraryInfo.location(QLibraryInfo.TranslationsPath)):
        if base.load('qtbase_tr', folder): app.installTranslator(base); break
    app._tr_override = Overrides(app); app.installTranslator(app._tr_override)

def main():
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    # Keep every pen/touch sample (Qt merges fast moves by default, which
    # turns curves into visible corners on interactive boards).
    QApplication.setAttribute(Qt.AA_CompressHighFrequencyEvents, False)
    if hasattr(Qt,'AA_CompressTabletEvents'): QApplication.setAttribute(Qt.AA_CompressTabletEvents, False)
    app = QApplication(sys.argv); app.setApplicationName(PRODUCT)
    install_turkish(app)
    data_dir=os.path.join(QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation),'umal-tahta')
    os.makedirs(data_dir,mode=0o700,exist_ok=True)
    lock=QLockFile(os.path.join(data_dir,'uygulama.lock'));lock.setStaleLockTime(0)
    if not lock.tryLock(3000 if '--yeniden' in sys.argv else 100):
        if '--bekci' in sys.argv: return
        QMessageBox.information(None,PRODUCT,'Uygulama zaten açık. Görev çubuğundaki pencereye dönün; serbest kalem için Ekrana yaz düğmesini kullanın.');return
    app.umal_lock = lock   # yeniden başlatmada bırakılır
    window = Window(); window.show()
    if os.path.isfile('/usr/lib/umal-tahta/umal-bekci'): QProcess.startDetached('/usr/lib/umal-tahta/umal-bekci', [])   # sınav saatlerinde uygulama kapanırsa yeniden açar (tek kopya)
    handling_error=[False]
    def report_error(kind,value,tb):
        if handling_error[0]:return
        handling_error[0]=True
        try:
            import traceback
            import datetime
            with open(os.path.join(data_dir,'hata-kaydi.txt'),'a',encoding='utf-8') as f:
                f.write('### %s\n' % datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')); traceback.print_exception(kind,value,tb,file=f)
            if window.screen_session:window.screen_session.leave()
            window.show();window.raise_()
            QMessageBox.warning(window,'İşlem tamamlanamadı','Bir hata oluştu. Çalışmanızı PDF kaydet ile kaydedebilirsiniz. Hata kaydı cihazda tutuldu.\n'+str(value))
        finally:handling_error[0]=False
    sys.excepthook=report_error
    # Açılış kaydı: who started the app and how (to find unwanted start-ups).
    try:
        with open('/proc/uptime') as f: uptime = float(f.read().split()[0])
    except (OSError, ValueError): uptime = 9999
    try:
        with open('/proc/%d/comm' % os.getppid()) as f: parent = f.read().strip()
    except OSError: parent = '?'
    try:
        import datetime
        with open(os.path.join(data_dir,'acilis-kaydi.txt'),'a',encoding='utf-8') as f:
            f.write('%s  açılıştan %d sn sonra  başlatan=%s  ayar=%s\n' % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), uptime, parent, ' '.join(sys.argv[1:]) or '-'))
    except OSError: pass
    # Uygulama nasıl başlatılırsa başlatılsın (açılış kaydı, "Serbest Kalem" kısayolu, tahtanın tuşu)
    # her zaman PDF'ye yaz ekranıyla açılır; Ekrana yaz yalnızca paneldeki düğmeyle açılır.
    if '--serbest-kalem' in sys.argv: QTimer.singleShot(0,window.init_tabs)
    elif len(sys.argv) > 1 and not sys.argv[1].startswith('--'):
        try:
            doc = fitz.open(sys.argv[1])
            if doc.needs_pass or not doc.page_count: raise ValueError('Bu dosyayı PDF aç düğmesiyle açın.')
            window.init_tabs(restore=False)
            same=next((t for t in window.tabs if t.get('source') and os.path.realpath(t['source'])==os.path.realpath(sys.argv[1])),None)
            if same: doc.close(); window.switch_tab(same['id'])
            else:
                window.start_tab(os.path.splitext(os.path.basename(sys.argv[1]))[0],sys.argv[1])
                window.replace(doc,sys.argv[1]);window.tabs_changed()
        except Exception as e: QMessageBox.warning(window,'PDF açılamadı',str(e))
    else:QTimer.singleShot(0,window.init_tabs)
    window.start_state_reports(); window.start_messages(); QTimer.singleShot(6000, window.ask_class)
    if '--yeniden' not in sys.argv:   # her açılışta: tam ekran, açılış logosu, ardından karşılama kartı
        def open_full():   # önce öğretmenin seçimi, sonra logo ve seçilen ekran
            window.showFullScreen(); QTimer.singleShot(100, window.fit_page); QTimer.singleShot(150, window.show_welcome)
        QTimer.singleShot(300, open_full)
    if '--yeniden' in sys.argv: QTimer.singleShot(50, window.resume_after_restart)   # yönetim: durum bildirimi, tahtanın sınıfı (bir kez)
    sys.exit(app.exec_())

if __name__ == '__main__': main()
